<template>
  <router-view />
</template>

<script>
import { defineComponent } from 'vue';
import { useQuasar, useMeta } from 'quasar';
const metaData = {
  // sets document title
  meta: {
    // lang: 'ko-KR',
    description: {
      name: 'description',
      content: "모두의 가능성을 실현하는 '세상에서 가장 큰 학교' 대교입니다.",
    },
    keywords: {
      name: 'keywords',
      content: '세상에서 가장 큰 학교, 대교닷컴',
    },
    // keywords: {
    //   name: 'keywords',
    //   content: '세상에서 가장 큰 학교, 대교닷컴',
    // },
    // keywords: { name: 'keywords', content: 'Quasar website' },
    equiv: {
      'http-equiv': 'Content-Type',
      content: 'text/html; charset=UTF-8',
    },
    // note: for Open Graph type metadata you will need to use SSR, to ensure page is rendered by the server
    ogTitle: {
      property: 'og:title',
      // optional; similar to titleTemplate, but allows templating with other meta properties
      template(ogTitle) {
        return `${ogTitle} | 대교`;
      },
    },
    ogTitle: {
      property: 'og:description',
      // optional; similar to titleTemplate, but allows templating with other meta properties
      template(description) {
        return `${description} "모두의 가능성을 실현하는 '세상에서 가장 큰 학교' 대교입니다."`;
      },
    },
  },
  title: '루트페이지',
  titleTemplate: (title) => `${title} - 대교 드림스`,
  // meta tags

  // CSS tags
  // link: {
  //   material: {
  //     rel: 'stylesheet',
  //     href: 'https://fonts.googleapis.com/icon?family=Material+Icons',
  //   },
  // },

  // JS tags

  // <html> attributes
  htmlAttr: {
    'xmlns:cc': 'http://creativecommons.org/ns#', // generates <html xmlns:cc="http://creativecommons.org/ns#">,
    empty: undefined, // generates <html empty>
  },

  // <body> attributes
  bodyAttr: {
    'action-scope': 'xyz', // generates <body action-scope="xyz">
    empty: undefined, // generates <body empty>
  },

  // <noscript> tags
  noscript: {
    default: 'This is content for browsers with no JS (or disabled JS)',
  },
};
export default defineComponent({
  name: 'App',
  methods: {},
  setup() {
    const $q = useQuasar();
    // 커스텀 아이콘
    // $q.iconMapFn = (iconName) => {
    //   if (iconName.startsWith('app:') === true) {
    //     // we strip the "app:" part
    //     const name = iconName.substring(4);

    //     return {
    //       cls: 'mos' + name,
    //     };
    //   }
    // };
    $q.screen.setSizes({ sm: 10, md: 767, lg: 1025, xl: 200000 });
    useMeta(metaData);
    return {
      metaData,
    };
  },
});
</script>
