<template>
  <q-dialog
    :modelValue="props.memberModal"
    class="mob_dimm"
    transition-show="fade"
    transition-hide="fade"
    persistent
  >
    <div class="box_member_list">
      <div class="sec_header">
        <h3 class="title3 text-grey-2">회원이동</h3>
        <q-btn unelevated class="size_xs" @click="memberModalClose">
          <q-icon name="icon-close" class="icon_svg" size="16px"></q-icon>
        </q-btn>
      </div>
      <div class="sec_body">
        <q-carousel
          v-model="slide"
          ref="carousel"
          transition-prev="slide-right"
          transition-next="slide-left"
          animated
          swipeable
          arrows
        >
          <q-carousel-slide name="1">
            <ul class="member_list">
              <li class="active">
                <q-btn
                  unelevated
                  align="left"
                  label="김윤찬"
                  class="title3 text-grey-3"
                >
                  <q-icon name="icon-check" class="icon_svg"></q-icon>
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
            </ul>
          </q-carousel-slide>
          <q-carousel-slide name="2">
            <ul class="member_list">
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="김윤찬"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
            </ul>
          </q-carousel-slide>
          <q-carousel-slide name="3">
            <ul class="member_list">
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="김윤찬"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
            </ul>
          </q-carousel-slide>
          <q-carousel-slide name="4">
            <ul class="member_list">
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="김윤찬"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="홍길동"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
              <li>
                <q-btn
                  unelevated
                  align="left"
                  label="임지은"
                  class="title3 text-grey-3"
                >
                </q-btn>
              </li>
            </ul>
          </q-carousel-slide>
        </q-carousel>

        <div class="btn_area">
          <div class="body2 text-grey-3">
            <q-icon name="icon-guide" class="icon_svg filter-grey-3"></q-icon>
            다른 요일의 회원이동
          </div>
          <div>
            <q-btn
              outline
              class="btn_circle32"
              @click="$refs.carousel.previous()"
              :class="slide.valueOf() === '1' ? 'disabled' : ''"
            >
              <q-icon name="icon-arrow-left" class="icon_svg"></q-icon>
            </q-btn>
            <!-- 마지막 slide 갯수 페이지는 4 - 개발필요! -->
            <q-btn
              outline
              class="btn_circle32"
              @click="$refs.carousel.next()"
              :class="slide.valueOf() === '4' ? 'disabled' : ''"
            >
              <q-icon name="icon-arrow-right" class="icon_svg"></q-icon>
            </q-btn>
          </div>
        </div>
      </div>
    </div>
  </q-dialog>
</template>
<script setup>
import { ref, defineProps, defineEmits } from 'vue';

const slide = ref('1');
const props = defineProps({
  memberModal: Boolean,
});
const emit = defineEmits(['changeModalState']);

function memberModalClose() {
  emit('changeModalState');
}
</script>
<style>
.mob_dimm {
  .q-dialog__backdrop {
    display: none;
  }
}
.screen--md,
.screen--sm {
  .mob_dimm {
    .q-dialog__backdrop {
      display: block;
    }
  }
}
</style>
<style lang="scss" scoped>
@import '../../../css/list_c.scss';
.disabled {
  opacity: 0.2 !important;
  pointer-events: none;
}
</style>
