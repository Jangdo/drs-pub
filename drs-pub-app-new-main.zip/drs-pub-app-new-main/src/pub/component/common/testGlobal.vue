<template>
  testGlobal component
</template>
