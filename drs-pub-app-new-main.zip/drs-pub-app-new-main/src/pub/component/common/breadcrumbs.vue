<template>
  <q-breadcrumbs
    active-color="grey-3"
    class="location mb0"
    v-if="$q.screen.name == 'lg'"
  >
    <template v-slot:separator>
      <q-icon size="1.5em" name="chevron_right" />
    </template>
    <q-breadcrumbs-el label="HOME" to="/" />
    <q-breadcrumbs-el label="1 depth" to="/pub/list_c" />
    <q-breadcrumbs-el label="2 depth" to="/pub/list_d" />
    <q-breadcrumbs-el label="3 depth" to="/pub/admin" />
    <q-breadcrumbs-el label="4 depth" to="/pub/list_g" />
    <q-breadcrumbs-el :label="$route.name" class="active" />
  </q-breadcrumbs>
</template>
<script setup></script>
<style lang="scss" scoped>
@import '../../../css/list_c.scss';
</style>
