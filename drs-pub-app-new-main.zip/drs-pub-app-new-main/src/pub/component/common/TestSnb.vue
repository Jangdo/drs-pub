<template>
  <h3 class="my25">Test link</h3>
  <q-btn-group class="column_2 w100p mb24">
    <q-btn label="헤더 메인 관리자" to="header_main" target="_blank" />
    <q-btn label="헤더 서브 선생님" to="header_sub" target="_blank" />
    <q-btn label="TEST" to="/pub/test" target="_blank" />
    <q-btn label="testpjs" to="/pub/testpjs" target="_blank" />
    <q-btn label="공통검색" to="/pub/common_search_new" target="_blank" />
    <q-btn label="Masonry" to="/pub/masonry" target="_blank" />
    <q-btn label="Table" to="/pub/table" target="_blank" />
    <q-btn label="drag" to="/pub/drag" target="_blank" />
    <q-btn label="tree" to="/pub/tree" target="_blank" />
    <q-btn label="carousel" to="/pub/carousel" target="_blank" />
    <q-btn label="calender" to="/pub/calender" target="_blank" />
    <q-btn label="scheduler" to="/pub/scheduler" target="_blank" />
    <q-btn label="lottie" to="/pub/lottie" target="_blank" />
    <q-btn label="highchart" to="/pub/highchart" target="_blank" />
    <q-btn label="sample" to="/sample" target="_blank" />
    <q-btn label="member" to="/pub/testmemberjoin" target="_blank" />
  </q-btn-group>
</template>
