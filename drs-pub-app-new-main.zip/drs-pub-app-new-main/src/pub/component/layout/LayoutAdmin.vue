<template>
  <q-layout class="layout_responsive layout_admin">
    <q-header class="pc_header">
      <router-link to="/pub/"><h1 class="logo">DAEKYO Dreams</h1></router-link>
      <div class="infor_area">
        <div class="alert_area">
          <q-btn flat dense unelevated :ripple="false">
            <q-icon class="notification" />
          </q-btn>
        </div>
        <div class="user_area">
          <div class="pic_area">
            <!-- <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" /> -->
          </div>
          <div class="txt_area">
            <span class="name">{{ userInofor.name }}님</span>
            <span class="info">
              <span>{{ userInofor.branch }}</span>
              <span>{{ userInofor.team }}</span>
            </span>
          </div>
        </div>
        <div class="btn_area">
          <q-btn fill unelevated color="grey-4"> 로그아웃 </q-btn>
        </div>
      </div>
    </q-header>
    <q-page-container>
      <div class="wrap_gnb_pc manager">
        <transition name="sl_0">
          <div class="gnb_depth1">
            <!-- depth1 리스트 -->
            <q-list class="menu_main">
              <q-item
                v-for="(item, index) in routesList"
                :key="index"
                :class="[item.active ? 'on' : '']"
                ><q-btn
                  flat
                  @click="toggleDrawer(index)"
                  :class="item.ico"
                  icon=""
                  >{{ item.title }}</q-btn
                >
              </q-item>
            </q-list>
            <!--// depth1 리스트 -->
          </div>
        </transition>
        <!-- gnb_depth2 -->
        <q-drawer
          class="gnb_depth2"
          v-model="leftDrawerOpen"
          side="left"
          overlay
          behavior="mobile"
        >
          <q-btn
            flat
            dense
            fill
            unelevated
            icon="ion-ios-arrow-back"
            @click="leftDrawerOpen = false"
            class="btn_menu_contract"
          ></q-btn>
          <q-list v-for="(item, index) in reoutesDepth" :key="index">
            <!-- depth3 expansion-->
            <q-expansion-item
              v-if="item.children"
              expand-separator
              :label="item.title"
              :class="[item.active ? 'on' : '']"
              default-opened
            >
              <div
                class="menu_link type_btn"
                v-for="(itemDepth1, idx2) in item.children"
                :key="idx2"
              >
                <q-btn
                  v-if="itemDepth1.path"
                  :class="[itemDepth1.active ? 'on' : '']"
                  flat
                  :to="`${item.path}/${itemDepth1.path}`"
                >
                  {{ itemDepth1.title }}</q-btn
                >
                <span v-else>{{ itemDepth1.title }} </span>
              </div>
            </q-expansion-item>
            <!--// depth3 expansion-->
            <!-- depth2 -->
            <div class="menu_link type_other" v-else>
              <router-link :to="item.path">{{ item.title }}</router-link>
            </div>
            <!--// depth2 -->
          </q-list>
        </q-drawer>
        <!--// gnb_depth2 -->
      </div>
      <div class="inner_pc_only">
        <router-view />
      </div>
    </q-page-container>
  </q-layout>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useQuasar, useMeta } from 'quasar';
import { useRoute } from 'vue-router';
const metaData = {};
const $q = useQuasar();
const route = useRoute();
$q.screen.setSizes({ sm: 10, md: 11, lg: 12, xl: 200000 });
onMounted(() => {
  metaData.title = route.name;
  metaData.bodyAttr = { id: 'pcOnly' };
  metaData.htmlAttr = { id: user.value };
  useMeta(metaData);
  setTimeout(() => {
    $q.loading.hide();
  }, 800);
});
const header = ref(route.matched[1].props.default.headerType);
const user = ref(route.matched[1].props.default.userType);
console.log(header, user);
// alert count
// const alertCount = ref(12);
//userInofor
const userInofor = ref({
  name: '김대교(12345678)',
  branch: '경기병점',
  team: '뜨란채센터1팀',
});
// gnb 리스트
const routesList = [
  {
    title: '홈',
    ico: 'home',
    active: true,
    children: [
      {
        title: 'Depth2-1',
        active: true,
        path: '',
        children: [
          {
            title: '펍가이드',
            path: 'pub',
            active: true,
          },
          {
            title: 'A전체메뉴',
            path: 'pub/list_a',
          },
          {
            title: 'B상담',
            path: 'pub/list_b',
          },
          {
            title: 'C수업',
            path: 'pub/list_c',
          },
          {
            title: 'D회원',
            path: 'pub/list_d',
          },
          {
            title: 'E마이',
            path: 'pub/list_e',
          },
          {
            title: 'F커뮤니티',
            path: 'pub/list_F',
          },
          {
            title: 'G조직관리',
            path: 'pub/list_g',
          },
          {
            title: 'H공통관리',
            path: 'pub/admin',
          },
        ],
      },
      {
        title: 'Depth2-1',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '수업',
    ico: 'study',
  },
  {
    title: '회원',
    ico: 'person_heart',
  },
  {
    title: '상담',
    ico: 'chat',
  },
  {
    title: '실적',
    ico: 'performance',
  },
  {
    title: '조직',
    ico: 'group',
    children: [
      {
        title: '교육국관리',
        children: [
          {
            path: '/pub-page/',
            title: '기본정보',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: '관할구역',
          },
          {
            path: '/pub-page/tree',
            title: '영수증관리_현금영수증',
          },
        ],
      },
      {
        title: '채널관리',
        path: '/pub-page/test',
      },
      {
        title: '구성원관리',
        path: '/pub-page/test',
      },
      {
        title: '자재신청관리',
        path: '/pub-page/test',
      },
      {
        title: '영업활동',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '입금',
    ico: 'coin',
  },
  {
    title: '진도',
    ico: 'clipboard',
  },
  {
    title: '커뮤니티',
    ico: 'community',
  },
  {
    title: '검색',
    ico: 'search',
  },
  {
    title: '마이페이지',
    ico: 'me',
  },
  {
    title: '공통',
    ico: 'layers',
  },
  // {
  //   title: '회원등록',
  //   ico: 'user_add',
  // },
  // {
  //   title: '회원관리',
  //   ico: 'user_check',
  // },
  {
    title: '바로가기',
    ico: 'external-link',
  },
];
// deph2 ~리스트
const reoutesDepth = ref();
reoutesDepth.value = routesList[0].children;
// gnb 리스트를 클릭시 그 index 값을 받아 그에 따른 depth의 children 값을 Drawer에 랜더링
function toggleDrawer(index) {
  reoutesDepth.value = routesList[index].children;
  leftDrawerOpen.value = true;
}
// deph2 ~ 리스트  Drawer 상태
const leftDrawerOpen = ref(false);

// 상당 토글 버튼 Drawer 상태변경
// function toggleLeftDrawer() {
//   leftDrawerOpen.value = !leftDrawerOpen.value;
// }

// m_gnb
// const mGnbDialog = ref(false);
</script>
<style lang="scss">
@import 'src/assets/sass/admin/admin.scss';
@import 'src/assets/sass/responsive/responsive.scss';
</style>
