<template>
  <!-- manager 어드민일때 teacher 선생님일때 클래스 변경 -->
  <q-layout class="layout_responsive">
    <q-header class="pc_header" v-if="$q.screen.name == 'lg'">
      <router-link to="/pub/"><h1 class="logo">DAEKYO Dreams</h1></router-link>
      <div class="infor_area">
        <div class="alert_area">
          <q-btn flat dense unelevated :ripple="false">
            <q-icon class="notification" />
          </q-btn>
        </div>
        <div class="user_area">
          <div class="pic_area">
            <!-- 사용자이미지 -->
            <!-- <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" /> -->
          </div>
          <div class="txt_area">
            <span class="name">{{ userInofor.name }}님</span>
            <span class="info">
              <span>{{ userInofor.branch }}</span>
              <span>{{ userInofor.team }}</span>
            </span>
          </div>
        </div>
        <div class="btn_area">
          <q-btn fill unelevated color="grey-4"> 로그아웃 </q-btn>
        </div>
      </div>
    </q-header>

    <!-- m_header -->
    <div
      class="m_header"
      :class="header"
      v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
    >
      <!-- router에서 props userType main 메인화면 헤더 -->
      <q-btn
        to="/home"
        flat
        :ripple="false"
        class="btn_logo"
        v-if="header == 'main'"
      >
        <h1 class="logo_head">DAEKYO Dreams</h1>
      </q-btn>
      <!--  router에서 props userType sub일때 서브화면 헤더 -->
      <div v-if="header == 'sub'" class="tit_area">
        <q-btn
          @click="$router.go(-1)"
          flat
          :ripple="false"
          class="btn_back"
          icon=""
        >
        </q-btn>
        <h3 class="tit_header">프로필카드</h3>
      </div>
      <div class="alert_area">
        <q-btn flat dense unelevated :ripple="false" rounded class="btn_noti">
          <q-icon class="notification" />
        </q-btn>
      </div>
    </div>
    <!--// m_header -->
    <!-- container -->
    <q-page-container>
      <!-- pc 고정 gnb -->
      <div class="wrap_gnb_pc" v-if="$q.screen.name == 'lg'" :class="user">
        <transition name="sl_0">
          <div class="gnb_depth1">
            <q-list class="menu_main">
              <q-item
                v-for="(item, index) in routesList"
                :key="index"
                :class="[item.active ? 'on' : '']"
                ><q-btn
                  flat
                  @click="toggleDrawer(index)"
                  :class="item.ico"
                  icon=""
                  >{{ item.title }}</q-btn
                >
              </q-item>
            </q-list>
          </div>
        </transition>
        <q-drawer
          class="gnb_depth2"
          v-model="leftDrawerOpen"
          side="left"
          overlay
          behavior="mobile"
        >
          <q-btn
            flat
            dense
            fill
            unelevated
            icon="ion-ios-arrow-back"
            @click="leftDrawerOpen = false"
            class="btn_menu_contract"
          ></q-btn>
          <q-list v-for="(item, index) in reoutesDepth" :key="index">
            <q-expansion-item
              v-if="item.children"
              expand-separator
              :label="item.title"
              :class="[item.active ? 'on' : '']"
              default-opened
            >
              <div
                class="menu_link type_btn"
                v-for="(itemDepth1, idx2) in item.children"
                :key="idx2"
              >
                <q-btn
                  v-if="itemDepth1.path"
                  :class="[itemDepth1.active ? 'on' : '']"
                  flat
                  :to="`${item.path}/${itemDepth1.path}`"
                  >{{ itemDepth1.title }}</q-btn
                >
                <span v-else>{{ itemDepth1.title }} </span>
              </div>
            </q-expansion-item>
            <q-item v-else>
              <div class="menu_link">
                <!-- <router-link :to="item.path">{{ item.title }}</router-link> -->
                <!-- menu color => class="on" -->
                <q-btn flat :to="item.path">{{ item.title }}</q-btn>
              </div>
            </q-item>
          </q-list>
        </q-drawer>
      </div>

      <div class="inner_dreams">
        <!-- <q-breadcrumbs
          active-color="grey-3"
          class="location"
          v-if="$q.screen.name == 'lg'"
        >
          <template v-slot:separator>
            <q-icon size="1.5em" name="chevron_right" />
          </template>
          <q-breadcrumbs-el label="HOME" to="/" />
          <q-breadcrumbs-el label="1 depth" to="/pub/list_c" />
          <q-breadcrumbs-el label="2 depth" to="/pub/list_d" />
          <q-breadcrumbs-el label="3 depth" to="/pub/admin" />
          <q-breadcrumbs-el label="4 depth" to="/pub/list_g" />
          <q-breadcrumbs-el :label="$route.name" class="active" />
        </q-breadcrumbs> -->
        <router-view />
      </div>

      <!-- 퀵메뉴 열고 닫힘 -->
      <div class="wrap_quick_menu" v-if="false">
        <q-btn
          class="size_big btn_quick_open"
          @click="quickOpen = true"
          v-show="quickOpen == false"
          stack
          fill
          unelevated
          icon=""
          :color="[user == 'manager' ? 'primary' : 'positive']"
          label="바로가기"
        />
        <q-btn
          class="size_big btn_quick_close"
          @click="quickOpen = false"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          :color="[user == 'manager' ? 'primary' : 'positive']"
          label="닫기"
        />
        <q-btn
          class="size_big btn_quick_edit"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="편집"
        />
        <q-btn
          class="size_big btn_quick_lms"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="lms"
        />
        <q-btn
          class="size_big btn_quick_attendance"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="출결"
        />
        <q-btn
          class="size_big btn_quick_content"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="콘텐츠"
        />
      </div>
    </q-page-container>
    <!--// container -->
    <!-- m_toolbar -->
    <div
      class="m_toolbar"
      v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
    >
      <ul class="inner_box">
        <li class="on">
          <q-btn
            icon=""
            class="btn_m_home new"
            flat
            square
            stack
            label="홈"
          ></q-btn>
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_consulting new"
            flat
            square
            stack
            label="상담"
          ></q-btn>
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_lesson new"
            flat
            square
            stack
            label="수업"
          ></q-btn>
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_search"
            flat
            square
            stack
            label="검색"
          ></q-btn>
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_menu"
            flat
            stack
            label="메뉴"
            @click="mGnbDialog = true"
          ></q-btn>
        </li>
      </ul>
      <!-- m_gnb_dialog -->
      <q-dialog
        class="m_gnb_dialog"
        v-model="mGnbDialog"
        maximized
        position="right"
      >
        <q-card>
          <div class="gnb_header">
            <h3 class="intro">전체메뉴</h3>
            <div class="infor_area">
              <div class="alert_area">
                <q-btn
                  flat
                  dense
                  unelevated
                  :ripple="false"
                  rounded
                  class="btn_noti"
                >
                  <q-icon class="notification">
                    <!-- <span class="number_alarm">{{ alertCount }}</span> -->
                  </q-icon>
                </q-btn>
              </div>
              <q-btn
                flat
                dense
                icon=""
                @click="mGnbDialog = false"
                class="gnb_close"
              />
            </div>
          </div>
          <div class="infor_header">
            <div class="user_area">
              <div class="user">
                <div class="pic_area">
                  <!-- <img
                    src="https://drs-imaged.daekyo.co.kr/images/avatar.png"
                  /> -->
                </div>
                <div class="txt_area">
                  <span class="name">{{ userInofor.name }}</span>
                  <span class="info">
                    <span>{{ userInofor.branch }}</span>
                    <span>{{ userInofor.team }}</span>
                  </span>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn fill unelevated color="grey-4" class="btn_logout"
                >로그아웃</q-btn
              >
            </div>
          </div>
          <div class="m_gnb_list">
            <div class="depth1">
              <q-list class="menu_main">
                <q-item
                  v-for="(item, index) in routesList"
                  :key="index"
                  :class="[item.active ? 'on' : '']"
                  ><q-btn
                    flat
                    stack
                    square
                    @click="toggleDrawer(index)"
                    :class="item.ico"
                    icon=""
                    >{{ item.title }}</q-btn
                  >
                </q-item>
              </q-list>
            </div>

            <div class="depth2">
              <q-list v-for="(item, index) in reoutesDepth" :key="index">
                <q-expansion-item
                  v-if="item.children"
                  expand-separator
                  :label="item.title"
                  :class="[item.active ? 'on' : '']"
                  default-opened
                >
                  <div
                    class="menu_link type_btn"
                    v-for="(itemDepth1, idx2) in item.children"
                    :key="idx2"
                  >
                    <q-btn
                      v-if="itemDepth1.path"
                      flat
                      :to="`${item.path}/${itemDepth1.path}`"
                      :class="[itemDepth1.active ? 'on' : '']"
                      >{{ itemDepth1.title }}</q-btn
                    >
                    <span v-else>{{ itemDepth1.title }} </span>
                  </div>
                </q-expansion-item>
                <q-item v-else>
                  <div class="menu_link">
                    <!-- <router-link :to="item.path">{{ item.title }}</router-link> -->
                    <!-- menu color => class="on" -->
                    <q-btn flat :to="item.path">{{ item.title }}</q-btn>
                  </div>
                </q-item>
              </q-list>
            </div>
          </div>
        </q-card>
      </q-dialog>
      <!--// m_gnb_dialog -->
    </div>
    <!--// m_toolbar -->
  </q-layout>
  <!-- teacher 초록색, Manager  파란색  -->
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useQuasar, useMeta } from 'quasar';
import { RouterLink, useRoute } from 'vue-router';
const metaData = {};
const $q = useQuasar();
const route = useRoute();
$q.screen.setSizes({ sm: 10, md: 767, lg: 1025, xl: 200000 });
const header = ref(route.matched[1].props.default.headerType);
const user = ref(route.matched[1].props.default.userType);
onMounted(() => {
  metaData.title = route.name;
  metaData.htmlAttr = { id: user.value };
  useMeta(metaData);
  setTimeout(() => {
    $q.loading.hide();
  }, 800);
});

// console.log(header, user);
// const alertCount = ref(12);
//userInofor
const userInofor = ref({
  name: '김대교(12345678)',
  branch: '경기병점',
  team: '뜨란채센터1팀',
});

// gnb 리스트
const routesList = [
  {
    title: '홈',
    ico: 'home',
    active: true,
    children: [
      {
        title: 'Depth2-1',
        active: true,
        path: '',
        children: [
          {
            title: '펍가이드',
            path: 'pub',
            active: true,
          },
          {
            title: 'A전체메뉴',
            path: 'pub/list_a',
          },
          {
            title: 'B상담',
            path: 'pub/list_b',
          },
          {
            title: 'C수업',
            path: 'pub/list_c',
          },
          {
            title: 'D회원',
            path: 'pub/list_d',
          },
          {
            title: 'E마이',
            path: 'pub/list_e',
          },
          {
            title: 'F커뮤니티',
            path: 'pub/list_F',
          },
          {
            title: 'G조직관리',
            path: 'pub/list_g',
          },
          {
            title: 'H공통관리',
            path: 'pub/admin',
          },
        ],
      },
      {
        title: 'Depth2-1',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '수업',
    ico: 'study',
  },
  {
    title: '회원',
    ico: 'person_heart',
  },
  {
    title: '상담',
    ico: 'chat',
  },
  {
    title: '실적',
    ico: 'performance',
  },
  {
    title: '조직',
    ico: 'group',
    children: [
      {
        title: '교육국관리',
        children: [
          {
            path: '/pub-page/',
            title: '기본정보',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: '관할구역',
          },
          {
            path: '/pub-page/tree',
            title: '영수증관리_현금영수증',
          },
        ],
      },
      {
        title: '채널관리',
        path: '/pub-page/test',
      },
      {
        title: '구성원관리',
        path: '/pub-page/test',
      },
      {
        title: '자재신청관리',
        path: '/pub-page/test',
      },
      {
        title: '영업활동',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '입금',
    ico: 'coin',
  },
  {
    title: '진도',
    ico: 'clipboard',
  },
  {
    title: '커뮤니티',
    ico: 'community',
  },
  {
    title: '검색',
    ico: 'search',
  },
  {
    title: '마이페이지',
    ico: 'me',
  },
  {
    title: '공통',
    ico: 'layers',
  },
  // {
  //   title: '회원등록',
  //   ico: 'user_add',
  // },
  // {
  //   title: '회원관리',
  //   ico: 'user_check',
  // },
  {
    title: '바로가기',
    ico: 'external-link',
  },
];
// deph2 ~리스트
const reoutesDepth = ref();
reoutesDepth.value = routesList[0].children;
// gnb 리스트를 클릭시 그 index 값을 받아 그에 따른 depth의 children 값을 Drawer에 랜더링
function toggleDrawer(index) {
  reoutesDepth.value = routesList[index].children;
  leftDrawerOpen.value = true;
}
// deph2 ~ 리스트  Drawer 상태
const leftDrawerOpen = ref(false);

// 상당 토글 버튼 Drawer 상태변경
// function toggleLeftDrawer() {
//   leftDrawerOpen.value = !leftDrawerOpen.value;
// }

// m_gnb
const mGnbDialog = ref(false);

// 퀵메뉴
const quickOpen = ref(false);
</script>

<style lang="scss">
@import 'src/assets/sass/responsive/responsive.scss';
</style>
