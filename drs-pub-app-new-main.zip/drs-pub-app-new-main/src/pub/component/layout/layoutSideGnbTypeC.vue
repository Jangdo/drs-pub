<template>
  <q-layout :class="user" class="layout_responsive">
    <!-- 퀵메뉴 배경 -->
    <div class="quick_dimed" v-show="quickOpen == true"></div>
    <!-- manager 어드민일때 teacher 선생님일때 클래스 변경 -->
    <!-- pc 고정 gnb -->
    <div class="wrap_gnb_pc" v-if="$q.screen.name == 'lg'" :class="user">
      <transition name="sl_0">
        <div class="gnb_depth1">
          <!-- depth1 리스트 -->
          <q-list class="menu_main">
            <q-item
              v-for="(item, index) in routesList"
              :key="index"
              :class="[item.active ? 'on' : '']"
              ><q-btn
                flat
                @click="toggleDrawer(index)"
                :class="item.ico"
                icon=""
                >{{ item.title }}</q-btn
              >
            </q-item>
          </q-list>
          <!--// depth1 리스트 -->
          <q-separator></q-separator>
          <!-- depth1 리스트 하위 하드코딩 아이템 -->
          <q-list class="menu_member">
            <q-item>
              <q-btn flat class="user_add" icon="">회원등록</q-btn>
            </q-item>
            <q-item>
              <q-btn flat class="user_check" icon="">임시 회원관리</q-btn>
            </q-item>
            <!-- <q-item clickable v-ripple >
              <q-item-section avatar>
                <q-icon name="home" />
              </q-item-section>
              <q-item-section>회원등록</q-item-section>
            </q-item>
            <q-item clickable v-ripple >
              <q-item-section avatar>
                <q-icon name="home" />
              </q-item-section>
              <q-item-section>임시 회원관리</q-item-section>
            </q-item> -->
          </q-list>
          <!-- depth1 리스트 하위 하드코딩 아이템 -->
        </div>
      </transition>
      <!-- gnb_depth2 -->
      <q-drawer
        class="gnb_depth2"
        v-model="leftDrawerOpen"
        side="left"
        overlay
        behavior="mobile"
      >
        <q-btn
          flat
          dense
          fill
          unelevated
          icon="ion-ios-arrow-back"
          @click="leftDrawerOpen = false"
          class="btn_menu_contract"
        ></q-btn>
        <q-list v-for="(item, index) in reoutesDepth" :key="index">
          <!-- depth3 expansion-->

          <!-- depth2 on -->
          <q-expansion-item
            v-if="item.children"
            expand-separator
            :label="item.title"
            :class="[item.active ? 'on' : '']"
            default-opened
          >
            <div
              class="menu_link type_btn"
              v-for="(itemDepth1, idx2) in item.children"
              :key="idx2"
            >
              <!-- depth3 on -->
              <q-btn
                v-if="itemDepth1.path"
                :class="[itemDepth1.active ? 'on' : '']"
                flat
                :to="`${item.path}/${itemDepth1.path}`"
                >{{ itemDepth1.title }}</q-btn
              >
              <span v-else>{{ itemDepth1.title }} </span>
            </div>
          </q-expansion-item>
          <!--// depth3 expansion-->
          <!-- depth2 -->
          <div class="menu_link type_other" v-else>
            <router-link :to="item.path">{{ item.title }}</router-link>
          </div>
          <!--// depth2 -->
        </q-list>
      </q-drawer>
      <!--// gnb_depth2 -->
    </div>
    <!--// pc 고정 gnb -->

    <!--pc_header -->
    <q-header class="pc_header" v-if="$q.screen.name == 'lg'">
      <q-btn to="/" flat :ripple="false" dense class="btn_logo"
        ><h2 class="logo_head">DAEKYO Dreams</h2></q-btn
      >
      <div class="infor_area">
        <div class="alert_area">
          <q-btn flat dense unelevated :ripple="false" rounded class="btn_noti">
            <q-icon class="notification">
              <span class="number_alarm">{{ alertCount }}</span>
            </q-icon>
          </q-btn>
        </div>
        <div class="user_area">
          <div class="user">
            <div class="pic_area">
              <img src="https://cdn.quasar.dev/img/avatar.png" />
            </div>
            <div class="txt_area">
              <span class="name"> {{ userInofor.name }}님</span>
              <span class="info"
                >{{ userInofor.branch }}ㅣ{{ userInofor.team }}</span
              >
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn fill unelevated color="grey-4" class="btn_logout"
            >로그아웃</q-btn
          >
        </div>
      </div>
    </q-header>
    <!--//pc_header -->
    <!-- m_header -->
    <div
      class="m_header"
      :class="header"
      v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
    >
      <!-- router에서 props userType main 메인화면 헤더 -->
      <q-btn
        to="/home"
        flat
        :ripple="false"
        class="btn_logo"
        v-if="header == 'main'"
        ><h2 class="logo_head">DAEKYO Dreams</h2></q-btn
      >
      <!--  router에서 props userType sub일때 서브화면 헤더 -->
      <div v-if="header == 'sub'" class="tit_area">
        <q-btn
          @click="$router.go(-1)"
          flat
          :ripple="false"
          class="btn_back"
          icon=""
        >
        </q-btn>
        <h3 class="tit_header flex items-center">
          프로필카드
          <!-- .. c01040101인 경우만 버튼 노출 -->
          <q-btn
            v-show="memberModalCall"
            flat
            class="size_xxs no_line ml10"
            :ripple="false"
            @click="openState = !openState"
          >
            <q-icon
              name="icon-chevron_down"
              class="icon_svg filter-white"
              size="22px"
            />
          </q-btn>
        </h3>
      </div>

      <div class="alert_area">
        <q-btn flat dense unelevated :ripple="false" rounded class="btn_noti">
          <q-icon class="notification">
            <span class="number_alarm">{{ alertCount }}</span>
          </q-icon>
        </q-btn>
      </div>
    </div>
    <!--// m_header -->
    <!-- m_toolbar -->
    <div
      class="m_toolbar"
      v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
    >
      <ul class="inner_box">
        <li class="on">
          <q-btn
            icon=""
            class="btn_m_home new"
            flat
            square
            stack
            label="홈"
          ></q-btn>
          <!-- <p class="txt">홈</p> -->
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_consulting new"
            flat
            square
            stack
            label="상담"
          ></q-btn>
          <!-- <p class="txt">상담</p> -->
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_lesson new"
            flat
            square
            stack
            label="수업"
          ></q-btn>
          <!-- <p class="txt">수업</p> -->
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_search"
            flat
            square
            stack
            label="검색"
          ></q-btn>
          <!-- <p class="txt">검색</p> -->
        </li>
        <li>
          <q-btn
            icon=""
            class="btn_m_menu"
            flat
            stack
            label="메뉴"
            @click="mGnbDialog = true"
          ></q-btn>
          <!-- <p class="txt">메뉴</p> -->
        </li>
      </ul>
      <!-- m_gnb_dialog -->
      <q-dialog
        class="m_gnb_dialog"
        v-model="mGnbDialog"
        maximized
        position="right"
      >
        <q-card>
          <div class="gnb_header">
            <h3 class="intro">전체메뉴</h3>
            <div class="infor_area">
              <div class="alert_area">
                <q-btn
                  flat
                  dense
                  unelevated
                  :ripple="false"
                  rounded
                  class="btn_noti"
                >
                  <q-icon class="notification">
                    <span class="number_alarm">{{ alertCount }}</span>
                  </q-icon>
                </q-btn>
              </div>
              <q-btn
                flat
                dense
                icon=""
                @click="mGnbDialog = false"
                class="gnb_close"
              />
            </div>
          </div>
          <div class="infor_header">
            <div class="user_area">
              <div class="user">
                <div class="pic_area">
                  <img src="https://cdn.quasar.dev/img/avatar.png" />
                </div>
                <div class="txt_area">
                  <span class="name">{{ userInofor.name }}</span>
                  <span class="info"
                    >{{ userInofor.branch }}ㅣ{{ userInofor.team }}</span
                  >
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn fill unelevated color="grey-4" class="btn_logout"
                >로그아웃</q-btn
              >
            </div>
          </div>
          <div class="m_gnb_list" :class="user">
            <div class="depth1">
              <!-- depth1 리스트 -->
              <q-list class="menu_main">
                <q-item
                  color="primary"
                  v-for="(item, index) in routesList"
                  :key="index"
                  :class="[item.active ? 'on' : '']"
                  ><q-btn
                    flat
                    stack
                    square
                    @click="toggleDrawer(index)"
                    :class="item.ico"
                    icon=""
                    >{{ item.title }}</q-btn
                  >
                </q-item>
              </q-list>
              <!--// depth1 리스트-->
              <!-- depth1 리스트 하위 하드코딩 아이템 -->
              <q-list class="menu_member">
                <q-item>
                  <q-btn flat stack square class="user_add" icon=""
                    >회원등록</q-btn
                  >
                </q-item>
                <q-item class="on">
                  <q-btn flat stack square class="user_check" icon=""
                    >임시 회원관리</q-btn
                  >
                </q-item>
                <!-- <q-item clickable v-ripple >
                  <q-item-section avatar>
                    <q-icon name="ion-ios-leaf" />
                  </q-item-section>
                  <q-item-section>회원등록</q-item-section>
                </q-item>
                <q-item clickable v-ripple >
                  <q-item-section avatar>
                    <q-icon name="ion-ios-leaf" />
                  </q-item-section>
                  <q-item-section>임시 회원관리</q-item-section>
                </q-item> -->
              </q-list>
              <!-- depth1 리스트 하위 하드코딩 아이템-->
            </div>

            <div class="depth2">
              <q-list v-for="(item, index) in reoutesDepth" :key="index">
                <!-- depth3  expansion-->
                <!-- depth2 on -->
                <q-expansion-item
                  v-if="item.children"
                  expand-separator
                  :label="item.title"
                  :class="[item.active ? 'on' : '']"
                  default-opened
                >
                  <div
                    class="menu_link type_btn"
                    v-for="(itemDepth1, idx2) in item.children"
                    :key="idx2"
                  >
                    <!-- depth3 on -->

                    <q-btn
                      v-if="itemDepth1.path"
                      flat
                      :to="`${item.path}/${itemDepth1.path}`"
                      :class="[itemDepth1.active ? 'on' : '']"
                      >{{ itemDepth1.title }}</q-btn
                    >
                    <span v-else>{{ itemDepth1.title }} </span>
                  </div>
                </q-expansion-item>
                <!--// depth3 expansion-->
                <!-- depth2 -->
                <div class="menu_link type_other" v-else>
                  <router-link :to="item.path">{{ item.title }}</router-link>
                </div>
                <!--// depth2 -->
              </q-list>
            </div>
          </div></q-card
        >
      </q-dialog>
      <!--// m_gnb_dialog -->
    </div>
    <!--// m_toolbar -->

    <!-- container -->
    <q-page-container>
      <div class="inner_dreams">
        <!-- breadcrumbs -->
        <q-breadcrumbs
          active-color="grey-3"
          class="location"
          v-if="$q.screen.name == 'lg'"
        >
          <template v-slot:separator>
            <q-icon size="1.5em" name="chevron_right" />
          </template>
          <q-breadcrumbs-el label="HOME" to="/" />
          <q-breadcrumbs-el label="1 depth" to="/pub/list_c" />
          <q-breadcrumbs-el label="2 depth" to="/pub/list_d" />
          <q-breadcrumbs-el label="3 depth" to="/pub/admin" />
          <q-breadcrumbs-el label="4 depth" to="/pub/list_g" />
          <q-breadcrumbs-el label="5 depth" to="" class="active" />
        </q-breadcrumbs>
        <!--// breadcrumbs -->
        <!-- // .. c01040101 모달 -->
        <router-view :memberModal="openState" @changeModal="changeModal" />
      </div>

      <!-- 퀵메뉴 열고 닫힘 -->
      <div class="wrap_quick_menu" v-if="header == 'main'">
        <q-btn
          class="size_big btn_quick_open"
          @click="quickOpen = true"
          v-show="quickOpen == false"
          stack
          fill
          unelevated
          icon=""
          :color="[user == 'manager' ? 'primary' : 'positive']"
          label="바로가기"
        />
        <q-btn
          class="size_big btn_quick_close"
          @click="quickOpen = false"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          :color="[user == 'manager' ? 'primary' : 'positive']"
          label="닫기"
        />
        <q-btn
          class="size_big btn_quick_edit"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="편집"
        />
        <q-btn
          class="size_big btn_quick_lms"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="lms"
        />
        <q-btn
          class="size_big btn_quick_attendance"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="출결"
        />
        <q-btn
          class="size_big btn_quick_content"
          v-show="quickOpen == true"
          stack
          fill
          unelevated
          icon=""
          color="black"
          label="콘텐츠"
        />
      </div>
    </q-page-container>
    <!--// container -->
  </q-layout>
  <!-- teacher 초록색, Manager  파란색  -->
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useQuasar, useMeta } from 'quasar';
import { useRoute } from 'vue-router';

const metaData = {};
const $q = useQuasar();
const route = useRoute();
$q.screen.setSizes({ sm: 10, md: 767, lg: 1025, xl: 200000 });
const header = ref(route.matched[1].props.default.headerType);
const user = ref(route.matched[1].props.default.userType);

// 임시.. c01040101인 경우만 버튼 노출
const routerPath = ref(route.path);
const routerPathArr = routerPath.value.split('/');
const memberModalCall = ref(false);
const openState = ref(false);
function changeModal() {
  openState.value = false;
}

onMounted(() => {
  metaData.title = route.name;
  metaData.htmlAttr = { id: user.value };

  useMeta(metaData);
  setTimeout(() => {
    $q.loading.hide();
  }, 800);
  // 임시.. c01040101인 경우만 버튼 노출
  if (routerPathArr[2] == 'c01040101') {
    memberModalCall.value = true;
  }
});

console.log(header, user);
// alert count
const alertCount = ref(12);
//userInofor
const userInofor = ref({
  name: '김대교(12345678)',
  branch: '경기병점',
  team: '뜨란채센터1팀',
});

// gnb 리스트
const routesList = [
  {
    title: '홈',
    ico: 'home',
    active: true,
    children: [
      {
        title: 'Depth2-1',
        active: true,
        path: '',
        children: [
          {
            title: '펍가이드',
            path: 'pub',
            active: true,
          },
          {
            title: 'A전체메뉴',
            path: 'pub/list_a',
          },
          {
            title: 'B상담',
            path: 'pub/list_b',
          },
          {
            title: 'C수업',
            path: 'pub/list_c',
          },
          {
            title: 'D회원',
            path: 'pub/list_d',
          },
          {
            title: 'E마이',
            path: 'pub/list_e',
          },
          {
            title: 'F커뮤니티',
            path: 'pub/list_F',
          },
          {
            title: 'G조직관리',
            path: 'pub/list_g',
          },
          {
            title: 'H공통관리',
            path: 'pub/admin',
          },
        ],
      },
      {
        title: 'Depth2-1',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '상담',
    ico: 'chat',
  },
  {
    title: '수업',
    ico: 'study',
  },
  {
    title: '검색',
    ico: 'search',
  },
  {
    title: '조직관리',
    ico: 'group',
    children: [
      {
        title: '교육국관리',
        children: [
          {
            path: '/pub-page/',
            title: '기본정보',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: '관할구역',
          },
          {
            path: '/pub-page/tree',
            title: '영수증관리_현금영수증',
          },
        ],
      },
      {
        title: '채널관리',
        path: '/pub-page/test',
      },
      {
        title: '구성원관리',
        path: '/pub-page/test',
      },
      {
        title: '자재신청관리',
        path: '/pub-page/test',
      },
      {
        title: '영업활동',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: '공통관리',
    ico: 'layers',
  },
  {
    title: '커뮤니티',
    ico: 'community',
  },
  {
    title: '마이',
    ico: 'me',
  },
  {
    title: '외부링크',
    ico: 'external-link',
  },
];
// deph2 ~리스트
const reoutesDepth = ref();
reoutesDepth.value = routesList[0].children;
// gnb 리스트를 클릭시 그 index 값을 받아 그에 따른 depth의 children 값을 Drawer에 랜더링
function toggleDrawer(index) {
  reoutesDepth.value = routesList[index].children;
  leftDrawerOpen.value = true;
}
// deph2 ~ 리스트  Drawer 상태
const leftDrawerOpen = ref(false);

// 상당 토글 버튼 Drawer 상태변경
// function toggleLeftDrawer() {
//   leftDrawerOpen.value = !leftDrawerOpen.value;
// }

// m_gnb
const mGnbDialog = ref(false);

// 퀵메뉴
const quickOpen = ref(false);
</script>

<style lang="scss">
@import 'src/assets/sass/responsive/responsive.scss';
</style>
