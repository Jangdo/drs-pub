<template>
  <header class="header">
    <div class="title_area">
      <h1>Admin List</h1>
      <h3 class="text-body1 made">아이캔 매니지먼트aaa</h3>
    </div>
    <div class="link_box" v-if="$q.screen.name == 'lg'">
      <router-link
        v-for="(item, index) in iaLinkData"
        :key="index"
        :to="item.link"
      >
        {{ item.txt }}{{ item.index }}{{ item.index }}
      </router-link>
    </div>
    <q-btn
      color="primary"
      fab
      :icon="item_menu == true ? 'close' : 'menu'"
      v-else
      ref="target"
    >
      <q-menu transition-show="fade" transition-hide="fade" v-model="item_menu">
        <q-list style="min-width: 100px">
          <q-item
            clickable
            v-close-popup
            v-for="(item, index) in iaLinkData"
            :key="index"
          >
            <router-link :to="item.link"> {{ item.txt }}</router-link>
          </q-item>
        </q-list>
      </q-menu>
    </q-btn>
  </header>
</template>
<script setup>
import { ref, } from 'vue';
import { useQuasar } from 'quasar';
const item_menu = ref(false);
const iaLinkData = ref([
  {
    txt: '퍼블리싱 가이드',
    link: '/pub/',
  },

  {
    txt: '공통',
    link: '/pub-admin',
  },

]);
const $q = useQuasar();
</script>
<style lang="scss">
.snb {
  background: #fff;
}

</style>
