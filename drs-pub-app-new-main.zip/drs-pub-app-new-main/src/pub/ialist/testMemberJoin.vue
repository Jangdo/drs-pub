<template>
  <div class="q-py-md q-gutter-sm">
    <q-breadcrumbs class="mb10">
      <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
      <q-breadcrumbs-el :label=$route.name />
    </q-breadcrumbs>
  </div>

  <!-- 신규회원 -->
  <div class="q-py-md member-join">
    <q-btn label="Reset" push color="white" text-color="primary" @click="reset" class="q-mb-md" />

    <q-stepper
      v-model="step"
      header-nav
      ref="stepper"
      color="primary"
      animated
    >
      <q-step
        :name="1"
        title="step1"
        caption="기본 정보"
        :done="done1"
      >

        <div class="user-name">
          <p class="inout-title required">이름</p>
          <q-input
          outlined
          v-model="studentName"
          label="입력하세요"
          lazy-rules dense
          :rules="[ val => val && val.length > 0 || '필수입력입니다.']"
          />
        </div>

        <div class="birth">
          <p class="inout-title required">생년월일</p>
          <q-input outlined v-model="date" mask="date" :rules="['date']" dense>
            <template v-slot:prepend>
              <q-icon name="event" class="cursor-pointer">
                <q-popup-proxy @before-show="updateProxy" cover transition-show="scale" transition-hide="scale">
                  <q-date v-model="proxyDate" minimal>
                    <div class="row items-center justify-end q-gutter-sm">
                      <q-btn label="Cancel" color="primary" flat v-close-popup />
                      <q-btn label="OK" color="primary" flat @click="save" v-close-popup />
                    </div>
                  </q-date>
                </q-popup-proxy>
              </q-icon>
            </template>
          </q-input>
        </div>

        <div class="gender">
          <p class="inout-title required">성별</p>
          <q-btn-toggle
            v-model="gender"
            spread
            toggle-color="primary"
            text-color="primary"
            :options="[
              {label: '남', value: '남'},
              {label: '여', value: '여'}
            ]"
          />
        </div>

        <div class="grade">
          <p class="inout-title required">학년</p>
          <q-select outlined label="선택하세요" v-model="gradeSelect" :options="grade" dense
          lazy-rules
          :rules="[ val => val && val.length > 0 || '선택해 주세요.']"
          ></q-select>
        </div>

        <div class="phone">
          <p class="inout-title">휴대전화</p>
          <q-input
          outlined
          v-model="phone"
          label="- 없이 숫자만 입력"
          dense
          :bottom-slots="true"
          />
        </div>

        <div class="address">
          <p class="inout-title required">주소</p>
          <q-input outlined label="입력하세요" v-model="address" dense :bottom-slots="true" @click="zipCode = true">
            <template v-slot:prepend>
              <q-icon name="search" />
            </template>

            <q-dialog v-model="zipCode">
              <q-card>
                <q-card-section class="q-pt-none text-body1">
                  주소검색
                </q-card-section>
                <q-card-actions align="center">
                  <q-btn unelevated label="확인" color="primary" v-close-popup />
                </q-card-actions>
              </q-card>
            </q-dialog>

          </q-input>
        </div>

        <q-stepper-navigation>
          <q-btn @click="() => { done1 = true; step = 2 }" color="primary" label="Continue" />
        </q-stepper-navigation>
      </q-step>

      <q-step
        :name="2"
        title="step2"
        caption="보호자 정보"
        :done="done2"
      >
        <div class="user-name">
          <p class="inout-title required">이름</p>
          <q-input
          outlined
          v-model="parentName"
          label="입력하세요"
          lazy-rules dense
          :rules="[ val => val && val.length > 0 || '필수입력입니다.']"
          />
        </div>

        <div class="relationship">
          <p class="inout-title required">관계</p>
          <q-select outlined label="선택하세요" v-model="relationship" :options="relationshipSelect" dense
            lazy-rules
            :rules="[ val => val && val.length > 0 || '선택해 주세요.']"
          ></q-select>
        </div>

        <div class="phone">
          <p class="inout-title required">연락처</p>
          <q-input
          outlined
          v-model="parentphone"
          label="- 없이 숫자만 입력"
          dense
          :bottom-slots="true"
          />
        </div>

        <div class="certification">
          <p class="inout-title">인증방법</p>
          <p>pass앱이나 네이버 간편인증</p>
        </div>

        <q-stepper-navigation>
          <q-btn @click="() => { done2 = true; step = 3 }" color="primary" label="Continue" />
          <q-btn flat @click="step = 1" color="primary" label="Back" class="q-ml-sm" />
        </q-stepper-navigation>
      </q-step>

      <q-step
        :name="3"
        title="step3"
        caption="회원정보확인"
        :done="done3"
      >
        <p>회원정보 보여짐</p>
        <p>이름 : {{ name }}</p>
        <p>생년월일 : {{ date }}</p>
        <p>성별 : {{ gender }}</p>
        <p>{{ done1 }}</p>
        <p>{{ done2 }}</p>
        <p>{{ done3 }}</p>

        <q-stepper-navigation>
          <q-btn color="primary" label="Finish" @click="done3 = true" />
          <q-btn flat @click="step = 2" color="primary" label="Back" class="q-ml-sm" />
        </q-stepper-navigation>

        <q-dialog v-model="done3">
          <q-card>
            <q-card-section>
              <div class="text-h3" align="center">가입완료</div>
            </q-card-section>

            <q-card-section class="q-pt-none text-body1">
              회원가입이 완료되었습니까<br>

              <q-btn color="primary" label="팝업2" @click="popup2 = true" />
              <q-dialog v-model="popup2">
                <q-card>
                  <q-card-section>
                    <div class="text-h3" align="center">제목2222</div>
                  </q-card-section>

                  <q-card-section class="q-pt-none text-body1">
                    내용222
                  </q-card-section>

                  <q-card-actions align="center">
                    <q-btn unelevated label="아니요" color="deep-orange" v-close-popup />
                    <q-btn unelevated label="네" color="primary" v-close-popup />
                  </q-card-actions>
                </q-card>
              </q-dialog>

            </q-card-section>

            <q-card-actions align="center">
              <q-btn unelevated label="아니요" color="deep-orange" v-close-popup />
              <q-btn unelevated label="네" color="primary" v-close-popup />
            </q-card-actions>
          </q-card>
        </q-dialog>

      </q-step>
    </q-stepper>
  </div>
  <!-- //신규회원 -->

</template>
<script setup>
// import { useQuasar } from 'quasar'
import { ref } from 'vue'

// const $q = useQuasar()
const step = ref(1)
const done1 = ref(false)
const done2 = ref(false)
const done3 = ref(false)
const popup2 = ref(null)
const studentName = ref(null)
const date = ref('2012/01/01')
const proxyDate = ref('2012/01/01')
const gender = ref('남')
const grade = ref(['유아', '초등1', '초등2', '초등3', '초등4', '초등5', '초등6', '중등1', '중등2', '중등3', '고등1', '고등2', '고등3'])
const gradeSelect = ref(null)
const phone = ref(null)
const address = ref(null)
const zipCode = ref(null)
const parentName = ref(null)
const relationship = ref(null)
const relationshipSelect = ref(['엄마', '아빠'])
const parentphone = ref(null)
// const joinFinish = ref(null)

function reset () {
  done1.value = false
  done2.value = false
  done3.value = false
  step.value = 1
}

function updateProxy () {
  proxyDate.value = date.value
}

function save () {
  date.value = proxyDate.value
}

// function joinFinish () {
//   $q.dialog({
//     title: 'Alert',
//     message: 'Some message'
//   }).onOk(() => {
//     // console.log('OK')
//   }).onCancel(() => {
//     // console.log('Cancel')
//   }).onDismiss(() => {
//     // console.log('I am triggered on both OK and Cancel')
//   })
// }

// function onSubmit () {
//   if (done1.value !== true) {
//     $q.notify({
//       color: 'red-5',
//       textColor: 'white',
//       icon: 'warning',
//       message: 'You need to fill empty field'
//     })
//   }
//   else {
//     $q.notify({
//       color: 'green-4',
//       textColor: 'white',
//       icon: 'cloud_done',
//       message: 'Submitted'
//     })
//   }
// }
</script>

<style>
.q-tab{
  white-space: unset !important;
}
.sup{
  vertical-align: super !important;
  font-size: 0.8125em !important;
}
.q-item__section--main{
  position: relative;
}
.q-item__label--caption{
  position: absolute;
  right: 0;
}

.member-join .inout-title{
  display: block;
  margin-bottom: 10px;
  font-size: 17px;
  font-weight: normal;
}
.member-join .gender{
  padding-bottom: 15px;
}
p.required{
  padding-left: 7px;
}
p.required::before{
  position: relative;
  content: "*";
  color: #ff0000;
  font-size: 0.9em;
  padding-right: 3px;
}
</style>
