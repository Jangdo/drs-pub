<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- <div class="time_area">09:00</div> -->
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list1"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <div class="time_area">09:00</div>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list2"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <div class="time_area">09:00</div>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list3"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <div class="time_area">09:00</div>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list4"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list5"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list6"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <div class="time_area">09:00</div>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list7"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <div class="time_area">09:00</div>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list8"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <draggable
      class="list-group"
      handle=".tit_area"
      :list="list9"
      group="people"
      @change="log"
      itemKey="name"
      @end="onEnd"
    >
      <template #item="{ element }">
        <section>
          <div class="profile_area">
            <div class="tit_area">
              <button dense flat class="tit text-h3" @click="log">
                {{ element.name }}
                <span class="add_txt text-body1">{{ element.grade }}</span>
              </button>
            </div>
          </div>
        </section>
      </template>
    </draggable>
    <!-- //section_pay -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
import draggable from 'vuedraggable';
// const slide = ref('attendance');
// const time = ref([
//   '09:00',
//   '10:00',
//   '11:00',
//   '12:00',
//   '13:00',
//   '14:00',
//   '15:00',
//   '16:00',
//   '17:00',
// ]);

const list1 = ref([
  {
    name: '김윤찬',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '2이름',
    grade: '초등2',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '3이름',
    grade: '초등3',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list2 = ref([
  {
    name: '4이름',
    grade: '초등4',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list3 = ref([
  {
    name: '5이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list4 = ref([
  {
    name: '6이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list5 = ref([
  {
    name: '7이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list6 = ref([
  {
    name: '8이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list7 = ref([
  {
    name: '9이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list8 = ref([
  {
    name: '10이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);
const list9 = ref([
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: false,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
  {
    name: '11이름',
    grade: '초등1',
    newMember: true,
    birth: true,
    care: true,
    parents: true,
    memo: true,
    call: true,
  },
]);

function log(evt) {
  window.console.log(evt);
}
function onEnd() {
  console.log();
}
</script>
<style lang="scss" scoped></style>
<style lang="scss">
.list-group {
  padding-left: 10px;
  position: relative;
}

.list-group:after {
  display: block;
  content: '';
  height: 140%;
  position: absolute;
  border: 1px solid #aaa;
  left: 0;
  top: -6px;
}

.time_area {
  font-size: 15px;
  font-weight: bold;
  color: #03a9f4;
  position: relative;
  padding: 4px 10px;
}

.time_area:before {
  display: block;
  content: '';
  position: absolute;
  width: 10px;
  height: 10px;
  background: green;
  border-radius: 10px;
  left: -4px;
  top: 7px;
}
</style>
