<template>
  <div class="wrap_ia_list">
    <q-table
      title="Admin 가이드 230508 이후"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub-admin/` + props.row.name.toLowerCase()">
              /pub-admin/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
    <q-table
      title="Admin 가이드 230508 이전"
      :rows="rows_old"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub-admin/` + props.row.name.toLowerCase()">
              /pub-admin/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td key="Infor" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:350px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:180px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  //
  {
    name: 'H0601010102',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 게시판_화면구성',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 참고하세요',
  },
  {
    name: 'H06010303P',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 게시판_화면구성',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H060503P',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 팝업관리*미리보기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'H0601010105',
    name2: '(F0601010105)',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 게시물조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 버튼 컬러 수정, 테이블',
  },
  {
    name: 'H02010102P',
    Depth2: '권한관리',
    Depth3: '사용자정보관리 - 일괄등록[사용자]',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H02010103P',
    Depth2: '권한관리',
    Depth3: '사용자정보관리 - 일괄등록[조직]',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H02010104P',
    Depth2: '권한관리',
    Depth3: '사용자정보관리 - 사용자정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  {
    name: 'H02010305P',
    Depth2: '권한관리',
    Depth3: '사용자정보관리 - 채점교사 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'H02010306P',
    Depth2: '권한관리',
    Depth3: '사용자정보관리 - 채점교사 수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  {
    name: 'H0601010103P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 단일코드 코드 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H0601010104P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 멀티코드 코드 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H0601010106P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 신고하기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H06010201T',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 조회 -기본정보 상세 조회',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'H06010202T',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 조회 -컬럼설정 상세조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'H0601030102P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 등록수정 -게시판-기본정보*카테고리설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H0601030103P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 등록수정 -게시판-기본정보*권한설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H0601030104P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 등록수정 -게시판-기본정보*담당자지정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  {
    name: 'H06010304P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 등록수정  - 양식지정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'H060504P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 팝업관리 - 팝업게시물 검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 하단 버튼',
  },
  {
    name: 'H060603P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 말머리관리 - 말머리 폴더*등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H060702P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 신고게시물관리 - 게시물 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼 삭제',
  },
  {
    name: 'H060703P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 신고게시물관리 - 신고게시물 보기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'H060804P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 컬럼속성관리- 노드정보\_등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하던 버튼 수정',
  },

  //
  {
    name: 'H061101',
    Depth2: '게시판메뉴관리',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러, 수정테이블',
  },
  // {
  //   name: 'H061102',
  //   Depth2: '게시판메뉴관리',
  //   Depth3: '게시판등록',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  // {
  //   name: 'H061103',
  //   Depth2: '게시판메뉴관리',
  //   Depth3: '게시판 폴더명_등록/수정',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'H060501',
    Depth2: '게시판관리',
    Depth3: '팝업관리-목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'H060502',
    Depth2: '게시판관리',
    Depth3: '팝업관리-등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오, 하단 버튼',
  },
  {
    name: 'H060502_pop',
    Depth2: '게시판관리',
    Depth3: '팝업관리-등록/수정_pop',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 하단 버튼',
  },
  {
    name: 'h010902_pop',
    Depth2: '공통관리',
    Depth3: '캘린더관리-일정상세_pop',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'H060503',
    Depth2: '게시판관리',
    Depth3: '팝업관리-미리보기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'H060601',
    Depth2: '게시판관리',
    Depth3: '말머리관리-목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 수정',
  },

  {
    name: 'H060602',
    Depth2: '게시판관리',
    Depth3: '말머리관리-등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H060701',
    Depth2: '게시판관리',
    Depth3: '신고게시물관리-목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러 수정',
  },
  {
    name: 'H06090201',
    Depth2: '게시판관리',
    Depth3: '테이블 관리 -목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러 수정',
  },
  {
    name: 'H06090202',
    name2: '(H05020202)',
    Depth2: '게시판관리',
    Depth3: '테이블 관리 -등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 테이블, 하단 버튼',
  },

  {
    name: 'H06090203',
    name2: '(H060203, h05020203)',
    Depth2: '게시판관리',
    Depth3: '테이블 관리 -상세조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 테이블',
  },
  {
    name: 'H020602T',
    Depth2: '그룹별권한관리',
    Depth3: '조직',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'H02060201P',
    Depth2: '그룹별권한관리',
    Depth3: '권한변경-조직 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 하단 버튼, 테이블',
  },
  {
    name: 'H02060202P',
    Depth2: '그룹별권한관리',
    Depth3: '권한이력-조직',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 하단버튼 삭제, 테이블',
  },

  {
    name: 'H0204010101P',
    Depth2: '권한그룹관리',
    Depth3: '권한그룹등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },
  {
    name: 'H020403P',
    Depth2: '그룹별권한관리',
    Depth3: '조직설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H030301T',
    name2: '(H030302T,H030303T)',
    Depth2: '그룹별 사용자 관리',
    Depth3: '권한 설정이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  //
  {
    name: 'H020701',
    Depth2: '권한관리',
    Depth3: '겸직로그인관리*목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러 수정',
  },
  {
    name: 'H020702',
    Depth2: '권한관리',
    Depth3: '겸지골그인관리*등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H060801T',
    name2: '(H060802T,H060803T)',
    Depth2: '권한관리',
    Depth3: '컬럼속성관리*게시판신고유형',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 수정',
  },

  {
    name: 'H061001',
    Depth2: '권한관리',
    Depth3: '게시물 목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러 수정, 테이블',
  },
  {
    name: 'H061102P',
    Depth2: '공통게시판 설정',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H061103P_pop',
    Depth2: '공통수정팝업',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼 수정',
  },

  {
    name: 'H02060102P',
    Depth2: '권한관리',
    Depth3: '그룹별권한관리 - 권한이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },

  {
    name: 'H0505',
    Depth2: '회원데이터',
    Depth3: '회원데이터 출력 조회 및 폐기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'H060101',
    Depth2: '게시판',
    Depth3: ' 게시판 관리_new',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러 수정, 테이블',
  },
  {
    name: 'H0601010101',
    Depth2: '게시판',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러 수정',
  },
  {
    name: 'H06010301T',
    Depth2: '공지사항',
    Depth3: '기본정보_등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'H0601030101P',
    Depth2: '게시판',
    Depth3: '기본정보_말머리설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },

  {
    name: 'H011202',
    Depth2: '공지사항',
    Depth3: '공지사항_등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오, 하단 버튼',
  },

  {
    name: 'H011201',
    Depth2: '공지사항',
    Depth3: '공지사항_목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
]);

const rows_old = ref([
  {
    name: 'H010101T',
    Depth2: '공통코드관리',
    Depth3: '상위코드/하위코드',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 토글, 체크박스, 버튼 컬러',
  },
  // {
  //   name: 'H01010101T',
  //   Depth2: '공통코드관리',
  //   Depth3: '코드 검색 (단건 선택 반환)',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  // {
  //   name: 'H01010102T',
  //   Depth2: '공통코드관리',
  //   Depth3: '코드 검색 (다건 선택 반환)',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  {
    name: 'H0105',
    Depth2: '시스템메시지관리',
    Depth3: '공통코드관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'H010501P',
    name2: '(H05020102P)',
    Depth2: '공통코드관리',
    Depth3: '메시지 등록 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'H010502P',
    Depth2: '공통코드관리',
    Depth3: '메시지 등록 카테고리 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  // 공통관리

  {
    name: 'H01120201P',
    Depth2: '공통관리',
    Depth3: '팝업공지등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  // {
  //   name: 'H0108_1',
  //   Depth2: '공통관리',
  //   Depth3: '우편번호관리_1',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  // {
  //   name: 'H0108_2',
  //   Depth2: '공통관리',
  //   Depth3: '우편번호관리_2',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  //
  {
    name: 'H011301T',
    Depth2: '공통관리',
    Depth3: '메시지(탬플릿)관리 - 문자패턴관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러 수정',
  },
  {
    name: 'H011302T',
    Depth2: '공통관리',
    Depth3: '메시지(탬플릿)관리 -방문시간 안내 멘트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 수정',
  },
  {
    name: 'H01130102P',
    Depth2: '공통관리',
    Depth3: '메시지(탬플릿)관리 - 문자패턴관리 -문자패턴미리보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'H011402',
    Depth2: '공통관리',
    Depth3: '메시지(알림)관리 -등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 하단 버튼',
  },
  {
    name: 'H011403',
    Depth2: '공통관리',
    Depth3: '메시지(알림)관리 -상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H01140401P',
    Depth2: '공통관리',
    Depth3: '메시지(알림)관리 -상세 -PUSH발송대상조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 하단 버튼 삭제, 테이블',
  },
  {
    name: 'H01140402P',
    Depth2: '공통관리',
    Depth3: '메시지(알림)관리 -상세 -URL찾기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },

  // 권한관리
  {
    name: 'H020601T',
    Depth2: '권한관리',
    Depth3: '그룹별권한관리 - 사용자',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },

  {
    name: 'H02060101P',
    Depth2: '권한관리',
    Depth3: '그룹별권한관리 - 권한변경',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },

  // {
  //   name: 'H0601010102',
  //   Depth2: '게시판',
  //   Depth3: '등록/수정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '작업',
  // },

  {
    name: 'H06010302T',
    Depth2: '게시판',
    Depth3: '컬럼설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 버튼 컬러',
  },

  // 양식관리
  {
    name: 'H060201',
    Depth2: '양식관리',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'H060202',
    Depth2: '양식관리',
    Depth3: '조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H060203',
    Depth2: '양식관리',
    Depth3: '등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  //
  {
    name: 'H060301',
    Depth2: '게시판 관리',
    Depth3: '금칙어 관리 -목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'H060302',
    Depth2: '게시판 관리',
    Depth3: '금칙어 관리 -등록수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼테이블',
  },

  //

  {
    name: 'H060401',
    Depth2: '게시판관리',
    Depth3: '붐업관리 -붐업설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },

  {
    name: 'H060402',
    Depth2: '게시판관리',
    Depth3: '붐업관리 -붐업목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },

  {
    name: 'H0502030301T',
    Depth2: '권한관리',
    Depth3: '게시판관리 -등록수정 - 기본정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 하단 버튼',
  },
  {
    name: 'H050203010101',
    Depth2: '권한관리',
    Depth3: '게시판관리 - 목록 -기시물관리 -게시물 목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러, 테이블',
  },

  // {
  //   name: 'H050203010102',
  //   Depth2: '권한관리',
  //   Depth3: '목록 -기시물관리 -게시물 등록/수정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '홀딩',
  // },
  // {
  //   name: 'H050203010103',
  //   Depth2: '권한관리',
  //   Depth3: '권한관리 - 게시판관리 - 목록 -기시물관리 -게시물 조회',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '홀딩',
  // },
  // {
  //   name: 'H0502030303P',
  //   Depth2: '권한관리',
  //   Depth3: '게시판관리 - 등록주성 -기본정보- 말머리 설정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '홀딩',
  // },
  // {
  //   name: 'H0502030304T',
  //   Depth2: '권한관리',
  //   Depth3: '게시판관리 - 등록주성 -컬럼설정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '홀딩',
  // },
  {
    name: 'H0502030305T',
    Depth2: '권한관리',
    Depth3: '게시판관리 - 등록주성 -화면구성',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'H0502030305T_1',
    Depth2: '권한관리',
    Depth3: '게시판관리 - 등록주성 -화면구성_1',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'H050201',
    Depth2: '권한관리',
    Depth3: '환경설정관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'H05020901',
    Depth2: '권한관리',
    Depth3: '신고게시물관리 -목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 테이블',
  },
  {
    name: 'H0502090101P',
    Depth2: '권한관리',
    Depth3: '신고게시물관리 신고게시물 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 삭제',
  },
  {
    name: 'H05021001',
    Depth2: '권한관리',
    Depth3: '컬럼속성관리 - 게시판신고유형',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러',
  },

  //
  {
    name: 'H05020301',
    Depth2: '권한관리',
    Depth3: '게시판관리-목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 버튼 컬러, 테이블',
  },
  // 가연 차장님 이후
  // {
  //   name: 'H05020302',
  //   Depth2: '권한관리',
  //   Depth3: '게시판관리-조회',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '230314 디자인수령',
  // },

  //팝업관리
  {
    name: 'H05020701',
    name2: '(H06090201,H060901)',
    Depth2: '팝업관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 토글, 버튼 컬러, 테이블',
  },
  //말머리관리
  // {
  //   name: 'H05020801',
  //   Depth2: '팝업관리',
  //   Depth3: '',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '230314 디자인수령',
  // },
  // {
  //   name: 'H05020801',
  //   Depth2: '팝업관리',
  //   Depth3: '등록/수정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '230314 디자인수령',
  // },

  // 일정관리
  {
    name: 'h010901T',
    name2: '(h010902T)',
    Depth2: '일정 관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블 ',
  },
  {
    name: 'h01090101p',
    Depth2: '일정 관리',
    Depth3: '일정등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H010902',
    Depth2: '일정 관리',
    Depth3: '일정등록 - 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  // {
  //   name: 'h01090201p_1',
  //   Depth2: '일정 관리',
  //   Depth3: '일정등록 1',
  //   Infor: {
  //     date: '23.03.02',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  // {
  //   name: 'h01090201p_2',
  //   Depth2: '일정 관리',
  //   Depth3: '일정등록 2',
  //   Infor: {
  //     date: '23.03.02',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  //사용자 정보 관리
  {
    name: 'H020101T',
    name2: '(H020102T,H011401)',
    Depth2: '사용자 정보 관리',
    Depth3: '시스템 사용자',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'H02010101p',
    Depth2: '사용자 정보 관리',
    Depth3: '시스템 사용자-신규등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'H02010201P',
    Depth2: '사용자 정보 관리',
    Depth3: '채점교사-신규등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: ' 라디오, 하단 버튼, 테이블',
  },
  // 사용자 검색
  {
    name: 'H02010301P',
    name2: '(H02010303P)',
    Depth2: '사용자 검색',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: ' 검색, 라디오, 하단 버튼, 테이블',
  },
  {
    name: 'H02010302P',
    name2: '(H02010304P)',
    Depth2: '사용자 검색',
    Depth3: '사용자검색(다건)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 버튼 컬러, 테이블',
  },
  //
  {
    name: 'H0203',
    Depth2: '메뉴구조관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 토글, 버튼 컬러, 테이블',
  },
  {
    name: 'H020301P',
    name2: '(H01130101P)',
    Depth2: '메뉴구조관리',
    Depth3: '메뉴설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  {
    name: 'H0204',
    Depth2: '권한그룹관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 토글, 버튼 컬러',
  },
  {
    name: 'H020401P',
    Depth2: '권한그룹관리',
    Depth3: '사용자설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'H020402P',
    Depth2: '권한그룹관리',
    Depth3: '메뉴설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  //그룹별 사용자 관리
  // {
  //   name: 'H0206',
  //   Depth2: '그룹별 사용자 관리',
  //   Depth3: '',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '230221 디자인수령',
  // },
  // {
  //   name: 'H020601P',
  //   Depth2: '그룹별 사용자 관리',
  //   Depth3: '권한변경',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: 'H02060101P,230221 디자인수령',
  // },
  // {
  //   name: 'H020602P',
  //   Depth2: '그룹별 사용자 관리',
  //   Depth3: '권한이력',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: 'H02060102P,230221 디자인수령',
  // },

  {
    name: 'h05020101',
    name2: '(H0204)',
    Depth2: '카테고리 ',
    Depth3: '카테고리 목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 토글, 테이블 ',
  },

  // {
  //   name: 'H01010101T_markup',
  //   Depth2: '공통코드관리',
  //   Depth3: '코드 검색 (단건 선택 반환)',
  //   Infor: {
  //     date: '23.02.09',
  //     state: '진행중',
  //     worker: '',
  //   },
  //   Comment: '',
  //   btn: {
  //     edit: true,
  //     del: true,
  //   },
  // },
  // {
  //   name: 'H01010102T_markup',
  //   Depth2: '공통코드관리',
  //   Depth3: '코드 검색 (다건 선택 반환',
  //   Infor: {
  //     date: '23.02.09',
  //     state: '진행중',
  //     worker: '',
  //   },
  //   Comment: '',
  //   btn: {
  //     edit: true,
  //     del: true,
  //   },
  // },

  // {
  //   name: 'H0105_markup',
  //   Depth2: '시스템메시지관리',
  //   Depth3: '',
  //   Infor: {
  //     date: '23.02.03',
  //     state: '진행중',
  //     worker: '',
  //   },
  //   Comment: '마크업진행중',
  //   btn: {
  //     edit: true,
  //     del: true,
  //   },
  // },

  // {
  //   name: 'MA02',
  //   Depth2: 'temp2',
  //   Depth3: 'temp3',
  //   Infor: {
  //     date: '22.12.01',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '비고',
  //   btn: {
  //     edit: true,
  //     del: false,
  //   },
  // },
  // {
  //   name: 'test-btn',
  //   Depth2: 'est-btn',
  //   Depth3: 'est-btn',
  //   Infor: {
  //     date: '22.12.01',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '비고',
  //   btn: {
  //     edit: false,
  //     del: true,
  //   },
  // },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '1차완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}

.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}

.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}

.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
