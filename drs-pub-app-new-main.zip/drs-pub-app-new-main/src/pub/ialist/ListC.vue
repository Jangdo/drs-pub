<template>
  <div class="wrap_ia_list">
    <q-table
      title="[C]수업"
      row-key="index"
      class="table_01"
      :rows="rows"
      :columns="columns"
      :pagination="initialPagination"
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td key="name">
            {{ props.row.name }}
          </q-td>
          <q-td key="name">
            <router-link :to="props.row.name.toLowerCase()">
              {{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,

    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    sortOrder: 'da',
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  {
    name: 'C01050201P',
    Depth2: '채점결과 발송',
    Depth3: '팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010101P',
    Depth2: '교재신청',
    Depth3: '긴급교재신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 버튼',
  },
  {
    name: 'C01010101P',
    Depth2: '교재신청',
    Depth3: '긴급부교재신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 버튼',
  },
  {
    name: 'C010102P',
    Depth2: '교재신청',
    Depth3: '회수/AS신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 테이블, 버튼',
  },
  {
    name: 'C01010301P',
    Depth2: '교재신청',
    Depth3: '부교재 목록-마감진도',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'C01010302P',
    Depth2: '교재신청',
    Depth3: '부교재 목록-미마감진도',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },

  {
    name: 'C0103P',
    Depth2: '선생님 메모 ',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010301P',
    Depth2: '선생님 메모 ',
    Depth3: '메모 쓰기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010302P',
    Depth2: '선생님 메모',
    Depth3: '없음',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0108T',
    Depth2: '오늘의 수업',
    Depth3: '출석부 (과목 보기)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010804T',
    Depth2: '오늘의 수업',
    Depth3: '출석부(과목보기)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '토글',
  },
  {
    name: 'C010801P',
    Depth2: '오늘의 수업',
    Depth3: '회원통화',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010802P',
    Depth2: '오늘의 수업',
    Depth3: '위치보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010803',
    Depth2: '오늘의 수업',
    Depth3: '캘린더 펼침',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010401',
    Depth2: '오늘의 수업',
    Depth3: '진도결정-주차별보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01040102',
    Depth2: '오늘의 수업',
    Depth3: '진도결정-세트선택 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'C03',
    Depth2: '수업일정관리',
    Depth3: '-회원일정변경',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0301P',
    Depth2: '수업일정관리',
    Depth3: '회원일정변경',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오',
  },
  {
    name: 'C030106P',
    Depth2: '수업일정관리',
    Depth3: '회원일정변경완료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0302',
    Depth2: '수업일정관리',
    Depth3: '교실관리',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C030201P',
    Depth2: '수업일정관리',
    Depth3: '교실관리-교실 상세 정보',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C030202P',
    Depth2: '수업일정관리',
    Depth3: '교실관리-교실 추가',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C03020101P',
    Depth2: '수업일정관리',
    Depth3: '교실 상세 정보- 수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C0109T',
    Depth2: '오늘의 수업',
    Depth3: '수업준비',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010901P',
    Depth2: '오늘의 수업',
    Depth3: '다른과목 보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010902P',
    Depth2: '오늘의 수업',
    Depth3: '학습완료처리(일괄/개인)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C0110T',
    Depth2: '오늘의 수업',
    Depth3: '수업 중',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01040302P_1',
    Depth2: '진도관리',
    Depth3: '써밋부교재신청',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01040303P',
    Depth2: '진도관리',
    Depth3: '써밋부교재신청목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'C010405',
    Depth2: '진도관리',
    Depth3: '솔루니',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 테이블',
  },
  {
    name: 'C010406',
    Depth2: '진도관리',
    Depth3: '창의독서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 테이블',
  },
  {
    name: 'C01040602',
    Depth2: '진도관리',
    Depth3: '창의독서 배송지 수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 테이블',
  },
  //
  {
    name: 'C010403',
    Depth2: '진도관리',
    Depth3: '진도수정/리셋 - 써밋 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 테이블, 버튼사이즈',
  },
  {
    name: 'C01040101',
    Depth2: '진도관리',
    Depth3: '진도결정-그래프보기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'C01040103',
    Depth2: '진도관리',
    Depth3: '진도결정-캘린더보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01040104P',
    Depth2: '진도관리',
    Depth3: '부교재 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 테이블',
  },
  //
  {
    name: 'C0111T',
    Depth2: '수업',
    Depth3: '오늘의 수업-수업종료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0112T',
    Depth2: '수업',
    Depth3: '지난 수업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0112T_01',
    Depth2: '수업',
    Depth3: '지난 수업(회원없음)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0113T',
    Depth2: '수업',
    Depth3: '미래수업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 변경',
  },
  {
    name: 'C010501',
    Depth2: '수업',
    Depth3: '학습관리 - 지류',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010501_2',
    Depth2: '수업',
    Depth3: '학습관리 - 지류 케이스2',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010501_3',
    Depth2: '수업',
    Depth3: '학습관리 - 지류 케이스3',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01053904P',
    Depth2: '수업',
    Depth3: '학습관리-문자이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 변경, 테이블',
  },
  {
    name: 'C02P',
    Depth2: '화상연결',
    Depth3: '회원 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0401T',
    Depth2: '진도관리',
    Depth3: '요일별',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0402T',
    Depth2: '진도관리',
    Depth3: '회원별',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'no-padding',
  },
  {
    name: 'C0701',
    Depth2: '기타화면',
    Depth3: '데이터 미연동 시',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010503',
    Depth2: '학습관리',
    Depth3: '써밋 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010539',
    Depth2: '학습관리',
    Depth3: '다이렉트(통신교사) - 학습관리 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'C01053901P',
    Depth2: '수업관리',
    Depth3: '전화 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C01053902P',
    Depth2: '수업관리',
    Depth3: '문자 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C01053903P',
    Depth2: '수업관리',
    Depth3: '전화 -1차상담 완료 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C0105390301P',
    Depth2: '수업관리',
    Depth3: '전화 -2차상담 완료',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C05',
    Depth2: '조직선택',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스',
  },
  {
    name: 'C0501T',
    Depth2: '조직선택',
    Depth3: '선생님선택(채점선생님)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '토글',
  },
  {
    name: 'C0501T_01',
    Depth2: '조직선택',
    Depth3: '선생님선택(채점선생출석부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '토글',
  },
  {
    name: 'C0501T_02',
    Depth2: '조직선택',
    Depth3: '수업준비',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 변경',
  },
  {
    name: 'C0501T_03',
    Depth2: '조직선택',
    Depth3: '수업중',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0501T_04',
    Depth2: '조직선택',
    Depth3: '수업종료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0502',
    Depth2: '선생님선택',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C0502_1',
    Depth2: '채점선생님',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C060101',
    Depth2: '조직선택',
    Depth3: '정성회원 목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C060102',
    Depth2: '조직선택',
    Depth3: '정성회원 등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C0105390302P',
    Depth2: '수업관리',
    Depth3: '전화 -상담관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C0105390303P',
    Depth2: '수업관리',
    Depth3: '전화 -기타관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C0105390304P',
    Depth2: '수업관리',
    Depth3: '전화 -해피콜',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C0105390305P',
    Depth2: '수업관리',
    Depth3: '문자 -셀프러닝 선생님',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  {
    name: 'C0105390306P',
    Depth2: '수업관리',
    Depth3: '문자 -상담실',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 버튼 컬러 변경',
  },
  // {
  //   name: 'C010601',
  //   Depth2: '수업관리',
  //   Depth3: '문자 -상담실',
  //   Infor: {
  //     date: '',
  //     state: '진행중',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  {
    name: 'C010601',
    Depth2: '학습이력',
    Depth3: '지류 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010602',
    Depth2: '학습이력',
    Depth3: '써밋',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010701',
    Depth2: '결과리포트',
    Depth3: '지류',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '코칭가이드',
  },
  {
    name: 'C010702',
    Depth2: '결과리포트',
    Depth3: '써밋',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '코칭가이드',
  },
  {
    name: 'C01070201',
    Depth2: '결과리포트',
    Depth3: '써밋1',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070202',
    Depth2: '결과리포트',
    Depth3: '써밋2',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070203',
    Depth2: '결과리포트',
    Depth3: '써밋3',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070204',
    Depth2: '결과리포트',
    Depth3: '써밋4',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070205',
    Depth2: '결과리포트',
    Depth3: '써밋5',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070206',
    Depth2: '결과리포트',
    Depth3: '써밋6',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070207',
    Depth2: '결과리포트',
    Depth3: '써밋7',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '코칭가이드',
  },
  {
    name: 'C01070208',
    Depth2: '결과리포트',
    Depth3: '써밋8',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010703P',
    Depth2: '결과리포트',
    Depth3: '통합진도 그래프',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010704P',
    Depth2: '결과리포트',
    Depth3: '학부모 공유',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'C01070401P',
    Depth2: '결과리포트',
    Depth3: '그룹메시지 보내기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010707P',
    Depth2: '결과리포트',
    Depth3: '그룹메시지 보내기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C01070701P',
    Depth2: '결과리포트',
    Depth3: '받는분 추가-교실선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 토글',
  },
  {
    name: 'C01070702P',
    Depth2: '결과리포트',
    Depth3: '받는분 추가-회원선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 토글',
  },
  {
    name: 'C0108',
    Depth2: '결과리포트',
    Depth3: '공유',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'C010801',
    Depth2: '결과리포트',
    Depth3: '공유 템플릿',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  //

  // {
  //   name: 'C010803P',
  //   Depth2: '',
  //   Depth3: '캘린더',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  //
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '수정요청완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss" scoped>
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
// .q-tr.edit {
//   td {
//     background: rgb(255, 171, 227) !important;
//   }
// }
.q-tr.ing {
  td {
    background: rgb(204, 229, 250) !important;
  }
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}
.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}
.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
