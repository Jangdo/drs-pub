<template>
  <div class="q-pa-sm page_Calander">
    <div class="q-gutter-md" style="max-width: 300px"></div>
    <div class="q-pa-md row items-start q-gutter-md">

      <q-card>
        <q-date v-model="days.from" ref="ref_dateFrom"  minimal   :events="events" @update:model-value="aa" multi today-btn
        />
      </q-card>
      <q-card>
        <q-date v-model="days.to" ref="ref_dateTo" minimal   :events="events" @update:model-value="bb" multi today-btn />
      </q-card>

    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const ref_dateFrom = ref();
const events = ref();
const days = ref({ from: '2020/07/01', to: '2020/08/01' });
// function test01(view){
//   console.log(view)
//   aa.value.setCalendarTo(1982,7)
// }
function aa(value, reason, details) {
  console.log(value, reason, details)
  ref_dateFrom.value = '2021/07/01';
  // setTimeout(() => {
  //   aa.value.setCalendarTo(2022, 7)
  // }, 300);
}
function bb(value, reason, details) {
  console.log(value, reason, details)
  // days_to.value = '2022/07/10';
  events.value = date => date >= days.value.from && date <= days.value.to;
  // setTimeout(() => {
  //   aa.value.setCalendarTo(2022, 7)
  // }, 300);
}

</script>
<style lang="scss">
.page_Calander .q-card {
  width: 360px;
}

.q-date {
  width: 100%;
}
</style>
