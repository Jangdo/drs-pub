<template>

  <div class="wrap_ia_list">
    <TestSnb />
    <h3 class="my25">컴포넌트 가이드</h3>
    <!-- 아이콘 -->
    <q-expansion-item :default-opened="false" icon="mood" label="Icon" header-class="text-primary">
      <q-card>
        <q-card-section>
          <h4>
            1. Material Icons
            <p class="text-body2">
              https://fonts.google.com/icons?icon.set=Material+Icons&icon.platform=web
            </p>
          </h4>

          <div class="text-primary q-gutter-md" style="font-size: 32px">
            <q-icon color="negative" name="search"></q-icon>
            <q-icon color="warning" name="home"></q-icon>
            <q-icon color="positive" name="settings"></q-icon>
            <q-icon color="primary" name="more_vert"></q-icon>
            <q-icon color="negative" name="settings"></q-icon>
            <q-icon color="grey-10" name="menu"></q-icon>
            <q-icon color="grey-9" name="refresh"></q-icon>
            <q-icon color="grey-8" name="close"></q-icon>
          </div>

          <h4>
            2.Ion Icons
            <p class="text-body2">https://ionic.io/ionicons/v4</p>
          </h4>
          <div class="text-primary q-gutter-md" style="font-size: 32px">
            <q-icon color="negative" name="ion-ios-search"></q-icon>
            <q-icon color="warning" name="ion-ios-home"></q-icon>
            <q-icon color="positive" name="ion-ios-settings"></q-icon>
            <q-icon color="primary" name="ion-ios-more"></q-icon>
            <q-icon color="negative" name="ion-ios-settings"></q-icon>
            <q-icon color="grey-10" name="ion-ios-menu"></q-icon>
            <q-icon color="grey-9" name="ion-ios-more"></q-icon>
            <q-icon color="grey-8" name="ion-ios-close"></q-icon>
          </div>
        </q-card-section>
      </q-card>
    </q-expansion-item>
    <!--// 아이콘 -->
    <q-separator />
    <!-- Typhography -->
    <q-expansion-item :default-opened="false" icon="format_size" label="Typhography" header-class="text-teal">
      <q-card>
        <q-card-section>
          <div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-h1
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  h1
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h1" cursor-pointer>
                <q-tooltip>
                  font-size: 30px; *가독성 폴백 <br />
                  font-size: 1.875rem; line-height: 2.625rem; font-weight:
                  900;
                </q-tooltip>
                Headline/Large 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-h2
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  h2
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h2" cursor-pointer>
                <q-tooltip>
                  font-size: 1.625rem; line-height: 2.25rem; font-weight: 700;
                </q-tooltip>
                Headline/Medium 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-h3
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  h3
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h3" cursor-pointer>
                <q-tooltip>
                  font-size: 22px; font-size: 1.375rem; line-height: 1.875rem;
                  font-weight: 500;
                </q-tooltip>
                Headline/Small 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-h4
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  h4
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h4" cursor-pointer>
                <q-tooltip>
                  font-size: 20px; font-size: 1.25rem; line-height: 29px;
                  font-weight: 700;
                </q-tooltip>
                Title/Large 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-h5
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  h5
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h5" cursor-pointer>
                <q-tooltip>
                  font-size: 18px; font-size: 1.8125rem; line-height:
                  1.5625rem; font-weight: 500;
                </q-tooltip>
                Title/Medium 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-body1
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  *
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body1" cursor-pointer>
                <q-tooltip>
                  font-size: 15px; font-size: 0.9375rem; line-height:
                  0.9375rem; font-weight: 500;
                </q-tooltip>
                Title/Small 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-body2
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  *
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body2" cursor-pointer>
                <q-tooltip>
                  font-size: 13px; font-size: 0.8125rem; line-height:
                  1.3125rem; font-weight: 500;
                </q-tooltip>
                Body/Large 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-body3
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  *
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body3" cursor-pointer>
                <q-tooltip>font-size: 12px; font-size: 0.75rem; line-height: 1.25rem;
                  font-weight: 900;</q-tooltip>
                Body/Medium 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status" cursor-pointer>
                  text-body4
                  <q-tooltip> class </q-tooltip>
                </div>
                <div class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status" cursor-pointer>
                  *
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body4" cursor-pointer>
                <q-tooltip>
                  font-size: 11px; font-size: 0.6875rem; line-height:
                  1.125rem; font-weight: 500;</q-tooltip>
                Body/Small 차세대드림스
              </div>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </q-expansion-item>
    <!--// Typhography -->
    <q-separator />
    <!-- Color -->
    <q-expansion-item :default-opened="false" icon="palette" label="Color" header-class="text-purple">
      <div class="q-pa-md row items-start q-gutter-md">
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-grey-10" cursor-pointer>
            <q-tooltip> $grey-10: #060606; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">Natural10</div>
            <div class="text-subtitle2">$grey-10: #060606;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-grey-9" cursor-pointer>
            <q-tooltip> $grey-9: #090909; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">Natural20</div>
            <div class="text-subtitle2">$grey-9: #090909;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-grey-8" cursor-pointer>
            <q-tooltip> $grey-8: #555d67; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">Natural30</div>
            <div class="text-subtitle2">$grey-8: #555d67;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-grey-7" cursor-pointer>
            <q-tooltip> $grey-7: #c0c4cd; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">Natural40</div>
            <div class="text-subtitle2">$grey-7: #c0c4cd;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-grey-6" cursor-pointer>
            <q-tooltip> $grey-6: #f4f5fb; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">Natural50</div>
            <div class="text-subtitle2">$grey-6: #f4f5fb;</div>
          </q-card-section>
        </q-card>
      </div>
      <div class="q-pa-md row items-start q-gutter-md">
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-negative" cursor-pointer>
            <q-tooltip> $negative: #f27321; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">negative</div>
            <div class="text-subtitle2">$negative: #f27321;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-warning" cursor-pointer>
            <q-tooltip> $warning: #fcb813; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">warning</div>
            <div class="text-subtitle2">$warning: #fcb813;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-positive" cursor-pointer>
            <q-tooltip> $positive: #44b87b; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">positive</div>
            <div class="text-subtitle2">$positive: #44b87b;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-primary" cursor-pointer>
            <q-tooltip> $primary: #0080b6; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">primary</div>
            <div class="text-subtitle2">$primary: #0080b6;</div>
          </q-card-section>
        </q-card>
        <q-card class="my-card q-pa-sm">
          <div class="circle_shape bg-white" cursor-pointer>
            <q-tooltip> $white: #f4f5fb; </q-tooltip>
          </div>

          <q-card-section>
            <div class="text-h6">white</div>
            <div class="text-subtitle2">$white: #fff;</div>
          </q-card-section>
        </q-card>
      </div>
    </q-expansion-item>
    <!-- //Color -->
    <q-separator />
    <!-- BUTTON -->
    <q-expansion-item :default-opened="false" icon="play_for_work" label="Button">
      <q-card class="">
        <q-btn flat color="primary" label="Flat" />
        <q-btn flat rounded color="primary" label="Flat Rounded" />
        <q-btn flat round color="primary" icon="card_giftcard" />
        <br />
        <q-btn outline color="primary" label="Outline" />
        <q-btn outline rounded color="primary" label="Outline Rounded" />
        <q-btn outline round color="primary" icon="card_giftcard" />
        <br />
        <q-btn push color="primary" label="Push" />
        <q-btn push color="primary" round icon="card_giftcard" />
        <q-btn push color="white" text-color="primary" label="Push" />
        <q-btn push color="white" text-color="primary" round icon="card_giftcard" />
        <br />
        <q-btn unelevated color="primary" label="Unelevated" />
        <q-btn unelevated rounded color="primary" label="Unelevated Rounded" />
        <q-btn unelevated round color="primary" icon="card_giftcard" />
        <br />
        <q-btn no-caps color="primary" label="No caps" />
        <br />
        <q-btn class="glossy" color="secondary" label="Glossy" />
        <q-btn class="glossy" rounded color="negative" label="Glossy Rounded" />
        <q-btn class="glossy" round color="primary" icon="card_giftcard" />
        <q-btn class="glossy" round color="secondary" icon="local_florist" />
        <q-btn class="glossy" round color="negative" icon="local_activity" />
        <br>
        <q-btn color="primary" style="width: 200px">
          <div class="ellipsis">
            This is some very long text that is expected to be truncated
          </div>
        </q-btn>
      </q-card>
    </q-expansion-item>
    <!--// BUTTON -->
    <q-separator />
    <!-- Radio -->
    <q-expansion-item :default-opened="false" icon="radio_button_checked" label="Radio">
      <q-card class="">
        <q-radio v-model="dataRadio" val="primary" label="primary" color="primary" />
        <q-radio v-model="dataRadio" val="secondary" label="secondary" color="secondary" />
        <q-radio v-model="dataRadio" val="warning" label="warning" color="warning" />
        <q-radio v-model="dataRadio" val="negative" label="negative" color="negative" />
        <q-radio v-model="dataRadio" val="info" label="info" color="info" />
      </q-card>
    </q-expansion-item>
    <!--// Radio -->
    <q-separator />
    <!-- checkbox -->
    <q-expansion-item :default-opened="false" icon="download_done" label="checkbox" header-class="text-purple">
      <q-card class="">
        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-checkbox v-model="dataCheck.primary" label="primary" color="primary" />
            <q-checkbox v-model="dataCheck.secondary" label="secondary" color="secondary" />
            <q-checkbox v-model="dataCheck.negative" label="negative" color="negative" />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //checkbox -->
    <q-separator />
    <!-- toggle -->
    <q-expansion-item :default-opened="false" icon="toggle_on" label="toggle" header-class="text-teal">
      <q-card class="">
        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-toggle color="primary" label="primary" v-model="dataToggle" val="primary" />
            <q-toggle color="negative" label="negative" v-model="dataToggle" val="negative" />
            <q-toggle color="warning" label="warning" v-model="dataToggle" val="warning" />
            <q-toggle color="positive" label="positive" v-model="dataToggle" val="positive" />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //toggle -->
    <q-separator />
    <!-- Dropdown -->
    <q-expansion-item :default-opened="false" icon="menu_open" label="Dropdown" header-class="text-gray-8">
      <q-card class="">
        <div class="q-pa-md" style="max-width: 400px">
          <q-select outlined label="선택해주세요" v-model="dataSelect" :options="dataSelectOption" dense>
          </q-select>
          <h4>Error</h4>
          <q-select outlined label="선택해주세요" v-model="dataSelect" :options="dataSelectOption" :rules="[
            (val, rules) => false || 'Please enter a valid email address',
          ]" dense>
            <template v-slot:hint> Field hint </template>
          </q-select>
          <h4>disable</h4>
          <q-select outlined disable label="선택해주세요" v-model="dataSelect" :options="dataSelectOption" dense>
          </q-select>
          <h4>readonly</h4>
          <q-select outlined readonly label="선택해주세요" v-model="dataSelect" :options="dataSelectOption" dense>
          </q-select>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Dropdown -->
    <q-separator />
    <!-- Input Fields -->
    <q-expansion-item :default-opened="false" icon="edit_note" label="Input Fields" header-class="text-purple"
      @after-show="sampleFocus(testInput), dataInput = 'test'">
      <q-card class="">
        <div class="q-pa-md" style="max-width: 400px">

          <q-input class="mb25" filled v-model="dataInput" label="Label (stacked)" stack-label dense />
          <h4>Focus</h4>
          <q-input class="mb25" filled ref="testInput" v-model="dataInput" label="Focus" stack-label dense />
          <h4>Error</h4>
          <q-input class="mb25" filled v-model="dataInput" label="Error" error :rules="[
            (val, rules) => false || 'Please enter a valid email address',
          ]" dense />

          <h4>Disable</h4>
          <q-input class="mb25" disable for="test" filled v-model="dataInput" label="Disable" dense />
          <h4>Suffix</h4>
          <q-input class="mb25" filled v-model="dataInput" label="Suffix" dense suffix="10점" id="" />
          <h4>Icon</h4>
          <q-input class="mb25" filled dense placeholder="Placeholder">
            <template v-slot:prepend>
              <q-icon name="search" />
            </template>
          </q-input>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Input Fields -->
    <q-separator />
    <!-- Textarea -->
    <q-expansion-item :default-opened="false" icon="note_alt" label="TextArea" header-class="text-gray-8">
      <q-card class="">
        <div class="q-pa-md" style="max-width: 400px">
          <q-input v-model="dataTextArea" filled type="textarea" />
        </div>
      </q-card></q-expansion-item>
    <!-- //Textarea -->
    <q-separator />
    <!-- Snackbars -->
    <q-expansion-item :default-opened="false" icon="mark_unread_chat_alt" header-class="text-warning" label="Snackbars">
      <q-card class="">
        <div class="q-pa-md">
          <q-btn outline @click="showNotif" label="Snackbars" />
        </div>
      </q-card>
    </q-expansion-item>
    <!--// Snackbars -->
    <q-separator />
    <!-- Dialogs -->
    <q-expansion-item :default-opened="false" icon="call_to_action" header-class="text-teal" label="Dialogs">
      <q-card class="">
        <div class="q-pa-md">
          <q-btn class="ma10" label="Alert" color="primary" @click="dataDialog.alert = true" />
          <q-btn class="ma10" label="Confirm" color="primary" @click="dataDialog.confirm = true" />
          <q-btn class="ma10" label="Prompt" color="primary" @click="dataDialog.prompt = true" />
          <q-btn class="ma10" label="bottomsheet" color="primary" @click="dataDialog.bottomsheet = true" />

          <q-dialog v-model="dataDialog.alert">
            <q-card>
              <q-card-section>
                <div class="text-h3" align="center">제목:Alert</div>
              </q-card-section>

              <q-card-section class="q-pt-none text-body1">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum
                repellendus sit voluptate voluptas eveniet porro. Rerum
                blanditiis perferendis totam, ea at omnis vel numquam
                exercitationem aut, natus minima, porro labore.
              </q-card-section>

              <q-card-actions align="center">
                <q-btn unelevated label="확인" color="primary" v-close-popup />
              </q-card-actions>
            </q-card>
          </q-dialog>
          <q-dialog v-model="dataDialog.confirm" persistent>
            <q-card>
              <q-card-section class="row items-center">
                <q-avatar icon="campaign" color="primary" text-color="white" />
                <span class="q-ml-sm">confirm ?</span>
              </q-card-section>

              <q-card-actions align="right">
                <q-btn outline label="거절" color="primary" v-close-popup />
                <q-btn unelevated label="동의" color="primary" v-close-popup />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.prompt" persistent>

            <q-card style="min-width: 350px">
              <q-card-section>
                <div class="text-h6">prompt 입력</div>
              </q-card-section>
              <q-card-section class="q-pt-none">
                <q-input dense v-model="dataDialog.prompt_input" autofocus
                  @keyup.enter="dataDialog.prompt_input = false" />
              </q-card-section>
              <q-card-actions align="right" class="text-primary">
                <q-btn outline label="취소" v-close-popup />
                <q-btn unelevated color="primary" label="입력완료" v-close-popup />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.bottomsheet" full-width position="bottom">
            <q-card style="    border-top-left-radius: 20px;
    border-top-right-radius: 20px;" v-touch-swipe.mouse="swipe_bottom">

              <q-card-section class="row items-center no-wrap">
                <q-list>
                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-icon color="primary" name="bluetooth" />
                    </q-item-section>

                    <q-item-section>Icon as avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar color="teal" text-color="white" icon="bluetooth" />
                    </q-item-section>

                    <q-item-section>Avatar-type icon</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar rounded color="purple" text-color="white" icon="bluetooth" />
                    </q-item-section>

                    <q-item-section>Rounded avatar-type icon</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar color="primary" text-color="white">
                        R
                      </q-avatar>
                    </q-item-section>

                    <q-item-section>Letter avatar-type</q-item-section>
                  </q-item>

                  <q-separator />

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png">
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar square>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png">
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image square avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar rounded>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png">
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image rounded avatar</q-item-section>
                  </q-item>

                  <q-separator />

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar rounded>
                        <img src="https://cdn.quasar.dev/img/mountains.jpg">
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>List item</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section thumbnail>
                      <img src="https://cdn.quasar.dev/img/mountains.jpg">
                    </q-item-section>
                    <q-item-section>List item</q-item-section>
                  </q-item>
                </q-list>

                <q-space />

              </q-card-section>
            </q-card>
          </q-dialog>
        </div>
      </q-card>
    </q-expansion-item>
    <!--// Dialogs -->
    <q-separator />
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { useQuasar, useMeta } from 'quasar';
const metaData = {};
const route = useRoute();
const $q = useQuasar();
const dataSelect = ref('');
const testInput = ref(null);
const dataInput = ref('인풋테스트');
const dataTextArea = ref('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in ex ');
const dataRadio = ref('primary');
const dataCheck = ref({ primary: false, secondary: false, negative: false });
const dataDialog = ref({
  alert: false,
  confirm: false,
  prompt: false,
  prompt_input: '...',
  bottomsheet: false,
  bottomsheet_drag: null
});
function swipe_bottom({ ...newInfo }) {
  dataDialog.value.bottomsheet_drag = newInfo;
  if (dataDialog.value.bottomsheet_drag.direction == 'down' && dataDialog.value.bottomsheet_drag.distance.y > 8) {
    dataDialog.value.bottomsheet = false
  }
}
const dataToggle = ref(['primary', 'warning']);
const dataSelectOption = ref(['Google', 'Facebook', 'Twitter', 'Apple', 'Oracle']);
// setTimeout(() => {
//   testInput.value.focus();
// }, 30);

onMounted(() => {
  metaData.title = route.name;
  // console.log(route.name);
  useMeta(metaData);
});

function showNotif() {
  $q.notify({
    timeout: 3000,
    message: '멀티 라인 snack bar <br> with icon ',
    html: true,
    color: 'primary',
    multiLine: true,
    avatar: 'favicon.ico',
    progress: true,
    caption: '3초예시',
    onDismiss: () => {
      console.log('Dismissed');
    },

    actions: [
      {
        label: '버튼 예시',
        color: 'yellow',
        handler: () => {
          console.log('버튼 이벤트');
        },
      },
      {
        label: '닫기',
        color: 'white',
        handler: () => {
          console.log('닫기');
        },
      },
    ],
  });

}
function sampleFocus(_target) {
  console.log('값', _target.modelValue)
  _target.focus();

}

</script>

<style lang="scss">
.q-expansion-item.q-expansion-item--expanded {
  background: rgb(232 232 232 / 30%);
}

.my-card {
  width: 100%;
  max-width: 250px;
}

.circle_shape {
  height: 0;
  margin: 0 auto;
  width: 40%;
  padding-bottom: 40%;
  border-radius: 60px !important;
  outline: 1px solid #eee;
  border: 1px solid #aaa;
}

.q-dialog__inner--minimized {
  padding: 0;
}
</style>
