<template>
  <div class="testPage">
    <div class="header" v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'">
      <q-btn icon="west" flat></q-btn>
      <p class="tit">검색</p>
      <q-btn icon="menu" flat></q-btn>
    </div>
    <div v-if="$q.screen.name == 'lg'" class="pc_header">
      <div class="fixed_gnb">
        <q-btn class="btn_menu" icon="menu" flat></q-btn>
        <q-list class="list_gnb" dense>
          <q-item clickable v-ripple>
            <q-item-section> 상담 </q-item-section>
          </q-item>

          <q-item clickable v-ripple>
            <q-item-section> 수업 </q-item-section>
          </q-item>

          <q-item clickable v-ripple>
            <q-item-section> 검색 </q-item-section>
          </q-item>
          <q-item clickable v-ripple>
            <q-item-section> 조직관리 </q-item-section>
          </q-item>
          <q-item clickable v-ripple>
            <q-item-section> 공통관리 </q-item-section>
          </q-item>
          <q-item clickable v-ripple>
            <q-item-section> 커뮤니티 </q-item-section>
          </q-item>
          <q-item clickable v-ripple>
            <q-item-section> 마이 </q-item-section>
          </q-item>
        </q-list>

        <q-list class="list_link" dense>
          <q-item clickable v-ripple>
            <q-item-section> 외부링크 </q-item-section>
          </q-item>

          <q-item clickable v-ripple>
            <q-item-section> 외부링크 </q-item-section>
          </q-item>

          <q-item clickable v-ripple>
            <q-item-section> 외부링크 </q-item-section>
          </q-item>
        </q-list>

        <div class="gnb_footer">
          <q-icon class="bell" name="notifications" size="20px" />
          <q-btn class="log" label="로그아웃" flat></q-btn>
          <q-btn class="big_btn" label="Logo" flat></q-btn>
        </div>
      </div>
      <div class="heading">
        <!-- breadcrumbs -->
        <q-breadcrumbs active-color="#666" class="">
          <template v-slot:separator>
            <q-icon size="1.5em" name="chevron_right" />
          </template>
          <q-breadcrumbs-el icon="home" style="font-size: 20px;" />
          <q-breadcrumbs-el label="검색" />
          <q-breadcrumbs-el label="회원" />
          <q-breadcrumbs-el label="프로필카드" />
        </q-breadcrumbs>
        <!--// breadcrumbs -->

        <p class="tit_big">검색</p>
      </div>
    </div>
    <div class="content">
      <section class="box">
        <p class="tit1">어떤 검색을 하시겠어요?</p>
        <div class="wrap_scr">
          <ul class="wrap_item search">
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
                <span>회원</span>
              </div>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
                <span>상품</span>
              </div>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
                <span>플레이스</span>
              </div>
            </li>
          </ul>
        </div>
      </section>
      <section>
        <p class="tit2">
          <q-icon name="image" size="20px" /> 빠른 검색을 할 때
        </p>
        <div class="wrap_scr">
          <div class="tag_box">
            <q-badge rounded label="#진도 미결정" />
            <q-badge rounded label="#미납" />
            <q-badge rounded label="#(구)자동이체" />
            <q-badge rounded label="#신입" />
          </div>
        </div>
      </section>

      <section>
        <p class="tit2">
          <q-icon name="image" size="20px" /> 스스로 공부하는 힘!
        </p>
        <div class="wrap_scr">
          <ul class="wrap_item big">
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
              </div>
              <span>눈높이 수학</span>
              <span class="sm_txt"># 계산력 # 수학</span>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
              </div>
              <span>눈높이 수학</span>
              <span class="sm_txt"># 계산력 # 수학</span>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
              </div>
              <span>눈높이 수학</span>
              <span class="sm_txt"># 계산력 # 수학</span>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
              </div>
              <span>눈높이 수학</span>
              <span class="sm_txt"># 계산력 # 수학</span>
            </li>
            <li>
              <div class="item">
                <q-icon name="image" size="20px" />
              </div>
              <span>눈높이 수학</span>
              <span class="sm_txt"># 계산력 # 수학</span>
            </li>
          </ul>
        </div>
      </section>
      <section class="box">
        <p class="tit2"><q-icon name="image" size="20px" />내 플레이스</p>
        <div class="map_area">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1111.1992493613589!2d126.9265055309321!3d37.49090445408967!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357c9fbb097933bf%3A0x6a9d9b93e5caa874!2zKOyjvCnrjIDqtZA!5e0!3m2!1sko!2skr!4v1678164583834!5m2!1sko!2skr"
            width="100%"
            height="200px"
            style="border: 0"
            allowfullscreen=""
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
      </section>
    </div>
    <div class="footer" v-if="$q.screen.name == 'sm' && 'md'">
      <ul class="inner_box">
        <li>
          <q-btn icon="home" color="#c0c04cd" flat></q-btn>
          <p class="txt">홈</p>
        </li>
        <li>
          <q-btn icon="image" color="#c0c04cd" flat></q-btn>
          <p class="txt">상담</p>
        </li>
        <li>
          <q-btn icon="image" color="#c0c04cd" flat></q-btn>
          <p class="txt">수업</p>
        </li>
        <li class="on">
          <q-btn icon="image" color="#090909" flat></q-btn>
          <p class="txt">검색</p>
        </li>
        <li>
          <q-btn icon="image" color="#c0c04cd" flat></q-btn>
          <p class="txt">마이</p>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
</script>

<style lang="scss">
@import 'src/assets/sass/admin/temp1.scss';
</style>
