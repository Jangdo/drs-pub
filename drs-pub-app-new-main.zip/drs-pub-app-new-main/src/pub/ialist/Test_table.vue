<template>
  <div class="wrap_ia_list">
    <q-intersection transition="jump-up">

      <q-table title="데이터 수정 가능한 테이블" :rows="seed" :columns="columns" row-key="index" :pagination="initialPagination" hide-bottom separator="cell"
        class="table_01">

        <template v-slot:body-cell-index="props">
          <q-td :props="props">
            {{ props.rowIndex }}
          </q-td>
        </template>
        <template v-slot:body-cell-link="props">
          <q-td :props="props">
            <router-link :to="props.row.name.toLowerCase()">
              pub/{{ props.row.name.toLowerCase() }}</router-link>
          </q-td>
        </template>
        <template v-slot:body-cell-infor="props">
          <q-td :props="props" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}/{{ props.row.Infor.state }}/{{
              props.row.Infor.worker
            }}
          </q-td>
        </template>
        <template v-slot:body-cell-Comment="props">
          <q-td :props="props" :class="getClass(props.row.Infor.state)">
            <div v-if="props.row.edit" class="box_td_input">
              <q-input v-model:model-value="props.row.Comment" :dense="true" />
              <q-btn unelevated color="primary" icon="check" size="xs" v-if="props.row.btn.edit"
                @click="seed[props.rowIndex].edit = false" />
            </div>

            <q-btn flat @click="seed[props.rowIndex].edit = true" v-else>
              {{
                props.row.Comment
              }}
            </q-btn>

          </q-td>
        </template>
        <template v-slot:body-cell-btn="props">
          <q-td :props="props" :class="getClass(props.row.Infor.state)">
            <div class="btn_inner_table">
              <q-btn unelevated color="primary" icon="edit" size="sm" v-if="props.row.btn.edit"
                @click="clickSample(props.row)" />
              <q-btn unelevated color="negative" icon="delete" size="sm" v-if="props.row.btn.del"
                @click="clickSample('삭제되었습니다.')" />
            </div>
          </q-td>
        </template>
      </q-table>

      <q-table title="합계테이블" :rows="seed" :columns="columns" :filter="filter" row-key="index" :pagination="initialPagination" separator="cell" hide-bottom class="scrollable tbl_row_4">
        <template v-slot:top-right>
          <q-input outlined dense v-model="filter" class="size_sm" placeholder="Search">
            <template v-slot:append>
              <q-icon name="icon-search" class="icon_svg"></q-icon>
            </template>
          </q-input>
        </template>
        <template v-slot:bottom-row>
          <q-tr class="tr_btm">
            <q-td class="align_center">합계</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">80.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
          </q-tr>
          <q-tr class="tr_btm type_total">
            <q-td class="align_center">수정합계</q-td>
            <q-td class="align_right">100.0</q-td>
            <q-td class="align_right">8,000.0</q-td>
            <q-td class="align_right">1.0</q-td>
            <q-td class="align_right">1.0</q-td>
            <q-td class="align_right"><span class="fc_orange">1.0</span></q-td>
            <q-td class="align_right">1.0</q-td>
          </q-tr>
        </template>
      </q-table>

      <div style="height:50px;"></div>

      <q-table title="합계테이블 sticky left top"
        :rows="seed"
        :columns="columns"
        row-key="index"
        :pagination="initialPagination"
        separator="cell"
        hide-bottom
        class="scrollable tbl_row_4 sticky_table_header sticky_table_footer stickty_left_table"
      >
        <template v-slot:bottom-row>
          <q-tr class="tr_btm">
            <q-td class="align_center">합계</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">80.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
          </q-tr>
        </template>
      </q-table>

      <div style="height:50px;"></div>

      <q-table title="합계테이블 sticky left4 top bottom"
        :rows="seed"
        :columns="columns"
        row-key="index"
        :pagination="initialPagination"
        separator="cell"
        hide-bottom
        class="scrollable tbl_row_4 sticky_table_header sticky_table_footer"
      >
        <template v-slot:bottom-row>
          <q-tr class="tr_btm">
            <q-td class="align_center tbl_left_fix_1">합계</q-td>
            <q-td class="align_right tbl_left_fix_2">1,000.0</q-td>
            <q-td class="align_right tbl_left_fix_3">80.0</q-td>
            <q-td class="align_right tbl_left_fix_4">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
            <q-td class="align_right">1,000.0</q-td>
          </q-tr>
          <!-- <q-tr class="tr_btm type_total">
            <q-td class="align_center">수정합계</q-td>
            <q-td class="align_right">100.0</q-td>
            <q-td class="align_right">8,000.0</q-td>
            <q-td class="align_right">1.0</q-td>
            <q-td class="align_right">1.0</q-td>
            <q-td class="align_right"><span class="fc_orange">1.0</span></q-td>
            <q-td class="align_right">1.0</q-td>
          </q-tr> -->
        </template>
      </q-table>

      <div style="height:50px;"></div>
      <p>테이블 클래스 stickty_left_table_1 ~ stickty_left_table_5 까지 5컬럼까지 고정 가능</p>
      <p>고정되는 칼럼 th에 클래스 추가 tbl_left_fix_1 ~ tbl_left_fix_5</p>

      <q-table title="합계테이블 sticky left top 멀티헤드 트리포함"
        class="scrollable tbl_row_14 sticky_table_header sticky_table_footer stickty_left_table multi_head stickty_left_table"
        :rows="dataRows"
        row-key="idx"
        v-model:pagination="dataPagination"
        hide-bottom
        hide-pagination
        separator="cell"
      >
        <template v-slot:header>
          <tr>
            <th rowspan="3" class="tbl_left_fix_1">구분</th>
            <th colspan="48">연 목표 성과관리현황</th>
          </tr>
          <tr>
            <th colspan="3" class="row_first">1월</th>
            <th colspan="3">2월</th>
            <th colspan="3">3월</th>
            <th colspan="3">1Q</th>
            <th colspan="3">4월</th>
            <th colspan="3">5월</th>
            <th colspan="3">6월</th>
            <th colspan="3">2Q</th>
            <th colspan="3">7월</th>
            <th colspan="3">8월</th>
            <th colspan="3">9월</th>
            <th colspan="3">3Q</th>
            <th colspan="3">10월</th>
            <th colspan="3">11월</th>
            <th colspan="3">12월</th>
            <th colspan="3">4Q</th>
          </tr>
          <tr>
            <th class="row_first">목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
            <th>실적</th>
            <th>달성률</th>
            <th>목표</th>
          </tr>
        </template>
        <template v-slot:body="props">
          <q-tr :props="props">
            <q-td
              key="section"
              class="section hastree"
              :class="props.row.depth"
            >
              <q-btn
                outline
                v-show="props.row.flat == false"
                class="btn_tree_expand_tbl"
                :icon="
                  props.row.state == true
                    ? 'ion-arrow-dropup'
                    : 'ion-arrow-dropdown'
                "
              >
              </q-btn>
              <p :class="props.row.flat == true ? 'flat_txt' : ''">
                {{ props.row.section }}
              </p>
              <q-img
                v-show="props.row.img"
                :src="
                  props.row.img +
                  '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                "
                spinner-color="white"
                class="user_thumb"
              />
            </q-td>
            <q-td key="goal1" class="goal text-right">
              {{ props.row.goal1 }}
            </q-td>
            <q-td key="result1" class="results text-right">
              {{ props.row.result1 }}
            </q-td>
            <q-td key="rate1" class="rate text-right">
              {{ props.row.rate1 }}
            </q-td>
            <q-td key="goal2" class="goal text-right">
              {{ props.row.goal2 }}
            </q-td>
            <q-td key="result2" class="results text-right">
              {{ props.row.result2 }}
            </q-td>
            <q-td key="rate2" class="rate text-right">
              {{ props.row.rate2 }}
            </q-td>
            <q-td key="goal3" class="goal text-right">
              {{ props.row.goal3 }}
            </q-td>
            <q-td key="result3" class="results text-right">
              {{ props.row.result3 }}
            </q-td>
            <q-td key="rate3" class="rate text-right">
              {{ props.row.rate3 }}
            </q-td>                  
            <q-td key="goalQ1" class="goal text-right">
              {{ props.row.goalQ1 }}
            </q-td>
            <q-td key="resultQ1" class="results text-right">
              {{ props.row.resultQ1 }}
            </q-td>
            <q-td key="rateQ1" class="rate text-right">
              {{ props.row.rateQ1 }}
            </q-td>                  
            <q-td key="goal4" class="goal text-right">
              {{ props.row.goal4 }}
            </q-td>
            <q-td key="result4" class="results text-right">
              {{ props.row.result4 }}
            </q-td>
            <q-td key="rate4" class="rate text-right">
              {{ props.row.rate4 }}
            </q-td>
            <q-td key="goal5" class="goal text-right">
              {{ props.row.goal5 }}
            </q-td>
            <q-td key="result5" class="results text-right">
              {{ props.row.result5 }}
            </q-td>
            <q-td key="rate5" class="rate text-right">
              {{ props.row.rate5 }}
            </q-td>
            <q-td key="goal6" class="goal text-right">
              {{ props.row.goal6 }}
            </q-td>
            <q-td key="result6" class="results text-right">
              {{ props.row.result6 }}
            </q-td>
            <q-td key="rate6" class="rate text-right">
              {{ props.row.rate6 }}
            </q-td>
            <q-td key="goalQ2" class="goal text-right">
              {{ props.row.goalQ2 }}
            </q-td>
            <q-td key="resultQ2" class="results text-right">
              {{ props.row.resultQ2 }}
            </q-td>
            <q-td key="rateQ2" class="rate text-right">
              {{ props.row.rateQ2 }}
            </q-td>                  
            <q-td key="goal7" class="goal text-right">
              {{ props.row.goal7 }}
            </q-td>
            <q-td key="result7" class="results text-right">
              {{ props.row.result7 }}
            </q-td>
            <q-td key="rate7" class="rate text-right">
              {{ props.row.rate7 }}
            </q-td>
            <q-td key="goal8" class="goal text-right">
              {{ props.row.goal8 }}
            </q-td>
            <q-td key="result8" class="results text-right">
              {{ props.row.result8 }}
            </q-td>
            <q-td key="rate8" class="rate text-right">
              {{ props.row.rate8 }}
            </q-td>
            <q-td key="goal9" class="goal text-right">
              {{ props.row.goal9 }}
            </q-td>
            <q-td key="result9" class="results text-right">
              {{ props.row.result9 }}
            </q-td>
            <q-td key="rate9" class="rate text-right">
              {{ props.row.rate9 }}
            </q-td>
            <q-td key="goalQ3" class="goal text-right">
              {{ props.row.goalQ3 }}
            </q-td>
            <q-td key="resultQ3" class="results text-right">
              {{ props.row.resultQ3 }}
            </q-td>
            <q-td key="rateQ3" class="rate text-right">
              {{ props.row.rateQ3 }}
            </q-td>
            <q-td key="goal10" class="goal text-right">
              {{ props.row.goal10 }}
            </q-td>
            <q-td key="result10" class="results text-right">
              {{ props.row.result10 }}
            </q-td>
            <q-td key="rate10" class="rate text-right">
              {{ props.row.rate10 }}
            </q-td>
            <q-td key="goal11" class="goal text-right">
              {{ props.row.goal11 }}
            </q-td>
            <q-td key="result11" class="results text-right">
              {{ props.row.result11 }}
            </q-td>
            <q-td key="rate11" class="rate text-right">
              {{ props.row.rate11 }}
            </q-td>                  
            <q-td key="goal12" class="goal text-right">
              {{ props.row.goal12 }}
            </q-td>
            <q-td key="result12" class="results text-right">
              {{ props.row.result12 }}
            </q-td>
            <q-td key="rate12" class="rate text-right">
              {{ props.row.rate12 }}
            </q-td>                  
            <q-td key="goalQ4" class="goal text-right">
              {{ props.row.goalQ4 }}
            </q-td>
            <q-td key="resultQ4" class="results text-right">
              {{ props.row.resultQ4 }}
            </q-td>
            <q-td key="rateQ4" class="rate text-right">
              {{ props.row.rateQ4 }}
            </q-td>
          </q-tr>
        </template>
        <template v-slot:bottom-row>
          <q-tr class="tr_btm">
            <q-td>합계</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
            <q-td class="text-right">0</q-td>
          </q-tr>
        </template>
      </q-table>

      <div style="height:50px;"></div>

      <q-table title="Nodata Table"
        class="multi_head"          
        row-key="idx"
        separator="cell"
        :data="dataData"
        no-data-label="데이터가 없습니다."         
      >
        <template v-slot:header>
          <tr>
            <th rowspan="2">No</th>
            <th rowspan="2">교재수급일</th>
            <th rowspan="2">사업팀</th>
            <th rowspan="2">선생님명</th>
            <th colspan="2">월</th>
            <th colspan="2">화</th>
            <th colspan="2">수</th>
            <th colspan="2">목</th>
            <th colspan="2">금</th>
          </tr>
          <tr>
            <th class="row_first">출장일</th>
            <th>주분</th>
            <th>출장일</th>
            <th>주분</th>
            <th>출장일</th>
            <th>주분</th>
            <th>출장일</th>
            <th>주분</th>
            <th>출장일</th>
            <th>주분</th>
          </tr>
        </template>
      </q-table>

    </q-intersection>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const filter = ref('');

const dataData = ref([]);

const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: true,
    field: (row) => row.index,
  },
  {
    name: 'link',
    label: 'link',
    align: 'center',
    sortable: true,
    field: (row) => row.name,
  },
  {
    name: 'Depth2',
    align: 'center',
    label: 'Depth2',
    field: 'Depth2',
    sortable: true,
  },
  {
    name: 'Depth3',
    align: 'center',
    label: 'Depth3',
    field: 'Depth3',
    sortable: true,
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: true,
    field: (row) => row.date,
  },
  { name: 'Comment', align: 'center', label: 'Comment', field: 'Comment' },

  {
    name: 'btn',
    label: 'btn',
    align: 'center',
  },
]);
const initialPagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});
const seed = ref([
  {
    name: '1234567890123456789',
    Depth2: '1234567890123456789',
    Depth3: '1234567890123456789',
    Infor: {
      date: '22.12.01',
      state: '진행중',
      worker: '윤상기',
    },
    Comment: '1234567890123456789',
    btn: {
      edit: true,
      del: true,
    },
    edit: false
  },
  {
    name: 'MA02',
    Depth2: 'temp2',
    Depth3: 'temp3',
    Infor: {
      date: '22.12.01',
      state: '완료',
      worker: '윤상기',
    },
    Comment: '비고',
    btn: {
      edit: true,
      del: false,
    },
    edit: false
  },
  {
    name: 'MA03',
    Depth2: 'temp3',
    Depth3: 'temp3',
    Infor: {
      date: '22.12.01',
      state: '완료',
      worker: '윤상기',
    },
    Comment: '비고',
    btn: {
      edit: false,
      del: true,
    },
    edit: false
  },
]);

const dataRows = ref([
    {
      idx: 11,
      section: '서울서북',
      depth: 'depth1',
      state: true,
      flat: false,
      goal1: '0',
      result1: '0',
      rate1: '0',
      goal2: '0',
      result2: '0',
      rate2: '0',
      goal3: '0',
      result3: '0',
      rate3: '0',
      goalQ1: '0',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',      
    },
    {
      idx: 10,
      section: '강서교육국 [김대교]',
      depth: 'depth2',
      state: true,
      flat: false,
      goal1: '0',
      result1: '0',
      rate1: '0',
      goal2: '0',
      result2: '0',
      rate2: '0',
      goal3: '0',
      result3: '0',
      rate3: '0',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 9,
      section: '강서교육국 [김대교]',
      depth: 'depth3',
      state: true,
      flat: false,
      goal1: '0',
      result1: '0',
      rate1: '0',
      goal2: '0',
      result2: '0',
      rate2: '0',
      goal3: '0',
      result3: '0',
      rate3: '0',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 8,
      section: '강서교육국 [강정현]',
      depth: 'depth4',
      state: true,
      flat: true,
      goal1: '0',
      result1: '0',
      rate1: '0',
      goal2: '0',
      result2: '0',
      rate2: '0',
      goal3: '0',
      result3: '0',
      rate3: '0',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 7,
      section: '강서교육국 [강정현]',
      depth: 'depth3',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 6,
      section: '강서교육국 [강정현]',
      depth: 'depth2',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 5,
      section: '서울강북',
      depth: 'depth1',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 4,
      section: '서울남동',
      depth: 'depth1',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 3,
      section: '강서교육국 [강정현]',
      depth: 'depth2',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 2,
      section: '울산',
      depth: 'depth1',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '0',
      rateQ1: '0',
      goal4: '0',
      result4: '0',
      rate4: '0',
      goal5: '0',
      result5: '0',
      rate5: '0',
      goal6: '0',
      result6: '0',
      rate6: '0',
      goalQ2: '0',
      resultQ2: '0',
      rateQ2: '0',
      goal7: '0',
      result7: '0',
      rate7: '0',
      goal8: '0',
      result8: '0',
      rate8: '0',
      goal9: '0',
      result9: '0',
      rate9: '0',
      goalQ3: '0',
      resultQ3: '0',
      rateQ3: '0',
      goal10: '0',
      result10: '0',
      rate10: '0',
      goal11: '0',
      result11: '0',
      rate11: '0',
      goal12: '0',
      result12: '0',
      rate12: '0',
      goalQ4: '0',
      resultQ4: '0',
      rateQ4: '0',  
    },
    {
      idx: 1,
      section: '경북',
      depth: 'depth1',
      state: true,
      flat: false,
      goal1: '999,999',
      result1: '999,999',
      rate1: '9,999,999',
      goal2: '99,999,999',
      result2: '99,999,999',
      rate2: '99,999,999',
      goal3: '999,999,9993',
      result3: '999,999,999',
      rate3: '999,999,999',
      resultQ1: '999,999,999',
      rateQ1: '999,999,999',
      goal4: '999,999,999',
      result4: '99,999,999',
      rate4: '9,999,999',
      goal5: '99,999,999',
      result5: '999,999,999',
      rate5: '99,999,999',
      goal6: '999,999,999',
      result6: '9,999,999',
      rate6: '999,999,999',
      goalQ2: '99,999,999',
      resultQ2: '9,999,999',
      rateQ2: '999,999',
      goal7: '99,999',
      result7: '9,999',
      rate7: '999',
      goal8: '99',
      result8: '999,999,999',
      rate8: '999,999,999',
      goal9: '999,999,999',
      result9: '999,999,999',
      rate9: '999,999,999',
      goalQ3: '999,999,999',
      resultQ3: '999,999,999',
      rateQ3: '999,999,999',
      goal10: '999,999,999',
      result10: '999,999,999',
      rate10: '0999,999,999',
      goal11: '999,999,999',
      result11: '999,999,999',
      rate11: '999,999,999',
      goal12: '999,999,999',
      result12: '999,999,999',
      rate12: '999,999,999',
      goalQ4: '999,999,999',
      resultQ4: '999,999,999',
      rateQ4: '999,999,999',
    },
  ]);
  const dataPagination = ref({
    sortBy: 'idx',
    descending: true,
    page: 1,
    rowsPerPage: 99999,
  });

  
// function columEdit(props) {
//   console.log(props.rowIndex)
//   seed.value[props.rowIndex].edit = true
//   console.log(seed.value[0])

// }
function clickSample(txt) {
  console.log(txt);
}
function getClass(priority) {
  switch (priority) {
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    default:
      return '';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}


.box_td_input {
  display: flex;
  flex-direction: row;
  height: 20px;

  .q-field__inner.relative-position.col.self-stretch {
    height: 100%;
    box-sizing: border-box;
  }

  .q-field__control.relative-position.row.no-wrap {
    height: 100%;
    margin-right: 5px;
    min-width: 70px;
  }
}
</style>
