<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>
  <div class="q-pa-sm page_Calander">
    <div class="q-gutter-md" style="max-width: 300px"></div>
    <div class="q-pa-md row items-start q-gutter-md">
      <q-btn
        unelevated
        class="ma10"
        label="년도선택"
        color="primary"
        @click="dataDialog.year = true"
      />
      <q-btn
        unelevated
        class="ma10"
        label="월 선택"
        color="primary"
        @click="dataDialog.month = true"
      />
      <q-dialog class="calendar_dialog" v-model="dataDialog.year">
        <q-card class="dialog_card type_02">
          <q-card-section class="pop_title_wrap">
            <h3 class="tit">년도선택</h3>
            <q-btn
              icon="close"
              class="btn_close"
              v-close-popup
              flat
              @click="popForm = false"
              unelevated
              dense
              outline
              ><b class="a11y">닫기</b></q-btn
            >
          </q-card-section>
          <q-card-section class="dialog_content">
            <div class="dialog_calandar_title">
              <q-btn flat icon="ion-ios-arrow-back" class="prev"
                ><span class="a11y">이전</span>
              </q-btn>
              <div class="title1">2019 ~ 2030</div>
              <q-btn flat icon="ion-ios-arrow-forward" class="next"
                ><span class="a11y">다음</span></q-btn
              >
            </div>
            <div class="btn_calandar_box">
              <q-btn fill unelevated disable class="calandar" label="2019" />
              <q-btn fill unelevated disable class="calandar" label="2020" />
              <q-btn fill unelevated disable class="calandar" label="2021" />
              <q-btn fill unelevated disable class="calandar" label="2022" />
              <q-btn outline class="calandar" label="2023" />
              <q-btn outline class="calandar" label="2024" />
              <q-btn outline class="calandar" label="2025" />
              <q-btn outline class="calandar" label="2026" />
              <q-btn outline class="calandar" label="2027" />
              <q-btn outline class="calandar" label="2028" />
              <q-btn outline class="calandar" label="2029" />
              <q-btn outline class="calandar" label="2030" />
            </div>
          </q-card-section>
        </q-card>
      </q-dialog>
      <q-dialog class="calendar_dialog" v-model="dataDialog.month">
        <q-card class="dialog_card type_02">
          <q-card-section class="pop_title_wrap">
            <h3 class="tit">월 선택</h3>
            <q-btn
              icon="close"
              class="btn_close"
              v-close-popup
              flat
              @click="popForm = false"
              unelevated
              dense
              outline
              ><b class="a11y">닫기</b></q-btn
            >
          </q-card-section>
          <q-card-section class="dialog_content">
            <div class="dialog_calandar_title">
              <q-btn flat icon="ion-ios-arrow-back" class="prev"
                ><span class="a11y">이전</span>
              </q-btn>
              <div class="title1">2022</div>
              <q-btn flat icon="ion-ios-arrow-forward" class="next"
                ><span class="a11y">다음</span></q-btn
              >
            </div>
            <div class="btn_calandar_box">
              <q-btn fill unelevated disable class="calandar" label="1월" />
              <q-btn fill unelevated disable class="calandar" label="2월" />
              <q-btn fill unelevated disable class="calandar" label="3월" />
              <q-btn fill unelevated disable class="calandar" label="4월" />
              <q-btn outline class="calandar" label="5월" />
              <q-btn outline class="calandar" label="6월" />
              <q-btn outline class="calandar" label="7월" />
              <q-btn outline class="calandar" label="8월" />
              <q-btn outline class="calandar" label="9월" />
              <q-btn outline class="calandar" label="10월" />
              <q-btn outline class="calandar" label="11월" />
              <q-btn outline class="calandar" label="12월" />
            </div>
          </q-card-section>
        </q-card>
      </q-dialog>
    </div>
    <div class="q-pa-md row items-start q-gutter-md">
      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">Default</div>
          <div class="text-subtitle2"></div>
        </q-card-section>
        <q-input lazy-rules="ondemand" filled v-model="date" mask="date">
          <template v-slot:prepend> <q-icon name="event" /> </template
        ></q-input>
        <q-date v-model="date" today-btn minimal />
      </q-card>
      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">day</div>
          <div class="text-subtitle2"></div>
        </q-card-section>

        <div id="day_calendar">
          <q-date
            @navigation="event_day_after"
            v-model="day_calandar"
            today-btn
            minimal
          />
        </div>
      </q-card>
    </div>
    <div class="q-pa-md row items-start q-gutter-md">
      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">Range</div>
          <div class="text-subtitle2"></div>
        </q-card-section>

        <q-date v-model="days" range today-btn minimal />
      </q-card>
      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">Range multiple</div>
        </q-card-section>
        <q-date v-model="multiDays" minimal range multiple today-btn />
      </q-card>
    </div>
    <div class="q-pa-md row items-start q-gutter-md">
      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">Days_separate from</div>
        </q-card-section>
        <q-date
          v-model="days2.from"
          minimal
          :events="events"
          @update:model-value="setFrom"
          multi
          today-btn
        />
      </q-card>

      <q-card>
        <q-card-section class="bg-primary">
          <div class="text-h6 text-white">Days_separate to</div>
        </q-card-section>
        <q-date
          v-model="days2.to"
          minimal
          :events="events"
          @update:model-value="setTo"
          multi
          today-btn
        />
      </q-card>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const date = ref('2020/07/04');
const dataDialog = ref({ month: false, year: false });

const day_calandar = ref('2020/07/04');
const events = ref();
const days = ref({ from: '2020/07/01', to: '2020/07/10' });
const days2 = ref({ from: '2020/07/01', to: '2020/07/10' });
const multiDays = ref([
  { from: '2020/07/01', to: '2020/07/10' },
  { from: '2020/07/15', to: '2020/07/23' },
]);
multiDays;
const days_separate = ref({ from: '2020/07/01', to: '2020/07/10' });

function event_day_after() {
  console.log('aaaa');
  document.querySelector(
    '#day_calendar .q-date__calendar-days-container'
  ).scrollLeft = 0;
}
function setFrom(value, reason, details) {
  console.log(value, reason, details);
  days_separate.value.from = value;
}
function setTo(value, reason, details) {
  console.log(value, reason, details);
  days_separate.value.to = value;
  events.value = (date) =>
    date >= days_separate.value.from && date <= days_separate.value.to;
}
</script>
<style></style>
<style lang="scss">
.page_Calander .q-card {
  width: 320px;
}

.q-date {
  width: 100%;
}

#day_calendar {
  .q-date__calendar-item--fill {
    opacity: 0.3 !important;
    visibility: visible;
  }
  .q-date__view {
    min-height: 170px;
  }
  .q-date__calendar-weekdays.row {
    display: none;
  }

  .q-date__calendar-days-container {
    width: 100%;
    white-space: nowrap;
    overflow: auto !important;
    min-height: 20px;
    height: 80px;
    overflow-y: hidden !important;
  }

  .q-date__content {
    width: 100%;
  }

  .q-date__calendar-days {
    width: fit-content !important;
    overflow-x: auto;
    display: inline-block;
    padding-top: 32px;
    overflow-y: hidden;
  }

  .q-date__calendar-days > div {
    width: 30px !important;
  }

  .q-date__content {
    height: 20px !important;
    min-height: 20px !important;
  }

  .q-date.q-date--portrait.q-date--portrait-minimal {
    height: 110px;
    overflow: hidden;
  }

  .q-date__content,
  .q-date__main {
    height: 60px !important;
  }
  .q-date__calendar-item:nth-child(7n + 2):before {
    content: '월';
  }
  .q-date__calendar-item:nth-child(7n + 3):before {
    content: '화';
  }
  .q-date__calendar-item:nth-child(7n + 4):before {
    content: '수';
  }
  .q-date__calendar-item:nth-child(7n + 5):before {
    content: '목';
  }
  .q-date__calendar-item:nth-child(7n + 6):before {
    content: '금';
  }

  .q-date__calendar-item:before {
    display: block;
    content: '일';
    position: absolute;
    top: -32px;
  }
}
</style>
