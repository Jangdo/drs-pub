<template>
  <div class="tree_container">
    <q-tree
      :nodes="treeData3"
      node-key="id"
      text-color="grey-2"
      selected-color="black"
      class="category"
      v-model:selected="treeSelected3"
      default-expand-all
      @update:selected="temp('트리3', treeSelected3)"
      ><template v-slot:default-header="prop">
        <div
          class="row items-center"
          :class="prop.node.selected ? 'tree_selected' : ''"
        >
          {{ prop.node.label }} {{ prop.node.selected }}
        </div>
      </template>
    </q-tree>
  </div>
  <h3 class="mt30 mb10">class="category type_02"</h3>
  <div class="tree_container">
    <q-tree
      :nodes="treeData3"
      tick-strategy="none"
      node-key="id"
      text-color="grey-2"
      selected-color="black"
      no-selection-unsets="false"
      v-model:selected="treeSelected3"
      default-expand-all
      @update:selected="temp('트리3', treeSelected3)"
      ><template v-slot:default-header="prop">
        <div
          class="row items-center"
          :class="prop.node.selected ? 'tree_selected' : ''"
        >
          {{ prop.node.label }}
        </div>
      </template>
    </q-tree>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const treeData3 = ref([
  {
    label: '경인본부',
    id: 'a_1',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        selected: false,
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            selected: false,
            children: [
              {
                id: 'a_4',
                label: '뎁스4',
                selected: true,
              },
              {
                id: 'a_5',
                label: '뎁스4',
                selected: false,
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            selected: false,
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        selected: false,
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            selected: false,
            children: [
              { id: 'a_9', label: '뎁스4', selected: false },
              { id: 'a_10', label: '뎁스4', selected: false },
            ],
          },
          { id: 'a_11', label: '뎁스3', selected: true },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        selected: false,
        children: [
          { id: 'a_13', label: '뎁스4', selected: false },
          { id: 'a_14', label: '뎁스4', selected: false },
        ],
      },
    ],
  },
]);
const treeSelected3 = ref('메시지 카테고리');
// 트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}
</script>
<style lang="scss">
// .row.items-center.tree_selected {
//   // border-radius: 4px;
//   // background-color: #eeeae4;
//   width: fit-content;
// }

// body
//   .tree_container
//   .q-tree.type_02:first-child
//   > .q-tree__node--parent.q-tree__node:first-child
//   > .q-tree__node-header:first-child {
//   .q-tree__node-header-content > div {
//     font-weight: 600;
//   }

//   .q-icon.q-tree__arrow {
//     background: url(/icons/icon-home.svg) no-repeat center;
//     transform: rotate(0);
//     text-indent: -999px;
//     background-position: center;
//     background-size: contain;
//   }
// }
</style>
