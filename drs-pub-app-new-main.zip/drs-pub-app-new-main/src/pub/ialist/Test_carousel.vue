<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label=$route.name />
  </q-breadcrumbs>
  <q-carousel
    animated
    swipeable
    v-model="slide"
    navigation
    arrows
    transition-prev="slide-right"
    transition-next="slide-left"
    control-text-color="primary"
    @mouseenter="autoplay = false"
    @mouseleave="autoplay = true"
    @before-transition="beforeSlideState"
    @transition="afterSlideState"
    ref="carousel00"
    style="height: 70vh; margin: 0 auto"
  >
    <q-carousel-slide
      v-for="(item, index) in listSlide"
      :key="index"
      :name="index"
      style="
        height: 100%;
        padding: 20px 20px 60px;
        display: flex;
        justify-content: center;
      "
    >
      <q-card
        style="
          width: 60%;
          height: 100%;
          padding: 0px 20px;
          display: block;
          overflow-y: auto;
          min-width: 300px;
        "
      >
        <q-item>
          <q-item-section avatar>
            <q-skeleton animation="pulse" type="QAvatar" />
          </q-item-section>

          <q-item-section style="width: 100%">
            <q-item-label>
              <p class="text-h1">{{ 'slide' + slide }}</p>
            </q-item-label>
            <q-item-label caption>
              <q-skeleton animation="pulse" type="text" />
            </q-item-label>
          </q-item-section>
        </q-item>

        <q-skeleton animation="pulse" height="30vh" square />

        <q-card-actions style="width: 100%">
          <q-btn @click="carousel00.next()">next </q-btn>
          <q-btn @click="carousel00.previous()">pre</q-btn>
          <q-btn @click="carousel00.toggleFullscreen()">toggleFullscreen</q-btn>
          <q-btn @click="carousel00.goTo(0)">0번째 페이지</q-btn>
        </q-card-actions>
      </q-card>
    </q-carousel-slide>
  </q-carousel>

  <!-- 사진 상세보기 -->
  <div class="pop_c_padding">
    <q-carousel
      animated
      v-model="slide2"
      arrows
      infinite
      class="photo_slider"
    >
      <q-carousel-slide :name="1" img-src="https://cdn.quasar.dev/img/mountains.jpg" />
      <q-carousel-slide :name="2" img-src="https://cdn.quasar.dev/img/parallax1.jpg" />
      <q-carousel-slide :name="3" img-src="https://cdn.quasar.dev/img/parallax2.jpg" />
      <q-carousel-slide :name="4" img-src="https://cdn.quasar.dev/img/quasar.jpg" />
    </q-carousel>
  </div>


</template>

<script setup>
import { ref } from 'vue';
const listSlide = ref([
  {
    txt: '퍼블리싱 가이드',
    link: '/pub/',
  },
  {
    txt: '테스트[TEST]',
    link: '/pub/test',
  },
  {
    txt: '테스트[lottie]',
    link: '/pub/lottie',
  },
  {
    txt: '테스트[echart]',
    link: '/pub/echart',
  },
  {
    txt: '테스트[table]',
    link: '/pub/table',
  },
]);
const slide = ref(1);
const carousel00 = ref();
const autoplay = ref(true);
function beforeSlideState() {
  console.log('change before  +');
  slideState();
}
function afterSlideState() {
  console.log('change after  +');
  slideState();
}
function slideState() {
  console.log(listSlide.value.length + '/' + slide.value);
}

const slide2 = ref(1);

</script>
<style lang="scss">
.q-card__actions .q-btn {
  padding: 10px 8px;
  margin: 3px 8px;
}
</style>
