<template>
  <div class="wrap_ia_list">
    <q-intersection transition="jump-up">
      <q-table
        title="기본가이드"
        :rows="rows"
        :columns="columns"
        row-key="index"
        :pagination="initialPagination"
        class="table_01"
      >
        <template v-slot:body-cell-link="props">
          <q-td :props="props">
            <router-link :to="props.row.name.toLowerCase()">
              pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
        </template>
        <template v-slot:body-cell-infor="props">
          <q-td :props="props" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}/{{ props.row.Infor.state }}/{{
              props.row.Infor.worker
            }}
          </q-td>
        </template>
        <template v-slot:body-cell-btn="props">
          <q-td :props="props" :class="getClass(props.row.Infor.state)">
            <div class="btn_inner_table">
              <q-btn
                unelevated
                color="primary"
                icon="edit"
                size="sm"
                v-if="props.row.btn.edit"
                @click="clickSample(props.row)"
              />
              <q-btn
                unelevated
                color="negative"
                icon="delete"
                size="sm"
                v-if="props.row.btn.del"
                @click="clickSample('삭제되었습니다.')"
              />
            </div>
          </q-td>
        </template>
      </q-table>
    </q-intersection>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const columns = ref(
  [
  {
    name: 'index',
    label: 'idx',
    align: 'left',
    sortable: true,
    field: (row) => row.index,
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: true,
    field: (row) => row.name,
  },
  {
    name: 'Depth2',
    align: 'center',
    label: 'Depth2',
    field: 'Depth2',
    sortable: true,
  },
  {
    name: 'Depth3',
    align: 'center',
    label: 'Depth3',
    field: 'Depth3',
    sortable: true,
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: true,
    field: (row) => row.date,
  },
  { name: 'Comment', align: 'center', label: 'Comment', field: 'Comment' },

  {
    name: 'btn',
    label: 'btn',
    align: 'center',
  },
]);
const initialPagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});
const seed = ref(
  [
  {
    name: 'MA01',
    Depth2: 'temp2',
    Depth3: 'temp3',
    Infor: {
      date: '22.12.01',
      state: '진행중',
      worker: '윤상기',
    },
    Comment: '비고',
    btn: {
      edit: true,
      del: true,
    },
  },
  {
    name: 'MA02',
    Depth2: 'temp2',
    Depth3: 'temp3',
    Infor: {
      date: '22.12.01',
      state: '완료',
      worker: '윤상기',
    },
    Comment: '비고',
    btn: {
      edit: true,
      del: false,
    },
  },
  {
    name: 'test-btn',
    Depth2: 'est-btn',
    Depth3: 'est-btn',
    Infor: {
      date: '22.12.01',
      state: '완료',
      worker: '윤상기',
    },
    Comment: '비고',
    btn: {
      edit: false,
      del: true,
    },
  },
]);
let rows = [];

rows = rows.concat(seed.value.slice(0).map((r) => ({ ...r })));

rows.forEach((row, index) => {
  row.index = index;
});
function clickSample(txt) {
  console.log(txt);
}
function getClass(priority) {
  switch (priority) {
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    default:
      return '';
  }
};
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}
</style>
