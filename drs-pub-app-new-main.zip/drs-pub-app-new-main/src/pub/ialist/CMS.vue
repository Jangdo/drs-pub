<template>
  <div class="wrap_ia_list">
    <q-table
      title="CMS Page"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            {{ props.row.name }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="props.row.name.toLowerCase()">
              {{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td key="Infor" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  {
    name: 'ID071P',
    Depth2: '학습현황',
    Depth3: '수학 - 감성문자',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'ID072P',
    Depth2: '학습현황',
    Depth3: '감성문자 - 보내기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '수정요청완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정중':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss" scoped>
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
.q-tr.edit {
  td {
    background: rgb(255, 171, 227) !important;
  }
}
.q-tr.ing {
  td {
    background: rgb(204, 229, 250) !important;
  }
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}
.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}
.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
