<template>
  <div class="wrap_ia_list">
    <q-table title="기본가이드" :rows="rows" :columns="columns" row-key="index" :pagination="initialPagination" class="table_01">
      <template v-slot:body-cell-link="props">
        <q-td :props="props">
          <router-link :to="props.row.name.toLowerCase()">
            pub/{{ props.row.name.toLowerCase() }}</router-link>
        </q-td>
      </template>
      <template v-slot:body-cell-infor="props">
        <q-td :props="props" :class="getClass(props.row.Infor.state)">
          {{ props.row.Infor.date }}
          <span v-if="props.row.Infor.state">/</span>

          {{ props.row.Infor.state }}
          <span v-if="props.row.Infor.state">/</span>
          {{
  props.row.Infor.worker
          }}

        </q-td>
      </template>

    </q-table>
  </div>

</template>

<script setup>
import { computed, ref } from 'vue';
import { iaListStore } from 'stores/val_ia_list';
const store = iaListStore();
//  리스트 데이터
const seed = computed(() => store.home);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});
// 테이블 헤더 설정
const columns = ref(
  [
    {
      name: 'index',
      label: 'idx',
      align: 'left',
      sortable: true,
      field: (row) => row.index,
    },
    {
      name: 'link',
      label: 'link',
      align: 'left',
      sortable: true,
      field: (row) => row.name,
    },
    {
      name: 'Depth2',
      align: 'left',
      label: 'Depth2',
      field: 'Depth2',
      sortable: true,
    },

    {
      name: 'Depth3',
      align: 'center',
      label: 'Depth3',
      field: 'Depth3',
      sortable: true,
    },
    {
      name: 'infor',
      label: 'infor',
      align: 'center',
      sortable: true,
      field: (row) => row.date,
    },
    { name: 'Comment', align: 'center', label: 'Comment', field: 'Comment' },
  ]);
// 테이블 td 커스텀
let rows = [];
rows = rows.concat(seed.value.slice(0).map((r) => ({ ...r })));
rows.forEach((row, index) => {
  row.index = index;
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    default:
      return 'tobe';
  }
};




</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}
</style>
