<template>
  <div class="wrap_ia_list">
    <q-table
      title="[B]상담"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            {{ props.row.name }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  {
    name: 'B01T',
    Depth2: '입회상담(국장)',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'B0101',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세- 대기중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B0101_1',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세- 매칭회원 있음',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B010101',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세- 대기중 - 상담선생님 지정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B010102P',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세- 대기중  삼담답변',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 변경',
  },
  {
    name: 'B0102',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세 - 상담중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B0104',
    Depth2: '입회상담(국장)',
    Depth3: '상담상세 - 선생님 이관',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'B0105',
    Depth2: '입회상담(국장)',
    Depth3: '상담메모입력',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'B02T',
    Depth2: '입회상담(선생님)',
    Depth3: '- ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'B0201',
    Depth2: '입회상담(선생님)',
    Depth3: '-대기중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B0202',
    Depth2: '입회상담(선생님)',
    Depth3: '-상담중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B0203',
    Depth2: '입회상담(선생님)',
    Depth3: '-상담완료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  // 상담시작하기
  {
    name: 'B0301',
    Depth2: '상담시작하기',
    Depth3: '(국장) - 입회상담',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 버튼',
  },
  {
    name: 'B0301_1',
    Depth2: '상담시작하기',
    Depth3: '(선생님) - 입회상담',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 버튼',
  },
  {
    name: 'B030102',
    Depth2: '상담시작하기',
    Depth3: '학습과목 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'B030103',
    Depth2: '상담시작하기',
    Depth3: '입회상담 상세 - 상담중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B030103_1',
    Depth2: '상담시작하기',
    Depth3: '(국장) - 입회상담 상세 - 상담중',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'B030104',
    Depth2: '상담시작하기',
    Depth3: '- 입회상담 - 상담회원 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'B03010401P',
    Depth2: '상담시작하기',
    Depth3: '- 입회상담 - 상담회원 선택 팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'B04T',
    Depth2: '일반상담',
    Depth3: ' -상담상세- 답변쓰기 -미답변(고객불만)국장-대기중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'B0401_type1',
    Depth2: '일반상담',
    Depth3: '-상담상세- 답변쓰기- 매칭회원있음',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'B0401_type2',
    Depth2: '일반상담',
    Depth3: '-상담상세- 답변쓰기- 미답변(그외)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼',
  },
  {
    name: 'B0402',
    Depth2: '일반상담',
    Depth3: '-상담상세- 상담완료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
//
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '완료후 완료 예정':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}
.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}
.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
