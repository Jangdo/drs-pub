<template>
  <header class="header" style="background: rgb(255, 113, 136)">
    <div class="title_area">
      <h1>IA List</h1>
    </div>
    <div class="link_box" v-if="$q.screen.name == 'lg'">
      <router-link
        v-for="(item, index) in iaLinkData"
        :key="index"
        :to="item.link"
      >
        {{ item.txt }}{{ item.index }}{{ item.index }}
      </router-link>
    </div>
    <q-btn
      color="primary"
      fab
      :icon="item_menu == true ? 'close' : 'menu'"
      v-else
      ref="target"
    >
      <q-menu transition-show="fade" transition-hide="fade" v-model="item_menu">
        <q-list style="min-width: 100px">
          <q-item
            clickable
            v-close-popup
            v-for="(item, index) in iaLinkData"
            :key="index"
          >
            <router-link :to="item.link"> {{ item.txt }}</router-link>
          </q-item>
        </q-list>
      </q-menu>
    </q-btn>
  </header>
</template>
<script setup>
import { ref } from 'vue';
import { useQuasar } from 'quasar';
const item_menu = ref(false);
const iaLinkData = ref([
  {
    txt: '퍼블리싱 가이드',
    link: '/pub/',
  },
  {
    txt: '[A]전체메뉴',
    link: '/pub/list_a',
  },
  {
    txt: '[B]상담',
    link: '/pub/list_b',
  },
  {
    txt: '[C]수업',
    link: '/pub/list_c',
  },
  {
    txt: '[D]회원',
    link: '/pub/list_d',
  },
  {
    txt: '[E]마이',
    link: '/pub/list_e',
  },
  {
    txt: '[H]공통관리',
    link: '/pub/admin',
  },
  {
    txt: '[G]조직관리',
    link: '/pub/list_g',
  },
  {
    txt: '[F]커뮤니티',
    link: '/pub/list_F',
  },
  {
    txt: 'CMS',
    link: '/pub/CMS',
  },

  // {
  //   txt: 'Home',
  //   link: '/pub/home',
  // },
]);
const $q = useQuasar();
</script>
<style lang="scss">
.snb {
  background: #fff;
}
</style>
