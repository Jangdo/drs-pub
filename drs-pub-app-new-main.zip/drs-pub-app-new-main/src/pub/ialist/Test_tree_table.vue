<template>
  <div class="q-pa-md q-gutter-sm">
    <q-tree :nodes="customize" node-key="label" default-expand-all>
      <template v-slot:default-header="prop">
        <div class="row items-center">
          <div class="text-weight-bold text-primary">
            <!-- {{ prop.node.label }} -->
            <q-btn
              flat
              color="white"
              text-color="black"
              icon-right="ion-ios-link"
              :label="prop.node.label"
              :to="prop.node.link"
              @click="test(prop.node)"
            ></q-btn>
          </div>
        </div>
      </template>
    </q-tree>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const customize = ref([
  {
    label: 'Satisfied customers',
    link: '/pub-admin/h010101t',
    children: [
      {
        label: 'a',
        link: '/pub',
        children: [
          {
            label: 'Quality ingredients',
            link: '/pub',
            children: [
              {
                label: '4depth',
                link: '/4depth',
              },
            ],
          },
          {
            label: 'Good recipe',
            body: 'story',
            link: '/pub-admin/h010101t',
          },
        ],
      },
      {
        label: 'Good service',
        body: 'toggle',
        caption:
          'Why are we as consumers so captivated by stories of great customer service? Perhaps it is because...',
        enabled: false,
        children: [
          { label: 'Prompt attention', link: '/pub-admin/h010101t' },
          { label: 'Professional waiter', link: '/pub' },
        ],
      },
      {
        label: 'Pleasant surroundings',
        link: '/pub',
        children: [
          { label: 'Happy atmosphere', link: '/pub' },
          {
            label: 'Good table presentation',
            link: '/pub',
          },
          { label: 'Pleasing decor', link: '/pub' },
        ],
      },
    ],
  },
]);
function test(p) {
  console.log(p);
}
</script>
