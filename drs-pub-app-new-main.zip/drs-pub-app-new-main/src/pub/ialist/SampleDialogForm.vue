<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">기본정보 관리</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <section class="section_form">
            <!-- inner_list -->
            <ul class="inner_list">
              <li>
                <span class="as_dt required">생년월일</span>
                <q-input
                  outlined
                  v-model="date"
                  class="as_dd hide_label inp_date"
                >
                  <template v-slot:label>생년월일</template>
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date minimal v-model="date">
                          <div class="row items-center justify-end">
                            <q-btn
                              v-close-popup
                              label="확인"
                              color="primary"
                              flat
                            />
                          </div>
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </li>
              <li>
                <span class="as_dt required">성별</span>
                <q-btn-toggle
                  v-model="gender"
                  spread
                  toggle-color="positive"
                  text-color="grey-3"
                  class="as_dd inp_gender"
                  :options="[
                    { label: '남자', value: '남' },
                    { label: '여자', value: '여' },
                  ]"
                />
              </li>
              <li>
                <span class="as_dt required">학년</span>
                <q-select
                  class="as_dd"
                  outlined
                  dense
                  v-model="dataFrom.grade"
                  :options="gradeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                ></q-select>
              </li>
              <li>
                <span class="as_dt required">주소</span>
                <q-input
                  v-model="dataFrom.address"
                  class="as_dd hide_label inp_search"
                  label="* 주소"
                  outlined
                  placeholder="주소를 검색하세요"
                  stack-label
                  dense
                >
                  <template v-slot:label>주소</template>
                  <template v-slot:append>
                    <q-btn flat :ripple="false">
                      <q-icon name="icon-search_m" class="icon_svg"></q-icon>
                    </q-btn>
                  </template>
                </q-input>
                <q-input
                  v-model="dataFrom.address2"
                  class="as_dd hide_label inp_search2"
                  disabled
                  label="상세주소"
                  outlined
                  placeholder=""
                  stack-label
                  dense
                >
                  <template v-slot:label>상세주소</template>
                </q-input>
              </li>
              <li>
                <span class="as_dt required">휴대폰 번호</span>
                <div class="wrap_input">
                  <q-input
                    v-model="dataFrom.phone"
                    class="as_dd hide_label"
                    label="* 휴대폰 번호"
                    outlined
                    placeholder="휴대폰 번호를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>휴대폰 번호</template>
                  </q-input>
                  <q-btn
                    fill
                    unelevated
                    class="btn_check"
                    color="grey-2"
                    label="중복확인"
                  />
                </div>
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_certi_num full-width"
                  color="grey-5"
                  label="인증번호 발송"
                />
                <q-input
                  v-model="dataFrom.certi"
                  class="as_dd hide_label inp_certi"
                  label="* 인증번호"
                  outlined
                  placeholder="인증번호 4자리 숫자를 입력"
                  stack-label
                  dense
                >
                  <template v-slot:append>
                    <span class="time_count text-orange">05:00</span>
                  </template>
                </q-input>
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_certi_num full-width"
                  color="grey-5"
                  label="인증번호 확인"
                />
              </li>
              <li class="hasCheckbox">
                <div class="as_dd">
                  <q-checkbox
                    v-model="dataCheck.parent"
                    dense
                    color="orange"
                    class="inp_check"
                    label="대표보호자 지정"
                  />
                </div>
              </li>

              <li>
                <span class="as_dt"
                  >회원이 조직원 본인이거나 조직원의 자녀인가요?</span
                >
                <div class="form_data has_radio">
                  <q-radio
                    v-model="dataRadio"
                    dense
                    val="Y"
                    label="예"
                    color="orange"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                  />
                  <q-radio
                    v-model="dataRadio"
                    dense
                    val="N"
                    label="아니오"
                    color="orange"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                  />
                </div>
              </li>
              <li>
                <span class="as_dt">증빙자료</span>
                <p class="caption">
                  증빙자료 정보동의서가 없는 경우 감사대상이 될 수 있습니다.
                  증빙자료는 신청일로 부터 1년간 보관됩니다.<span
                    class="text-orange"
                    >(jpg, jpeg, gif, tif, pdf 등록 가능합니다)</span
                  >
                </p>
                <div class="wrap_input">
                  <q-file
                    outlined
                    dense
                    clearable
                    v-model="dataFrom.information"
                    placeholder="정보동의서를 선택"
                    label="정보동의서를 선택"
                    class="hide_label file_custom"
                  >
                    <template v-slot:after>
                      <q-btn
                        fill
                        unelevated
                        class="btn_file_select"
                        color="grey-2"
                        label="선택"
                      />
                    </template>
                    <template v-slot:append>
                      <q-btn flat dense :ripple="false" class="btn_input_slot">
                        <q-icon
                          v-if="dataFrom.information === null"
                          name="icon-search_m"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                    </template>
                  </q-file>
                </div>
                <div class="wrap_input">
                  <q-file
                    outlined
                    dense
                    clearable
                    v-model="dataFrom.family"
                    placeholder="가족관계증명서 선택"
                    label="가족관계증명서 선택"
                    class="hide_label file_custom"
                  >
                    <template v-slot:after>
                      <q-btn
                        fill
                        unelevated
                        class="btn_file_select"
                        color="grey-2"
                        label="선택"
                      />
                    </template>
                    <template v-slot:append>
                      <q-btn flat dense :ripple="false" class="btn_input_slot">
                        <q-icon
                          v-if="dataFrom.family === null"
                          name="icon-search_m"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                    </template>
                  </q-file>
                </div>
              </li>
            </ul>
            <!--// inner_list -->
            <hr class="separator" />
            <!-- 조직여부관리 아니오 선택시 -->
            <section class="section_form">
              <p class="info_txt">
                조직원 또는 조직원인 경우 “예'를 선택하시고 정보를 입력해주세요.
              </p>
              <p class="info_txt">교육지원비는 추후 월급에 반영됩니다.</p>
            </section>
            <hr class="separator" />
            <!-- //조직여부관리 아니오 선택시 -->
          </section>
          <section class="section_form">
            <div class="box_form_group outline">
              <div class="group_top_area">
                <p class="info_head">승인 요청 정보</p>
                <p class="info_txt">신청대상: <span>직원 자녀</span></p>
                <p class="info_txt">
                  조직원 정보:
                  <span>김대교 (010011 - 대전세종본부 / 대전세종지원팀)</span>
                </p>
              </div>
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt">증빙자료</span>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      dense
                      clearable
                      readonly
                      v-model="dataFrom.information"
                      placeholder="정보동의서를 선택"
                      label="정보동의서를 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <!-- <q-icon v-if="dataFrom.information === null" name="icon-search_m" class="icon_svg"></q-icon> -->
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      clearable
                      dense
                      readonly
                      v-model="dataFrom.family"
                      placeholder="가족관계증명서 선택"
                      label="가족관계증명서 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <!-- <q-icon v-if="dataFrom.family === null" name="icon-search_m" class="icon_svg"></q-icon> -->
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </div>
          </section>
          <section class="section_form text-center">
            <p class="info_tit">
              조직원 신청 <span class="text-orange">대기중</span> 입니다
            </p>
            <p class="info_txt">
              팀장 및 국장의 승인 완료 후 신청이 완료됩니다
            </p>
            <q-table
              :rows="userRows"
              :columns="userColumns"
              row-key="code"
              hide-bottom
              hide-pagination
              separator="cell"
              class="tbl_custom"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="companion" class="companion">
                    <span class="text-orange">{{ props.row.name }}</span>
                    <span class="text-grey-3">{{ props.row.name2 }}</span>
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </section>
          <!-- <hr class="separator" /> -->
          <!-- <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p> -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            v-close-popup
            class="size_lg btn_cancel"
            color="black"
            label="취소"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const gender = ref('남');
const date = ref('2023/02/01');
const dataFrom = ref({
  id: '',
  phone: '',
  txt: '',
  address: '주소를 입력하세요',
  address2: '',
  sys: '선택하세요',
  grade: '선택하세요',
  allow: 'true',
});
const dataCheck = ref({
  parent: false,
  positive: true,
  negative: true,
  brown: true,
});
const gradeOption = ref([
  {
    id: 'type01',
    desc: '1학년',
  },
  {
    id: 'type02',
    desc: '2학년',
  },
]);
const userRows = ref([
  {
    name: '반려',
    name2: '(2023.02.01)',
  },
]);
const userColumns = ref([
  {
    name: 'companion',
    label: '국장',
    sortable: false,
    align: 'center',
    field: (row) => row.path,
  },
]);
const dataRadio = ref('Y');
</script>
<style lang="scss"></style>
