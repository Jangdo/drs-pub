<template>
  <input type="time" value="13:30"/>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>
  <div class="row q-col-gutter-sm q-py-sm">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #ea4b64">
        <q-card-section class="text-h6 text-white">
          chart_column
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_column"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #666">
        <q-card-section class="text-h6 text-white"> chart_line </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_line"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #38b1c5">
        <q-card-section class="text-h6 text-white">
          chart_bubble
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_bubble"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #38b1c5">
        <q-card-section class="text-h6 text-white">
          circle q-knob</q-card-section
        >
        <q-card-section class="q-pa-none row" style="background: #f1f7fb">
          <q-knob
            readonly
            v-model="circle1"
            show-value
            size="127px"
            :thickness="0.3"
            color="blue-10"
            track-color="grey-6"
            class=""
          >
            <div class="label_area">
              <div class="text-body3 text-center">월누적</div>
              <div class="text-h3">{{ circle1 }}%</div>
            </div>
          </q-knob>

          <q-knob
            readonly
            v-model="circle2"
            show-value
            size="127px"
            :thickness="0.3"
            color="orange-10"
            track-color="grey-6"
            class=""
          >
            <div class="label_area">
              <div class="text-body3 text-center">2주차</div>
              <div class="text-h3">{{ circle2 }}%</div>
            </div></q-knob
          >
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #fcb813">
        <q-card-section class="text-h6 text-white">
          chart_column_shadow
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_column_shadow"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #fcb813">
        <q-card-section class="text-h6 text-white"> chart_pie </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_pie"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #fcb813">
        <q-card-section class="text-h6 text-white"> chart_pie2 </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts :options="chart_pie2"></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import accessibility from 'highcharts/modules/accessibility';
import Highcharts from 'highcharts';

// q-knob circle
const circle1 = ref(80);
const circle2 = ref(70);
// Highcharts
HighchartsMore(Highcharts);
accessibility(Highcharts);
Highcharts.setOptions({
  colors: ['#f27321', '#fcb813', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'], // 차트 막대 색상

  lang: {
    thousandsSep: ',',
  },
});
const chart_column = {
  colors: ['#0964CE', '#BCD5F2', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'],
  chart: {
    type: 'column',
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontWeight: 700,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  xAxis: {
    categories: ['입회', '퇴회', '순증', '현재총원'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: {
    min: 0,
    tickInterval: 100,
    title: false,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  tooltip: {
    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    // pointFormat:
    //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
    footerFormat: '</table>',
    shared: true,
    useHTML: true,
  },
  plotOptions: {
    column: {
      pointPadding: 0.4,
      borderWidth: 0,
      borderRadius: 3,
      pointWidth: 7,
    },
  },

  series: [
    {
      name: '외방',
      data: [230, 110, 310, 480],
    },
    {
      name: '내방',
      data: [310, 40, 400, 550],
    },
  ],
};
const chart_column_shadow = {
  chart: {
    backgroundColor: '#F1F7FB',
    type: 'column',
  },
  title: false,
  xAxis: {
    categories: ['월요일', '화요일', '수요일', '목요일', '금요일'],
  },
  yAxis: [
    {
      min: 0,
      max: 100,
      opposite: false,
    },
  ],
  legend: false,
  tooltip: {
    shared: false,
  },
  plotOptions: {
    column: {
      grouping: false,
      shadow: false,
      borderWidth: 0,
      borderRadius: 2,
      pointWidth: 24,
    },
  },

  series: [
    {
      name: '목표',
      color: 'rgba(85 ,93, 103 ,0.4)',
      data: [100, 100, 100, 100, 100],
      pointPadding: 0.3,
      pointPlacement: -0.2,
    },
    {
      name: '달성',
      color: '#555D67',
      data: [88, 90, 0, 0, 0],
      pointPadding: 0.3,
      pointPlacement: -0.2,
      dataLabels: [
        {
          // pointFormat:
          //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          format: '{point.y}%',
          enabled: true,
          inside: true,
          style: {
            textOutline: false,
            color: '#fff',
            fontSize: 12,
            fontWeight: '400',
            fontFamily: 'Pretendard',
          },
        },
      ],
    },
  ],
};
const chart_line = {
  colors: ['#BCD5F2', '#9747FF', '#44b87b', '#FF6B23', '#555d67', '#c0c4cd'],
  chart: {
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,

  yAxis: {
    title: false,
    labels: {
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  xAxis: {
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  plotOptions: {
    line: {
      marker: false,
    },
    series: {
      label: {
        connectorAllowed: false,
      },
      // pointStart: 2010,
    },
  },

  series: [
    {
      name: '회원매출액',
      data: [74000, 80000, 100000, 125000, 150000, 160000],
    },
    {
      name: '회원당매출액',
      data: [50000, 60000, 70000, 67000, 24000, 50000],
    },
    {
      name: '입금총액',
      data: [54000, 74000, 78000, 69000, 80000, 82000],
    },
    {
      name: '입금률(%)',
      data: [82000, 72000, 62000, 54000, 12000, 72000],
    },
  ],

  responsive: {
    rules: [
      {
        condition: {
          maxWidth: 500,
        },
        chartOptions: {
          legend: {
            //  layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            itemMarginTop: 0,
            itemMarginBottom: 28,
            itemStyle: {
              color: '#000',
              fontWeight: 700,
              fontFamily: 'Pretendard',
              fontSize: '14px',
            },
          },
        },
      },
    ],
  },
};

const chart_bubble = {
  colors: ['#0080B6', '#44B87B', '#F27321', '#FCB813', '#0080B6', '#44B87B'],
  chart: {
    type: 'bubble',
    plotBorderWidth: 1,
    zoomType: 'xy',
    backgroundColor: '#F1F7FB',
  },

  legend: {
    enabled: false,
  },

  title: false,

  subtitle: false,

  accessibility: {
    point: {
      valueDescriptionFormat:
        '{index}. {point.name}, fat: {point.x}g, sugar: {point.y}g, obesity: {point.z}%.',
    },
  },

  xAxis: {
    categories: ['1월', '2월', '3월', '4월 ', '5월', '6월', ''],
    gridLineWidth: 1,
    gridLineDashStyle: 'longdash',
    labels: {
      format: '{value}',
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },

    plotLines: [
      {
        label: {
          rotation: 0,
          y: 15,
          style: {
            fontStyle: 'italic',
          },
        },
        zIndex: 3,
      },
    ],
    accessibility: {
      rangeDescription: 'Range: 60 to 100 grams.',
    },
  },

  yAxis: {
    min: 0,
    max: 100,
    startOnTick: true,
    endOnTick: true,
    title: false,
    subtitle: false,
    labels: { enabled: false, format: '{value}월' },
    maxPadding: 0.2,

    plotLines: [
      {
        // color: 'black',
        dashStyle: 'dot',
        // width: 2,
        value: 0,
        label: {
          align: 'right',
          style: {
            fontStyle: 'italic',
          },

          x: -10,
        },
        zIndex: 3,
      },
    ],
    accessibility: {
      rangeDescription: 'Range: 0 to 160 grams.',
    },
  },

  tooltip: {
    enabled: false,
    useHTML: true,
    headerFormat: '<table>',
    pointFormat:
      '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
      '<tr><th>Fat intake:</th><td>{point.x}g</td></tr>' +
      '<tr><th>Sugar intake:</th><td>{point.y}g</td></tr>' +
      '<tr><th>Obesity (adults):</th><td>{point.z}%</td></tr>',
    footerFormat: '</table>',
    followPointer: true,
  },

  plotOptions: {
    series: {
      dataLabels: {
        enabled: true,
        format: '{point.y}',
      },
    },
    bubble: {
      color:'white',
      marker: {
        fillOpacity:1
      },
      minSize: 40,
      maxSize: 80,
      dataLabels: {
        style: {
          textOutline: false,
          color: '#000',
          fontSize: 12,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
      },
    },
  },

  series: [
    {
      data: [
        { y: 30, z: 30 },
        { y: 52.15, z: 52.15 },
        { y: 88, z: 88 },
        { y: 88, z: 88 },
        { y: 45, z: 45 },
        { y: 66.08, z: 66.08 },
      ],
      colorByPoint: true,
    },
  ],
};
const chart_pie = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
    type: 'pie',
    backgroundColor: '#F1F7FB',
  },
  colors: [
    '#BCD5F2',
    '#9747FF',
    '#44B87B',
    '#EFD26A',
    '#555d67',
    '#0964CE',
    '#BD0000',
    '#00B2BD',
    '#BD00AA',
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontSize: '14',
      lineHight: '16',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  title: false,
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },
  accessibility: {
    point: {
      valueSuffix: '%',
    },
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '{point.percentage:.2f}',
        style: {
          textOutline: false,
          color: '#fff',
          fontSize: 9,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
        distance: -20,
        filter: {
          property: 'percentage',
          operator: '>',
          value: 1,
        },
      },
      showInLegend: true,
    },
  },
  series: [
    {
      name: '과목',
      borderWidth: 0,

      data: [
        { name: '국어', y: 35.7 },
        { name: '영어', y: 38.0 },
        { name: '수학', y: 12.5 },
        { name: '사회과학', y: 7.1 },
        { name: '내신완공', y: 3.1 },
        { name: '한자일본어', y: 3.6 },
        { name: '유아', y: 3.6 },
        { name: '기타', y: 3.6 },
      ],
    },
  ],
};
const chart_pie2 = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
    type: 'pie',
    backgroundColor: '#F1F7FB',
  },
  colors: [
    '#0964CE',
    '#BCD5F2',
    '#44B87B',
    '#EFD26A',
    '#555d67',
    '#0964CE',
    '#BD0000',
    '#00B2BD',
    '#BD00AA',
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontSize: '14',
      lineHight: '16',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  title: false,
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },
  accessibility: {
    point: {
      valueSuffix: '%',
    },
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '{point.percentage:.2f}',
        style: {
          textOutline: false,
          color: '#fff',
          fontSize: 9,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
        distance: '-50%',

        filter: {
          property: 'percentage',
          operator: '>',
          value: 1,
        },
      },
      showInLegend: true,
    },
  },
  series: [
    {
      name: '과목',
      borderWidth: 0,
      data: [
        { name: '디지털 학습', y: 51.9 },
        { name: '페이퍼 학습', y: 46.1 },
      ],
    },
  ],
};
</script>
<style lang="scss">
.vue-highcharts {
  width: 100%;
}
.my-card {
  width: 100%;
  max-width: 500px;
}

.circle_shape {
  height: 0;
  margin: 0 auto;
  width: 40%;
  padding-bottom: 40%;
  border-radius: 60px !important;
  outline: 1px solid #eee;
  border: 1px solid #aaa;
}

.stack-column-round .highcharts-axis-line {
  // stroke: #7cb5ec;
}
</style>

