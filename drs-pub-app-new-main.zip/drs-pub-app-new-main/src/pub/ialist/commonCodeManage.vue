<template>
  <div class="q-py-lg w900 page_admin">
    <q-breadcrumbs class="location_admin">
      <q-breadcrumbs-el label="HOME" to="/" />
      <q-breadcrumbs-el label="공통코드관리" to="/" />
      <q-breadcrumbs-el :label="$route.name" />
    </q-breadcrumbs>

    <div class="q-py-sm">
      <h2 class="text24b">공통코드관리</h2>
    </div>
    <div class="q-py-sm">
      <div class="q-gutter-y-lg">
        <q-tabs
          v-model="tab"
          color="white"
          active-color="brown-4"
          indicator-color="transparent"
          align="justify"
          class="tab_basic bg-white"
        >
          <q-tab name="topCode" label="상위코드" /> 
          <q-tab name="subCode" label="하위코드" />
        </q-tabs>

        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="topCode">
            <div class="q-pa-lg">
              <div class="row q-gutter-x-md flex justify-between mb56">
                <div class="w260">
                  <q-select outlined v-model="dataSelect" label="코드를 선택하세요" :options="dataSelectOption" dense>
                  </q-select>
                </div>
                <div class="col">
                  <q-input outlined for="test" v-model="dataInput" label="코드 or 코드명을 입력하세요" dense />
                </div>
                <div class="">
                  <q-btn fill color="grey-9" label="조회" class="size_md" />
                </div>
                <div class="">
                  <q-btn outline color="grey-9" label="초기화" class="size_md" icon="refresh" />
                </div>
              </div>
              <div class="row q-gutter-x-sm flex justify-between mb14">
                <q-btn outline color="grey-9" label="행추가" class="size_sm" icon="add" />
                <q-btn outline color="grey-9" label="행삭제" class="size_sm" icon="remove" />
                <q-space />
                <q-btn fill color="black" label="저장" class="size_sm" icon="save" />
              </div>
              <div class="mb14">
                <q-table
                  title="Treats"
                  :rows="rows"
                  :columns="columns"
                  row-key="name"
                  selection="single"
                  v-model:selected="selected"
                  separator="cell"
                />
                <div class="q-pa-lg flex flex-center">
                  <q-pagination
                    v-model="current"
                    :max="5"
                    color="grey-8"
                    active-color="black"
                    direction-links
                    boundary-links
                    icon-first="keyboard_double_arrow_left"
                    icon-last="keyboard_double_arrow_right"
                    icon-prev="keyboard_arrow_left"
                    icon-next="keyboard_arrow_right"
                  />
                </div>
                <!-- <template v-slot:header-selection="scope">
                  <q-toggle v-model="scope.selected" />
                </template> -->
                <!-- <q-table title="기본가이드" :rows="seed" :columns="columns" row-key="index" :pagination="initialPagination" class="table_01">

                  <template v-slot:body-cell-index="props">
                    <q-td :props="props">
                      {{ props.rowIndex }}
                    </q-td>
                  </template>
                  <template v-slot:body-cell-link="props">
                    <q-td :props="props">
                      <router-link :to="props.row.name.toLowerCase()">
                        pub/{{ props.row.name.toLowerCase() }}</router-link>
                    </q-td>
                  </template>
                  <template v-slot:body-cell-infor="props">
                    <q-td :props="props" :class="getClass(props.row.Infor.state)">
                      {{ props.row.Infor.date }}/{{ props.row.Infor.state }}/{{
                        props.row.Infor.worker
                      }}
                    </q-td>
                  </template>
                  <template v-slot:body-cell-Comment="props">
                    <q-td :props="props" :class="getClass(props.row.Infor.state)">
                      <div v-if="props.row.edit" class="box_td_input">
                        <q-input v-model:model-value="props.row.Comment" :dense="true" />
                        <q-btn unelevated color="primary" icon="check" size="xs" v-if="props.row.btn.edit"
                          @click="seed[props.rowIndex].edit = false" />
                      </div>

                      <q-btn flat @click="seed[props.rowIndex].edit = true" v-else>
                        {{
                          props.row.Comment
                        }}
                      </q-btn>


                    </q-td>
                  </template>
                  <template v-slot:body-cell-btn="props">
                    <q-td :props="props" :class="getClass(props.row.Infor.state)">
                      <div class="btn_inner_table">
                        <q-btn unelevated color="primary" icon="edit" size="sm" v-if="props.row.btn.edit"
                          @click="clickSample(props.row)" />
                        <q-btn unelevated color="negative" icon="delete" size="sm" v-if="props.row.btn.del"
                          @click="clickSample('삭제되었습니다.')" />
                      </div>
                    </q-td>
                  </template>
                </q-table> -->
              </div>
            </div>
          </q-tab-panel>

          <q-tab-panel name="subCode">
            <q-card>
              subCode
            </q-card>
          </q-tab-panel>

        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const tab = ref('topCode');

const dataSelect = ref('');
const dataSelectOption = ref(['a', 'b', 'c', 'd', 'e']);

const current = ref(1);
const columns = [
  {
    name: 'name',
    required: true,
    label: '코드',
    align: 'center',
    field: row => row.name,
    format: val => `${val}`,
    sortable: false
  },
  { name: 'calories', align: 'center', label: '코드명', field: 'calories', sortable: false },
  { name: 'fat', align: 'center', label: '상태', field: 'fat', sortable: false },
  { name: 'carbs', align: 'center', label: '사용여부', field: 'carbs' },
]

const rows = [
  {
    name: 'Frozen Yogurt',
    calories: 159,
    fat: 6.0,
    carbs: 24,
    protein: 4.0,
    sodium: 87,
    calcium: '14%',
    iron: '1%'
  },
  {
    name: 'Ice cream sandwich',
    calories: 237,
    fat: 9.0,
    carbs: 37,
    protein: 4.3,
    sodium: 129,
    calcium: '8%',
    iron: '1%'
  },
  {
    name: 'Eclair',
    calories: 262,
    fat: 16.0,
    carbs: 23,
    protein: 6.0,
    sodium: 337,
    calcium: '6%',
    iron: '7%'
  },
  {
    name: 'Cupcake',
    calories: 305,
    fat: 3.7,
    carbs: 67,
    protein: 4.3,
    sodium: 413,
    calcium: '3%',
    iron: '8%'
  },
  {
    name: 'Gingerbread',
    calories: 356,
    fat: 16.0,
    carbs: 49,
    protein: 3.9,
    sodium: 327,
    calcium: '7%',
    iron: '16%'
  },
  {
    name: 'Jelly bean',
    calories: 375,
    fat: 0.0,
    carbs: 94,
    protein: 0.0,
    sodium: 50,
    calcium: '0%',
    iron: '0%'
  },
  {
    name: 'Lollipop',
    calories: 392,
    fat: 0.2,
    carbs: 98,
    protein: 0,
    sodium: 38,
    calcium: '0%',
    iron: '2%'
  },
  {
    name: 'Honeycomb',
    calories: 408,
    fat: 3.2,
    carbs: 87,
    protein: 6.5,
    sodium: 562,
    calcium: '0%',
    iron: '45%'
  },
  {
    name: 'Donut',
    calories: 452,
    fat: 25.0,
    carbs: 51,
    protein: 4.9,
    sodium: 326,
    calcium: '2%',
    iron: '22%'
  },
  {
    name: 'KitKat',
    calories: 518,
    fat: 26.0,
    carbs: 65,
    protein: 7,
    sodium: 54,
    calcium: '12%',
    iron: '6%'
  }
]
</script>