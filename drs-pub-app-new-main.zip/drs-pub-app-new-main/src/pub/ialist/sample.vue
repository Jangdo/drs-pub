<template>
  <div class="wrap_ia_list">
    <q-intersection
      transition="jump-up"
      transitionDuration="400"
      id="container"
    >
      <div class="q-pa-md row items-start q-gutter-md mb50">
        <!-- section_tit -->
        <div class="sample_box">
          <div class="text-subtitle2">section_tit</div>
          <q-card-section>
            <!-- section_tit -->
            <div class="section_tit">
              <h3 class="icon_txt">
                <div class="txt">
                  <q-icon name="settings"></q-icon>
                  학습중
                </div>
                <span class="impact">43</span>
                <span> 과목 </span>
              </h3>
              <q-btn to="" flat>
                <q-icon name="icon-arrow-right" class="icon_svg"></q-icon>
                <div class="a11y">바로가기</div>
              </q-btn>
            </div>
            <!-- section_tit -->
          </q-card-section>
        </div>

        <!-- section_tit -->
        <div class="sample_box">
          <div class="text-subtitle2">.tit_area.with_link</div>
          <q-card-section>
            <!-- gray_roundbox tit_area with_link -->
            <div class="gray_roundbox">
              <div class="tit_area with_link">
                <p class="title3">
                  <span class="text-primary">신대방 LC</span>
                  출결현황
                </p>
                <q-btn to="" flat>
                  <q-icon name="keyboard_arrow_right" class="icon_svg"></q-icon>
                  <div class="a11y">바로가기</div>
                </q-btn>
              </div>
              <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
            </div>
            <!-- gray_roundbox tit_area with_link -->
          </q-card-section>
        </div>

        <!-- section_card_profile -->
        <div class="sample_box">
          <div class="text-subtitle2">section_card_profile</div>

          <!-- section_card_profile -->
          <section class="section_card_profile">
            <q-card class="card_profile" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_member_info"
                  label="회원정보"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_lesson_manage"
                  label="학습관리"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_pay_status"
                  label="회비현황"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_history_manage"
                  label="이력관리"
                >
                </q-btn>
              </div>
              <!--// main_btn_area -->
              <!-- parents_area -->
              <div class="parents_area">
                <p class="tit title3">김윤찬 어머님</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_map"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->

          <!-- section_card_profile-->
          <section class="section_card_profile">
            <q-card class="card_profile" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <hr class="border" />
              <!-- parents_area -->
              <div class="parents_area">
                <p class="tit title3">선생님 메모</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_map"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->
          <!-- section_card_profile type02-->
          <section class="section_card_profile">
            <q-card class="card_profile type02" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_member_info"
                  label="회원정보"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_lesson_manage"
                  label="학습관리"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_pay_status"
                  label="회비현황"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_history_manage"
                  label="이력관리"
                >
                </q-btn>
              </div>
              <!--// main_btn_area -->
              <!-- parents_area -->
              <!-- <div class="parents_area">
                  <p class="tit title3"></p>
                  <div class="btn_area">
                    <q-btn
                      round
                      fill
                      unelevated
                      color="grey-4"
                      icon=""
                      class="btn_add_study"
                    />
                  </div>
                </div> -->
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile type02-->
          <!-- section_card_profile -->
          <section class="section_card_profile">
            <q-card class="card_profile type02" flat>
              <!-- infor_area -->
              <div class="infor_area items-center">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김대교</p>
                    <span class="member_number">선생님</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn flat stack dense icon="" class="btn_myAlarm">
                  <p>알림 <span class="text-green-2">9</span></p>
                </q-btn>
                <hr class="h_separator" />
                <q-btn flat stack dense icon="" class="btn_myComplete">
                  <p>승인 <span class="text-green-2">4</span></p>
                </q-btn>
                <hr class="h_separator" />
                <q-btn flat stack dense icon="" class="btn_myConfirm">
                  <p>승인요청 <span class="text-green-2">5</span></p>
                </q-btn>
              </div>
              <!--// main_btn_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->

          <!-- section_card_profile -->
          <section class="section_card_profile type02">
            <q-card class="card_profile" flat>
              <div class="infor_area_wrap">
                <!-- infor_area -->
                <div class="infor_area">
                  <div class="photo">
                    <div class="pic_area">
                      <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                    </div>
                    <button type="button" class="btn_add" aria-label="사진변경">
                      <q-icon name="icon-plus-grey" class="icon_svg"></q-icon>
                    </button>
                  </div>
                  <div class="txt_area">
                    <div class="tit_area">
                      <span class="badge">신입</span>
                      <p class="tit text-h2">김윤찬</p>
                      <span class="member_number">(P15907)</span>
                    </div>
                    <div class="more text-body2">
                      <span>초등1</span>
                      <span>강남교육국 외2</span>
                    </div>
                  </div>
                </div>
                <!--// infor_area -->

                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_write"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_map"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_view"
                  />
                </div>
              </div>

              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_member_info"
                  label="회원정보"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_lesson_manage"
                  label="학습관리"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_pay_status"
                  label="회비현황"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_history_manage"
                  label="이력관리"
                >
                </q-btn>
              </div>
              <!--// main_btn_area -->
              <!-- parents_area -->
              <div class="parents_area">
                <p class="tit title3">김윤찬 어머님</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="green-2"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->
        </div>

        <!-- section_profile_small -->
        <div class="sample_box">
          <div class="text-subtitle2">section_profile_small</div>
          <q-card-section>
            <section class="list_profile_small">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="state_area">
                    <q-icon name="icon-id-green" class="icon_svg"></q-icon>
                    <q-icon name="icon-cake-orange" class="icon_svg"></q-icon>
                    <q-icon name="icon-hand-brown" class="icon_svg"></q-icon>
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
            </section>
            <section class="list_profile_small">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="state_area">
                    <q-icon name="icon-id-green" class="icon_svg"></q-icon>
                    <q-icon name="icon-cake-orange" class="icon_svg"></q-icon>
                    <q-icon name="icon-hand-brown" class="icon_svg"></q-icon>
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="subject_area">
                <div class="row">
                  <div class="tag_txt text-body1">눈높이 수학</div>
                  <div class="tag_txt text-body1">눈높이 국어</div>
                  <div class="tag_txt text-body1">눈높이 한자</div>
                </div>
                <div class="row">
                  <div class="tag_txt text-body1">써밋 스피드 국어</div>
                  <div class="tag_txt text-body1">써밋 스피드 수학</div>
                </div>
              </div>
            </section>
            <section class="list_profile_small active">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="state_area">
                    <q-icon name="icon-id-green" class="icon_svg"></q-icon>
                    <q-icon name="icon-cake-orange" class="icon_svg"></q-icon>
                    <q-icon name="icon-hand-brown" class="icon_svg"></q-icon>
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
            </section>
            <section class="list_profile_small active">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="state_area">
                    <q-icon name="icon-id-green" class="icon_svg"></q-icon>
                    <q-icon name="icon-cake-orange" class="icon_svg"></q-icon>
                    <q-icon name="icon-hand-brown" class="icon_svg"></q-icon>
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="subject_area">
                <div class="row">
                  <div class="tag_txt text-body1">눈높이 수학</div>
                  <div class="tag_txt text-body1">눈높이 국어</div>
                  <div class="tag_txt text-body1">눈높이 한자</div>
                </div>
                <div class="row">
                  <div class="tag_txt text-body1">써밋 스피드 국어</div>
                  <div class="tag_txt text-body1">써밋 스피드 수학</div>
                </div>
              </div>
            </section>
          </q-card-section>
        </div>

        <!-- 학생카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">
            학생카드 section_card_profile lecture
          </div>
          <q-card-section>
            <section class="section_card_profile lecture">
              <q-card class="card_profile" flat>
                <!-- infor_area -->
                <div class="infor_area">
                  <div class="pic_area">
                    <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                  </div>
                  <div class="txt_area">
                    <div class="tit_area">
                      <p class="tit title1">김윤찬</p>
                    </div>
                    <div class="more text-body2">
                      <span>P159072349</span>
                      <span>초등2</span>
                    </div>
                  </div>
                </div>
                <!--// infor_area -->
                <div class="btm_btn_area">
                  <q-btn
                    fill
                    v-close-popup
                    class="full-width size_sm"
                    color="grey-2"
                    label="부교재 신청목록"
                  />
                </div>
              </q-card>
            </section>
          </q-card-section>
        </div>

        <!-- 학생카드 profile_card -->
        <div class="sample_box">
          <div class="text-subtitle2">학생카드 profile_card</div>
          <q-card-section>
            <q-toggle
              color="grey-2"
              label="과목보기"
              left-label
              dense
              v-model="hideSubject"
              val="subject"
            />
            <!-- profile_card -->
            <div class="profile_card">
              <div class="tit_area">
                <div class="row">
                  <span class="tit title1">김윤찬</span>
                  <q-space />
                  <q-badge color="black" class="small">출석</q-badge>
                  <q-badge color="positive" class="small">예정</q-badge>
                  <q-badge color="grey-2" class="small">지각</q-badge>
                  <q-badge color="orange" class="small">결석</q-badge>
                </div>
                <div class="row state">
                  <span class="grade">초등2</span>
                  <q-space />
                  <div class="right">
                    <span class="body2">신규</span>
                    <span class="body2">생일</span>
                    <span class="body2">정성</span>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn
                  round
                  fill
                  unelevated
                  color="grey-5"
                  icon=""
                  class="btn_user"
                />
                <q-btn
                  round
                  fill
                  unelevated
                  color="grey-5"
                  icon=""
                  class="btn_memo"
                />
                <q-btn
                  round
                  fill
                  unelevated
                  color="grey-5"
                  icon=""
                  class="btn_call"
                />
              </div>
              <div class="subject_area" v-show="hideSubject">
                <div class="subject">
                  <span>눈높이 수학</span>
                  <span>, </span>
                  <span>눈높이 국어</span>
                  <span>, </span>
                  <span>눈높이 한자</span>
                  <span>, </span>
                  <span>써밋 스피드 국어</span>
                  <span>, </span>
                  <span>써밋 스피드 수학</span>
                </div>
              </div>
            </div>
            <!-- //profile_card -->
          </q-card-section>
        </div>

        <!-- 학생카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">학생정보 student_card</div>
          <q-card-section>
            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>
            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
                <div class="btm_content">
                  <div class="body1">교사소개</div>
                  <p class="paragraph">
                    상담요청 내용이 노출됩니다. 학부모 메뉴, 디스플레이 밝기,
                    계정 전환 등 불편사항 개선을 요구하심
                  </p>
                </div>
              </div>
            </div>
          </q-card-section>
        </div>

        <!-- 학생카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">
            학생정보 student_card + type02 회원정보
          </div>
          <q-card-section>
            <div class="student_card type02 on">
              <div class="date">
                <p class="body1">2023.03.12</p>
                <p class="body1">2023.03.20</p>
              </div>
              <div class="profile_box">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge color="green" class="small">단체</q-badge>
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">
                  <span>본인인증</span>
                  <span>대기</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli"
                    >눈높이 수학, 솔루니 논술, 눈높이 국어, 눈높이 수학, 솔루니
                    논술</strong
                  >
                </div>
              </div>
            </div>
            <div class="student_card type02">
              <div class="date">
                <p class="body1">2023.03.12</p>
                <p class="body1">2023.03.20</p>
              </div>
              <div class="profile_box">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge color="green" class="small">단체</q-badge>
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">
                  <span>본인인증</span>
                  <span>대기</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli"
                    >눈높이 수학, 솔루니 논술, 눈높이 국어, 눈높이 수학, 솔루니
                    논술</strong
                  >
                </div>
              </div>
            </div>
          </q-card-section>
        </div>

        <!-- 학생카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">
            학생정보 student_card + type03 회원정보
          </div>
          <q-card-section>
            <div class="student_card type03">
              <div class="date">
                <p class="body1">2023.04.04(수)</p>
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="blue" class="medium">승인요청</q-badge>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="medium circle"
                    label="N"
                  />
                </div>
                <div class="wrap_personal_check">
                  <div class="">
                    <q-checkbox
                      v-model="dataCheck"
                      val="check01"
                      label="김윤찬"
                      color="positive"
                      dense
                    />
                    <p class="grade">초등2</p>
                  </div>
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="bottom body2">
                  <div class="bottom_item">
                    <span>구분</span>
                    <strong class="eli">회비대체</strong>
                  </div>
                  <div class="bottom_item">
                    <span>입금과목/대체과목</span>
                    <strong class="eli"
                      >써밋스코어수학 중등1/써밋스코어국어 중등1</strong
                    >
                  </div>
                  <div class="bottom_item">
                    <span>요청 선생님</span>
                    <strong class="eli">김대교 [12345678]</strong>
                  </div>
                  <div class="bottom_item">
                    <span>승인상태</span>
                    <strong class="eli">총 1건(대기 0)</strong>
                  </div>
                </div>
              </div>
            </div>

            <div class="student_card type03">
              <div class="date">
                <p class="body1">2023.04.04(수)</p>
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="red" class="medium">반려</q-badge>
                </div>
                <div class="wrap_personal_check">
                  <span class="name">부교재/소모품 신청 요청서</span>
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="bottom body2">
                  <div class="bottom_item">
                    <span>구분</span>
                    <strong class="eli">부고재/소모품 신청 승인 요청서</strong>
                  </div>
                  <div class="bottom_item">
                    <span>승인요청 선생님</span>
                    <strong class="eli">김대교 [12345678]</strong>
                  </div>
                </div>
              </div>
            </div>
          </q-card-section>
        </div>

        <!-- 회원정보카드 member_info_card -->
        <div class="sample_box">
          <div class="text-subtitle2">회원정보카드 member_info_card</div>
          <q-card-section>

            <!-- member_info_card -->
            <div class="member_info_card">
              <div class="infor_area">
                <div class="pic_area big">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <q-badge color="grey-3" class="small">임시</q-badge>
                    <p class="name">김윤찬</p>
                    <p class="member_number">P159071234</p>
                    <p class="grade">초등1</p>
                  </div>
                </div>
              </div>
              <div class="state_area">
                <div class="body2 text-grey-3 mb6 ellipsis">
                  <span>입회 : </span>
                  <span>눈높이수학(주4회)</span>
                  <span>, </span>
                  <span>눈높이국어(주5회)</span>
                  <span>, </span>
                  <span>솔루니독서토론논술</span>
                </div>
                <div class="body2 text-grey-3 ellipsis">체험 : 눈높이수학똑똑, i Listening, 써밋스코어국어</div>
              </div>
            </div>
            <!-- //member_info_card -->

            <q-separator class="mt10 mb10" />

            <!-- member_info_card 진도 미결정-->
            <div class="member_info_card">
              <div class="infor_area">
                <div class="txt_area">
                  <div class="tit_area">
                    <q-badge color="positive" class="small">단체</q-badge>
                    <div class="name">아브디라쉬토바엘레오노라아브디라쉬토바엘레오노라아브디라쉬토바엘레오노라아브디라쉬토바엘레오노라</div>
                    <p class="member_number">P159071234</p>
                    <p class="grade">
                      <span>초등1</span>
                      <span class="text-grey-6 ml6 mr6">|</span>
                      <span>강남교육국 외 00</span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="state_area">
                <div class="badge_group_area mb4">
                  <q-badge color="grey-4" class="small">대기중</q-badge>
                  <q-badge color="primary" class="small">공공사업</q-badge>
                </div>
                <div class="row mb8">
                  <span class="title1">솔루니 독서토론논술</span>
                </div>
                <div class="body2 text-grey-3">
                  <span>김대교</span>
                  <span> / 월 </span>
                  <span> / 11:00 </span>
                  <span> / 내방 </span>
                  <span> / 2023.05.23~</span>
                </div>
                <q-separator class="mt16" />
                <div class="mt16">
                  <div class="row-2">
                    <span class="body2 text-grey-1">이번주 진도</span>
                    <div class="body2 text-grey-2">A01, A02, A03</div>
                  </div>
                </div>
              </div>
            </div>
            <!-- //member_info_card -->

            <q-separator class="mt10 mb10" />

            <!-- member_info_card 회비미납 -->
            <div class="member_info_card">
              <div class="infor_area">
                <div class="txt_area">
                  <div class="tit_area">
                    <q-badge color="positive" class="small">단체</q-badge>
                    <div class="name">김윤찬</div>
                    <p class="member_number">P159071234</p>
                    <p class="grade">
                      <span>초등1</span>
                      <span class="text-grey-6 ml6 mr6">|</span>
                      <span>강남교육국 외 00</span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="state_area">
                <div class="badge_group_area mb4">
                  <q-badge color="positive" class="small">학습중</q-badge>
                </div>
                <div class="row mb8">
                  <span class="title1">솔루니 독서토론논술</span>
                </div>
                <div class="body2 text-grey-3">
                  <span>김대교</span>
                  <span> / 월 </span>
                  <span> / 11:00 </span>
                  <span> / 내방 </span>
                  <span> / 2023.05.23~</span>
                </div>
                <q-separator class="mt16" />
                <div class="mt16">
                  <div class="row-2">
                    <span class="body2 text-grey-1">최종회비</span>
                    <div class="body2 text-grey-2">2023.01</div>
                  </div>
                  <div class="row-2">
                    <span class="body2 text-grey-1">미납금</span>
                    <div class="body2 text-grey-2">70,000원</div>
                  </div>
                </div>
              </div>
            </div>
            <!-- //member_info_card -->
          </q-card-section>
        </div>

        <!-- 회원추가 -->
        <div class="sample_box">
          <div class="text-subtitle2">회원추가</div>
          <q-card-section>
            회원추가
          </q-card-section>
        </div>

        <!-- section_cost -->
        <div class="sample_box">
          <div class="text-subtitle2">section_cost</div>
          <q-card-section>
            <div class="section_cost mt10">
              <ul class="history">
                <li>
                  <div class="as_dt text-body2">학습상품</div>
                  <div class="as_dd text-body1">20,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">연계상품</div>
                  <div class="as_dd text-body1">10,000원</div>
                </li>
              </ul>
              <dl class="total_coast">
                <dt class="title1">결제금액</dt>
                <dd class="title1">130,000원</dd>
              </dl>
            </div>
            <div class="section_cost type02 mt10">
              <ul class="history">
                <li>
                  <div class="as_dt title3">상품 금액</div>
                  <div class="as_dd title3">310,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">학습 상품</div>
                  <div class="as_dd text-body2">210,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">비학습 상품</div>
                  <div class="as_dd text-body2">100,000원</div>
                </li>
              </ul>
              <ul class="history">
                <li>
                  <div class="as_dt title3">할인 금액</div>
                  <div class="as_dd title3">100,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">프로모션</div>
                  <div class="as_dd text-body2">50,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">공공지원</div>
                  <div class="as_dd text-body2">50,000원</div>
                </li>
              </ul>
            </div>
          </q-card-section>
        </div>

        <!-- list_profile_state -->
        <div class="sample_box">
          <div class="text-subtitle2">학생 list_profile_state</div>
          <q-card-section>
            <!-- list_profile_state -->
            <section class="list_profile_state">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="badge_area">
                    <q-badge color="black" class="small">출석 </q-badge>
                    <!-- <q-badge color="positive" class="small">예정 </q-badge>
          <q-badge color="grey-5" class="small">지각</q-badge> -->
                    <!-- <q-badge color="orange" class="small">결석</q-badge> -->
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="subject_area">
                <p class="subject_tit title1">
                  눈높이 수학
                  <span class="add_txt text-body1 text-orange">체험</span>
                </p>
                <div class="state">
                  <div class="row">
                    <div class="as_dt text-body2">지난주</div>
                    <div class="as_dd text-body2">
                      <div class="item_subject_state bold border">A15</div>
                      <div class="item_subject_state bold border">A16</div>
                      <div class="item_subject_state bold">A18</div>
                      <div class="item_subject_state">A19</div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="as_dt text-body2">이번주</div>
                    <div class="as_dd text-body2">
                      <div class="item_subject_state">A20</div>
                      <div class="item_subject_state">A21</div>
                      <div class="item_subject_state">A22</div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="as_dt text-body2">부교재</div>
                    <div class="as_dd text-body2">
                      <div class="txt">부교재명</div>
                    </div>
                  </div>
                </div>
                <div class="btn_area col4">
                  <q-btn
                    class="size_sm shadow text-body1"
                    unelevated
                    label="진도관리"
                  />
                  <q-btn
                    class="size_sm shadow text-body1"
                    unelevated
                    label="학습관리"
                  />
                  <q-btn
                    class="size_sm shadow text-body1"
                    unelevated
                    label="학습이력"
                  />
                  <q-btn
                    class="size_sm shadow text-body1"
                    unelevated
                    label="결과서"
                  />
                </div>
              </div>
            </section>
            <!-- list_profile_state.study -->
            <section class="list_profile_state study impact">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="badge_area">
                    <q-badge color="black" class="small">출석 </q-badge>
                    <!-- <q-badge color="positive" class="small">예정 </q-badge>
          <q-badge color="grey-5" class="small">지각</q-badge> -->
                    <!-- <q-badge color="orange" class="small">결석</q-badge> -->
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="study_view">
                <div class="wrap_linear_progress">
                  <p class="tit text-body3 text-grey-3">전체 진행률 36%</p>
                  <div class="linear_progress green mb24">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>

                <p class="study_tit title1">
                  눈높이 수학
                  <span class="add_txt text-body1 text-orange">체험</span>
                </p>
                <div class="list_study">
                  <div class="item_subject_state bold border">A15</div>
                  <div class="item_subject_state bold border">A16</div>
                  <div class="item_subject_state bold">A18</div>
                  <div class="item_subject_state">A19</div>
                </div>

                <div class="class_area">
                  <div class="class pause">
                    <p class="class_tit title3">풀이중 (00:12:10)</p>

                    <div class="infor">
                      <q-icon name="icon-pause-grey" class="icon_svg"></q-icon>
                      <p class="txt title4">정지</p>
                      <p class="time title3">00:36</p>
                    </div>
                  </div>

                  <div class="class delay">
                    <p class="class_tit title3">형성평가중 (00:08:21)</p>
                    <div class="infor">
                      <q-icon name="icon-clock-grey" class="icon_svg"></q-icon>
                      <p class="txt title4">지체</p>
                    </div>
                  </div>

                  <div class="class">
                    <p class="class_tit title3">타교실 학습중</p>
                  </div>
                </div>
              </div>
              <div class="btn_area col4">
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="진도관리"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="학습관리"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="학습이력"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="결과서"
                />
              </div>
            </section>

            <!-- list_profile_state.study -->
            <section class="list_profile_state study impact">
              <div class="profile_area">
                <div class="tit_area">
                  <p class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </p>
                  <div class="badge_area">
                    <q-badge color="black" class="small">출석 </q-badge>
                    <!-- <q-badge color="positive" class="small">예정 </q-badge>
          <q-badge color="grey-5" class="small">지각</q-badge> -->
                    <!-- <q-badge color="orange" class="small">결석</q-badge> -->
                  </div>
                </div>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_user"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_memo"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="study_view">
                <div class="wrap_linear_progress">
                  <p class="tit text-body3 text-grey-3">전체 진행률 36%</p>
                  <div class="linear_progress green mb24">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>

                <p class="study_tit title1">
                  눈높이 수학
                  <span class="add_txt text-body1 text-orange">체험</span>
                </p>
                <div class="list_study">
                  <p class="text-body2">주제별 어휘 Unit 6 (01:14:06)</p>
                </div>
                <q-btn
                  fill
                  unelevated
                  color="grey-7"
                  class="size_sm"
                  label="1:1 코칭"
                />
                <div class="class_area">
                  <div class="class">
                    <p class="class_tit title3">Class 1</p>
                  </div>
                </div>
              </div>
              <div class="btn_area col4">
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="진도관리"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="학습관리"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="학습이력"
                />
                <q-btn
                  class="size_sm shadow text-body1"
                  unelevated
                  label="결과서"
                />
              </div></section
          ></q-card-section>
        </div>

        <!-- 결제 카드 정보 -->
        <div class="sample_box">
          <div class="text-subtitle2">결제 카드 정보 pay_card</div>
          <q-card-section>
            <!-- pay_card -->
            <div class="pay_card">
              <div class="tit_area">
                <div class="row">
                  <span class="tit title1">KB국민카드</span>
                  <q-space />
                </div>
                <div class="row state">
                  <span class="body2 text-grey-3">1234-4567-6789-****</span>
                  <q-space />
                </div>
              </div>
              <div class="date_area">
                <div class="row-2">
                  <div class="body2 text-grey-1">결제일</div>
                  <div class="body2 text-grey-2">
                    <span>25</span>
                    <span>일</span>
                  </div>
                </div>
              </div>
            </div>
            <!-- //pay_card -->
          </q-card-section>
        </div>

        <!-- section_cost -->
        <div class="sample_box">
          <div class="text-subtitle2">결제 section_cost</div>
          <q-card-section>
            <div class="section_cost mt10">
              <ul class="history">
                <li>
                  <div class="as_dt text-body2">학습상품</div>
                  <div class="as_dd text-body1">20,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">연계상품</div>
                  <div class="as_dd text-body1">10,000원</div>
                </li>
              </ul>
              <dl class="total_coast">
                <dt class="title1">결제금액</dt>
                <dd class="title1">130,000원</dd>
              </dl>
            </div>
            <div class="section_cost type02 mt10">
              <ul class="history">
                <li>
                  <div class="as_dt title3">상품 금액</div>
                  <div class="as_dd title3">310,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">학습 상품</div>
                  <div class="as_dd text-body2">210,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">비학습 상품</div>
                  <div class="as_dd text-body2">100,000원</div>
                </li>
              </ul>
              <ul class="history">
                <li>
                  <div class="as_dt title3">할인 금액</div>
                  <div class="as_dd title3">100,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">프로모션</div>
                  <div class="as_dd text-body2">50,000원</div>
                </li>
                <li>
                  <div class="as_dt text-body2">공공지원</div>
                  <div class="as_dd text-body2">50,000원</div>
                </li>
              </ul>
            </div>
          </q-card-section>
        </div>

        <!-- 조직 카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">조직 카드 organization_card</div>
          <q-card-section>
            <!-- organization_card -->
            <div class="organization_card">
              <div class="tit_area">
                <div class="column">
                  <div class="row mb8">
                    <div class="tit title1">수원동부교육국</div>
                  </div>
                  <div class="body2 text-grey-3">경기본부</div>
                </div>
              </div>
              <div class="con_area">
                <div class="cont_group underline">
                  <p class="title1 text-black mb8">눈높이 LC러닝센터</p>
                  <div class="row">
                    <span class="body2 text-grey-3">경기본부</span>
                    <span class="body2 text-grey-3 ml4 mr4">&#62;</span>
                    <span class="body2 text-grey-3">수원동부교육국</span>
                  </div>
                </div>
                <div class="cont_group underline">
                  <p class="body2 text-grey-1">[12345]</p>
                  <p class="body2 text-grey-1">
                    경기도 수원시 영통구 영통로 21번길 82-12번지 3층
                  </p>
                </div>
                <div class="cont_group underline">
                  <div class="row-2">
                    <p class="body2 text-grey-1">전화</p>
                    <p class="body2 text-grey-2">031-234-1234</p>
                  </div>
                  <div class="row-2">
                    <p class="body2 text-grey-1">팩스</p>
                    <p class="body2 text-grey-2">031-234-1234</p>
                  </div>
                </div>
                <div class="cont_group underline">
                  <div class="row-2">
                    <p class="title3 text-grey-1">팀장</p>
                    <p class="title3 text-grey-1">김길동</p>
                  </div>
                  <div class="row-2">
                    <p class="body2 text-grey-1">구성원</p>
                    <p class="body2 text-grey-2">30명</p>
                  </div>
                </div>
                <div class="cont_group">
                  <div class="row-2 mb16">
                    <p class="title3 text-grey-1">국장</p>
                    <p class="title3 text-grey-1">홍길동</p>
                  </div>
                  <div class="column">
                    <q-btn
                      unelevated
                      class="size_xxl text-grey-1 full-width text_long"
                      color="white"
                    >
                      <div class="row-2 w100p">
                        <span class="body2">001팀 - 눈높이 LC 러닝센터</span>
                        <q-icon
                          name="icon-arrow-right"
                          class="icon_svg filter-grey-3"
                        ></q-icon>
                      </div>
                    </q-btn>
                    <q-btn
                      unelevated
                      class="size_xxl text-grey-1 full-width text_long"
                      color="white"
                    >
                      <div class="row-2 w100p">
                        <span class="body2">001팀 - 눈높이 LC 러닝센터</span>
                        <q-icon
                          name="icon-arrow-right"
                          class="icon_svg filter-grey-3"
                        ></q-icon>
                      </div>
                    </q-btn>
                    <q-btn
                      unelevated
                      class="size_xxl text-grey-1 full-width text_long"
                      color="white"
                    >
                      <div class="row-2 w100p">
                        <span class="body2">001팀 - 눈높이 LC 러닝센터</span>
                        <q-icon
                          name="icon-arrow-right"
                          class="icon_svg filter-grey-3"
                        ></q-icon>
                      </div>
                    </q-btn>
                    <q-btn
                      unelevated
                      class="size_xxl text-grey-1 full-width text_long"
                      color="white"
                    >
                      <div class="row-2 w100p">
                        <span class="body2">001팀 - 눈높이 LC 러닝센터</span>
                        <q-icon
                          name="icon-arrow-right"
                          class="icon_svg filter-grey-3"
                        ></q-icon>
                      </div>
                    </q-btn>
                  </div>
                </div>
              </div>
            </div>
            <!-- //organization_card -->
          </q-card-section>
        </div>

        <!-- 추가 -->
        <div class="sample_box">
          <div class="text-subtitle2">제목</div>
          <q-card-section> 추가 </q-card-section>
        </div>

        <div class="sample_box">
          <div class="text-subtitle2">wrap_list_infor_00</div>
          <q-card-section>
            <!-- wrap_list_infor_00 -->
            <div class="wrap_list_infor_00">
              <div class="item">
                <div class="wrap_tit">
                  <div class="tit txt title1">김윤찬</div>
                </div>
                <div class="wrap_row">
                  <div class="row">
                    <span class="as_dt">회원상태</span>
                    <span class="as_dd"
                      ><span class="text-body1 text-positive"
                        >입회회원</span
                      ></span
                    >
                  </div>
                  <div class="row">
                    <span class="as_dt">생년월일/나이</span>
                    <span class="as_dd">2012.01.01/12살</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">성별</span>
                    <span class="as_dd">남</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">학년/학교명</span>
                    <span class="as_dd">6학년/보라매초등학교</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">이메일</span>
                    <span class="as_dd">nyanyaong77@gmail.com</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">휴대폰 번호</span>
                    <span class="as_dd">010-1234-5678</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">주소</span>
                    <span class="as_dd"
                      >[12345] 서울특별시 관악구 신대방동 11길 12 대교아파트 1동
                      101호</span
                    >
                  </div>
                </div>
                <q-btn
                  class="size_sm shadow text-body1"
                  color="white"
                  text-color="black"
                  unelevated
                  label="기본 정보 관리"
                />
              </div>
            </div>
            <!--// wrap_list_infor_00 -->

            <hr class="separator expand" />
            <div class="text-body1 text-grey-3 pt30_sm_scope">
              공공지원 정보
            </div>
            <section class="ma0">
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="alert">
                    <div class="alert_tit title4">
                      조직원 신청이
                      <span class="bold title4 text-orange">반려 </span
                      >되었습니다
                    </div>
                    <div class="alert_txt text-body2">
                      팀장/국장의 승인 후 처리가 완료됩니다
                    </div>
                  </div>
                  <div class="wrap_row border">
                    <div class="row alert">
                      <span class="as_dt">처리상태</span>
                      <span class="as_dd text-orange">반려</span>
                    </div>
                    <div class="row alert">
                      <span class="as_dt">신청일</span>
                      <span class="as_dd">2023.01.05</span>
                    </div>
                    <div class="column">
                      <span class="as_dt">반려사유</span>
                      <span class="as_dd"
                        >가족관계증명서 내용이 잘 안보입니다. <br />
                        증명서를 수정해서 다시 신청해주세요.</span
                      >
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="조직원 여부 관리"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
            </section>
          </q-card-section>
        </div>

        <!-- wrap_list_infor_02 -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_list_infor_02</div>
          <q-card-section>
            <!-- wrap_list_infor_02 -->
            <div class="wrap_list_infor_02">
              <div class="item">
                <div class="wrap_row">
                  <div class="row">
                    <span class="as_dt">학습금액</span>
                    <span class="as_dd semibold">80,000원</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">할인금액</span>
                    <span class="as_dd semibold">8,000원</span>
                  </div>
                  <div class="row">
                    <span class="as_dt title3">총 학습금액</span>
                    <span class="as_dd title3">72,000원</span>
                  </div>
                </div>
              </div>
            </div>
            <!--// wrap_list_infor_02 -->
          </q-card-section>
        </div>

        <!--// list_infor_00 -->
        <div class="sample_box">
          <div class="text-subtitle2">list_type_0</div>
          <q-card-section>
            <!--// list_type_0 -->
            <ul class="list_type_0">
              <li>
                <q-btn to="" flat>
                  <p class="txt title3">눈높이 수학</p>
                  <p class="count impact_color text-body1">주3회</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li>
                <q-btn to="" flat>
                  <p class="txt title3">
                    솔루니 점프마스Lorem ipsum dolor sit amet consectetur
                    adipisicing elit. Soluta, illo incidunt quae, saepe natus
                    mollitia porro quibusdam alias maxime ex consequatur velit
                    voluptatum ipsum fugit enim maiores omnis! Ad, laboriosam?
                  </p>
                  <p class="count impact_color text-body1">3회</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li class="on">
                <q-btn :ripple="false" to="" flat>
                  <p class="txt title3">써밋 중등 수학</p>
                  <p class="count text-body1">체험</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li class="on">
                <q-btn :ripple="false" to="" flat>
                  <p class="txt title3">써밋 어휘력</p>
                  <p class="count text-body1">체험</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
            </ul>
            <!-- list_type_0 -->
          </q-card-section>
        </div>

        <!--// list_contact -->
        <div class="sample_box">
          <div class="text-subtitle2">list_contact</div>
          <q-card-section>
            <!-- 연락처 정보 -->
            <div class="list_contact">
              <div class="row">
                <p class="title1">김윤찬</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-7"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="row">
                <p class="title1">김윤찬 어머니</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <div class="row">
                <p class="body2 text-grey-3">
                  서울특별시 관악구 보라매로 3길 23 대교타워 14층
                </p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-5"
                    icon=""
                    class="btn_map"
                  />
                </div>
              </div>
            </div>
          </q-card-section>
        </div>

        <!--wrap_goods -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_goods</div>
          <q-card-section>
            <!-- wrap_goods -->
            <div class="wrap_goods mt20">
              <div class="item active">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >솔루니 독서논술솔루니 독서논술솔루니 독서논술솔루니
                      독서논술</span
                    >
                    <!-- tooltip_down -->
                    <q-fab direction="down" hide-icon class="tooltip_down" flat>
                      <q-fab-action
                        square
                        @click="onClick"
                        label=""
                        label-position="left"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">
                          [눈높이역사, 눈높이사회]
                          <span class="text-orange"> 결합상품 </span>입니다.
                        </p>
                      </q-fab-action>
                    </q-fab>
                    <!--// tooltip_down -->
                    <span class="text-body1 text-grey-5">대기중</span>
                  </div>
                  <div class="more text-body2">
                    <span>센터</span>
                    <span>4회 학습</span>
                    <span>수학</span>
                  </div>
                  <p class="date text-body2">학습예정일 : 2022.12.07~</p>
                </div>

                <q-btn class="size_sm shadow" unelevated label="진도 설정" />

                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >솔루니 독서논술솔루니 독서논술솔루니 독서논술솔루니
                      독서논술</span
                    >
                    <!-- tooltip_down -->
                    <q-fab direction="down" hide-icon class="tooltip_down" flat>
                      <q-fab-action
                        square
                        @click="onClick"
                        label=""
                        label-position="left"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">
                          [눈높이역사, 눈높이사회]
                          <span class="text-orange"> 결합상품 </span>입니다.
                        </p>
                      </q-fab-action>
                    </q-fab>
                    <!--// tooltip_down -->
                    <span class="text-body1 text-grey-5">대기중</span>
                  </p>
                  <div class="more text-body2">
                    <span>센터</span>
                    <span>4회 학습</span>
                    <span>수학</span>
                  </div>
                  <p class="date text-body2">학습예정일 : 2022.12.07~</p>
                </div>

                <q-btn class="size_sm shadow" unelevated label="진도 설정" />

                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <!--//버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>

              <div class="item join">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge
                  class="badge20"
                  rounded
                  color="positive"
                  label="결합"
                />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span class="text-body1 text-brown-2">학습종료</span>
                  </p>
                  <div class="more text-body2">
                    <span>셀프러닝</span>
                    <span>4회 학습</span>
                    <span>사회, 역사</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~2022.12.05</p>
                </div>

                <div class="set_infor">
                  <p class="title3">A과정 17세트</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <p v-if="false" class="tit text-body3">공공지원할인1</p>
                    <p class="txt">적용된 할인 내역이 없습니다.</p>
                  </div>
                  <div class="btn_area col1">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn
                      class="size_sm shadow"
                      unelevated
                      label="지난 학습현황"
                    />
                  </div>
                </div>
              </div>
              <div class="item join">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge
                  class="badge20"
                  rounded
                  color="positive"
                  label="결합"
                />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span class="text-body1 text-brown-2">학습종료</span>
                  </p>
                  <div class="more text-body2">
                    <span>셀프러닝</span>
                    <span>4회 학습</span>
                    <span>사회, 역사</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~2022.12.05</p>
                </div>

                <q-btn
                  v-if="false"
                  outline
                  class="size_xs mb16"
                  style="margin-top: 20px; width: 100%"
                  label="진도 설정"
                />
                <div class="set_infor">
                  <p class="title3">A과정 17세트</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="txt">적용된 할인 내역이 없습니다.</p>
                  </div>
                  <div class="btn_area col1">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn
                      class="size_sm shadow"
                      unelevated
                      label="지난 학습현황"
                    />
                  </div>
                </div>
              </div>

              <div class="item package">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge class="badge20" rounded color="black" label="패키지" />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span v-if="false" class="text-body1 text-orange"
                      >학습종료</span
                    >
                  </p>
                  <div class="more text-body2">
                    <span>센터, 방문수업</span>
                    <span>4회 학습</span>
                    <span>국어</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~</p>
                </div>

                <q-btn
                  v-if="false"
                  outline
                  class="size_xs mb16"
                  style="margin-top: 20px; width: 100%"
                  label="진도 설정"
                />
                <div class="set_infor">
                  <p class="title3">A단계</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <!--//버튼 추가 타입    _btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>
            </div>
            <!--// wrap_goods -->
          </q-card-section>
        </div>

        <!--wrap_goods_type02 -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_goods_type02</div>
          <q-card-section>
            <!--wrap_goods_type02  -->
            <div class="wrap_goods_type02 mt20">
              <div class="item active">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >눈높이 코어수학눈높이 코어수학눈높이 코어수학눈높이
                      코어수학눈높이 코어수학</span
                    >
                    <span class="text-body1 text-orange">선납할인</span>
                  </div>
                  <div class="infor_box text-body2">
                    <div class="row">
                      <div class="as_dt">연령</div>
                      <div class="as_dd">예비초, 초등, 중등</div>
                    </div>
                    <div class="row">
                      <div class="as_dt">가격</div>
                      <div class="as_dd text-body1 text-black">
                        <span class="text-positive"> 방문/LC </span>
                        38,000원
                      </div>
                    </div>
                    <div class="row">
                      <div class="as_dt">과정</div>
                      <div class="as_dd">4A-F과정(24세트)</div>
                    </div>
                  </div>
                </div>

                <div class="btn_area">
                  <q-btn class="size_sm shadow" unelevated label="입회" />
                  <q-btn class="size_sm shadow" unelevated label="체험" />
                  <q-btn class="size_sm shadow" unelevated label="학습바구니" />
                </div>
              </div>
              <div class="item">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >눈높이 코어수학눈높이 코어수학눈높이 코어수학눈높이
                      코어수학눈높이 코어수학</span
                    >
                    <span class="text-body1 text-orange">선납할인</span>
                  </div>
                  <div class="infor_box text-body2">
                    <div class="row">
                      <div class="as_dt">연령</div>
                      <div class="as_dd">예비초, 초등, 중등</div>
                    </div>
                    <div class="row">
                      <div class="as_dt">가격</div>
                      <div class="as_dd text-body1 text-black">
                        <span class="text-positive"> 방문/LC </span>
                        38,000원
                      </div>
                    </div>
                    <div class="row">
                      <div class="as_dt">과정</div>
                      <div class="as_dd">4A-F과정(24세트)</div>
                    </div>
                  </div>
                </div>

                <div class="btn_area">
                  <q-btn class="size_sm shadow" unelevated label="입회" />
                  <q-btn class="size_sm shadow" unelevated label="체험" />
                  <q-btn class="size_sm shadow" unelevated label="학습바구니" />
                </div>
              </div>
            </div>
            <!--// wrap_goods_type02  -->
          </q-card-section>
        </div>
        <!--// wrap_goods_type02 -->

        <!-- section_form -->
        <!-- <div class="sample_box">
          <div class="text-subtitle2">section_form</div>
          <q-card-section>
            <section class="section_form">
              <ul class="inner_list">
                <li>
                  <span class="as_dt"
                    >회원이 조직원 본인이거나 조직원의 자녀인가요?</span
                  >
                  <div class="form_data has_radio">
                    <q-radio
                      v-model="dataRadio"
                      dense
                      val="Y"
                      label="예"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataRadio"
                      dense
                      val="N"
                      label="아니오"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </li>
              </ul>
            </section>
            <hr class="separator" />
            <section class="section_form">
              <ul class="inner_list">
                <li>
                  <span class="as_dt">신청 대상</span>
                  <div class="form_data top_radio">
                    <q-radio
                      v-model="dataRadio2"
                      dense
                      val="children"
                      label="직원자녀"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataRadio2"
                      dense
                      val="self"
                      label="직원본인"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                  <q-input
                    class="as_dd hide_label inp_search"
                    label="조직 구성원"
                    outlined
                    placeholder="조직 구성원을 검색하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:append>
                      <q-btn flat :ripple="false" class="btn_input_slot">
                        <q-icon name="icon-search_m" class="icon_svg"></q-icon>
                      </q-btn>
                    </template>
                  </q-input>
                  <q-input
                    class="as_dd hide_label inp_search2"
                    disabled
                    label="상세주소"
                    outlined
                    placeholder=""
                    stack-label
                    dense
                  >
                    <template v-slot:label>상세주소</template>
                  </q-input>
                </li>
              </ul>
            </section>
            <section class="section_form">
              <ul class="inner_list">
                <li>
                  <span class="as_dt">증빙자료</span>
                  <p class="caption">
                    증빙자료 정보동의서가 없는 경우 감사대상이 될 수 있습니다.
                    증빙자료는 신청일로 부터 1년간 보관됩니다.<span
                      class="text-orange"
                      >(jpg, jpeg, gif, tif, pdf 등록 가능합니다)</span
                    >
                  </p>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      dense
                      clearable
                      placeholder="정보동의서를 선택"
                      label="정보동의서를 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:after>
                        <q-btn
                          fill
                          unelevated
                          class="btn_file_select"
                          color="grey-2"
                          label="선택"
                        />
                      </template>
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <q-icon
                            name="icon-search_m"
                            class="icon_svg"
                          ></q-icon>
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      dense
                      clearable
                      placeholder="가족관계증명서 선택"
                      label="가족관계증명서 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:after>
                        <q-btn
                          fill
                          unelevated
                          class="btn_file_select"
                          color="grey-2"
                          label="선택"
                        />
                      </template>
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <q-icon
                            name="icon-search_m"
                            class="icon_svg"
                          ></q-icon>
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                </li>
              </ul>
            </section>
            <hr class="separator" />
            <section class="section_form">
              <ul class="inner_list">
                <li>
                  <span class="as_dt required">이름</span>
                  <q-input
                    class="as_dd hide_label inp_search"
                    label="* 이름"
                    outlined
                    placeholder="이름을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>이름</template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt required">관계</span>
                  <q-select
                    class="as_dd"
                    outlined
                    dense
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                  ></q-select>
                </li>
                <li>
                  <span class="as_dt required">휴대폰 번호</span>
                  <q-input
                    class="as_dd hide_label"
                    label="* 휴대폰 번호"
                    outlined
                    placeholder="-없이 입력해 주세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>휴대폰 번호</template>
                  </q-input>
                </li>
                <li class="hasCheckbox">
                  <div class="as_dd">
                    <q-checkbox
                      dense
                      color="orange"
                      class="inp_check"
                      label="대표보호자 지정"
                    />
                  </div>
                </li>
              </ul>
            </section>
          </q-card-section>
        </div> -->

        <!-- pay_list -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type01</div>
          <q-card-section>
            <!-- pay_list -->
            <q-list class="pay_list">
              <q-expansion-item
                class="expansion_custom type01"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="date">
                    <span class="year">2023</span>
                    <span class="dot">.</span>
                    <span class="month">01</span>
                  </q-item-section>
                  <q-item-section class="price">
                    <div class="btn_area">
                      <q-btn
                        fill
                        unelevated
                        icon=""
                        class="btn_exclamation"
                        @click="tooltip1 = true"
                      ></q-btn>
                      <div v-show="tooltip1" class="pay_alert">
                        <div class="tooltip_area">
                          <div class="text">
                            이번달
                            <span class="text-orange"
                              >미납 <span>1</span>건</span
                            >이 있어요
                          </div>
                          <q-btn
                            fill
                            dense
                            class="btn_close"
                            @click="tooltip1 = false"
                          ></q-btn>
                        </div>
                      </div>
                    </div>
                    <div class="pre">총</div>
                    <div class="num">135,000</div>
                    <div class="won">원</div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">정기</span>
                      <span class="num">2</span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <q-badge color="orange" class="normal">미납</q-badge>
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          결제완료
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                  <q-separator class=""></q-separator>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">비정기</span>
                      <span class="num"></span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <q-badge color="grey-4" class="normal"
                            >결제대기</q-badge
                          >
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>
              <q-expansion-item
                class="expansion_custom type01"
                default-opened
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="date">
                    <span class="year">2023</span>
                    <span class="dot">.</span>
                    <span class="month">01</span>
                  </q-item-section>
                  <q-item-section class="price">
                    <div class="btn_area">
                      <q-btn
                        fill
                        unelevated
                        icon=""
                        class="btn_exclamation"
                        @click="tooltip2 = true"
                      ></q-btn>
                      <div v-show="tooltip2" class="pay_alert">
                        <div class="tooltip_area">
                          <div class="text">
                            이번달
                            <span class="text-orange"
                              >미납 <span>1</span>건</span
                            >이 있어요
                          </div>
                          <q-btn
                            fill
                            dense
                            class="btn_close"
                            @click="tooltip2 = false"
                          ></q-btn>
                        </div>
                      </div>
                    </div>
                    <div class="pre">총</div>
                    <div class="num">135,000</div>
                    <div class="won">원</div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">정기</span>
                      <span class="num">2</span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <q-badge color="orange" class="normal">미납</q-badge>
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          결제완료
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                  <q-separator class=""></q-separator>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">비정기</span>
                      <span class="num"></span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <q-badge color="grey-4" class="normal"
                            >결제대기</q-badge
                          >
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>
            </q-list>
            <!-- //pay_list -->
          </q-card-section>
        </div>

        <!-- 입금현황 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type02</div>
          <q-card-section>
            <q-list class="pay_list">
              <q-expansion-item
                class="expansion_custom type02"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <span class="title">입금현황</span>
                    <span class="process_area">
                      <span class="txt">입금률</span>
                      <span class="num">54</span>
                      <span class="sign">%</span>
                    </span>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="text-center">
                      <div class="date">
                        <span>2023</span>
                        <span>년</span>&nbsp;
                        <span>2</span>
                        <span>월</span>&nbsp;
                        <span>5</span>
                        <span>일</span>
                      </div>
                      <div class="price_area">
                        <q-icon name="icon-pay" class="icon_svg"></q-icon>
                        <div class="price">
                          <span>3,980,000</span>
                          <span>원</span>
                        </div>
                      </div>
                    </div>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                      <span class="txt">전일기준</span>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
              <q-expansion-item
                default-opened
                class="expansion_custom type02"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <span class="title">입금현황</span>
                    <span class="process_area">
                      <span class="txt">입금률</span>
                      <span class="num">54</span>
                      <span class="sign">%</span>
                    </span>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="text-center">
                      <div class="date">
                        <span>2023</span>
                        <span>년</span>&nbsp;
                        <span>2</span>
                        <span>월</span>&nbsp;
                        <span>5</span>
                        <span>일</span>
                      </div>
                      <div class="price_area">
                        <q-icon name="icon-pay" class="icon_svg"></q-icon>
                        <div class="price">
                          <span>3,980,000</span>
                          <span>원</span>
                        </div>
                      </div>
                    </div>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                      <span class="txt">전일기준</span>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
              <q-expansion-item
                default-opened
                class="expansion_custom type02"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <span class="title">입금현황</span>
                    <span class="process_area">
                      <span class="txt">입금률</span>
                      <span class="num">54</span>
                      <span class="sign">%</span>
                    </span>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section class="right">
                    <div>
                      <div class="date">
                        <span>2023</span>
                        <span>년</span>&nbsp;
                        <span>2</span>
                        <span>월</span>&nbsp;
                        <span>5</span>
                        <span>일</span>
                      </div>
                      <div class="price_area">
                        <q-icon name="icon-pay" class="icon_svg"></q-icon>
                        <div class="price">
                          <span>3,980,000</span>
                          <span>원</span>
                        </div>
                      </div>
                    </div>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                      <span class="txt">전일기준</span>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- 영업지표 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type03</div>
          <q-card-section>
            <q-list class="pay_list">
              <q-expansion-item
                class="expansion_custom type03"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <div class="title">영업지표</div>
                    <div class="process_area">
                      <span class="txt">순종수</span>
                      <span class="num">+234</span>
                    </div>
                  </q-item-section>
                </template>
                <q-card>
                  <div class="date_area">
                    <q-icon name="icon-check-grey" class="icon_svg"></q-icon>
                    <span>2023.1</span>
                    <span>월 기준</span>
                  </div>
                  <q-card-section>
                    <table class="sales_index">
                      <thead>
                        <tr>
                          <th>
                            <span class="txt">순증수</span>
                            <span class="num text-black">2714</span>
                          </th>
                          <th>
                            <span class="txt">순증지수</span>
                            <span class="num text-black">2714</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-warning">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-orange">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-positive">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <td>
                            <span class="txt">총원</span>
                            <span class="num text-primary">634</span>
                          </td>
                          <td>
                            <span class="txt">총원지수</span>
                            <span class="num text-black">23,456</span>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <span class="txt">영업마감일</span>
                      <div class="day">
                        <span>D</span>
                        <span>-</span>
                        <span>8</span>
                      </div>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
              <q-expansion-item
                default-opened
                class="expansion_custom type03"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <div class="title">영업지표</div>
                    <div class="process_area">
                      <span class="txt">순종수</span>
                      <span class="num">+234</span>
                    </div>
                  </q-item-section>
                </template>
                <q-card>
                  <div class="date_area">
                    <q-icon name="icon-check-grey" class="icon_svg"></q-icon>
                    <span>2023.1</span>
                    <span>월 기준</span>
                  </div>
                  <q-card-section>
                    <table class="sales_index">
                      <thead>
                        <tr>
                          <th>
                            <span class="txt">순증수</span>
                            <span class="num text-black">2714</span>
                          </th>
                          <th>
                            <span class="txt">순증지수</span>
                            <span class="num text-black">2714</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-warning">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-orange">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-positive">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <td>
                            <span class="txt">총원</span>
                            <span class="num text-primary">634</span>
                          </td>
                          <td>
                            <span class="txt">총원지수</span>
                            <span class="num text-black">23,456</span>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <span class="txt">영업마감일</span>
                      <div class="day">
                        <span>D</span>
                        <span>-</span>
                        <span>8</span>
                      </div>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- 학생카드 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type04</div>
          <q-card-section>
            <q-expansion-item
              default-opened
              class="expansion_custom type04 impact"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <q-checkbox
                    val="all"
                    color="orange"
                    v-model="expansionCustomType04Check"
                  />
                  <div class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </div>
                </q-item-section>
              </template>
              <ul class="list_check">
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list1"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">
                      눈높이 수학
                      <span class="add_txt text-body1 text-orange">체험</span>
                    </p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">A15</div>
                    <div class="item text-body2">A16</div>
                    <div class="item text-body2">A18</div>
                    <div class="item text-body2">A19</div>
                  </div>
                </li>
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list2"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">써밋 스텝 영어</p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">주제별 어휘 Unit 5</div>
                    <div class="item text-body2">주제별 어휘 Unit 6</div>
                  </div>
                </li>
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list3"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">눈높이 국어</p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">A15</div>
                    <div class="item text-body2">A16</div>
                    <div class="item text-body2">A18</div>
                    <div class="item text-body2">A19</div>
                  </div>
                </li>
              </ul>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type04"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <q-checkbox
                    val="all"
                    color="orange"
                    v-model="expansionCustomType04Check"
                  />
                  <div class="tit text-h3">
                    김윤찬 <span class="add_txt text-body1">초등1</span>
                  </div>
                </q-item-section>
              </template>
              <ul class="list_check">
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list1"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">
                      눈높이 수학
                      <span class="add_txt text-body1 text-orange">체험</span>
                    </p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">A15</div>
                    <div class="item text-body2">A16</div>
                    <div class="item text-body2">A18</div>
                    <div class="item text-body2">A19</div>
                  </div>
                </li>
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list2"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">써밋 스텝 영어</p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">주제별 어휘 Unit 5</div>
                    <div class="item text-body2">주제별 어휘 Unit 6</div>
                  </div>
                </li>
                <li>
                  <div class="wrap_checkbox">
                    <q-checkbox
                      val="list3"
                      color="orange"
                      v-model="expansionCustomType04Check"
                    />
                    <p class="subject_tit title1">눈높이 국어</p>
                  </div>
                  <div class="list_study">
                    <div class="item text-body2">A15</div>
                    <div class="item text-body2">A16</div>
                    <div class="item text-body2">A18</div>
                    <div class="item text-body2">A19</div>
                  </div>
                </li>
              </ul>
            </q-expansion-item>
          </q-card-section>
        </div>

        <!-- 트리 확장 리스트 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type05</div>
          <q-card-section>
            <q-list class="list_custom type01">
              <q-expansion-item class="expansion_custom type05">
                <template v-slot:header>
                  <q-item-section>
                    <div class="item_head">
                      <span class="title">채널</span>
                      <q-badge color="grey-4" class="medium"
                        >눈높이서비스부문</q-badge
                      >
                    </div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section> 내용 </q-card-section>
                </q-card>
              </q-expansion-item>
              <q-expansion-item class="expansion_custom type05">
                <template v-slot:header>
                  <q-item-section>
                    <div class="item_head">
                      <span class="title">본부</span>
                      <q-badge color="grey-4" class="medium"
                        >눈높이서비스부문</q-badge
                      >
                    </div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section> 내용 </q-card-section>
                </q-card>
              </q-expansion-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- expansion_custom type06-->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom type06</div>
          <q-card-section>
            <q-expansion-item
              default-opened
              class="expansion_custom type06"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <q-badge color="black" class="small">패키지</q-badge>
                    <div class="tit text-h3">눈높이 패키지</div>
                    <div class="text-body1 cost">
                      총 학습 금액 <span class="title3">280,000</span>원
                    </div>
                  </div>
                </q-item-section>
              </template>
              <ul class="wrap_list_subject">
                <li class="type_txt">
                  <p class="tit text-body1">눈높이 국어</p>
                  <dl class="row_between">
                    <dt class="title3">수업 금액</dt>
                    <dd class="title3">140,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">기준 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">옵션 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <p class="text-body2 more_txt">
                    (학습유형: 센터 / 총 수업 횟수: 5회)
                  </p>
                </li>
                <li class="type_card">
                  <p class="tit text-body1">학습 선생님</p>
                  <div class="card">
                    <div class="pic_area">
                      <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                    </div>
                    <div class="txt_area">
                      <p class="name title3">
                        김대교
                        <span class="id">(001000)</span>
                      </p>

                      <p class="info">
                        <span class="text-body2">경기교육국</span
                        ><span class="text-body2">001팀</span>
                      </p>
                      <p class="info">
                        <span class="text-body2">3회 수업</span
                        ><span class="text-body2">월, 화, 목</span>
                      </p>
                    </div>
                  </div>
                  <div class="card">
                    <div class="pic_area">
                      <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                    </div>
                    <div class="txt_area">
                      <p class="name title3">
                        박미자
                        <span class="id">(001000)</span>
                      </p>

                      <p class="info">
                        <span class="text-body2">경기교육국</span
                        ><span class="text-body2">001팀</span>
                      </p>
                      <p class="info">
                        <span class="text-body2">3회 수업</span
                        ><span class="text-body2">월, 화, 목</span>
                      </p>
                    </div>
                  </div>
                </li>

                <li class="type_txt">
                  <p class="tit text-body1">눈높이 수학</p>
                  <dl class="row_between">
                    <dt class="title3">수업 금액</dt>
                    <dd class="title3">140,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">기준 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">옵션 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <p class="text-body2 more_txt">
                    (학습유형: 센터 / 총 수업 횟수: 5회)
                  </p>
                </li>
                <li class="type_card">
                  <p class="tit text-body1">학습 선생님</p>
                  <div class="card">
                    <div class="pic_area">
                      <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                    </div>
                    <div class="txt_area">
                      <p class="name title3">
                        김대교
                        <span class="id">(001000)</span>
                      </p>

                      <p class="info">
                        <span class="text-body2">경기교육국</span
                        ><span class="text-body2">001팀</span>
                      </p>
                      <p class="info">
                        <span class="text-body2">3회 수업</span
                        ><span class="text-body2">월, 화, 목</span>
                      </p>
                    </div>
                  </div>
                </li>
              </ul>
            </q-expansion-item>

            <q-expansion-item
              default-opened
              class="expansion_custom type06"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <q-badge color="black" class="small">패키지</q-badge>
                    <div class="tit text-h3">눈높이 패키지</div>
                    <div class="text-body1 cost">
                      총 학습 금액 <span class="title3">280,000</span>원
                    </div>
                  </div>
                </q-item-section>
              </template>
              <ul class="wrap_list_subject">
                <li class="type_txt">
                  <p class="tit text-body1">눈높이 국어</p>
                  <dl class="row_between">
                    <dt class="title3">수업 금액</dt>
                    <dd class="title3">140,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">기준 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">옵션 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <p class="text-body2 more_txt">
                    (학습유형: 센터 / 총 수업 횟수: 5회)
                  </p>
                </li>

                <li class="type_txt">
                  <p class="tit text-body1">눈높이 수학</p>
                  <dl class="row_between">
                    <dt class="title3">수업 금액</dt>
                    <dd class="title3">140,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">기준 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">옵션 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <p class="text-body2 more_txt">
                    (학습유형: 센터 / 총 수업 횟수: 5회)
                  </p>
                </li>
              </ul>
            </q-expansion-item>

            <q-expansion-item
              default-opened
              class="expansion_custom type06"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="tit text-h3">대교 써밋 스텝영어</div>
                    <div class="text-body1 cost">
                      총 학습 금액 <span class="title3">280,000</span>원
                    </div>
                  </div>
                </q-item-section>
              </template>
              <ul class="wrap_list_subject">
                <li class="type_txt">
                  <p class="tit text-body1">눈높이 국어</p>
                  <dl class="row_between">
                    <dt class="title3">수업 금액</dt>
                    <dd class="title3">140,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">기준 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <dl class="row_between">
                    <dt class="text-body2">옵션 금액</dt>
                    <dd class="text-body2">40,000원</dd>
                  </dl>
                  <p class="text-body2 more_txt">
                    (학습유형: 센터 / 총 수업 횟수: 5회)
                  </p>
                </li>
              </ul>
            </q-expansion-item>

            <q-expansion-item
              default-opened
              class="expansion_custom type06"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="tit title1">비정기 결제 (12건)</div>
                    <div class="text-body1 cost">
                      총 금액 <span class="title3">340,000</span>원
                    </div>
                  </div>
                </q-item-section>
              </template>
              <div class="wrap_list_subject">
                <!-- 미납회비 -->
                <div class="type_txt02">
                  <p class="tit text-body1 text-grey-2">미납회비</p>
                  <div class="item_body">
                    <div class="item_body_inner">
                      <div class="item_tit">농협카드</div>
                      <div class="card_info body2">
                        <p class="text-grey-2">1234-3456-6789-****</p>
                        <div class="row justify-between mt10">
                          <p class="text-grey-1">결제일</p>
                          <p class="text-grey-2">25일</p>
                        </div>
                      </div>
                    </div>
                    <div class="item_body_inner breakline">
                      <div class="item_tit">
                        <q-checkbox
                          v-model="expansionCustomType04Check"
                          label="눈높이 코어수학"
                          color="grey-2"
                          dense
                        />
                      </div>
                      <div class="item_body_grey">
                        <div class="inner_item">
                          <div class="inner_item_tit">
                            <q-checkbox
                              v-model="expansionCustomType04Check"
                              color="grey-2"
                              dense
                            />
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">40,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              월/10:00/내방
                            </p>
                          </div>
                        </div>
                        <div class="inner_item">
                          <div class="inner_item_tit">
                            <q-checkbox
                              v-model="expansionCustomType04Check"
                              color="grey-2"
                              dense
                            />
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">40,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              수/10:00/내방
                            </p>
                          </div>
                        </div>
                        <div class="inner_item">
                          <q-badge color="red" class="small mb5">미납</q-badge>
                          <div class="inner_item_tit">
                            <q-checkbox
                              v-model="expansionCustomType04Check"
                              color="grey-2"
                              dense
                              disable
                            />
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">40,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              수/10:00/내방
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item_body_inner">
                      <div class="item_tit">
                        <q-checkbox
                          v-model="expansionCustomType04Check"
                          label="솔루니독서논술"
                          color="grey-2"
                          dense
                        />
                      </div>
                      <div class="item_body_grey">
                        <div class="inner_item">
                          <div class="inner_item_tit">
                            <q-checkbox
                              v-model="expansionCustomType04Check"
                              color="grey-2"
                              dense
                            />
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">40,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              월/10:00/내방
                            </p>
                          </div>
                        </div>
                        <div class="inner_item">
                          <q-badge color="red" class="small mb5">미납</q-badge>
                          <div class="inner_item_tit">
                            <q-checkbox
                              v-model="expansionCustomType04Check"
                              color="grey-2"
                              dense
                              disable
                            />
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">40,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              수/10:00/내방
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <q-btn
                      class="size_sm shadow mt15"
                      unelevated
                      label="결제하기"
                    />
                  </div>
                </div>

                <!-- 완납회비 -->
                <div class="type_txt02">
                  <p class="tit text-body1 text-grey-2">완납회비</p>
                  <div class="item_body">
                    <div class="item_body_inner">
                      <div class="item_tit">눈높이 국어똑똑</div>
                      <div class="item_body_grey">
                        <div class="inner_item">
                          <q-badge color="positive" class="small mb5"
                            >결제완료</q-badge
                          >
                          <div class="inner_item_tit">
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">30,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              월/10:00/내방
                            </p>
                          </div>
                        </div>
                        <div class="inner_item">
                          <q-badge color="positive" class="small mb5"
                            >결제완료</q-badge
                          >
                          <div class="inner_item_tit">
                            <div class="txt">
                              <p class="body2 text-grey-1">04월</p>
                              <p class="body2 text-grey-2">30,000원</p>
                            </div>
                            <p class="text-phara2 text-grey-3 mt10 subTxt">
                              월/10:00/내방
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item_body_inner">
                      <div class="item_tit">눈높이24개월 약정 태블릿</div>
                      <div class="item_body_grey">
                        <div class="inner_item">
                          <q-badge color="positive" class="small mb5"
                            >결제완료</q-badge
                          >
                          <div class="inner_item_tit">
                            <div class="txt">
                              <p class="body2 text-grey-1">2023.05월</p>
                              <p class="body2 text-grey-2">30,000원</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <q-btn
                      class="size_sm shadow mt15"
                      unelevated
                      label="영수증 목록"
                    />
                  </div>
                </div>
              </div>
            </q-expansion-item>
          </q-card-section>
        </div>

        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom type07</div>
          <q-card-section>
            <q-expansion-item class="expansion_custom type07" default-opened>
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="brown-2" class="square">Q1</q-badge>
                  <span class="question"
                    >선생님께서 수업 약속 시간을 잘 지켜주셨나요? 을 잘
                    지켜주셨나요? 을 잘 지켜주셨나요? 을 잘 지켜주셨나요?</span
                  >
                </div>
              </template>
              <p class="answer">
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요. 회원이 센터 등을 방문하는 경우는
                선생님께서 출석현황을 파악하고 관리해주셨는지 응답해주세요.
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요.
              </p>
            </q-expansion-item>

            <q-expansion-item class="expansion_custom type07">
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="brown-2" class="square">Q2</q-badge>
                  <span class="question"
                    >지난 학습 점검과 금주 학습 내용을 지도해주셨나요?</span
                  >
                </div>
              </template>
              <p class="answer">
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요.
              </p>
            </q-expansion-item>

            <q-expansion-item class="expansion_custom type07">
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="brown-2" class="square">Q3</q-badge>
                  <span class="question"
                    >회원에게 칭찬과 격려 등 동기부여를 해주셨나요?</span
                  >
                </div>
              </template>
              <p class="answer">
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요.
              </p>
            </q-expansion-item>

            <q-expansion-item class="expansion_custom type07">
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="brown-2" class="square">Q4</q-badge>
                  <span class="question"
                    >학습현황, 계획 등 학습상담을 해주셨나요? (면대면,전화,문자
                    등)</span
                  >
                </div>
              </template>
              <p class="answer">
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요.
              </p>
            </q-expansion-item>

            <q-expansion-item class="expansion_custom type07">
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="brown-2" class="square">Q5</q-badge>
                  <span class="question"
                    >선생님의 학습관리에 대해 전반적으로 만족하셨나요?</span
                  >
                </div>
              </template>
              <p class="answer">
                회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
                관리해주셨는지 응답해주세요.
              </p>
            </q-expansion-item>
          </q-card-section>
        </div>

        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom type08</div>
          <q-card-section>
            <div class="wrap_contents_box">
              <!-- group expansion -->
              <q-expansion-item
                class="expansion_custom type08"
                default-opened
                expand-icon-toggle
              >
                <template v-slot:header>
                  <h3 class="title1">대표보호자 정보</h3>
                </template>
                <div class="detail_top">
                  <div class="text-h3">이나래</div>
                  <q-btn
                    fill
                    unelevated
                    color="grey-5"
                    class="btn_circle"
                    label="circle"
                  >
                    <q-icon name="icon-call-white2" class="icon_svg"></q-icon>
                  </q-btn>
                </div>
                <dl class="detail_infor">
                  <dt class="title4">관계</dt>
                  <dd class="title4">어머니</dd>
                  <dt class="title4">휴대폰 번호</dt>
                  <dd class="title4">010-1234-5678</dd>
                </dl>
              </q-expansion-item>
              <!-- // group expansion -->
            </div>

            <div class="wrap_contents_box">
              <!-- group expansion -->
              <q-expansion-item
                class="expansion_custom type08"
                default-opened
                expand-icon-toggle
              >
                <template v-slot:header>
                  <h3 class="title1">상담정보</h3>
                </template>
                <dl class="detail_infor">
                  <dt class="title4">상담원명</dt>
                  <dd class="title4">홍길동</dd>
                  <dt class="title4">접수일</dt>
                  <dd class="title4">2023.03.10 (금)</dd>
                  <dt class="title4">상담채널</dt>
                  <dd class="title4">전화상담</dd>
                </dl>
              </q-expansion-item>
              <!-- // group expansion -->
            </div>

            <div class="wrap_contents_box">
              <!-- group expansion -->
              <q-expansion-item
                class="expansion_custom type08"
                default-opened
                expand-icon-toggle
              >
                <template v-slot:header>
                  <h3 class="title1">상담내용</h3>
                </template>
                <dl class="counsel_time">
                  <dt class="text-body2">상담가능시간</dt>
                  <dd class="text-body2">09:00 ~ 18:00</dd>
                </dl>
                <dl class="counsel_contents">
                  <dt>
                    상담실에서 직접 유선 통화를 한 건이 아닌, 인터넷 제품 상담
                    신청 접수건입니다.
                  </dt>
                  <dd>
                    상담 내용이 노출됩니다. 상담실에서 직접 유선 통화를 한 건이
                    아닌, 인터넷 제품 상담 신청 접수 건입니다 고객 메모와 주소
                    및 학년/연령 정보 재학인 부탁합니다. 상담 시 예전에 학습했던
                    회원인지 혹은 현재 다른 과목을 학습하고 있는 회원인지 확인
                    부탁드립니다. 감사합니다.
                  </dd>
                </dl>
                <div class="counsel_answer_contents">
                  <h4 class="title1">답변내용</h4>
                  <div class="counsel_answer">
                    <!-- 답변 미작성 : 버튼 노출 -->
                    <div class="btn_area">
                      <q-btn class="size_lg shadow" label="답변작성하기" />
                    </div>
                    <!-- 답변 작성 후 -->
                    <div class="text-body2">2023.03.16 (목)</div>
                    <div class="answer">
                      답변 미작성 시 답변작성하기 버튼이 나오고<br />
                      답변을 작성한 후 날짜와 답변 내용이 나옵니다.<br />
                      버튼과 이 영역 사이 여백이 없는 이유는 같이 나올 수가 없는
                      별개의 영역이기 때문입니다.<br />
                      안녕하세요. 회원님<br />
                      상담 답변내용이 노출됩니다. 상담시 알려주신 내용에 대한
                      답변이 노출됩니다.
                    </div>
                  </div>
                </div>
              </q-expansion-item>
              <!-- // group expansion -->
            </div>
          </q-card-section>
        </div>

        <!-- expansion_custom type10 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom type10</div>
          <q-card-section>
            <!-- 체크박스 -->
            <q-expansion-item default-opened class="expansion_custom type10">
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="row">
                      <q-badge color="grey-4" class="medium">대기중</q-badge>
                      <p class="body2 text-grey-2 ml10">-</p>
                    </div>
                    <div class="tit wrap_checkbox">
                      <q-checkbox
                        v-model="dataCheck"
                        val="check01"
                        label="월 10:00"
                        color="positive"
                        dense
                      />
                      <span class="add_txt title1 text-green">(내방)</span>
                    </div>
                  </div>
                </q-item-section>
              </template>
              <div class="wrap_expantion_cont">
                <div class="expantion_item underline">
                  <p class="item_header">반려사유</p>
                  <div class="item_body02">
                    <p class="text-phara2 text-grey-3">
                      반려사유를 이곳에 표시합니다 반려사유를 이곳에 표시합니다
                      반려사유를 이곳에 표시합니다 반려사유를 이곳에 표시합니다
                      반려사유를 이곳에 표시합니다
                    </p>
                  </div>
                </div>
                <div class="expantion_item">
                  <p class="item_header">이동 선생님 정보</p>
                  <div class="item_body">
                    <div class="inner_user_profile">
                      <div class="photo">
                        <img src="https://cdn.quasar.dev/img/avatar1.jpg" />
                      </div>
                      <div class="infor">
                        <div class="name">
                          <b>김대교</b><span>[001000]</span>
                        </div>
                        <div class="center">
                          <span class="text-body2 line">경기교육국</span>
                          <span class="text-body2">001팀</span>
                        </div>
                      </div>
                    </div>
                    <div class="wrap_row">
                      <div class="row breakline">
                        <span class="as_dt">학습요일</span>
                        <span class="as_dd">월</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="expantion_item underline">
                  <p class="item_header">회비정보</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="row">
                        <span class="as_dt">입회월</span>
                        <span class="as_dd">2023.04</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">시작회비</span>
                        <span class="as_dd">30,000원 (첫달 학습 3회)</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">차월회비</span>
                        <span class="as_dd">40,000원 (학습 4회)</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">할인금액</span>
                        <span class="as_dd">10,000원</span>
                      </div>
                      <div class="sm_row mt10">
                        <div class="row">
                          <span class="as_dt">프로모션명1</span>
                          <span class="as_dd">- 4,000원</span>
                        </div>
                        <div class="row">
                          <span class="as_dt">프로모션명2</span>
                          <span class="as_dd">- 4,000원</span>
                        </div>
                        <div class="row">
                          <span class="as_dt">선납할인</span>
                          <span class="as_dd">- 4,000원</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="total_price mt20">
                    <span>총 학습금액</span>
                    <span>20,000원</span>
                  </div>
                </div>
                <div class="expantion_item">
                  <p class="item_header">변경 정보</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="row">
                        <span class="as_dt">학습 옵션</span>
                        <span class="as_dd">외방</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">학습 변경일</span>
                        <span class="as_dd">2023.04.05</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">학습 횟수</span>
                        <span class="as_dd">2회</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="expantion_item">
                  <p class="item_header">이동정보</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="row">
                        <span class="as_dt">연락유무</span>
                        <span class="as_dd">유</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">이동사유</span>
                        <span class="as_dd">
                          <span>변경사유1</span> &gt;
                          <span>변경사유2</span>
                        </span>
                      </div>
                      <div class="column breakline">
                        <span class="as_dt">특이사항</span>
                        <span class="as_dd text-left"
                          >입력된 특이사항이 있으면 표시</span
                        >
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </q-expansion-item>

            <!-- 대기중 -->
            <q-expansion-item
              default-opened
              class="expansion_custom type10 header02"
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="row">
                      <q-badge color="grey-4" class="medium">대기중</q-badge>
                      <p class="body2 text-grey-2 ml10">-</p>
                    </div>
                    <div class="tit wrap_checkbox">
                      <q-checkbox
                        v-model="dataCheck"
                        val="check01"
                        label="눈높이 수학똑똑"
                        color="positive"
                        dense
                      />
                    </div>
                    <p class="addInfo">
                      1회<span class="text-green">(내방/월)</span>
                    </p>
                  </div>
                </q-item-section>
              </template>
              <div class="wrap_expantion_cont">
                <div class="expantion_item">
                  <p class="item_header">입회정보</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="row">
                        <span class="as_dt">학습시작일</span>
                        <span class="as_dd">2023.04.05</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">첫달학습횟수</span>
                        <span class="as_dd">3회</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">입회사유</span>
                        <span class="as_dd">학교성적향상</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">입회경로</span>
                        <span class="as_dd">주위권유</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="expantion_item">
                  <div class="item_body">
                    <p class="body1 text-grey-3">학습 선생님</p>
                    <div class="inner_user_profile mt15">
                      <div class="photo">
                        <img src="https://cdn.quasar.dev/img/avatar1.jpg" />
                      </div>
                      <div class="infor">
                        <div class="name">
                          <b>김대교</b><span>[001000]</span>
                        </div>
                        <div class="center">
                          <span class="text-body2 line">경기교육국</span>
                          <span class="text-body2">001팀</span>
                        </div>
                      </div>
                    </div>

                    <p class="body1 text-grey-3 breakline_lg">소개 선생님</p>
                    <div class="inner_user_profile mt15">
                      <div class="photo">
                        <img src="https://cdn.quasar.dev/img/avatar1.jpg" />
                      </div>
                      <div class="infor">
                        <div class="name">
                          <b>김대교</b><span>[001000]</span>
                        </div>
                        <div class="center">
                          <span class="text-body2 line">경기교육국</span>
                          <span class="text-body2">001팀</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </q-expansion-item>

            <!-- 체크박스 없음 -->
            <q-expansion-item default-opened class="expansion_custom type10">
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="row">
                      <q-badge color="blue" class="medium">상품</q-badge>
                    </div>
                    <div class="tit title1">약정태블릿(12개월)</div>
                  </div>
                </q-item-section>
              </template>
              <div class="wrap_expantion_cont">
                <div class="expantion_item">
                  <p class="item_header">옵션 정보</p>
                  <div class="item_body">선택한 옵션 정보</div>
                </div>
              </div>
            </q-expansion-item>

            <q-expansion-item
              default-opened
              class="expansion_custom type10 border_grey"
              hide-expand-icon
              disable
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <div class="colum">
                    <div class="row">
                      <q-badge color="orange" class="medium">정기</q-badge>
                    </div>
                    <div class="tit title1">4월 회비</div>
                  </div>
                </q-item-section>
              </template>
              <div class="wrap_expantion_cont">
                <div class="expantion_item">
                  <p class="item_header">영수정보</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="row">
                        <span class="as_dt title3">총 금액</span>
                        <span class="as_dd title3 text-grey-2">180,000원</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">거래일자</span>
                        <span class="as_dd text-grey-2">2023.04.04</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">선생님명</span>
                        <span class="as_dd text-grey-2">김대교</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">입금구분</span>
                        <span class="as_dd text-grey-2">카드이체</span>
                      </div>
                      <div class="row">
                        <span class="as_dt">승인번호</span>
                        <span class="as_dd text-grey-2">64400001</span>
                      </div>
                      <div class="column breakline">
                        <span class="as_dt">카드번호</span>
                        <span class="as_dd text-grey-2"
                          >국민카드 1234-3456-5678-****</span
                        >
                      </div>
                    </div>
                  </div>
                </div>
                <div class="expantion_item">
                  <p class="item_header">과목</p>
                  <div class="item_body">
                    <div class="wrap_row">
                      <div class="column">
                        <span class="as_dt">눈높이 코어수학</span>
                        <span class="as_dd">
                          <ul class="ul_custom mt10 ml10">
                            <li>월/10:00/내방 - 30,000원</li>
                            <li>월/14:00/외방 - 40,000원</li>
                            <li>수/10:00/내방 - 30,000원</li>
                          </ul>
                        </span>
                      </div>
                      <div class="column">
                        <span class="as_dt">눈높이 일본어</span>
                        <span class="as_dd">
                          <ul class="ul_custom mt10 ml10">
                            <li>월/10:00/내방 - 30,000원</li>
                          </ul>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </q-expansion-item>
          </q-card-section>
        </div>

        <!-- wrap_linear-progress -->
        <div class="sample_box">
          <div class="text-subtitle2">gray_roundbox wrap_linear-progress</div>
          <q-card-section>
            <div class="gray_roundbox">
              <q-expansion-item
                default-opened
                class="border_type"
                label="수업현황/출결현황"
              >
                <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
                <!-- wrap_linear-progress -->
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">1팀</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <!--// wrap_linear-progress -->
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">2팀</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress green">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">신대방 LC</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress yellow">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">보라매 LC</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress orange">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
              </q-expansion-item>
            </div>
          </q-card-section>
        </div>

        <!-- 반응형 검색영역 -->
        <div class="sample_box">
          <div class="text-subtitle2">
            반응형 검색영역 table_search_area type_flexable
          </div>
          <q-card-section>
            <p>
              table_search_area type_flexable (반응형 pc일때는 왼쪽정렬
              모바일에는 아래로)
            </p>
            <!-- table_search_area type_flexable -->
            <div class="table_search_area type_flexable">
              <div class="search_item">
                <!-- <h3>메시지명</h3> -->
                <q-input
                  class="inp_search"
                  outlined
                  v-model="msg_name"
                  placeholder="메시지명을 입력하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="search_item">
                <!-- <h3>등록자</h3> -->
                <q-input
                  class="box_580 inp_author"
                  outlined
                  v-model="author"
                  placeholder="등록자를 입력하세요"
                />
              </div>
              <div class="search_item">
                <!-- <h3>사용여부</h3> -->
                <q-select
                  class="box_l inp_use"
                  v-model="searchUseSelected"
                  :options="searchSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="search_item">
                <!-- <h3>구분</h3> -->
                <q-select
                  class="box_l inp_msg_type"
                  v-model="searchSelectChoice"
                  :options="searchSelectChoiceOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="search_item btn_area">
                <q-btn
                  fill
                  unelevated
                  class="size_sm btn_search"
                  label="조회"
                />
                <q-btn
                  class="size_sm btn_reset"
                  icon=""
                  outline
                  label="초기화"
                />
              </div>
            </div>
            <!--// table_search_area type_flexable -->
          </q-card-section>
        </div>

        <!-- 코멘트 wrap_info_box -->
        <div class="sample_box">
          <div class="text-subtitle2">코멘트 wrap_info_box</div>
          <q-card-section>
            <div class="wrap_info_box">
              <div class="tit_area">
                <q-icon name="icon-info02" class="icon_svg"></q-icon>
                <span>조회조건</span>
              </div>
              <div class="content">
                <p>눈높이서비스부문 > 서울서북본부 > 영등포교육국</p>
              </div>
            </div>
            <div class="wrap_info_box">
              <div class="tit_area">
                <q-icon name="icon-info" class="icon_svg"></q-icon>
                <span>참고하세요</span>
              </div>
              <div class="content">
                <p>
                  소개입회지수 - 눈높이 교육국 간 소개입회를제외한 소개입회실적
                </p>
                <p>
                  ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
                  소개입회지수, 소개퇴회지수 실적임
                </p>
              </div>
              <div class="btn_area">
                <q-btn
                  fill
                  unelevated
                  color="grey-4"
                  class="size_xs"
                  label="더보기"
                />
              </div>
            </div>
            <div class="wrap_info_box v_center">
              <div class="tit_area">
                <q-icon name="icon-info" class="icon_svg"></q-icon>
                <span>참고하세요</span>
              </div>
              <div class="content">
                <p>버튼 있는 케이스 + pc 한줄 + 가운데 정렬</p>
              </div>
              <div class="btn_area">
                <q-btn
                  fill
                  unelevated
                  color="grey-4"
                  class="size_xs"
                  label="더보기"
                />
              </div>
            </div>
          </q-card-section>
        </div>

        <!-- 닷 리스트 + 인포박스 info_list_box -->
        <div class="sample_box">
          <div class="text-subtitle2">
            닷 리스트 ul_custom + 인포박스 info_list_box
          </div>
          <q-card-section>
            <div class="info_list_box">
              <ul class="ul_custom disc">
                <li>
                  데이터가 많아 조회하는데 무리가 갈 수 있으므로 범위는
                  1일(하루)로 해주십시오.
                </li>
                <li>
                  각 교실의 인원수 Coloum을 클릭하여 교실별 인원수를
                  확인하십시요.
                </li>
              </ul>
            </div>
          </q-card-section>
        </div>

        <!-- 숫자 리스트 ol_custom -->
        <div class="sample_box">
          <div class="text-subtitle2">숫자 리스트 ol_custom</div>
          <q-card-section>
            <div class="info_list_box">
              <ul class="ol_custom">
                <li>엑셀업로드시 해당파일을 닫고 작업하시기 바랍니다.</li>
                <li>
                  생성클릭시 실시간으로 지점에 반영되는 데이터이며, 수정
                  불가합니다.
                </li>
                <li>
                  월말은 전사 작업량이 많으니 되도록 자제 부탁드립니다.
                  (입금마감 시간은 9시, 2시, 6시)
                </li>
              </ul>
            </div>
          </q-card-section>
        </div>

        <!-- 아이콘 문구 -->
        <div class="sample_box pa10">
          <p class="txt_exclamation">
            카드이체로 부터 ‘20일 이내’ 취소 가능합니다.
          </p>
          <p class="txt_exclamation">
            문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 문장이
            긴 경우 문장이 긴 경우 문장이 긴 경우 카드이체로 부터 ‘20일 이내’
            취소 가능합니다.
          </p>
          <p class="txt_exclamation">
            <b>카드이체로 부터 ‘20일 이내’ 취소 가능합니다.</b>
          </p>
          <p class="txt_exclamation">
            <b
              >문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 문장이 긴 경우
              문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 카드이체로 부터 ‘20일
              이내’ 취소 가능합니다.</b
            >
          </p>
          <p class="txt_exclamation2">
            카드이체로 부터 ‘20일 이내’ 취소 가능합니다.
          </p>
          <p class="txt_exclamation2">
            문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 문장이 긴 경우 문장이
            긴 경우 문장이 긴 경우 문장이 긴 경우 카드이체로 부터 ‘20일 이내’
            취소 가능합니다.
          </p>
        </div>

        <!-- 체크박스 -->
        <div class="sample_box">
          <div class="text-subtitle2">박스형태 체크박스, 라디오</div>
          <q-card-section>
            <!-- 라디오 -->
            <q-radio
              v-model="payment"
              val="type1"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              dense
              class="radio_custom_borderbox"
            >
              <div class="txt">
                <div class="row items-center text-black">
                  <p class="text-h2">김머니</p>
                  <p class="title4">(할머니)</p>
                </div>
                <p class="body2 text-grey-3 mt6">010-1234-5678</p>
              </div>
            </q-radio>

            <!-- 뱃지있는 라디오 'badge' 클래스 추가 -->
            <q-radio
              v-model="payment"
              val="type2"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              dense
              class="radio_custom_borderbox badge"
            >
              <div class="txt">
                <q-badge color="black" class="medium mb4">대표보호자</q-badge>
                <div class="row items-center text-black">
                  <p class="text-h2">박나래</p>
                  <p class="title4">(어머니)</p>
                </div>
                <p class="body2 text-grey-3 mt6">010-1234-5678</p>
              </div>
            </q-radio>

            <!-- 체크박스 -->
            <q-checkbox
              v-model="paymentchk"
              val="type1"
              color="black"
              dense
              class="radio_custom_borderbox"
            >
              <div class="txt">
                <div class="row items-center text-black">
                  <p class="text-h2">김머니</p>
                  <p class="title4">(할머니)</p>
                </div>
                <p class="body2 text-grey-3 mt6">010-1234-5678</p>
              </div>
            </q-checkbox>

            <!-- 뱃지있는 체크박스 'badge' 클래스 추가 -->
            <q-checkbox
              v-model="paymentchk"
              val="type2"
              color="black"
              dense
              class="radio_custom_borderbox badge"
            >
              <div class="txt">
                <q-badge color="black" class="medium mb4">대표보호자</q-badge>
                <div class="row items-center text-black">
                  <p class="text-h2">김머니</p>
                  <p class="title4">(할머니)</p>
                </div>
                <p class="body2 text-grey-3 mt6">010-1234-5678</p>
              </div>
            </q-checkbox>
          </q-card-section>
        </div>

        <!-- toggle option list -->
        <div class="sample_box">
          <div class="text-subtitle2">Toggle 옵션 리스트</div>
          <q-card-section>
            <q-list class="list_toggle_option mt16">
              <!-- 옵션 -->
              <q-item tag="label">
                <q-item-section>
                  <q-item-label>
                    <p class="title3">옵션제목</p>
                    <p class="text-body2 text-grey-3 mt4">옵션설명</p>
                  </q-item-label>
                </q-item-section>
                <q-item-section avatar>
                  <q-toggle
                    color="positive"
                    v-model="toggleList.opt1"
                    val="friend"
                    dense
                  />
                </q-item-section>
              </q-item>

              <!-- 옵션 -->
              <q-item tag="label">
                <q-item-section>
                  <q-item-label>
                    <p class="title3">옵션제목</p>
                    <p class="text-body2 text-grey-3 mt4">옵션설명</p>
                  </q-item-label>
                </q-item-section>
                <q-item-section avatar>
                  <q-toggle
                    color="positive"
                    v-model="toggleList.opt2"
                    val="friend"
                    dense
                  />
                </q-item-section>
              </q-item>

              <!-- 옵션 : disable -->
              <q-item tag="label" class="disable">
                <q-item-section>
                  <q-item-label>
                    <p class="title3">옵션제목 disable</p>
                    <p class="text-body2 text-grey-3 mt4">옵션설명 disable</p>
                  </q-item-label>
                </q-item-section>
                <q-item-section avatar>
                  <q-toggle
                    color="positive"
                    v-model="toggleList.opt3"
                    val="friend"
                    dense
                    disable
                  />
                </q-item-section>
              </q-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- 회색 배경, 번호 목록 -->
        <div class="sample_box">
          <div class="mb20">
            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">1</span>
                  </q-badge>
                  <span class="question">평가총원성장지수</span>
                </div>
              </template>
              <p class="answer">
                현재총원지수 - 월초총원지수 + 전출지수 - 전입지수
              </p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">2</span>
                  </q-badge>
                  <span class="question">평가총원성장지수 달성률</span>
                </div>
              </template>
              <p class="answer">평가총원성장지수 / 목표지수 x 100</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">3</span>
                  </q-badge>
                  <span class="question">평가총원성장지수율</span>
                </div>
              </template>
              <p class="answer">평가총원성장지수 / 월초총원지수 x 100</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">4</span>
                  </q-badge>
                  <span class="question">제품지수</span>
                </div>
              </template>
              <p class="answer">현재총원지수 / 현재총원</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">5</span>
                  </q-badge>
                  <span class="question"
                    >디스크립션 없는 타입 : 증빙번호 수정시
                    [소비자소득공제용/사업자지출증빙요]을 정확히 체크하시기
                    바랍니다.</span
                  >
                </div>
              </template>
            </q-expansion-item>
          </div>
        </div>

        <!-- image carousel -->
        <div class="sample_box">
          <div class="text-subtitle2">이미지 Carousel</div>

          <!-- image slides -->
          <q-carousel
            animated
            v-model="slide"
            transition-prev="jump-right"
            transition-next="jump-left"
            swipeable
            navigation
            infinite
            class="image_slider mb30"
          >
            <q-carousel-slide
              v-for="(item, index) in slideImg"
              :key="index"
              :name="index"
              :img-src="item.url"
            />
          </q-carousel>
          <!-- //image slides -->
        </div>
      </div>
    </q-intersection>
  </div>
</template>
<style lang="scss">
@import 'src/assets/sass/responsive/temp.scss';
</style>
<style lang="scss" scoped>
.screen--lg .wrap_goods_type02 > .item {
  width: 100%;
}
.screen--lg {
  .sample_box {
    width: 46%;
    .wrap_goods > .item {
      width: 100%;
    }
  }
}

// body.screen--sm {
//   .q-card__section > section {
//     margin: 0;
//   }
//   .sample_box > .q-card__section.q-card__section--vert {
//     padding: 0;
//   }
// }
.sample_box {
  background: #fff;
  width: 392px;
  height: 392px;
  overflow-y: scroll;
  border-radius: 10px;
  box-shadow: 0 1px 5px #0003, 0 2px 2px #00000024, 0 3px 1px -2px #0000001f;
  width: 100%;
  & > section {
    padding: 10px !important;
    border: none;
    margin: 0;
  }
  section {
    &.list_profile_small {
      margin-bottom: 20px;
    }
    &.list_profile_state {
      margin-bottom: 20px;
    }
  }
  .text-subtitle2 {
    text-align: center;
    background: #eee;
    padding: 10px;
    position: sticky;
    top: 0;
    z-index: 10;
  }
}

.expansion_custom.type01 {
  & ~ .expansion_custom.type01 {
    margin-top: 10px;
  }
}

.expansion_custom.type02 {
  & ~ .expansion_custom.type02 {
    margin-top: 10px;
  }
}

.expansion_custom.type03 {
  & ~ .expansion_custom.type03 {
    margin-top: 10px;
  }
}

.expansion_custom.type04 {
  & ~ .expansion_custom.type04 {
    margin-top: 10px;
  }
}

.expansion_custom.type06 {
  & ~ .expansion_custom.type06 {
    margin-top: 10px;
  }
}

.student_card {
  & ~ .student_card {
    margin-top: 15px;
  }
}

.wrap_info_box {
  & ~ .wrap_info_box {
    margin-top: 15px;
  }
}
</style>
<script setup>
import { ref } from 'vue';
const progress = ref('26');
function onClick() {
  console.log('툴팁');
}
// const dataRadio = ref('Y');
// const dataRadio2 = ref('children');
const expansionCustomType04Check = ref(['all']);

// 과목보기 토글
const hideSubject = ref(false);

const payment = ref('type1');
const paymentchk = ref(['type1']);

const toggleList = ref({
  opt1: true, //옵션1
  opt2: false, //옵션2
  opt3: true, //옵션3
});

// image slides
const slide = ref(0);

// image slides url
const slideImg = ref([
  {
    url : 'https://cdn.quasar.dev/img/mountains.jpg'
  },
  {
    url : 'https://cdn.quasar.dev/img/parallax1.jpg'
  },
  {
    url : 'https://cdn.quasar.dev/img/parallax2.jpg'
  },
  {
    url : 'https://cdn.quasar.dev/img/quasar.jpg'
  }
])
</script>
