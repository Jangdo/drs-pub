<template>
  <div class="inner_admin">
    <!-- breadcrumbs -->
    <q-breadcrumbs active-color="#666" class="mb10">
      <template v-slot:separator>
        <q-icon size="1.5em" name="chevron_right" />
      </template>
      <q-breadcrumbs-el label="HOME" to="/pub" />
      <q-breadcrumbs-el label="공통관리" to="/pub/admin" />
      <q-breadcrumbs-el :label="$route.name" />
    </q-breadcrumbs>
    <!--// breadcrumbs -->
    <!-- wrapper_tab  -->
    <div class="wrapper_tab">
      <!--  탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="text-grey"
        active-color="primary"
        indicator-color="primary"
        align="justify"
        narrow-indicator outside-arrows
      >
        <q-tab name="upper" label="상위코드" />
        <q-tab name="downer" label="하위코드" />
      </q-tabs>
      <!--//  탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 상위코드 tab 컨텐츠 -->
        <q-tab-panel name="upper">
          <!-- table_serch_area type_01 -->
          <div class="table_serch_area type_01">
            <div class="input_area">
              <q-select
                class="box_m"
                v-model="dataSelect"
                :options="dataSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
                :class="[dataSelect == 0 ? 'placehoder' : '']"
              >
              </q-select>
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword"
                placeholder="코드 or 코드명을 입력하세요"
              />
            </div>
            <div class="btn_area">
              <q-btn class="btn_fill" dense flat label="조회" />
              <q-btn
                class="btn_txt"
                icon="ion-ios-refresh"
                dense
                outline
                label="초기화"
              />
            </div>
          </div>
          <!--// table_serch_area type_01 -->
          <!-- add_code_table -->
          <div class="add_code_table">
            <div class="btn_area">
              <q-btn
                class="btn_txt"
                icon="ion-ios-add"
                dense
                outline
                label="행추가"
              />
            </div>
            <q-table
              :rows="add_rows"
              :columns="add_columns"
              row-key="code"
              v-model:pagination="add_pagination"
              hide-pagination
            >
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td style="width: 48px">
                    <q-btn
                      icon="ion-ios-close"
                      dense
                      flat
                      label=""
                      size="36px"
                    />
                  </q-td>
                  <q-td key="code">
                    <div style="display: flex; flex-direction: row">
                      <q-select
                        class="box_m"
                        v-model="props.row.code.select"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>

                      <q-input
                        outlined
                        v-model="props.row.code.input"
                        :error="props.row.code.sample_err"
                        dense
                      >
                        <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                      </q-input>
                    </div>
                  </q-td>
                  <q-td key="name">
                    <q-input
                      outlined
                      v-model="props.row.name"
                      placeholder="기본 인풋창"
                      dense
                    />
                  </q-td>
                  <q-td key="state" class="text-center">
                    {{ tdState(props.row.state) }}</q-td
                  >
                  <q-td key="allow" :props="props">
                    <q-toggle v-model="props.row.allow" color="negative" />
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!--// edite_table -->
          <!-- edite_table -->
          <div class="edite_table type_01">
            <div class="btn_area">
              <q-btn
                class="btn_txt"
                icon="ion-ios-remove"
                dense
                outline
                label="행삭제"
              />
              <q-btn
                class="btn_fill"
                dense
                icon="ion-ios-document"
                label="저장"
              />
            </div>
            <q-table
              :rows="rows"
              :columns="columns"
              row-key="code"
              v-model:selected="selected"
              selection="multiple"
              v-model:pagination="pagination"
              hide-pagination
            >
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td>
                    <template v-if="props.row.state == 'add'">
                      <q-btn
                        icon="ion-ios-close"
                        dense
                        flat
                        label=""
                        size="36px"
                      />
                    </template>
                    <template v-else>
                      <q-checkbox v-model="props.selected" />
                    </template>
                  </q-td>
                  <q-td key="sysytemSelect">
                    <template v-if="props.row.state == 'add'">
                     <q-select
                        class="box_m"
                        v-model="props.row.sysytemSelect"
                        :options="SystemSelectionOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </template>
                    <template v-else>
                      {{ props.row.code }}
                      <q-popup-edit
                        v-model="props.row.code"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" dense autofocus />
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="upperCodeSelect">
                    <template v-if="props.row.state == 'add'">
                     <q-select
                        class="box_m"
                        v-model="props.row.upperCodeSelect"
                        :options="UppercodeSelectionOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </template>
                    <template v-else>
                      {{ props.row.code }}
                      <q-popup-edit
                        v-model="props.row.code"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" dense autofocus />
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="code">
                    <template v-if="props.row.state == 'add'">
                     <q-input
                        outlined
                        v-model="props.row.code"
                        :error="props.row.code.sample_err"
                        dense
                      >
                        <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                      </q-input>
                    </template>
                    <template v-else>
                      {{ props.row.code }}
                      <q-popup-edit
                        v-model="props.row.code"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" dense autofocus />
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="name">
                    {{ props.row.name }}
                    <q-popup-edit
                      v-model="props.row.name"
                      buttons
                      label-set="확인"
                      label-cancel="취소"
                      v-slot="scope"
                    >
                      <q-input v-model="scope.value" dense autofocus />
                    </q-popup-edit>
                  </q-td>
                  <q-td key="state" class="text-center">
                    {{ tdState(props.row.state) }}</q-td
                  >
                  <q-td key="allow" :props="props">
                    <q-toggle v-model="props.row.allow" color="negative" />
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!--// edite_table -->
        </q-tab-panel>
        <!--// 상위코드  tab 컨텐츠 -->
        <!-- 하위코드  tab 컨텐츠 -->
        <q-tab-panel name="downer">
          <!-- wrap_table_col2 -->
          <div class="wrap_table_col2 row-2">
            <div class="sm_area">
              <!-- 상위코드 선택 table  -->
              <div class="edite_table type_01">
                <q-table
                  :rows="upper_choice_rows"
                  :columns="upper_choice_columns"
                  row-key="code"
                  v-model:pagination="upper_choice_pagination"
                  hide-pagination
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td key="code">
                        {{ props.row.code }}
                      </q-td>
                      <q-td key="name">
                        {{ props.row.name }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 상위코드 선택 table  -->
            </div>
            <div class="main_area">
              <!--하위코드 add_code_table -->
              <div class="add_code_table">
                <div class="btn_area">
                  <q-btn
                    class="btn_txt"
                    icon="ion-ios-add"
                    dense
                    outline
                    label="행추가"
                  />
                </div>
                <q-table
                  :rows="downer_add_rows"
                  :columns="downer_add_columns"
                  row-key="code"
                  v-model:pagination="downer_add_pagination"
                  hide-pagination
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td style="width: 48px">
                        <q-btn
                          icon="ion-ios-close"
                          dense
                          flat
                          label=""
                          size="36px"
                        />
                      </q-td>
                      <q-td key="code">
                        <div style="display: flex; flex-direction: row">
                          <q-select
                            class="box_m"
                            v-model="props.row.code.select"
                            :options="dataSelectOption"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                            :class="[dataSelect == 0 ? 'placehoder' : '']"
                          >
                          </q-select>

                          <q-input
                            outlined
                            v-model="props.row.code.input"
                            :error="props.row.code.sample_err"
                            dense
                          >
                            <!-- <template v-slot:error>
                            동일한 이름이 있습니다.
                          </template> -->
                          </q-input>
                        </div>
                      </q-td>
                      <q-td key="name">
                        <q-input
                          outlined
                          v-model="props.row.name"
                          placeholder="기본 인풋창"
                          dense
                        />
                      </q-td>
                      <q-td key="state" class="text-center">
                        {{ tdState(props.row.state) }}</q-td
                      >
                      <q-td key="allow" :props="props">
                        <q-toggle v-model="props.row.allow" color="negative" />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--//하위코드 add_code_table -->
              <!-- 하위코드 edite_table -->
              <div class="edite_table type_01">
                <div class="btn_area">
                  <q-btn
                    class="btn_txt"
                    icon="ion-ios-remove"
                    dense
                    outline
                    label="행삭제"
                  />
                  <q-btn
                    class="btn_fill"
                    dense
                    icon="ion-ios-document"
                    label="저장"
                  />
                </div>
                <q-table
                  :rows="downer_rows"
                  :columns="downer_columns"
                  row-key="code"
                  v-model:selected="downer_selected"
                  selection="multiple"
                  v-model:pagination="downer_pagination"
                  hide-pagination
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td>
                        <q-checkbox v-model="props.selected" />
                        <div
                          class="add_td"
                          v-if="props.row.state == 'add'"
                        ></div>
                      </q-td>
                      <q-td key="code">
                        {{ props.row.code }}
                        <q-popup-edit
                          v-model="props.row.code"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-input v-model="scope.value" dense autofocus />
                        </q-popup-edit>
                      </q-td>
                      <q-td key="name">
                        {{ props.row.name }}
                        <q-popup-edit
                          v-model="props.row.name"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-input v-model="scope.value" dense autofocus />
                        </q-popup-edit>
                      </q-td>
                      <q-td key="state" class="text-center">
                        {{ tdState(props.row.state) }}</q-td
                      >
                      <q-td key="allow" :props="props">
                        <q-toggle v-model="props.row.allow" color="negative" />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 하위코드 edite_table -->
            </div>
          </div>
        </q-tab-panel>
        <!--// 하위코드  tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

// tab
const tab = ref('upper');
// const tab = ref('downer');
// dropdown
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: '',
    desc: '코드를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
// serchbox input
const keyword = ref('');
// tab upper
//상위코드 edit_ table데이터
const selected = ref([]);
const columns = ref([
   {
    name: 'sysytemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'left',
  },
   {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'left',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,

    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const rows = ref([
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    sysytemSelect:'SALE_01',
    upperCodeSelect:'SALE_01',
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
]);
const SystemSelectionOption = ref([
  {
    id: '',
    desc: '코드를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '시스템 눈높이(N)',
  },
  {
    id: 'G',
    desc: '시스템 학원(G)',
  },
  {
    id: 'C',
    desc: '시스템 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '시스템 MOS(M)',
  },
]);

const UppercodeSelectionOption = ref([
  {
    id: '',
    desc: '코드를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '상위 눈높이(N)',
  },
  {
    id: 'G',
    desc: '상위 학원(G)',
  },
  {
    id: 'C',
    desc: '상위 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '상위 MOS(M)',
  },
]);


const pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

//상위코드 add_code_table 데이터

const add_columns = ref([
  {
    name: 'btn',
    label: '',
    sortable: false,
    //
    align: 'left',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,

    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const add_rows = ref([
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001', sample_err: true },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
]);
const add_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});
// tab downer
//하위코드 edit_ table데이터
const downer_selected = ref([]);
const downer_columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: false,

    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const downer_rows = ref([
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
]);
const downer_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

//상위코드 선택 table 데이터
const upper_choice_columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: false,

    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
]);
const upper_choice_rows = ref([
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
]);
const upper_choice_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

//하위코드 add_code_table 데이터
const downer_add_columns = ref([
  {
    name: 'btn',
    label: '',
    sortable: false,
    //
    align: 'left',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,

    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const downer_add_rows = ref([
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001', sample_err: true },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
]);
const downer_add_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

// td 상태값
function tdState(priority) {
  switch (priority) {
    case 'add':
      return '신규';
    case 'edit':
      return '수정';
    default:
      return '';
  }
}
</script>
<style lang="scss">
.add_code_table {
  margin-bottom: 20px;
}
.sm_area {
  margin-right: 50px;
}
</style>
