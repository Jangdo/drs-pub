<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>

  <vue-masonry-wall :items="items" :options="options">
    <template v-slot:default="{ item, index }">
      <div class="item" :style="'height:' + item.height">
        <h5>item: {{ index }} ,height:{{ item.height }}</h5>
        <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Atque neque
          provident, deserunt vero nisi nemo ut voluptas, expedita esse quam
          voluptatibus. Doloribus velit quasi quos laudantium fugit numquam
          soluta quae.
        </p>
      </div>
    </template>
  </vue-masonry-wall>
</template>

<script setup>
import { ref } from 'vue';
import VueMasonryWall from '@yeger/vue-masonry-wall';
const options = ref({
  width: 300,
  padding: {
    default: 12,
    2: 8,
    3: 8,
  },
});
const items = ref([
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '2500px' },
  { title: 'Item 2', height: '450px' },
  { title: 'Item 3', height: '200px' },
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '300px' },
  { title: 'Item 2', height: '230px' },
  { title: 'Item 3', height: '500px' },
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '110px' },
  { title: 'Item 2', height: '300px' },
  { title: 'Item 3', height: '300px' },
  { title: 'Item 2', height: '450px' },
  { title: 'Item 3', height: '200px' },
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '300px' },
  { title: 'Item 2', height: '320px' },
  { title: 'Item 3', height: '500px' },
  { title: 'Item 2', height: '450px' },
  { title: 'Item 3', height: '200px' },
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '300px' },
  { title: 'Item 2', height: '230px' },
  { title: 'Item 3', height: '500px' },
  { title: 'Item 2', height: '450px' },
  { title: 'Item 3', height: '200px' },
  { title: 'Item 0', height: '300px' },
  { title: 'Item 1', height: '300px' },
  { title: 'Item 2', height: '230px' },
  { title: 'Item 3', height: '500px' },
]);
</script>
<style lang="scss">
.item {
  padding: 16px 24px;
  border-radius: 3px;
  background: #f5f5f5;
  margin: 7px 10px;
  border: 1px solid #ddd;
}

@media (min-width: 1200px) {
  #app {
    padding-left: 80px;
    padding-right: 80px;
  }
}
h2 {
  font-size: 230px;
  margin: 0 0 24px;
}
h5 {
  font-size: 18px;
  line-height: 1.5;
  margin: 0 0 8px;
}
p {
  font-size: 17px;
  line-height: 1.5;
  font-weight: 400;
  margin: 0;
  word-break: break-word;
}
.item {
  padding: 16px 24px;
  border-radius: 3px;
  background: #f5f5f5;
}
</style>
