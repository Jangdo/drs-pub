<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label=$route.name />
  </q-breadcrumbs>
  <div class="wrap_ia_list">
    <div class="lottie_page">
      <Vue3Lottie
        class="lottie_area"
        ref="customControl"
        :animationData="CountdownJSON"
      />
      <div class="btn_area">
        <h3 class="text-h4 mb10">play stop pause</h3>
        <q-btn color="white" text-color="black" label="pause" @click="pause" />
        <q-btn color="primary" label="play" @click="play" />
        <q-btn color="secondary" label="stop" @click="stop" />
        <h3 class="text-h4 mb10">playGo</h3>
        <q-btn-group playGo>
          <q-btn playGo label="5" @click="playGo(0)" />
          <q-btn playGo label="4" @click="playGo(100)" />
          <q-btn playGo label="3" @click="playGo(200)" />
          <q-btn playGo label="2" @click="playGo(300)" />
          <q-btn playGo label="1" @click="playGo(500)" />
        </q-btn-group>
        <br />
        <h3 class="text-h4 mb10">playStop</h3>
        <q-btn-group playStop>
          <q-btn playStop label="5" @click="playStop(0)" />
          <q-btn playStop label="4" @click="playStop(100)" />
          <q-btn playStop label="3" @click="playStop(200)" />
          <q-btn playStop label="2" @click="playStop(300)" />
          <q-btn playStop label="1" @click="playStop(500)" />
        </q-btn-group>
        <h3 class="text-h4 mb10">playSegments</h3>
        <div>
          <q-range v-model="lottieSeg" :min="0" :max="600" :step="5" label />
          from: {{ lottieSeg.min }} --- to: {{ lottieSeg.max }}
          <q-btn label="seg play" @click="playSeg(lottieSeg)" />
        </div>
        <div>
          <q-toggle
            :label="direction + ' play'"
            color="pink"
            false-value="forward"
            true-value="reverse"
            v-model="direction"
            @click="toggleDirection()"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import 'vue3-lottie/dist/style.css';
import { Vue3Lottie } from 'vue3-lottie';
import CountdownJSON from '/public/lottie/snowball.json';

const customControl = ref(null);
const direction = ref('forward');
const lottieSeg = ref({
  min: 0,
  max: 600,
});
function playSeg() {
  console.log(lottieSeg);
  customControl.value.playSegments(
    [lottieSeg.value.min, lottieSeg.value.max],
    true
  );
}
function playStop(time) {
  customControl.value.goToAndStop(time, true);
}
function playGo(time) {
  customControl.value.goToAndPlay(time, true);
}
function play() {
  customControl.value.play();
}
function pause() {
  customControl.value.pause();
}
function stop() {
  customControl.value.stop();
}
function toggleDirection() {
  console.log(customControl);
  customControl.value.setDirection(direction.value);
}
// function getFrameCount() {
//   alert(
//     `This animation has ${customControl.value.getDuration(true)} frames`
//   );
// }
// function getTimeCount() {
//   alert(
//     `This animation takes ${customControl.value.getDuration(false)} seconds`
//   );
// }
</script>
