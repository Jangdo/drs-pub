<script>
import FullCalendar from '@fullcalendar/vue3';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
export default {
  components: {
    FullCalendar, // make the <FullCalendar> tag available
  },
  data: function () {
    return {
      calendarOptions: {
        initialDate: '2023-01-10',
        initialView: 'timeGridWeek',
        editable: true,
        selectable: true,
        plugins: [dayGridPlugin, interactionPlugin],
        locale: 'ko',

        initialView: 'dayGridMonth',
        dateClick: this.handleDateClick,
        eventClick: this.handleEvtClick,
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth',
        },
        select: this.handleSelect,
        weekends: false,
        events: [
          {
            title: 'Meeting',
            start: '2023-01-11T10:00:00',
            end: '2023-01-15T16:00:00',
          },
          {
            start: '2023-01-11T10:00:00',
            end: '2023-01-11T16:00:00',
            display: 'background',
            color: '#ff9f89',
          },
          {
            start: '2023-01-13T10:00:00',
            end: '2023-01-13T16:00:00',
            display: 'background',
            color: '#ff9f89',
          },
          {
            start: '2023-01-24',
            end: '2023-01-28',
            overlap: false,
            display: 'background',
          },
          {
            start: '2023-01-06',
            end: '2023-01-08',
            overlap: false,
            display: 'background',
          },
        ],
      },
    };
  },
  methods: {
    handleDateClick: function (info) {
      alert('dateaad click! ' + info.startStr + ' to ' + info.endStr, 'aaaa');
    },
    handleSelect: function (info) {
      alert('selected ' + info.startStr + ' to ' + info.endStr, 'aaaa');
    },
    handleEvtClick: function (info) {
      var eventObj = info.event;
      alert('Clicked ' + eventObj.title);
    },
  },
};
</script>

<template>
  <h1>Demo App</h1>
  <FullCalendar :options="calendarOptions" />
</template>
