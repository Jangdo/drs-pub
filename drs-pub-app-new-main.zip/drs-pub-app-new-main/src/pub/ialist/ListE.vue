<template>
  <div class="wrap_ia_list">
    <q-table
      title="[E]마이"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            {{ props.row.name }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  // 230531 추가분

  {
    name: 'E030213',
    Depth2: '퀵메뉴',
    Depth3: '승인 - 대량회원이동 승인 요청서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E030214',
    Depth2: '퀵메뉴',
    Depth3: ' 승인 - 승인리스트 - 기타',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030215',
    Depth2: '퀵메뉴',
    Depth3: '승인 회비대체 승인요청서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E030216',
    Depth2: '퀵메뉴',
    Depth3: '승인 환불의뢰 승인 요청서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'E',
    Depth2: '마이',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E0101P',
    Depth2: '마이',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '토글버튼',
  },
  {
    name: 'E02',
    Depth2: '내프로필 관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E020101P',
    Depth2: '내프로필 관리',
    Depth3: '주소검색 /pc상관없음',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt',
  },
  {
    name: 'E020102P',
    Depth2: '내프로필 관리',
    Depth3: '주소검색 입력/pc상관없음',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt',
  },
  {
    name: 'E020103P',
    Depth2: '내프로필 관리',
    Depth3: '상세주소 입력/pc상관없음',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E0202P',
    Depth2: '내프로필 관리',
    Depth3: '선생님소개',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'E0203P',
  //   Depth2: '내프로필 관리',
  //   Depth3: '조직원 인증',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'E0204P',
    Depth2: '내프로필 관리',
    Depth3: '프로필 사진 변경',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'E0205P',
  //   Depth2: '내프로필 관리',
  //   Depth3: '조직원 신청',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'E0203',
    Depth2: '내프로필 관리',
    Depth3: '권한위임',
    Infor: {
      date: '',
      state: '완료',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E0301',
    Depth2: '퀵메뉴',
    Depth3: '알림',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '탭변경',
  },
  {
    name: 'E0302',
    Depth2: '퀵메뉴',
    Depth3: '승인 리스트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030201',
    Depth2: '퀵메뉴',
    Depth3: '승인 - 승인 조직/채널',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030202',
    Depth2: '퀵메뉴',
    Depth3: '승인 - 조직원 승인요청서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'E030203',
  //   Depth2: '퀵메뉴',
  //   Depth3: '승인 -옵션변경 퇴회 승인 요청서',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  // {
  //   name: 'E030204',
  //   Depth2: '퀵메뉴',
  //   Depth3: '승인 -옵션변경 입회 승인 요청서',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'E030205',
    Depth2: '퀵메뉴',
    Depth3: '승인 -학습유형 변경 승인 요청서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030206',
    Depth2: '퀵메뉴',
    Depth3: '승인 -과목변경 승인 요청서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030207',
    Depth2: '퀵메뉴',
    Depth3: '승인 -회원이동 승인 요청서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  //
  {
    name: 'E03020601',
    Depth2: '퀵메뉴',
    Depth3: '퀵메뉴과목변경 반려사유',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E03020101P',
    Depth2: '퀵메뉴',
    Depth3: '퀵메뉴과목변경 반려사유 팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'E03020701',
    Depth2: '퀵메뉴',
    Depth3: '회원이동 반려사유',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E03020801',
    Depth2: '퀵메뉴',
    Depth3: '퇴회확인서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E030212',
    Depth2: '퀵메뉴',
    Depth3: '과목변경',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'E030208',
    Depth2: '퀵메뉴',
    Depth3: '퀵메뉴 -승인 -퇴회 승인 요청서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030209',
    Depth2: '퀵메뉴',
    Depth3: '퀵메뉴 -승인 - 입회 승인서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030210',
    Depth2: '퀵메뉴',
    Depth3: '승인 - 회수/AS신청 승인요청서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'E030211',
    Depth2: '퀵메뉴',
    Depth3: '승인 - 부교재/소모품 신청 승인 요청서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E0303',
    Depth2: '퀵메뉴',
    Depth3: '승인요청 -승인요청 리스트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E030301',
    Depth2: '퀵메뉴',
    Depth3: '승인요청 확인서 회수/AS신청 확인서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E0401',
    Depth2: '내실적',
    Depth3: '영업운영현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'E0402',
    Depth2: '내실적',
    Depth3: '고객만족도',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'E040201P',
    Depth2: '내실적',
    Depth3: '고객만족도 문항별평점내용',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E040202P',
    Depth2: '내실적',
    Depth3: '고객만족도 고객의견',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'E0501',
    Depth2: '내 활동 ',
    Depth3: '교재신청현황',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E050101P',
    Depth2: '내 활동 ',
    Depth3: '교재신청현황 - 긴급교재/부교재 신청상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'E050102',
    Depth2: '내 활동 ',
    Depth3: '교재신청현황 - 긴급교재신청',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E050103',
    Depth2: '내 활동 ',
    Depth3: '교재신청현황 - 긴급 부교재신청',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'E050201',
    Depth2: '내 활동 ',
    Depth3: '현급영수증관리 -조회/출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'label',
  },
  {
    name: 'E05020101P',
    Depth2: '내 활동 ',
    Depth3: '현급영수증관리 - 증빙자료인쇄',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'E050202',
    Depth2: '내 활동 ',
    Depth3: '현급영수증관리 - 재승인요청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'label',
  },
  {
    name: 'E05020201',
    Depth2: '내 활동 ',
    Depth3: '현급영수증관리 - 재승인요청-상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'E0503',
    Depth2: '내 활동 ',
    Depth3: '자동이체 제외/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'label',
  },
  {
    name: 'E050301',
    Depth2: '내실적',
    Depth3: '자동이체 제외/수정 -상세',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';

    case '1차완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}
.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}
.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
