<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>

  <div class="q-pa-sm page_Calander">
    <q-btn @click="fullCalandar.getApi().next()" label="next"></q-btn>
    <q-btn @click="fullCalandar.getApi().prev()" label="prev"></q-btn>
    <q-btn @click="fullCalandar.getApi().nextYear()" label="nextYear"></q-btn>
    <q-btn @click="fullCalandar.getApi().prevYear()" label="prevYear"></q-btn>
    <q-btn @click="fullCalandar.getApi().today()" label="today"></q-btn>
    <q-btn
      @click="fullCalandar.getApi().gotoDate('2018-06-01')"
      label="2018-06-01"
    ></q-btn>
&middot;
    <FullCalendar
      ref="fullCalandar"
      :options="calendarOptions"
      style="max-width: 800px"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import FullCalendar from '@fullcalendar/vue3';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
const fullCalandar = ref(null);
const calendarOptions = ref({
  initialDate: '2023-02-01',
  editable: false,
  selectable: false,
  showModal: true,
  plugins: [dayGridPlugin, interactionPlugin, timeGridPlugin],
  locale: 'ko',

  dateClick: handleDateClick,
  eventClick: handleEvtClick,
  headerToolbar: {
    left: 'prev,next today',
    center: 'title',
    right: '',
  },
  buttonText: {
    today: '오늘',
    month: 'month',
    week: 'week',
    day: 'day',
    list: 'list',
  },
  select: handleSelect,
  weekends: true,
  dayMaxEventRows: 2,
  events: [
    {
      title: '',
      start: '2023-02-12',
      end: '2023-02-19',
      display: 'background',
      color: '#3f51b5',
    },
    {
      title: '',
      start: '2023-01-29',
      end: '2023-02-05',
      display: 'background',
      color: '#ff9f89',
    },
    {
      title: ' · ',
      start: '2023-02-03',

    },
    {
      title: '내방',
      start: '2023-02-03',
    },
  ],
});

function handleDateClick(info) {
  alert('dateaad click! ' + info.startStr + ' to ' + info.endStr, 'aaaa');
}
function handleSelect(info) {
  alert('selected ' + info.startStr + ' to ' + info.endStr, 'aaaa');
}
function handleEvtClick(info) {
  var eventObj = info.event;
  alert('Clicked ' + eventObj.title);
}
</script>

<style>
.fc-day-sun {
  background: rgb(255 87 34 / 10%);
}
.fc-day-sat {
  background: rgb(0 188 212 / 10%);
}
</style>
