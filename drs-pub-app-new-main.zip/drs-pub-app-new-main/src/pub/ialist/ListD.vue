<template>
  <div class="wrap_ia_list">
    <q-table
      title="[D]회원"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="props.row.name.toLowerCase()">
              {{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
    <q-table
      title="[D]회원 가이드_old"
      :rows="rows_old"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            {{ props.row.name }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="props.row.name.toLowerCase()">
              {{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td key="Infor" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  // 230531 추가분
  {
    name: 'D01020102P',
    Depth2: '회원정보',
    Depth3: '수정 알림톡 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },
  {
    name: 'D0103041007P',
    Depth2: '학습관리',
    Depth3: 'OCR 결제',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010305P',
    Depth2: '학습관리',
    Depth3: '위약금 조회 - 중도해지 위약금 조회',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010601P',
    Depth2: '이력관리',
    Depth3: '지난 이력 히스토리',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010602P',
    Depth2: '이력관리',
    Depth3: '맵핑정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  //230315 디자인확정

  {
    name: 'D0101',
    Depth2: '회원',
    Depth3: '프로필 카드',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0102T',
    Depth2: '회원',
    Depth3: '회원정보 상세 - 본인회원',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010201P',
    Depth2: '회원',
    Depth3: '기본정보 관리 - 입회회원',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020101P',
    Depth2: '회원',
    Depth3: '기본정보 관리 - 체험회원',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D010202P',
    Depth2: '회원',
    Depth3: '보호자정보 목록',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020201P',
    Depth2: '회원',
    Depth3: '보호자정보 추가',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },

  {
    name: 'D01020202P',
    Depth2: '회원',
    Depth3: '보호자정보 수정 - 입회회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },

  {
    name: 'D010203P',
    Depth2: '회원',
    Depth3: '조직원 신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },

  {
    name: 'D01020301P',
    Depth2: '회원',
    Depth3: '조직원 신청 확인서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020302P',
    Depth2: '회원',
    Depth3: '조직원 정보 수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },
  //
  {
    name: 'D0302P',
    Depth2: '플레이스',
    Depth3: ' 조직도 구성원 보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010204T',
    Depth2: '회원정보 상세',
    Depth3: '  본인회원 아님 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010501',
    Depth2: '회비현황',
    Depth3: '리스트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01050101P',
    Depth2: '회비현황',
    Depth3: '결제내역-영수증 보기 팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0105020102P',
    Depth2: '회비현황',
    Depth3: '결제관리-결제일 변경',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },
  {
    name: 'D01050204T',
    Depth2: '회비현황',
    Depth3: '이월금 내역 리스트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010503',
    Depth2: '회비현황',
    Depth3: ' 영수증 목록',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01050401P',
    Depth2: '환불계좌 관리',
    Depth3: '환불계좌 등록',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D',
    Depth2: '검색',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'D0103T',
    Depth2: '학습관리',
    Depth3: '학습리스트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01030401P',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회) - 상품선택 -상품담기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D0103040103P',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회) - 상품선택 입회 횟수선택 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01030402',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회)정보입력/선생님(단일과목)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D0103040201',
    name2: '(D01030402)',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회) - 정보입력/관리자-소개(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0103040202',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회) -상품 구매 - 정보입력 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오',
  },
  {
    name: 'D0103040204',
    Depth2: '학습관리',
    Depth3: '학습관리 - 학습과목추가(입회) - 정보입력/선생님(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0103040205',
    name2: '(D0103040204)',
    Depth2: '학습관리',
    Depth3: '학습과목추가(입회) - 정보입력/관리자-소개(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01030405',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 프로모션 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'D01030406',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) -  정보확인',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'D0103040804',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) -  입회확인서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0103040807',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) -  입회확인서 - 입회취소 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //

  {
    name: 'D0103041001P',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 결제방법 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0103041002',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 결제수단 선택 - 비정기결제',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스',
  },
  {
    name: 'D0103041003',
    Depth2: '학습관리',
    Depth3: ' 합습과목추가(입회) - 결제 url - 전송하기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },

  //
  {
    name: 'D0103041004',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 결제 url 전송완료 ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D0103041005',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 결제완료',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D0103041006P',
    Depth2: '학습관리',
    Depth3: '합습과목추가(입회) - 가상계좌 교사납부',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01050201T',
    Depth2: '회비현황',
    Depth3: '결제관리- 결제수단 관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'D0301',
    Depth2: '플레이스',
    Depth3: '검색 목록',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D030101',
    Depth2: '플레이스',
    Depth3: ' 검색결과',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'D0105020101',
    Depth2: '결제수단',
    Depth3: ' 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D01050402',
    Depth2: '환불계좌',
    Depth3: '상세',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01050403',
    Depth2: '환불계좌',
    Depth3: '수정',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0106T',
    Depth2: '이력',
    Depth3: '히스토리',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'D0104P',
    Depth2: '변경선택',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104010102',
    Depth2: '옵션변경',
    Depth3: '정보확인',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104010202',
    Depth2: '옵션변경',
    Depth3: '확인서',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'D0104010301',
    Depth2: '옵션변경',
    Depth3: '정보입력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D010402',
    Depth2: '과목변경',
    Depth3: '정보입력(단일과목)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D01040201',
    Depth2: '과목변경',
    Depth3: '정보확인(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104020101',
    Depth2: '과목변경',
    Depth3: '정보확인(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'D0104010102',
  //   Depth2: '옵션변경',
  //   Depth3: '',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  {
    name: 'D01040202',
    Depth2: '과목변경',
    Depth3: '확인서(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104020201',
    Depth2: '과목변경',
    Depth3: '확인서(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01040203',
    Depth2: '과목변경',
    Depth3: ' 확인서(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0103040501P',
    Depth2: '',
    Depth3: '회차별 할인 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 토글, 하단 버튼',
  },
  // {
  //   name: 'D010403',
  //   Depth2: '',
  //   Depth3: '과목선택',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'D01040601',
    Depth2: '퇴회',
    Depth3: '정보입력(단일과목)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, html',
  },
  {
    name: 'D0104060101',
    Depth2: '퇴회',
    Depth3: '- 정보입력(패키지)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D01040602',
    Depth2: '퇴회',
    Depth3: '정보확인(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104060202',
    Depth2: '퇴회',
    Depth3: '정보확인(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01040603',
    Depth2: '퇴회',
    Depth3: '확인서(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104060301',
    Depth2: '퇴회',
    Depth3: '확인서(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01040701',
    Depth2: '회원이동',
    Depth3: '정보입력(단일과목)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오',
  },
  {
    name: 'D0104070101',
    Depth2: '회원이동',
    Depth3: ' 정보입력(패키지)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },
  {
    name: 'D01040703',
    Depth2: '회원이동',
    Depth3: '확인서(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104070301',
    Depth2: '회원이동',
    Depth3: '정보확인(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01040704',
    Depth2: '회원이동',
    Depth3: '확인서(단일과목)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0104070401',
    Depth2: '회원이동',
    Depth3: '확인서(패키지)',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'D010408',
    Depth2: '변경선택',
    Depth3: '회차선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D01040801P',
    Depth2: '변경선택',
    Depth3: '변경과목 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01040802P',
    Depth2: '변경선택',
    Depth3: '선생님 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  //
  {
    name: 'D0107',
    Depth2: '회원검색 메인',
    Depth3: '회원검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D010702',
    Depth2: '회원검색 메인',
    Depth3: '검색 필터 설정 - 회원 - 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D010703',
    Depth2: '회원검색 메인',
    Depth3: '이름으로 검색 결과',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D01070301',
    Depth2: '회원검색 메인',
    Depth3: ' 필터 설정 검색결과',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D01070302',
    Depth2: '회원검색 메인',
    Depth3: '빠른 검색결과',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'D01070303',
    Depth2: '회원미납',
    Depth3: '빠른 검색결과',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D0108',
    Depth2: '과목별검색 메인',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D010801',
    Depth2: '과목별검색 메인',
    Depth3: '상세검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'D0201',
    Depth2: '상품',
    Depth3: '상품 리스트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D02010101T',
    Depth2: '상품',
    Depth3: '상품정보 - 단일과목',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D0201010101T',
    Depth2: '상품',
    Depth3: '상품정보 - 패키지',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D02010102T',
    Depth2: '상품',
    Depth3: '상품정보 - 교재일람표',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'D0201010102P',
    Depth2: '상품',
    Depth3: '상품공유',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },
  {
    name: 'D0202',
    Depth2: '상품',
    Depth3: '검색 필터 설정 - 상품',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'D020201',
    Depth2: '상품',
    Depth3: '필터설정 검색결과',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0203',
    Depth2: '상품',
    Depth3: '학습 장바구니',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D020301',
    Depth2: '상품',
    Depth3: '입회정보 수정 - 단일과목',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D020302',
    Depth2: '상품',
    Depth3: '입회정보 수정 - 패키지',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  // {
  //   name: 'D020401',
  //   Depth2: '상품',
  //   Depth3: '체험-체험정보입력 - 과목선택',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  //
  // {
  //   name: 'D020402',
  //   Depth2: '상품',
  //   Depth3: '체험-체험정보입력 - 과목선택 없음',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  // {
  //   name: 'D020403',
  //   Depth2: '상품',
  //   Depth3: '체험-체험 확인서',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },
  {
    name: 'D020404P',
    Depth2: '상품',
    Depth3: '체험-체험 변경선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D02040401',
    Depth2: '상품',
    Depth3: '체험-체험 변경',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'D02040402P',
  //   Depth2: '상품',
  //   Depth3: '체험-이동 히스토리',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment:'',
  // },

  //
  {
    name: 'D01050202T',
    Depth2: '회비현황',
    Depth3: '청구 이력 조회',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01050203T',
    Depth2: '회비현황',
    Depth3: '환불/취소 이력조회',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D010505',
    Depth2: '회비현황',
    Depth3: '할인등록변경',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D01050501P',
    Depth2: '회비현황',
    Depth3: '할인 변경히스토리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  //
  {
    name: 'D020401',
    Depth2: '체험',
    Depth3: '체험 정보 입력(과목선택)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'D020402',
    Depth2: '체험',
    Depth3: '체험 정보 입력(과목선택없음)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },
  {
    name: 'd02040402P',
    Depth2: '체험',
    Depth3: ' 이동 히스토리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'D020403',
    Depth2: '체험',
    Depth3: '체험 변경선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  // {
  //   name: 'G0501010101p',
  //   Depth2: '',
  //   Depth3: '[성장사업] 제품지수현황-구분검색',
  //   Infor: {
  //     date: '23.02.24',
  //     state: '',
  //     worker: '윤상기,박재성',
  //   },
  //   Comment:'',
  // },
  // {
  //   name: 'G05010902',
  //   Depth2: '',
  //   Depth3: '[성장사업] 제품지수현황',
  //   Infor: {
  //     date: '23.02.24',
  //     state: '',
  //     worker: '윤상기,박재성',
  //   },
  //   Comment:'',
  // },
]);
//  리스트 데이터
const rows_old = ref([
  //230315 디자인확정
  {
    name: 'D0101_old',
    Depth2: '회원',
    Depth3: '프로필 카드',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'D0102T_old',
    Depth2: '회원',
    Depth3: '회원정보 상세 - 본인회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt',
  },
  // {
  //   name: 'D0103T_old',
  //   Depth2: '회원',
  //   Depth3: '학습관리',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  {
    name: 'D010201P_old',
    Depth2: '회원',
    Depth3: '기본정보 관리 - 입회회원',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020101P_old',
    Depth2: '회원',
    Depth3: '기본정보 관리 - 체험회원',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D010202P_old',
    Depth2: '회원',
    Depth3: '보호자정보 목록',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020201P_old',
    Depth2: '회원',
    Depth3: '보호자정보 추가',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },

  {
    name: 'D01020202P_old',
    Depth2: '회원',
    Depth3: '보호자정보 수정 - 입회회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스',
  },

  {
    name: 'D010203P_old',
    Depth2: '회원',
    Depth3: '조직원 신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },

  {
    name: 'D01020301P_old',
    Depth2: '회원',
    Depth3: '조직원 신청 확인서',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'D01020302P_old',
    Depth2: '회원',
    Depth3: '조직원 정보 수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오',
  },

  // {
  //   name: 'G0501010101p',
  //   Depth2: '',
  //   Depth3: '[성장사업] 제품지수현황-구분검색',
  //   Infor: {
  //     date: '23.02.24',
  //     state: '',
  //     worker: '윤상기,박재성',
  //   },
  //   Comment:'',
  // },
  // {
  //   name: 'G05010902',
  //   Depth2: '',
  //   Depth3: '[성장사업] 제품지수현황',
  //   Infor: {
  //     date: '23.02.24',
  //     state: '',
  //     worker: '윤상기,박재성',
  //   },
  //   Comment:'',
  // },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '1차 완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}
.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}
.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
