<template>
  <div class="wrap_ia_list">
    <q-intersection
      transition="jump-up"
      transitionDuration="400"
      id="container"
    >
      <div class="q-pa-md row items-start q-gutter-md mb50">
        <!-- section_tit -->
        <div class="sample_box">
          <div class="text-subtitle2">section_tit</div>
          <q-card-section>
            <!-- section_tit -->
            <div class="section_tit">
              <h3 class="icon_txt">
                <div class="txt">
                  <q-icon name="settings"></q-icon>
                  학습중
                </div>
                <span class="impact">43</span>
                <span> 과목 </span>
              </h3>
              <q-btn to="" flat>
                <q-icon name="icon-arrow-right" class="icon_svg"></q-icon>
                <div class="a11y">바로가기</div>
              </q-btn>
            </div>
            <!-- section_tit -->
          </q-card-section>
        </div>

        <!-- section_tit -->
        <div class="sample_box">
          <div class="text-subtitle2">section_tit</div>
          <q-card-section>
            <!-- gray_roundbox tit_area with_link -->
            <div class="gray_roundbox">
              <div class="tit_area with_link">
                <p class="title3">
                  <span class="text-primary">신대방 LC</span>
                  출결현황
                </p>
                <q-btn to="" flat>
                  <q-icon name="keyboard_arrow_right" class="icon_svg"></q-icon>
                  <div class="a11y">바로가기</div>
                </q-btn>
              </div>
              <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
            </div>
            <!-- gray_roundbox tit_area with_link -->
          </q-card-section>
        </div>

        <!-- section_card_profile -->
        <div class="sample_box">
          <div class="text-subtitle2">section_card_profile</div>
          <!-- section_card_profile -->
          <section class="section_card_profile">
            <q-card class="card_profile" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_member_info"
                  label="회원정보"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_lesson_manage"
                  label="학습관리"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_pay_status"
                  label="회비현황"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_history_manage"
                  label="이력관리"
                >
                </q-btn>
              </div>
              <!--// main_btn_area -->
              <!-- parents_area -->
              <div class="parents_area">
                <p class="tit title3">김윤찬 어머님</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_map"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->

          <!-- section_card_profile-->
          <section class="section_card_profile">
            <q-card class="card_profile" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <hr class="border" />
              <!-- parents_area -->
              <div class="parents_area">
                <p class="tit title3">선생님 메모</p>
                <div class="btn_area">
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_map"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_mail"
                  />
                  <q-btn
                    round
                    fill
                    unelevated
                    color="grey-4"
                    icon=""
                    class="btn_call"
                  />
                </div>
              </div>
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile -->
          <!-- section_card_profile type02-->
          <section class="section_card_profile">
            <q-card class="card_profile type02" flat>
              <!-- infor_area -->
              <div class="infor_area">
                <div class="pic_area">
                  <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <p class="tit text-h2">김윤찬</p>
                    <span class="member_number">(P15907)</span>
                    <span class="badge">신입</span>
                  </div>
                  <div class="more text-body2">
                    <span>초등1</span>
                    <span>강남교육국 외2</span>
                  </div>
                </div>
              </div>
              <!--// infor_area -->
              <!-- main_btn_area -->
              <div class="main_btn_area">
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_member_info"
                  label="회원정보"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_lesson_manage"
                  label="학습관리"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_pay_status"
                  label="회비현황"
                >
                </q-btn>
                <hr class="h_separator" />
                <q-btn
                  flat
                  stack
                  dense
                  icon=""
                  class="btn_history_manage"
                  label="이력관리"
                >
                </q-btn>
              </div>
              <!--// main_btn_area -->
              <!-- parents_area -->
              <!-- <div class="parents_area">
                    <p class="tit title3"></p>
                    <div class="btn_area">
                      <q-btn
                        round
                        fill
                        unelevated
                        color="grey-4"
                        icon=""
                        class="btn_add_study"
                      />
                    </div>
                  </div> -->
              <!--// parents_area -->
            </q-card>
          </section>
          <!--// section_card_profile type02-->
        </div>

        <!-- wrap_list_infor_00 -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_list_infor_00</div>
          <q-card-section>
            <!-- wrap_list_infor_00 -->
            <div class="wrap_list_infor_00">
              <div class="item">
                <div class="wrap_tit">
                  <div class="tit txt title1">김윤찬</div>
                </div>
                <div class="wrap_row">
                  <div class="row">
                    <span class="as_dt">회원상태</span>
                    <span class="as_dd"
                      ><span class="text-body1 text-positive"
                        >입회회원</span
                      ></span
                    >
                  </div>
                  <div class="row">
                    <span class="as_dt">생년월일/나이</span>
                    <span class="as_dd">2012.01.01/12살</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">성별</span>
                    <span class="as_dd">남</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">학년/학교명</span>
                    <span class="as_dd">6학년/보라매초등학교</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">이메일</span>
                    <span class="as_dd">nyanyaong77@gmail.com</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">휴대폰 번호</span>
                    <span class="as_dd">010-1234-5678</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">주소</span>
                    <span class="as_dd"
                      >[12345] 서울특별시 관악구 신대방동 11길 12 대교아파트 1동
                      101호</span
                    >
                  </div>
                </div>
                <q-btn
                  class="size_sm shadow text-body1"
                  color="white"
                  text-color="black"
                  unelevated
                  label="기본 정보 관리"
                />
              </div>
            </div>
            <!--// wrap_list_infor_00 -->

            <hr class="separator expand" />
            <div class="text-body1 text-grey-3 pt30_sm_scope">
              공공지원 정보
            </div>
            <section class="ma0">
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="alert">
                    <div class="alert_tit title4">
                      조직원 신청이
                      <span class="bold title4 text-orange">반려 </span
                      >되었습니다
                    </div>
                    <div class="alert_txt text-body2">
                      팀장/국장의 승인 후 처리가 완료됩니다
                    </div>
                  </div>
                  <div class="wrap_row border">
                    <div class="row alert">
                      <span class="as_dt">처리상태</span>
                      <span class="as_dd text-orange">반려</span>
                    </div>
                    <div class="row alert">
                      <span class="as_dt">신청일</span>
                      <span class="as_dd">2023.01.05</span>
                    </div>
                    <div class="column">
                      <span class="as_dt">반려사유</span>
                      <span class="as_dd"
                        >가족관계증명서 내용이 잘 안보입니다. <br />
                        증명서를 수정해서 다시 신청해주세요.</span
                      >
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="조직원 여부 관리"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
            </section>
          </q-card-section>
        </div>
        <!-- wrap_list_infor_00 -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_list_infor_00</div>
          <q-card-section>
            <!-- wrap_list_infor_00 -->
            <div class="wrap_list_infor_00">
              <div class="item">
                <div class="wrap_tit">
                  <div class="tit txt title1">김윤찬</div>
                </div>
                <div class="wrap_row">
                  <div class="row">
                    <span class="as_dt">회원상태</span>
                    <span class="as_dd"
                      ><span class="text-body1 text-positive"
                        >입회회원</span
                      ></span
                    >
                  </div>
                  <div class="row">
                    <span class="as_dt">생년월일/나이</span>
                    <span class="as_dd">2012.01.01/12살</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">성별</span>
                    <span class="as_dd">남</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">학년/학교명</span>
                    <span class="as_dd">6학년/보라매초등학교</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">이메일</span>
                    <span class="as_dd">nyanyaong77@gmail.com</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">휴대폰 번호</span>
                    <span class="as_dd">010-1234-5678</span>
                  </div>
                  <div class="row">
                    <span class="as_dt">주소</span>
                    <span class="as_dd"
                      >[12345] 서울특별시 관악구 신대방동 11길 12 대교아파트 1동
                      101호</span
                    >
                  </div>
                </div>
                <q-btn
                  class="size_sm shadow text-body1"
                  color="white"
                  text-color="black"
                  unelevated
                  label="기본 정보 관리"
                />
              </div>
            </div>
            <!--// wrap_list_infor_00 -->

            <hr class="separator expand" />
            <div class="text-body1 text-grey-3 pt30_sm_scope">
              공공지원 정보
            </div>
            <section class="ma0">
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                  <div class="wrap_row">
                    <div class="row">
                      <span class="as_dt">공공지원명</span>
                      <span class="as_dd">K-비대면 바우처</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용기간</span>
                      <span class="as_dd">2022.11.23~2023.05.01</span>
                    </div>
                    <div class="row">
                      <span class="as_dt">적용일</span>
                      <span class="as_dd">2023.06.31</span>
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="할인적용 학습보기"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
              <!-- wrap_list_infor_00 -->
              <div class="wrap_list_infor_00">
                <div class="item">
                  <div class="alert">
                    <div class="alert_tit title4">
                      조직원 신청이
                      <span class="bold title4 text-orange">반려 </span
                      >되었습니다
                    </div>
                    <div class="alert_txt text-body2">
                      팀장/국장의 승인 후 처리가 완료됩니다
                    </div>
                  </div>
                  <div class="wrap_row border">
                    <div class="row alert">
                      <span class="as_dt">처리상태</span>
                      <span class="as_dd text-orange">반려</span>
                    </div>
                    <div class="row alert">
                      <span class="as_dt">신청일</span>
                      <span class="as_dd">2023.01.05</span>
                    </div>
                    <div class="column">
                      <span class="as_dt">반려사유</span>
                      <span class="as_dd"
                        >가족관계증명서 내용이 잘 안보입니다. <br />
                        증명서를 수정해서 다시 신청해주세요.</span
                      >
                    </div>
                  </div>
                  <q-btn
                    class="size_sm shadow text-body1"
                    color="white"
                    text-color="black"
                    unelevated
                    label="조직원 여부 관리"
                  />
                </div>
              </div>
              <!--// wrap_list_infor_00 -->
            </section>
          </q-card-section>
        </div>

        <!--// list_infor_00 -->
        <div class="sample_box">
          <div class="text-subtitle2">list_type_0</div>
          <q-card-section>
            <!--// list_type_0 -->
            <ul class="list_type_0">
              <li>
                <q-btn to="" flat>
                  <p class="txt title3">눈높이 수학</p>
                  <p class="count impact_color text-body1">주3회</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li>
                <q-btn to="" flat>
                  <p class="txt title3">
                    솔루니 점프마스Lorem ipsum dolor sit amet consectetur
                    adipisicing elit. Soluta, illo incidunt quae, saepe natus
                    mollitia porro quibusdam alias maxime ex consequatur velit
                    voluptatum ipsum fugit enim maiores omnis! Ad, laboriosam?
                  </p>
                  <p class="count impact_color text-body1">3회</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li class="on">
                <q-btn :ripple="false" to="" flat>
                  <p class="txt title3">써밋 중등 수학</p>
                  <p class="count text-body1">체험</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
              <li class="on">
                <q-btn :ripple="false" to="" flat>
                  <p class="txt title3">써밋 어휘력</p>
                  <p class="count text-body1">체험</p>
                  <p class="time text-body2">23.03.05까지</p>
                </q-btn>
              </li>
            </ul>
            <!-- list_type_0 --></q-card-section
          >
        </div>

        <!--wrap_goods -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_goods</div>
          <q-card-section>
            <!-- wrap_goods -->
            <div class="wrap_goods mt20">
              <div class="item active">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >솔루니 독서논술솔루니 독서논술솔루니 독서논술솔루니
                      독서논술</span
                    >
                    <!-- tooltip_down -->
                    <q-fab direction="down" hide-icon class="tooltip_down" flat>
                      <q-fab-action
                        square
                        @click="onClick"
                        label=""
                        label-position="left"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">
                          [눈높이역사, 눈높이사회]
                          <span class="text-orange"> 결합상품 </span>입니다.
                        </p>
                      </q-fab-action>
                    </q-fab>
                    <!--// tooltip_down -->
                    <span class="text-body1 text-grey-5">대기중</span>
                  </div>
                  <div class="more text-body2">
                    <span>센터</span>
                    <span>4회 학습</span>
                    <span>수학</span>
                  </div>
                  <p class="date text-body2">학습예정일 : 2022.12.07~</p>
                </div>

                <q-btn class="size_sm shadow" unelevated label="진도 설정" />

                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >솔루니 독서논술솔루니 독서논술솔루니 독서논술솔루니
                      독서논술</span
                    >
                    <!-- tooltip_down -->
                    <q-fab direction="down" hide-icon class="tooltip_down" flat>
                      <q-fab-action
                        square
                        @click="onClick"
                        label=""
                        label-position="left"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">
                          [눈높이역사, 눈높이사회]
                          <span class="text-orange"> 결합상품 </span>입니다.
                        </p>
                      </q-fab-action>
                    </q-fab>
                    <!--// tooltip_down -->
                    <span class="text-body1 text-grey-5">대기중</span>
                  </p>
                  <div class="more text-body2">
                    <span>센터</span>
                    <span>4회 학습</span>
                    <span>수학</span>
                  </div>
                  <p class="date text-body2">학습예정일 : 2022.12.07~</p>
                </div>

                <q-btn class="size_sm shadow" unelevated label="진도 설정" />

                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <!--//버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>

              <div class="item join">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge
                  class="badge20"
                  rounded
                  color="positive"
                  label="결합"
                />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span class="text-body1 text-brown-2">학습종료</span>
                  </p>
                  <div class="more text-body2">
                    <span>셀프러닝</span>
                    <span>4회 학습</span>
                    <span>사회, 역사</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~2022.12.05</p>
                </div>

                <div class="set_infor">
                  <p class="title3">A과정 17세트</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <p v-if="false" class="tit text-body3">공공지원할인1</p>
                    <p class="txt">적용된 할인 내역이 없습니다.</p>
                  </div>
                  <div class="btn_area col1">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn
                      class="size_sm shadow"
                      unelevated
                      label="지난 학습현황"
                    />
                  </div>
                </div>
              </div>
              <div class="item join">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge
                  class="badge20"
                  rounded
                  color="positive"
                  label="결합"
                />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span class="text-body1 text-brown-2">학습종료</span>
                  </p>
                  <div class="more text-body2">
                    <span>셀프러닝</span>
                    <span>4회 학습</span>
                    <span>사회, 역사</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~2022.12.05</p>
                </div>

                <q-btn
                  v-if="false"
                  outline
                  class="size_xs mb16"
                  style="margin-top: 20px; width: 100%"
                  label="진도 설정"
                />
                <div class="set_infor">
                  <p class="title3">A과정 17세트</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="txt">적용된 할인 내역이 없습니다.</p>
                  </div>
                  <div class="btn_area col1">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn
                      class="size_sm shadow"
                      unelevated
                      label="지난 학습현황"
                    />
                  </div>
                </div>
              </div>

              <div class="item package">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <q-badge class="badge20" rounded color="black" label="패키지" />
                <div class="infor_area">
                  <p class="title1">
                    <span class="name eli"
                      >눈높이 초등사회/역사눈높이 초등사회/역사</span
                    >
                    <span v-if="false" class="text-body1 text-orange"
                      >학습종료</span
                    >
                  </p>
                  <div class="more text-body2">
                    <span>센터, 방문수업</span>
                    <span>4회 학습</span>
                    <span>국어</span>
                  </div>
                  <p class="date text-body2">학습일 : 2022.01.07~</p>
                </div>

                <q-btn
                  v-if="false"
                  outline
                  class="size_xs mb16"
                  style="margin-top: 20px; width: 100%"
                  label="진도 설정"
                />
                <div class="set_infor">
                  <p class="title3">A단계</p>
                </div>
                <p class="more_txt text-body2">
                  김대교(수/조직명), 이대교(토/조직명), 이대교 (토/조직명),
                  김대교(수/조직명)
                </p>
                <div class="border"></div>

                <div class="cost_area">
                  <div class="cost">
                    <q-badge
                      class="badge20"
                      rounded
                      color="brown-2"
                      label="공공기관"
                    />
                    <p class="tit text-body3">공공지원할인1</p>
                    <p class="txt">
                      (본인부담금: 10,000원/본사 지원금: 7,000원/공공지원금 :
                      21,000원)
                    </p>
                  </div>
                  <div class="btn_area">
                    <!--버튼 추가 타입 outline_btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="입회취소" />
                    <!--//버튼 추가 타입    _btn_40 -->
                    <q-btn class="size_sm shadow" unelevated label="학습현황" />
                    <q-btn class="size_sm shadow" unelevated label="교재신청" />
                  </div>
                </div>
              </div>
            </div>
            <!--// wrap_goods -->
          </q-card-section>
        </div>
        <!--wrap_goods_type02 -->
        <div class="sample_box">
          <div class="text-subtitle2">wrap_goods_type02</div>
          <q-card-section>
            <!--wrap_goods_type02  -->
            <div class="wrap_goods_type02 mt20">
              <div class="item active">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >눈높이 코어수학눈높이 코어수학눈높이 코어수학눈높이
                      코어수학눈높이 코어수학</span
                    >
                    <span class="text-body1 text-orange">선납할인</span>
                  </div>
                  <div class="infor_box text-body2">
                    <div class="row">
                      <div class="as_dt">연령</div>
                      <div class="as_dd">예비초, 초등, 중등</div>
                    </div>
                    <div class="row">
                      <div class="as_dt">가격</div>
                      <div class="as_dd text-body1 text-black">
                        <span class="text-positive"> 방문/LC </span>
                        38,000원
                      </div>
                    </div>
                    <div class="row">
                      <div class="as_dt">과정</div>
                      <div class="as_dd">4A-F과정(24세트)</div>
                    </div>
                  </div>
                </div>

                <div class="btn_area">
                  <q-btn class="size_sm shadow" unelevated label="입회" />
                  <q-btn class="size_sm shadow" unelevated label="체험" />
                  <q-btn class="size_sm shadow" unelevated label="학습바구니" />
                </div>
              </div>
              <div class="item">
                <div class="pic_area">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/d_search/goods_img/sample_goods.png?w=100"
                    alt=""
                  />
                </div>

                <div class="infor_area">
                  <div class="title1">
                    <span class="name eli"
                      >눈높이 코어수학눈높이 코어수학눈높이 코어수학눈높이
                      코어수학눈높이 코어수학</span
                    >
                    <span class="text-body1 text-orange">선납할인</span>
                  </div>
                  <div class="infor_box text-body2">
                    <div class="row">
                      <div class="as_dt">연령</div>
                      <div class="as_dd">예비초, 초등, 중등</div>
                    </div>
                    <div class="row">
                      <div class="as_dt">가격</div>
                      <div class="as_dd text-body1 text-black">
                        <span class="text-positive"> 방문/LC </span>
                        38,000원
                      </div>
                    </div>
                    <div class="row">
                      <div class="as_dt">과정</div>
                      <div class="as_dd">4A-F과정(24세트)</div>
                    </div>
                  </div>
                </div>

                <div class="btn_area">
                  <q-btn class="size_sm shadow" unelevated label="입회" />
                  <q-btn class="size_sm shadow" unelevated label="체험" />
                  <q-btn class="size_sm shadow" unelevated label="학습바구니" />
                </div>
              </div>
            </div>
            <!--// wrap_goods_type02  -->
          </q-card-section>
        </div>
        <!--// wrap_goods_type02 -->

        <!-- section_form -->
        <div class="sample_box">
          <div class="text-subtitle2">section_form</div>
          <q-card-section>
            <section class="section_form">
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt"
                    >회원이 조직원 본인이거나 조직원의 자녀인가요?</span
                  >
                  <div class="form_data has_radio">
                    <q-radio
                      v-model="dataRadio"
                      dense
                      val="Y"
                      label="예"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataRadio"
                      dense
                      val="N"
                      label="아니오"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </section>
            <hr class="separator" />
            <section class="section_form">
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt">신청 대상</span>
                  <div class="form_data top_radio">
                    <q-radio
                      v-model="dataRadio2"
                      dense
                      val="children"
                      label="직원자녀"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataRadio2"
                      dense
                      val="self"
                      label="직원본인"
                      color="orange"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                  <q-input
                    class="as_dd hide_label inp_search"
                    label="조직 구성원"
                    outlined
                    placeholder="조직 구성원을 검색하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:append>
                      <q-btn flat :ripple="false" class="btn_input_slot">
                        <q-icon name="icon-search_m" class="icon_svg"></q-icon>
                      </q-btn>
                    </template>
                  </q-input>
                  <q-input
                    class="as_dd hide_label inp_search2"
                    disabled
                    label="상세주소"
                    outlined
                    placeholder=""
                    stack-label
                    dense
                  >
                    <template v-slot:label>상세주소</template>
                  </q-input>
                </li>
              </ul>
              <!--// inner_list -->
            </section>
            <section class="section_form">
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt">증빙자료</span>
                  <p class="caption">
                    증빙자료 정보동의서가 없는 경우 감사대상이 될 수 있습니다.
                    증빙자료는 신청일로 부터 1년간 보관됩니다.<span
                      class="text-orange"
                      >(jpg, jpeg, gif, tif, pdf 등록 가능합니다)</span
                    >
                  </p>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      dense
                      clearable
                      placeholder="정보동의서를 선택"
                      label="정보동의서를 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:after>
                        <q-btn
                          fill
                          unelevated
                          class="btn_file_select"
                          color="grey-2"
                          label="선택"
                        />
                      </template>
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <q-icon
                            name="icon-search_m"
                            class="icon_svg"
                          ></q-icon>
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                  <div class="wrap_input">
                    <q-file
                      outlined
                      dense
                      clearable
                      placeholder="가족관계증명서 선택"
                      label="가족관계증명서 선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:after>
                        <q-btn
                          fill
                          unelevated
                          class="btn_file_select"
                          color="grey-2"
                          label="선택"
                        />
                      </template>
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <q-icon
                            name="icon-search_m"
                            class="icon_svg"
                          ></q-icon>
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </section>
            <hr class="separator" />
            <section class="section_form">
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt required">이름</span>
                  <q-input
                    class="as_dd hide_label inp_search"
                    label="* 이름"
                    outlined
                    placeholder="이름을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>이름</template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt required">관계</span>
                  <q-select
                    class="as_dd"
                    outlined
                    dense
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                  ></q-select>
                </li>
                <li>
                  <span class="as_dt required">휴대폰 번호</span>
                  <q-input
                    class="as_dd hide_label"
                    label="* 휴대폰 번호"
                    outlined
                    placeholder="-없이 입력해 주세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>휴대폰 번호</template>
                  </q-input>
                </li>
                <li class="hasCheckbox">
                  <div class="as_dd">
                    <q-checkbox
                      dense
                      color="orange"
                      class="inp_check"
                      label="대표보호자 지정"
                    />
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </section>
          </q-card-section>
        </div>

        <!-- pay_list -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type01</div>
          <q-card-section>
            <!-- pay_list -->
            <q-list class="pay_list">
              <q-expansion-item   default-opened class="expansion_custom" expand-icon-toggle>
                <template v-slot:header>
                  <q-item-section class="date">
                    <span class="year">2023</span>
                    <span class="dot">.</span>
                    <span class="month">01</span>
                  </q-item-section>
                  <q-item-section class="price">
                    <div class="btn_area">
                      <q-btn
                        fill
                        unelevated
                        icon=""
                        class="btn_exclamation"
                        @click="tooltip1 = true"
                      ></q-btn>
                      <div v-show="tooltip1" class="pay_alert">
                        <div class="tooltip_area">
                          <div class="text">
                            이번달
                            <span class="text-orange"
                              >미납 <span>1</span>건</span
                            >이 있어요
                          </div>
                          <q-btn
                            fill
                            dense
                            class="btn_close"
                            @click="tooltip1 = false"
                          ></q-btn>
                        </div>
                      </div>
                    </div>
                    <div class="pre">총</div>
                    <div class="num">135,000</div>
                    <div class="won">원</div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">정기</span>
                      <span class="num">2</span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <q-badge color="orange" class="normal">미납</q-badge>
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          결제완료
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                  <q-separator class=""></q-separator>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">비정기</span>
                      <span class="num"></span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <q-badge color="grey-4" class="normal"
                            >결제대기</q-badge
                          >
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>
              <q-expansion-item
                class="expansion_custom type01"
                  default-opened
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="date">
                    <span class="year">2023</span>
                    <span class="dot">.</span>
                    <span class="month">01</span>
                  </q-item-section>
                  <q-item-section class="price">
                    <div class="btn_area">
                      <q-btn
                        fill
                        unelevated
                        icon=""
                        class="btn_exclamation"
                        @click="tooltip2 = true"
                      ></q-btn>
                      <div v-show="tooltip2" class="pay_alert">
                        <div class="tooltip_area">
                          <div class="text">
                            이번달
                            <span class="text-orange"
                              >미납 <span>1</span>건</span
                            >이 있어요
                          </div>
                          <q-btn
                            fill
                            dense
                            class="btn_close"
                            @click="tooltip2 = false"
                          ></q-btn>
                        </div>
                      </div>
                    </div>
                    <div class="pre">총</div>
                    <div class="num">135,000</div>
                    <div class="won">원</div>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">정기</span>
                      <span class="num">2</span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <q-badge color="orange" class="normal">미납</q-badge>
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          결제완료
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                  <q-separator class=""></q-separator>
                  <q-card-section>
                    <div class="title">
                      <span class="regular">비정기</span>
                      <span class="num"></span>
                      <span class="case">건</span>
                    </div>
                    <table class="pay_tbl">
                      <tr>
                        <th>KB국민카드</th>
                        <td>
                          <span>1,1120,000</span>
                          <span>원</span>
                        </td>
                        <td>
                          <!-- 결제완료 -->
                          <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                          <q-badge color="grey-4" class="normal"
                            >결제대기</q-badge
                          >
                        </td>
                      </tr>
                    </table>
                  </q-card-section>
                </q-card>
              </q-expansion-item>
            </q-list>
            <!-- //pay_list -->
          </q-card-section>
        </div>

        <!-- 입금현황 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type02</div>
          <q-card-section>
            <q-list class="pay_list">
              <q-expansion-item
                default-opened
                class="expansion_custom type02"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <span class="title">입금현황</span>
                    <span class="process_area">
                      <span class="txt">입금률</span>
                      <span class="num">54</span>
                      <span class="sign">%</span>
                    </span>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="text-center">
                      <div class="date">
                        <span>2023</span>
                        <span>년</span>&nbsp;
                        <span>2</span>
                        <span>월</span>&nbsp;
                        <span>5</span>
                        <span>일</span>
                      </div>
                      <div class="price_area">
                        <q-icon name="icon-pay" class="icon_svg"></q-icon>
                        <div class="price">
                          <span>3,980,000</span>
                          <span>원</span>
                        </div>
                      </div>
                    </div>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                      <span class="txt">전일기준</span>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
              <q-expansion-item
                default-opened
                class="expansion_custom type02"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <span class="title">입금현황</span>
                    <span class="process_area">
                      <span class="txt">입금률</span>
                      <span class="num">54</span>
                      <span class="sign">%</span>
                    </span>
                  </q-item-section>
                </template>
                <q-card>
                  <q-card-section>
                    <div class="text-center">
                      <div class="date">
                        <span>2023</span>
                        <span>년</span>&nbsp;
                        <span>2</span>
                        <span>월</span>&nbsp;
                        <span>5</span>
                        <span>일</span>
                      </div>
                      <div class="price_area">
                        <q-icon name="icon-pay" class="icon_svg"></q-icon>
                        <div class="price">
                          <span>3,980,000</span>
                          <span>원</span>
                        </div>
                      </div>
                    </div>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                      <span class="txt">전일기준</span>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- 영업지표 -->
        <div class="sample_box">
          <div class="text-subtitle2">expansion_custom + type03</div>
          <q-card-section>
            <q-list class="pay_list">
              <q-expansion-item
                default-opened
                class="expansion_custom type03"
                expand-icon-toggle
              >
                <template v-slot:header>
                  <q-item-section class="tit_area">
                    <div class="title">영업지표</div>
                    <div class="process_area">
                      <span class="txt">순종수</span>
                      <span class="num">+234</span>
                    </div>
                  </q-item-section>
                </template>
                <q-card>
                  <div class="date_area">
                    <q-icon name="icon-check-grey" class="icon_svg"></q-icon>
                    <span>2023.1</span>
                    <span>월 기준</span>
                  </div>
                  <q-card-section>
                    <table class="sales_index">
                      <thead>
                        <tr>
                          <th>
                            <span class="txt">순증수</span>
                            <span class="num text-black">2714</span>
                          </th>
                          <th>
                            <span class="txt">순증지수</span>
                            <span class="num text-black">2714</span>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-warning">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-orange">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <q-icon
                              name="icon-smile-grey"
                              class="icon_svg"
                            ></q-icon>
                            <span class="txt">입회</span>
                            <span class="num text-positive">23</span>
                          </td>
                          <td>
                            <span class="txt">입회지수</span>
                            <span class="num">1,356</span>
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <td>
                            <span class="txt">총원</span>
                            <span class="num text-primary">634</span>
                          </td>
                          <td>
                            <span class="txt">총원지수</span>
                            <span class="num text-black">23,456</span>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </q-card-section>
                </q-card>
                <div class="btm_action">
                  <div class="btm_row">
                    <div class="info_area">
                      <span class="txt">영업마감일</span>
                      <div class="day">
                        <span>D</span>
                        <span>-</span>
                        <span>8</span>
                      </div>
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_sm"
                      label="내역보기"
                    />
                  </div>
                </div>
              </q-expansion-item>
            </q-list>
          </q-card-section>
        </div>

        <!-- wrap_linear-progress -->
        <div class="sample_box">
          <div class="text-subtitle2">gray_roundbox wrap_linear-progress</div>
          <q-card-section>
            <div class="gray_roundbox">
              <q-expansion-item   default-opened class="border_type" label="수업현황/출결현황">
                <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
                <!-- wrap_linear-progress -->
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">1팀</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <!--// wrap_linear-progress -->
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">2팀</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress green">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">신대방 LC</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress yellow">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
                <div class="wrap_linear-progress">
                  <div class="tit_area">
                    <span class="tit title3">보라매 LC</span>
                    <div class="balloon">
                      {{ progress }} <span class="unit">%</span>
                    </div>
                  </div>
                  <div class="linear_progress orange">
                    <div
                      class="pointer"
                      :style="{ width: progress + '%' }"
                    ></div>
                  </div>
                </div>
              </q-expansion-item>
            </div>
          </q-card-section>
        </div>

        <!--  -->
        <div class="sample_box">
          <div class="text-subtitle2"></div>
          <q-card-section> </q-card-section>
        </div>
      </div>
    </q-intersection>
  </div>
</template>
<style lang="scss">
@import 'src/assets/sass/responsive/temp.scss';
</style>
<style lang="scss" scoped>
.screen--lg .wrap_goods_type02 > .item {
  width: 100%;
}
.screen--lg {
  .sample_box {
    width: 46%;
    .wrap_goods > .item {
      width: 100%;
    }
  }
}

.sample_box {
  background: #fff;
  width: 392px;
  height: 392px;
  overflow-y: scroll;
  border-radius: 10px;
  box-shadow: 0 1px 5px #0003, 0 2px 2px #00000024, 0 3px 1px -2px #0000001f;
  width: 100%;
  section {
    padding: 10px !important;
    border: none;
    margin: 0;
  }
  .text-subtitle2 {
    text-align: center;
    background: #eee;
    padding: 10px;
    position: sticky;
    top: 0;
    z-index: 10;
  }
}
</style>
<script setup>
import { ref } from 'vue';
const progress = ref('26');
function onClick() {
  console.log('툴팁');
}
const dataRadio = ref('Y');
const dataRadio2 = ref('children');
</script>
