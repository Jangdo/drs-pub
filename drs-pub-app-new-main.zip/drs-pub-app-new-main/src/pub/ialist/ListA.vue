<template>
  <div class="wrap_ia_list">
    <q-table
      title="[A]전체메뉴"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:300px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  {
    name: 'A05P_1',
    Depth2: '신규-PC',
    Depth3: '팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A05P_2',
    Depth2: '신규-모바일',
    Depth3: '팝업',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A0202P',
    Depth2: '홈',
    Depth3: '써밋  LMS 리스트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A030101',
    Depth2: '',
    Depth3: '체험회원 등록(드림스)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, h-full css',
  },
  {
    name: 'A02',
    Depth2: '홈',
    Depth3: '선생님',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'A0204P',
    Depth2: '홈',
    Depth3: '즐겨찾기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mb 추가',
  },
  {
    name: 'A0205',
    Depth2: '홈',
    Depth3: '국장/ 행정선생님',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '퀵 바로가기',
  },
  //
  {
    name: 'A020601T',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A020602T',
    Depth2: '홈',
    Depth3: '홈-임원용-과목현황',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A020603T',
    Depth2: '홈',
    Depth3: '홈-임원용-조직현황',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A020604T',
    Depth2: '홈',
    Depth3: '홈-임원용-입금현황',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  //

  {
    name: 'A0401',
    Depth2: '홈',
    Depth3: '화면링크 오류 또는 데이터 미연동시 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  //
  {
    name: 'A0301',
    Depth2: '회원등록',
    Depth3: '등록확인 결과 회원정보있음',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030103',
    Depth2: '',
    Depth3: '등록확인 결과 회원정보있음 마카다미아',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030103_type01',
    name2: '(A03010301)',
    Depth2: '',
    Depth3: '등록확인 결과 회원정보없음 체험회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030103_type02',
    Depth2: '',
    Depth3: '등록확인 결과 회원정보있음 비회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030103_type03',
    Depth2: '',
    Depth3: '등록확인 결과 회원정보있음 입회회원',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },

  {
    name: 'A03010101',
    Depth2: '',
    Depth3: '회원등록 완료(체험회원)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '버튼 컬러 변경, h-full css',
  },
  {
    name: 'A03010102',
    name2: '(A03010102P)',
    Depth2: '',
    Depth3: '개인정보 수집 및 이용 동의',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A030102',
    Depth2: '',
    Depth3: '입회회원 등록 인증 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  //
  {
    name: 'a03010103P_pop',
    Depth2: '주소검색',
    Depth3: ' ',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A03010104P_pop',
    Depth2: '주소검색',
    Depth3: '우편번호 선택',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A03010104P_1_pop',
    Depth2: '주소검색',
    Depth3: '우편번호 선택 - 결과 없음',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //

  {
    name: 'a03010103P',
    Depth2: '주소검색',
    Depth3: ' ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt 제거',
  },
  {
    name: 'A03010104P',
    Depth2: '주소검색',
    Depth3: '우편번호 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt 제거',
  },
  {
    name: 'A03010104P_1',
    Depth2: '주소검색',
    Depth3: '우편번호 선택 - 결과 없음',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'mt 제거',
  },
  //
  {
    name: 'A03010105P',
    Depth2: '주소검색',
    Depth3: '상세주소',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  //
  {
    name: 'A03010201',
    Depth2: '',
    Depth3: '입회회원 등록 기본정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A03010202',
    name2: '(A03010201)',
    Depth2: '',
    Depth3: '입회회원 등록 보호자 정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A03010203',
    Depth2: '',
    Depth3: '입회회원 등록 완료 - 개인녹취',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A03010203_type01',
    Depth2: '',
    Depth3: '입회회원 등록 완료 - 마카다미아',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A03010203_type02',
    Depth2: '',
    Depth3: '입회회원 등록 완료 단체',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },

  {
    name: 'A03010204P',
    Depth2: '',
    Depth3: '입회회원 등록 - 마카다미아 URL 전송',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A0301020101',
    Depth2: '',
    Depth3: '기본정보입력 단체',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },

  {
    name: 'A0302',
    Depth2: '회원 관리',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'A030202',
    Depth2: '',
    Depth3: '입회회원 등록완료 -실패 녹취',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030202_type01',
    Depth2: '',
    Depth3: '입회회원 등록완료- 실패 마카다미아',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },

  {
    name: 'A030203',
    Depth2: '',
    Depth3: '기본정보 수정 개인',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
  {
    name: 'A030204',
    Depth2: '',
    Depth3: '기본정보 수정 보호자',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: 'h-full css',
  },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '완료후 수정 예정':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}

.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}

.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}

.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
