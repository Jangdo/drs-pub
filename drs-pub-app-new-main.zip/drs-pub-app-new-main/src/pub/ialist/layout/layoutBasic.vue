<template>
  <ul class="skip_menu">
    <li><a :href="$route.path + '#header'">메뉴바로가기</a></li>
    <li><a :href="$route.path + '#contentA'">컨텐츠 바로가기</a></li>
  </ul>
  <q-layout view="hHh lpR fFf">
    <q-page-container>
      <div class="ia_list" :class="visible === true ? '' : 'sticky_header'">
        <IaHeader />
        <div>
          <div v-intersection="onIntersection" style="height: 40px"></div>
          <div id="contentA">
            <router-view></router-view>
          </div>
        </div>
      </div>
    </q-page-container>
    <q-footer reveal class="text-body4 bg-grey-8" style="
            display: flex;
            justify-content: flex-end;
            padding: 2px 20px;
            color: #999;
          ">
          <!-- publishing by YSK, PJS -->
    </q-footer>
  </q-layout>
</template>
<script setup>
import { ref, onMounted, onUpdated } from 'vue';
import { useQuasar, useMeta } from 'quasar';
import IaHeader from 'src/pub/ialist/header/IaListHeader.vue';
import { useRoute } from 'vue-router';

const metaData = {};
const route = useRoute();
const $q = useQuasar();
$q.screen.setSizes({ sm: 10, md: 767, lg: 1025, xl: 200000 });
const visible = ref(false);
function onIntersection(entry) {
  visible.value = entry.isIntersecting;
};
$q.loading.show();
onUpdated(() => {
  metaData.title = route.name;
  useMeta(metaData);
  setTimeout(() => {
    $q.loading.hide();
  }, 800);
});
onMounted(() => {
  metaData.title = route.name;
  useMeta(metaData);
  setTimeout(() => {
    $q.loading.hide();
  }, 800);
});
</script>
<style lang="scss">
@import 'src/assets/sass/ialist/ia_list.scss';
</style>
<style lang="sass">
.example-state
  background: #ccc
  font-size: 20px
  color: #282a37
  padding: 10px
  opacity: 0.8

.example-observed
  width: 100%
  font-size: 20px
  color: #ccc
  background: #282a37
  padding: 10px

.example-area
  height: 300px

.example-filler
  height: 500px
</style>
