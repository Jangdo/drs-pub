<template>
  <q-layout class="layout_admin">
    <div class="wrap_gnb">
      <button
        class="dim"
        @click="closeGnb"
        v-show="gnbDepth1 == true && $q.screen.name !== 'lg'"
      ></button>
      <transition
        v-if="gnbDepth1 == true || $q.screen.name == 'lg'"
        appear
        enter-active-class="animated fadeIn"
        leave-active-class="animated fadeOut"
      >
        <div class="fix_gnb">
          <q-btn dense flat round icon="menu" @click="toggleLeftDrawer" />

          <q-list padding class="rounded-borders text-primary">
            <q-item
              color="primary"
              v-for="(item, index) in routesList"
              :active="link"
              :key="index"
              active-class="my-menu-link"
              ><q-btn flat @click="toggleDrawer(index)">{{ item.title }}</q-btn>
            </q-item>
          </q-list>

          <q-list padding class="rounded-borders text-primary">
            <q-item
              clickable
              v-ripple
              :active="link === 'help'"
              @click="link = 'help'"
              active-class="my-menu-link"
            >
              <q-item-section avatar>
                <q-icon name="ion-ios-leaf" />
              </q-item-section>

              <q-item-section>Help</q-item-section>
            </q-item>
          </q-list>
        </div>
      </transition>
    </div>
    <q-header reveal class="bg-primary text-white">
      <q-toolbar>
        <div class="link_box" v-if="$q.screen.name == 'md' || 'sm'">
          <q-btn
            v-if="$q.screen.name !== 'lg'"
            icon="ion-ios-menu"
            flat
            size="45px"
            style="font-size: 2rem; height: 45px; min-height: 0"
            @click="gnbDepth1 = true"
          >
          </q-btn>
        </div>
        <q-toolbar-title> Title </q-toolbar-title>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" side="left" overlay behavior="mobile">
      <q-list v-for="(item, index) in reoutesDepth" :key="index">
        <q-expansion-item
          v-if="item.children"
          expand-separator
          icon="mail"
          :label="item.title"
          caption="5 unread emails"
          default-opened
        >
          <div class="" v-for="(itemDepth1, idx2) in item.children" :key="idx2">
            <q-btn
              v-if="itemDepth1.path"
              flat
              :to="`${item.path}/${itemDepth1.path}`"
              >{{ itemDepth1.path }}</q-btn
            >
            <span v-else>{{ itemDepth1.path }} </span>
          </div>
        </q-expansion-item>
        <div class="" v-else>
          <router-link :to="item.path">item.path</router-link>
        </div>
      </q-list>
    </q-drawer>

    <q-page-container>
      <div class="pl40">
        <router-view />
      </div>
    </q-page-container>

    <q-footer reveal elevated class="text-body4 bg-grey-8 sample_footer"
      >publishing by YOON SANG KI
    </q-footer>
  </q-layout>
</template>

<script setup>
import { ref } from 'vue';
import { useRoute } from 'vue-router';
const route = useRoute();
const routesList = [
  {
    title: 'Depth1-1',
    ico: 'text',
    children: [
      {
        title: 'Depth2-1',
        children: [
          {
            path: '/pub-page/test',
            title: 'test',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: 'echart',
          },
          {
            path: '/pub-page/tree',
            title: 'tree',
          },
        ],
      },
      {
        title: 'Depth2-1',
        path: '/pub-page/test',
      },
    ],
  },
  {
    title: 'Depth1-2',
    children: [
      {
        path: '',
        title: 'Depth2-2',
        children: [
          {
            path: '/pub-page/test',
            title: 'test',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: 'echart',
          },
          {
            path: '/pub-page/tree',
            title: 'tree',
          },
        ],
      },
      {
        path: '',
        title: 'Depth2-2',
        children: [
          {
            path: '/pub-page/test',
            title: 'test',
          },
          { path: '/pub-page/calender', title: 'calender' },
          {
            path: '/pub-page/echart',
            title: 'echart',
          },
          {
            path: '/pub-page/tree',
            title: 'tree',
          },
        ],
      },
      {
        path: '#',
        title: 'Depth2-2',
      },
    ],
  },
  {
    title: 'Depth1-3',
    children: [
      {
        path: '',
        title: 'Depth2-3',
        children: [
          {
            path: '',
            title: 'Depth3-3',
          },
          {
            path: '',
            title: 'Depth3-3',
          },
          {
            path: '',
            title: 'Depth3-3',
          },
          {
            path: '',
            title: 'Depth3-3',
          },
        ],
      },
    ],
  },
];
const reoutesDepth = ref(routesList.find((e) => e.path === route.path));
const leftDrawerOpen = ref(false);
const gnbDepth1 = ref(false);
function closeGnb() {
  gnbDepth1.value = false;
}
const link = ref();
reoutesDepth.value = routesList[0].children;
function toggleDrawer(index) {
  reoutesDepth.value = routesList[index].children;
  console.log(index, reoutesDepth.value.children);
  leftDrawerOpen.value = true;
}
function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value;
}
</script>
<style lang="scss">
body {
  &.screen--lg {
    padding-left: 160px;
    header.q-header {
      left: 160px;
    }
    .q-page-container {
      padding-left: 0;
    }
  }
}
.q-dialog__inner.flex.no-pointer-events.q-dialog__inner--minimized.q-dialog__inner--left.fixed-left.items-center {
  left: 160px;
  background: #fff;
}
body .layout_admin {
  .my-menu-link {
    color: white;
    background: #f2c037;
  }
  .wrap_gnb {
    .dim {
      display: flex;
      position: fixed;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      background: rgb(0 0 0 / 20%);
      z-index: 2500;
    }
    .fix_gnb {
      display: block;
      position: fixed;
      width: 160px;
      top: 0;
      bottom: 0;
      left: 0;
      z-index: 10000;
      background: #eee;
    }
  }

  .q-page-container {
    padding-left: 0;
  }

  header.q-header {
    top: 0;
  }
  footer.q-footer {
    left: 160px;
  }
  .q-drawer {
    transition: 0.3s;
    position: fixed;
    left: 160px;
  }
  .sample_footer {
    display: flex;
    justify-content: flex-end;
    padding: 2px 20px;
    color: #999;
  }
}
</style>
