<template>
  <div class="wrap_ia_list">
    <q-table
      title="[G]조직관리"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
    <q-table
      title="조직관리 가이드 230428 이전"
      :rows="rows_before"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td key="Infor" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:180px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);
//  리스트 데이터
const rows = ref([
  {
    name: 'G1206P',
    Depth2: '',
    Depth3: '엑셀문서 암호화 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G040301',
    Depth2: '',
    Depth3: '월업무계획결산 조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },
  {
    name: 'G100202',
    Depth2: '할인관리',
    Depth3: '선납관리*등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 하단 버튼',
  },
  {
    name: 'G100203',
    Depth2: '행정관리',
    Depth3: '선납관리*수정*진행중',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 하단 버튼',
  },
  {
    name: 'G080101',
    Depth2: '결제(입금)관리 -회비현황조회 ',
    Depth3: '입금현황조회 입금현황조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블, 검색',
  },
  {
    name: 'G090501T',
    name2: '(G090501)',
    Depth2: '자재관리',
    Depth3: '솔루니 교재 패키지단위',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 검색, 버튼 컬러, 테이블',
  },
  {
    name: 'G02060410',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류자체 실태 점검표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 하단 버튼',
  },

  {
    name: 'G02010301p',
    Depth2: '',
    Depth3: '조직관리-교육국관리-기본정보-기본정보등록-채널순번 설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G01010303P',
    Depth2: '',
    Depth3: '기본정보-기본정보등록-조직순번 조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G08020101P',
    Depth2: '결제(입금)관리',
    Depth3: '은행 코드 조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오버튼, 테이블',
  },
  {
    name: 'G0206040101',
    Depth2: '채널관리',
    Depth3: '운영자료 - 필수 비치 서류 - 학원 운영 필수 이행 사항 안내',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 하단 버튼',
  },
  {
    name: 'G0206040102',
    Depth2: '채널관리',
    Depth3: '운영자료 - 필수 비치 서류 - 적정인원계산',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G0206040801P',
    Depth2: '채널관리',
    Depth3: '운영자료 - 필수 비치 서류 - 교습비 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G090403T',
    Depth2: '자재 신청관리',
    Depth3: '교재 및 부교재 배송현황 - 일반상품 배송현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G09040301P',
    Depth2: '자재 신청관리',
    Depth3: '교재 및 부교재 배송현황 -회원배송정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G09040302P',
    Depth2: '자재 신청관리',
    Depth3: '교재 및 부교재 배송현황 -일반상품 배송조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G0708',
    Depth2: '행정관리 ',
    Depth3: '임시추가',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G070801',
    Depth2: '행정관리',
    Depth3: '회비조정 - 회비조정 신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요, 하단 버튼',
  },
  {
    name: 'G07080102P',
    name2: '(g07080101p)',
    Depth2: '행정관리',
    Depth3: '회비조정 - 본사지원금 등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 하단 버튼, 테이블',
  },
  // {
  //   name: 'G07080103P',
  //   Depth2: '행정관리',
  //   Depth3: '회비조정 - 체납회비 수수료공제 등록',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //    Comment: '',
  // },
  {
    name: 'G07080104P',
    Depth2: '행정관리',
    Depth3: '회비조정 - 회비조정 상세조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 하단 버튼, 테이블',
  },
  {
    name: 'G07080105P',
    Depth2: '행정관리',
    Depth3: '회비조정 - 회비조정 승인',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 하단 버튼, 테이블',
  },
  {
    name: 'G080403P',
    Depth2: '결제(입금)관리 ',
    Depth3: '환불의뢰/조회- 환불 회원 검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 하단 버튼, 테이블',
  },
  // {
  //   name: 'G08060101P',
  //   Depth2: '결제(입금)관리 ',
  //   Depth3: ' 영수증조회 - 카드영수증조회/출력 - 매출전표',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '퍼블작업 없음/230531 추가분',
  // },
  // {
  //   name: 'G08060201P',
  //   Depth2: '결제(입금)관리 ',
  //   Depth3: '영수증조회 - 입금영수증조회/출력 -회비 영수증',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '퍼블작업 없음/230531 추가분',
  // },
  // {
  //   name: 'G08060301P',
  //   Depth2: '결제(입금)관리 ',
  //   Depth3: '영수증조회 - 현금영수증조회/출력 -현금 영수증',
  //   Infor: {
  //     date: '',
  //     state: '삭제',
  //     worker: '',
  //   },
  //   Comment: '퍼블작업 없음/230531 추가분',
  // },
  {
    name: 'G080701T',
    Depth2: '결제(입금)관리 ',
    Depth3: '영수증조회 - 입금률현황 - 월별입금률',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },
  {
    name: 'G080702T',
    Depth2: '결제(입금)관리 ',
    Depth3: '영수증조회 - 입금률현황 - 일별입금지표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요',
  },
  {
    name: 'G08100202P',
    Depth2: '결제(입금)관리 ',
    Depth3: '단말기결제 - 신규작성',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 테이블, 하단 버튼',
  },
  {
    name: 'G100301',
    Depth2: '할인관리',
    Depth3: '공공지원관리 - 공공지원관리*목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 버튼 컬러',
  },
  {
    name: 'G100302P',
    name2: '(G100304P)',
    Depth2: '할인관리',
    Depth3: '공공지원관리 - 공공지원사업*등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },
  {
    name: 'G100303P',
    Depth2: '할인관리',
    Depth3: '공공지원관리 - 공공지원사업 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },
  // {
  //   name: 'G100304P',
  //   Depth2: '할인관리',
  //   Depth3: '공공지원관리 - 공공지원사업 수정',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //    Comment: '',
  // },

  {
    name: 'G10030501P',
    Depth2: '할인관리',
    Depth3: '공공지원관리 - 공공지원/단체 회원 매칭',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼',
  },
  {
    name: 'G100306',
    Depth2: '할인관리',
    Depth3: '공공지원관리 - 공공/단체 지원금 등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요, 버튼 컬러',
  },
  //
  // {
  //   name: 'G07080104P',
  //   Depth2: '행정관리 ',
  //   Depth3: '회비조정이력',
  //   Infor: {
  //     date: '',
  //     state: '수정예정',
  //     worker: '',
  //   },
  //   Comment:
  //     '1차완료일 230517 ,G07080105P,기획 수정으로 5/16 수령,,https://www.figma.com/file/RFtPPjRNBzcKqfmiBCVRAQ/%EB%94%94%EC%9E%90%EC%9D%B8-%EC%8A%A4%ED%83%80%EC%9D%BC-%EA%B0%80%EC%9D%B4%EB%93%9C---PC?type=design&node-id=3996%3A91413&t=Kx4fHO3cUSZRLO9W-1',
  // },
  // {
  //   name: 'G070801',
  //   Depth2: '행정관리 ',
  //   Depth3: '회비조정등록',
  //   Infor: {
  //     date: '',
  //     state: '수정예정',
  //     worker: '',
  //   },
  //   Comment:
  //     '1차완료일 230517 ,기획 수정으로 5/16 수령,,https://www.figma.com/file/RFtPPjRNBzcKqfmiBCVRAQ/%EB%94%94%EC%9E%90%EC%9D%B8-%EC%8A%A4%ED%83%80%EC%9D%BC-%EA%B0%80%EC%9D%B4%EB%93%9C---PC?type=design&node-id=3996%3A91413&t=Kx4fHO3cUSZRLO9W-1',
  // },
  // {
  //   name: 'G0206040801P',
  //   Depth2: '',
  //   Depth3: '운영자료 운영 자료 필수 비치 서류 교습비 상세 팝업',
  //   Infor: {
  //     date: '',
  //     state: '수정예정',
  //     worker: '',
  //   },
  //   Comment: ' 1차완료일 230407',
  // },
  {
    name: 'G02060409',
    Depth2: '조직관리',
    Depth3: '운영자료 -필수 비치 서류 - 학원 안전점검 체크리스트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러',
  },
  {
    name: 'G0104',
    name2: '(G0205)',
    Depth2: '교육국관리',
    Depth3: '기본정보-변경이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G0713',
    Depth2: '온라인구매',
    Depth3: '회원상담',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },

  {
    name: 'G071301P',
    Depth2: '온라인구매',
    Depth3: '회원상담 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'G071302P',
    name2: '(G071303P)',
    Depth2: '온라인구매',
    Depth3: '회원관리-문자 -셀프러닝 선생님',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오, 하단 버튼',
  },

  // {
  //   name: 'G071303P',
  //   Depth2: '온라인구매',
  //   Depth3: '회원관리-문자 -상담실',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'G0501010104P',
    Depth2: '게시판관리 ',
    Depth3: '요일선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G0501010105P',
    Depth2: '게시판관리 ',
    Depth3: '계층/랭킹보기',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  // {
  //   name: 'G06030301P',
  //   Depth2: '게시판관리 ',
  //   Depth3: '과목 학습 회원',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'G071301P',
    Depth2: '온라인구매',
    Depth3: '회원상담 상세',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  // {
  //   name: 'G071301P',
  //   Depth2: '온라인구매',
  //   Depth3: '회원상담 상세',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  {
    name: 'G060402',
    Depth2: '운영관리 ',
    Depth3: '진도미결정교사조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G060403',
    name2: '(G060404)',
    Depth2: '운영관리 ',
    Depth3: '진도그래프 점검/추천',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G06040301P',
    Depth2: '운영관리 ',
    Depth3: '진도점검 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'G060301',
    Depth2: '행정관리 ',
    Depth3: '채널/학년별 회원 현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요',
  },

  {
    name: 'G07080101P',
    name2: '(G07080102P,G07080103P)',
    Depth2: '행정관리 ',
    Depth3: '회비조정등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 하단 버튼, 테이블',
  },

  //
  {
    name: 'G04010106P',
    name2: '(G06030101P,G06030301P,G06030301P,G04020103P,G04020104P)',
    Depth2: '눈높이 목표쉽',
    Depth3: '순증수변경이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'G0707',
    Depth2: '할인관리',
    Depth3: '이월금변경',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G090301',
    name2: '(g090201,G090503)',
    Depth2: '조직관리',
    Depth3: '자재신청관리 부교재/소모품 신청내역 조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G090301_pop_temp',
    Depth2: '공통팝업',
    Depth3: '공통팝업_ 신규추가 _수량변경',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'G04010101T',
    Depth2: '눈높이 목표수립 ',
    Depth3: '목표수립-본부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G04010102T',
    Depth2: ' 눈높이 목표수립',
    Depth3: '목표수립-조직',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요',
  },
  {
    name: 'G0401020101T',
    name2:
      '(G0401020102T ,G0401020103T,G0401020201T,G0401020202T,G0401020203T,G04020201,G04020202,G04020203)',
    Depth2: '눈높이 목표수립',
    Depth3: '월별목표-본부-순증수',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요',
  },
  {
    name: 'G0401020101T_1',
    name2: '(G0401020101T)',
    Depth2: '눈높이 목표수립',
    Depth3: '월별목표-본부-순증수_iniput',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G0711',
    Depth2: '행정관리',
    Depth3: '회원리스트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },

  {
    name: 'G04020105P',
    Depth2: '솔루니목표수립',
    Depth3: '총원지수변경이력*솔루니',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'G070901',
    name2: '(G070903,G070904)',
    Depth2: '',
    Depth3: '증빙번호등록 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 참고하세요',
  },

  {
    name: 'G070902',
    Depth2: '',
    Depth3: '현금영수증조회/취소요청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 하단 버튼',
  },

  {
    name: 'G050401',
    name2: '(G05010906)',
    Depth2: '소개현황',
    Depth3: '목록 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요',
  },
  {
    name: 'G0504010101P',
    Depth2: '',
    Depth3: '피소개자정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, mb',
  },
  {
    name: 'G11',
    Depth2: '구성원관리',
    Depth3: '구성원관리 목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스, 참고하세요, 버튼 컬러',
  },

  {
    name: 'G1101P',
    Depth2: '구성원관리',
    Depth3: '교사 채널일괄등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G1102P',
    Depth2: '구성원관리',
    Depth3: '다소속 교사 등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G1105',
    Depth2: '구성원관리',
    Depth3: '구성원관리-조직도처리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G1103',
    Depth2: '구성원관리',
    Depth3: '변경이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G1104',
    Depth2: '구성원관리',
    Depth3: '상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블, 하단 버튼',
  },
  {
    name: 'G100101',
    Depth2: '프로모션관리',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 토글버튼, 버튼 컬러',
  },
  {
    name: 'G100102',
    name2: '(G100103,G100104)',
    Depth2: '프로모션관리',
    Depth3: '등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 라디오, 테이블, 하단 버튼',
  },

  {
    name: 'G0705',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별 매출 목표 순증지수변경이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G04010102P',
    Depth2: '눈높이 목표수립',
    Depth3: '목표수립검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'G04010107P',
    Depth2: '참고하세요 공통팝업 재작업',
    Depth3: '',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'G07050101',
    Depth2: '행정관리',
    Depth3: '요일별 검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G07050102',
    Depth2: '행정관리',
    Depth3: '이동정보입력 - 요일별(인수인계)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스, 하단 버튼',
  },

  {
    name: 'G07050103',
    Depth2: '행정관리',
    Depth3: '회원이동확인서 - 요일별',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'G07050104P',
    Depth2: '행정관리',
    Depth3: '이동 과목 확인',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'G04010104P',
    Depth2: '눈높이 목표수립',
    Depth3: '',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, mb',
  },
  {
    name: 'G020103',
    Depth2: '조직관리',
    Depth3: '채널관리 기본정보 탭',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'G07050105P',
    Depth2: '행정관리',
    Depth3: '선생님/요일 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 테이블, 하단 버튼',
  },
  {
    name: 'G07050201',
    Depth2: '행정관리',
    Depth3: ' 회원별 검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스, 참고하세요, 버튼 컬러',
  },

  {
    name: 'G07050202',
    name2: '(G07050102,G0705010201)',
    Depth2: '행정관리 ',
    Depth3: ' 이동정보입력 - 회원별(인수인계)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스, 하단 버튼',
  },
  {
    name: 'G0705020201',
    Depth2: '행정관리 ',
    Depth3: ' 이동정보입력 - 회원별(인수인계)',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G07050203',
    Depth2: '행정관리',
    Depth3: '회원이동확인서 - 회원별',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },

  //
  {
    name: 'G070301',
    Depth2: '행정관리',
    Depth3: '학습일정표 출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G070302',
    Depth2: '행정관리',
    Depth3: '학습일정표 스티커 발행',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스',
  },
  {
    name: 'G070303',
    Depth2: '행정관리',
    Depth3: '긴급교재 스티커 발행',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스',
  },
  {
    name: 'G070304',
    Depth2: '행정관리',
    Depth3: '분국통합 학습일정표 스티커 발행',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스',
  },

  {
    name: 'G090502T',
    Depth2: '행정관리',
    Depth3: '솔루니 교재 개별품목단위 ',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스, 버튼 컬러, 테이블',
  },

  {
    name: 'G05050101T',
    name2: '(G05050102T,G05050201T,G05050202T)',
    Depth2: '행정관리',
    Depth3: '성과관리현황-눈높이- 총원성장',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 탭, 테이블',
  },
  {
    name: 'G050504T',
    name2: '(G050503T)',
    Depth2: '행정관리',
    Depth3: '총원성장/매출-솔루니',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 참고하세요, 테이블',
  },
  //
  {
    name: 'G071001T',
    Depth2: '행정관리',
    Depth3: '회원관리일지',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G071002T',
    Depth2: '행정관리',
    Depth3: '총원명부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G071003T',
    Depth2: '행정관리',
    Depth3: '가구별학습현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G0712',
    Depth2: '행정관리',
    Depth3: '내용증명서 관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G071201P',
    Depth2: '행정관리',
    Depth3: '내용증명서 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G10010502P',
    Depth2: '할인관리',
    Depth3: '적용대상*고객',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G10010504P',
    Depth2: '할인관리',
    Depth3: '적용대상*학년',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼, 테이블',
  },
  {
    name: 'G10010503P',
    Depth2: '할인관리',
    Depth3: '적용상품',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 라디오, 테이블, 하단 버튼, mb',
  },
  {
    name: 'G100201',
    Depth2: '할인관리',
    Depth3: '선납관리*목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 테이블, 버튼 컬러',
  },

  {
    name: 'G100204',
    Depth2: '할인관리',
    Depth3: '선납관리\*수정\_종료',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 체크박스, 테이블, 하단 버튼',
  },
  //
  {
    name: 'G060401',
    Depth2: '운영관리',
    Depth3: '진도점검관리- 선생님별교재청구점검표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G060404',
    Depth2: '운영관리',
    Depth3: '진도점검관리- 요일별진도점검표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G0702',
    Depth2: '행정관리',
    Depth3: '마감 외 진도수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G070201P',
    Depth2: '행정관리',
    Depth3: '마감 외 진도수정 신규작성',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G070601',
    Depth2: '행정관리',
    Depth3: '회비대체-목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G070602',
    Depth2: '행정관리',
    Depth3: '회비대체-등록/수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  //

  //
  // {
  //   name: 'g081001_1',
  //   Depth2: '결제(입금)관리 -회비현황조회 ',
  //   Depth3: '입금현황조회 입금현황조회-회비 납부 안내',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '',
  // },

  // {
  //   name: 'G0807',
  //   Depth2: '결제(입금)관리 ',
  //   Depth3: '입금률현황',
  //   Infor: {
  //     date: '',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '디자인 화면❌ 피그마 화면id 없음❌ (g080701T,g080702T 제목같음)',
  // },
  {
    name: 'G01010302P',
    name2: '(G08030201P)',
    Depth2: '',
    Depth3: '기본정보-기본정보등록-코드 조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 하단 버튼, 테이블',
  },
  {
    name: 'G08100201P',
    Depth2: '결제(입금)관리 ',
    Depth3: '지원금/외부결제 금액등록 -상세정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블, 하단 버튼',
  },
]);
//  리스트 데이터_0428이전
const rows_before = ref([
  {
    name: 'G0101',
    name2: '(G0201)',
    Depth2: '교육국관리',
    Depth3: '기본정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G010101P',
    Depth2: '',
    Depth3: '구분검색',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'G010103',
    name2: '(G020103)',
    Depth2: '',
    Depth3: '기본정보-기본정보등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '라디오, 하단 버튼',
  },
  {
    name: 'G01010302P_old',
    Depth2: '',
    Depth3: '기본정보-기본정보등록-코드조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼, 테이블',
  },

  {
    name: 'G010104',
    Depth2: '',
    Depth3: '기본정보-기본정보 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'G0105',
    Depth2: '',
    Depth3: '고객만족도',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G010501P',
    Depth2: '',
    Depth3: '고객만족도-문항별 평점',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G010502P',
    Depth2: '',
    Depth3: '고객만족도-고객의견',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },

  //230403
  {
    name: 'G020105',
    Depth2: '채널관리',
    Depth3: '채널정보 등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼',
  },
  {
    name: 'G020106',
    Depth2: '',
    Depth3: '기본정보',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G020106_1_popup',
    Depth2: '',
    Depth3: '기본정보 이미지 확대',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  // 230404
  {
    name: 'G02060101',
    Depth2: '',
    Depth3: '운영자료 학원운영 관련자료출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G020602',
    Depth2: '',
    Depth3: '운영자료 수입지출장부 조회/출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G020603_1_popup',
    Depth2: '',
    Depth3: '운영자료 수입지출장부 지출항목 등록팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G020605',
    Depth2: '',
    Depth3: '운영자료 운영 자료 설정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 하단 버튼, 테이블',
  },

  {
    name: 'G02060401',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 원칙',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G02060401_popup',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 원칙 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블 ',
  },
  {
    name: 'G02060402',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 직원명부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 버튼 컬러',
  },
  {
    name: 'G0206040201P',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 직원명부 등록 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G02060403',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 지도점검기록부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러',
  },
  {
    name: 'G02060405',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 교습비 게시표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 체크박스, 버튼 컬러',
  },
  {
    name: 'G02060406',
    Depth2: '',
    Depth3: '운영자료 운영 자료 필수 비치 서류 교습비 반환규정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  //230328
  {
    name: 'G05010901',
    name2:
      '(G05010701,G05020101,G05020201,G05020301,G05010501,G050104,G05010301,G05011001,G05010101,G0602,G0603,G060302,G060303,G0605)',
    Depth2: '영업관리 ',
    Depth3: '영업실적 [성장사업] 제품지수현황-전체',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },

  {
    name: 'G05010902',
    name2:
      '(G05010906,G05010703,G05010704,G05010705,G05010706,G05020103,G05020104,G05020105,G05020106,G05020202,G05020203,G05020204,G05020205,G05020206,G05020302,G05020303,G05020304,G05020305,G05020306,G05011002,G05011003,G05011004,G05011005,G05011006,G05020102,G05010702,G05010304,G05010306,G05010305,G05010302,G05010902,G05010903,G05010904,G05010905,,G05010502,G05010503,G05010303,G05010102,G05010103,G05010104,G05010105,G05010106,G05010504,G05010505,G05010506)',
    Depth2: '',
    Depth3: '영업실적 [성장사업] 제품지수현황- 본부별',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 참고하세요',
  },
  {
    name: 'G050201',
    Depth2: '',
    Depth3: ' 평가 총성원장-조직별 총원성장',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },
  {
    name: 'G050202',
    Depth2: '',
    Depth3: ' 평가 총성원장-[눈높이]제품지수 총원성장',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },

  {
    name: 'G0501010101p',
    name2: '(G0501090702P)',
    Depth2: '',
    Depth3: '영업실적 [전사]조직별 영업현황-구분검색- 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'g0501010101p_div',
    Depth2: '',
    Depth3: '영업실적 [전사]조직별 영업현황-구분검색- 팝업',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  // {
  //   name: 'G0501090702P',
  //   Depth2: '',
  //   Depth3: '[성장사업] 제품지수현황- 구분검색 바텀시트',
  //   Infor: {
  //     date: '23.03.27~',
  //     state: '',
  //     worker: '',
  //   },
  //   Comment: '디자인확정 230327',
  // },
  {
    name: 'G0501010103P',
    name2: '(G0501010102P)',
    Depth2: '',
    Depth3: '영업실적 [전사]조직별 영업현황 채널군검색 바텀시트',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'G050501T',
    Depth2: '',
    Depth3: '성과관리현황 평가총원성장',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 테이블',
  },
  {
    name: 'G05050301T',
    Depth2: '',
    Depth3: '성과관리현황 본부',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 테이블',
  },
  {
    name: 'G060101T',
    Depth2: '운영현황 ',
    Depth3: '영업현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G060102T',
    Depth2: '운영현황 ',
    Depth3: '회원매출/입금',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G060103T',
    Depth2: '운영현황 ',
    Depth3: '관리지표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G060104T',
    Depth2: '운영현황 ',
    Depth3: '서비스지표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G060105T',
    Depth2: '운영현황 ',
    Depth3: '출결율',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },
  {
    name: 'G060106T',
    Depth2: '운영현황 ',
    Depth3: '과목/학습방법 현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색',
  },

  {
    name: 'G08010201T',
    Depth2: '결제(입금)관리 -회비현황조회 ',
    Depth3: '퇴회자입금현황조회 - 퇴회미수금현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G08010202T',
    Depth2: '결제(입금)관리 -회비현황조회 ',
    Depth3: '퇴회이후 입금현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G080103',
    Depth2: '결제(입금)관리 -회비현황조회 ',
    Depth3: '미수/체납 현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  // 영업활동
  {
    name: 'G040101',
    Depth2: '영업활동',
    Depth3: '눈높이 목표수립',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러, 테이블',
  },
  {
    name: 'G040101_1',
    Depth2: '영업활동',
    Depth3: '눈높이 목표수립_수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G04010101P',
    name2: '(G040201,G04020101P)',
    Depth2: '',
    Depth3: '눈높이 목표수립 기본설정',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'G040102',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별목표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G040103',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별 매출 목표',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러, 테이블',
  },
  {
    name: 'G040103-1',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별 매출 목표_수정',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },

  //
  {
    name: 'G04010105P',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별 매출 목표 순증지수변경이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'G04010107P',
    Depth2: '',
    Depth3: '눈높이 목표수립 월별 매출 목표 순증지수변경이력 참고하세요',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },

  {
    name: 'G040302',
    Depth2: '',
    Depth3: '월업무계획결산 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  //
  {
    name: 'G0903',
    Depth2: '조직관리',
    Depth3: '자재신청관리 부교재/소모품',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 라디오, 체크박스, 버튼 컬러, 테이블',
  },

  //
  {
    name: 'G0902',
    Depth2: '조직관리',
    Depth3: '자재신청관리 홍보물신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러, 테이블',
  },
  // {
  //   name: 'G090201',
  //   Depth2: '조직관리',
  //   Depth3: '자재신청관리 홍보물신청 신청내역 조회',
  //   Infor: {
  //     date: '',
  //     state: '진행중',
  //     worker: '',
  //   },
  //   Comment: '',
  // },
  {
    name: 'G080104',
    Depth2: '결제(입금)관리 -회비현황조회 ',
    Depth3: '입금미마감현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G080201',
    Depth2: '결제(입금)관리',
    Depth3: 'CMS입금/현황조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G080202',
    Depth2: '결제(입금)관리',
    Depth3: 'CMS수정신청/내역조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G08030101T',
    Depth2: '결제(입금)관리-(구)CMS입금이력관리',
    Depth3: '이체이력조회-카드이체이력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G08030102T',
    Depth2: '결제(입금)관리-(구)CMS입금이력관리',
    Depth3: '이체이력조회-CMS수정신청/내역조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G08030201T',
    Depth2: '결제(입금)관리 -환불의뢰/조회 ',
    Depth3: '이체이력조회 -은행자동이체',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G08030202T',
    Depth2: '결제(입금)관리 -(구)이체관리 ',
    Depth3: '이체이력조회 -카드자동이체',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 참고하세요, 버튼 컬러',
  },
  {
    name: 'G080303',
    Depth2: '결제(입금)관리 -환불의뢰/조회 ',
    Depth3: '카드이체승인취소처리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G080401',
    Depth2: '결제(입금)관리 -환불의뢰내역조회 ',
    Depth3: '환불의뢰내역조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G080402P',
    Depth2: '결제(입금)관리 -환불의뢰내역조회 ',
    Depth3: '환불의뢰입력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G080501',
    Depth2: '결제(입금)관리 -비회원결제관리 ',
    Depth3: '비회원입금처리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러, 테이블',
  },
  {
    name: 'G080601T',
    Depth2: '결제(입금)관리 -영수증조회 ',
    Depth3: '카드영수증조회/출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G080602T',
    Depth2: '결제(입금)관리 -영수증조회 ',
    Depth3: '입금영수증조회/출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G080603T',
    Depth2: '결제(입금)관리 -영수증조회 ',
    Depth3: '현금영수증조회/출력',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
  {
    name: 'G0808',
    Depth2: '결제(입금)관리 ',
    Depth3: '회원별 회비점검',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G080901',
    Depth2: '결제(입금)관리 ',
    Depth3: '지원금/외부결제 금액등록 -목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 버튼 컬러',
  },
  {
    name: 'G081001',
    Depth2: '결제(입금)관리 ',
    Depth3: '지원금/외부결제 금액등록 - 단말기결제',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  //
  {
    name: 'G090101',
    Depth2: '자재신청관리',
    Depth3: '긴급교재관리   긴급교재 신청/조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G09010101P',
    name2: '(G0206040201P)',
    Depth2: '자재신청관리',
    Depth3:
      '긴급교재관리   긴급교재 신청/조회 긴급교재 신청/조회 긴급교재 신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G090102',
    name2: '(G0206040201P)',
    Depth2: '자재신청관리',
    Depth3: '긴급 부교재 신청/조회  긴급 부교재 신청',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'G09010201P',
    name2: '(G0206040201P)',
    Depth2: '자재신청관리',
    Depth3: '긴급 부교재 신청/조회  긴급 부교재 신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'G090401T',
    name2: '(G090103)',
    Depth2: '자재신청관리',
    Depth3: '교재 및 부교재 배송현황 교재배송현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'G090402T',
    name2: '(G090103)',
    Depth2: '자재신청관리',
    Depth3: '교재 및 부교재 배송현황 부교재배송현황',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  //

  {
    name: 'G090601T',
    name2: '(G090602T)',
    Depth2: '통신회원 AS및 배송관리',
    Depth3: 'AS관리 - 통신회원 AS관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 버튼 컬러',
  },
  {
    name: 'G09060101',
    name2: '(G09060102)',
    Depth2: '통신회원 AS및 배송관리',
    Depth3: 'AS관리 - 회원 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼, 테이블',
  },
  {
    name: 'G09060103',
    name2: '(G09060104)',
    Depth2: '통신회원 AS및 배송관리',
    Depth3: 'AS관리 -  회원 AS신청',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '체크박스, 하단 버튼, 테이블',
  },
  {
    name: 'G09060201',
    name2: '(G09060202)',
    Depth2: '통신회원 AS및 배송관리',
    Depth3: '배송관리 - 회원 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '1차완료':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}

.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}

.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}

.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
