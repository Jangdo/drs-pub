<template>
  <div class="wrap_ia_list">
    <!-- <div class="example-area q-pa-lg scroll">
      <div
        v-intersection="onIntersection"
        class="example-observed text-center rounded-borders"
      >
        Observed Element
      </div>

      <div class="example-filler" />
    </div> -->
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { useMeta } from 'quasar';
const metaData = {};
export default {
  components: {},

  data() {
    return {
      dataInput: '인풋테스트',
      dataRadio: 'primary',
      dataCheck: ['primary', 'secondary', 'negative'],
      optionsSelect: ['Google', 'Facebook', 'Twitter', 'Apple', 'Oracle'],
    };
  },
  setup() {
    const visible = ref(false);
    const route = useRoute();
    onMounted(() => {
      metaData.title = route.name;
      // console.log(route.name);
      useMeta(metaData);
    });
    return {
      visible,
      visibleClass: computed(() => `scr_${visible.value ? 'on' : 'off'}`),

      onIntersection(entry) {
        visible.value = entry.isIntersecting;
      },
    };
  },
};
</script>

<style lang="sass" scoped>
.example-state
  background: #ccc
  font-size: 20px
  color: #282a37
  padding: 10px
  opacity: 0.8

.example-observed
  width: 100%
  font-size: 20px
  color: #ccc
  background: #282a37
  padding: 10px

.example-area
  height: 300px

.example-filler
  height: 500px
</style>
