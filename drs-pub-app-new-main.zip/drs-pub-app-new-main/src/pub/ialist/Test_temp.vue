<template>
  <div class="row">
    <div class="col-8">
      <nested-draggable :tasks="list" />
    </div>

  </div>
</template>

<script setup>
import { ref } from 'vue';
import nestedDraggable from './nested.vue';
const list =ref([
        {
          name: 'task 1',
          tasks: [
            {
              name: 'task 2',
              tasks: []
            }
          ]
        },
        {
          name: 'task 3',
          tasks: [
            {
              name: 'task 4',
              tasks: []
            }
          ]
        },
        {
          name: 'task 5',
          tasks: []
        }
      ])

</script>
<style>
li {
    margin-left: 10px;
    display: block;
}

ul.dragArea {
    margin-left: 20px;
}
</style>
