<template>
  <div class="q-pa-md q-gutter-sm">
    <div class="tree_container">
      <q-tree
        :nodes="simple"
        accordion
        node-key="label"
        v-model:expanded="expanded"
        class="category"
      />
    </div>
  </div>

  <!-- 퀵메뉴 배경 -->
  <div class="quick_dimed" v-show="quickOpen == true"></div>
  <!-- 퀵메뉴 열고 닫힘 -->
  <div class="wrap_quick_menu" v-show="temp">
    <q-btn
      class="size_big btn_quick_open"
      @click="quickOpen = true"
      v-show="quickOpen == false"
      stack
      fill
      unelevated
      icon=""
      color="positive"
      label="바로가기"
    />
    <q-btn
      class="size_big btn_quick_close"
      @click="quickOpen = false"
      v-show="quickOpen == true"
      stack
      fill
      unelevated
      icon=""
      color="positive"
      label="닫기"
    />
    <q-btn
      class="size_big btn_quick_edit"
      v-show="quickOpen == true"
      stack
      fill
      unelevated
      icon=""
      color="black"
      label="편집"
    />
    <q-btn
      class="size_big btn_quick_lms"
      v-show="quickOpen == true"
      stack
      fill
      unelevated
      icon=""
      color="black"
      label="lms"
    />
    <q-btn
      class="size_big btn_quick_attendance"
      v-show="quickOpen == true"
      stack
      fill
      unelevated
      icon=""
      color="black"
      label="출결"
    />
    <q-btn
      class="size_big btn_quick_content"
      v-show="quickOpen == true"
      stack
      fill
      unelevated
      icon=""
      color="black"
      label="콘텐츠"
    />
  </div>
</template>

<script>
import { ref } from 'vue'

export default {
  setup () {
    return {
      expanded: ref([ 'Satisfied customers (with avatar)', 'Good food (with icon)' ]),
      quickOpen: ref(false),

      simple: [
        {
          label: 'Satisfied customers (with avatar)',
          // avatar: '/icons/icon-tree-home.svg',
          icon: '',
          children: [
            {
              label: 'Good food (with icon)',
              children: [
                { label: 'Quality ingredients',img: '/icons/icon-tree-folder.svg', },
                { label: 'Good recipe',img: '/icons/icon-tree-folder.svg', }
              ]
            },
            {
              label: 'Good service (disabled node with icon)',
              children: [
                { label: 'Prompt attention' },
                { label: 'Professional waiter' }
              ]
            },
            {
              label: 'Pleasant surroundings (with icon)',
              // icon: 'photo',
              children: [
                {
                  label: 'Happy atmosphere (with image)',
                  img: '/icons/icon-tree-folder.svg'
                },
                { label: 'Good table presentation' },
                { label: 'Pleasing decor' }
              ]
            }
          ]
        }
      ]
    }
  }
}
</script>
