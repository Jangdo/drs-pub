<template>
  <div class="inner_admin">
    <!-- breadcrumbs -->
    <q-breadcrumbs active-color="grey-3" class="location">
      <template v-slot:separator>
        <q-icon size="1.5em" name="chevron_right" />
      </template>
      <q-breadcrumbs-el label="HOME" to="/pub" />
      <q-breadcrumbs-el label="조직관리" to="/pub/g05" />
      <q-breadcrumbs-el label="영업실적" to="/pub/g05" />
      <q-breadcrumbs-el :label="$route.name" />
    </q-breadcrumbs>
    <!--// breadcrumbs -->

    <!-- admin_tit_area -->
    <div class="admin_tit_area">
      <h2 class="title">[성장사업] 제품지수현황</h2>
    </div>
    <!-- //admin_tit_area -->

    <!-- table_search_area type_02 -->
    <div class="table_search_area type_02">
      <div class="search_item">
        <!-- <h3>본부를 입력하세요</h3> -->
        <q-input class="box_m" outlined placeholder="본부를 입력하세요" />
      </div>
      <div class="search_item">
        <!-- <h3>조직을 입력하세요</h3> -->
        <q-input class="box_m" outlined placeholder="조직을 입력하세요" />
      </div>
      <div class="search_item">
        <!-- <h3>팀을 입력하세요</h3> -->
        <q-input class="box_m" outlined placeholder="팀을 입력하세요" />
      </div>
      <div class="search_item">
        <!-- <h3>채널을 입력하세요</h3> -->
        <q-input class="box_m" outlined placeholder="채널을 입력하세요" />
      </div>
      <div class="search_item">
        <!-- <h3>선생님을 입력하세요</h3> -->
        <q-input class="box_m" outlined placeholder="선생님을 입력하세요" />
      </div>
      <div class="btn_area align_in">
        <q-btn
          outline
          class="size_sm btn_search_m"
          icon=""
          label="검색"
        />
      </div>

      <!-- 줄바꿈 -->
      <!-- <div class="line_break"></div> -->

      <!-- <div class="search_item">
        <q-select
          class="box_m"
          v-model="searchSys"
          :options="searchSysOption"
          option-value="sysytemCategory"
          option-label="desc"
          option-disable="inactive"
          emit-value
          map-options
          dense
          outlined
          dropdown-icon="ion-ios-arrow-down"
        >
        </q-select>
      </div> -->
      <div class="search_item">
        <!-- <h3>채널조회 조건을 등록하세요</h3> -->
        <q-input
          class="box_m inp_search"
          outlined
          placeholder="채널조회 조건을 등록하세요"
        >
          <template v-slot:append>
            <q-icon name="icon-search" class="icon_svg" flat :ripple="false" /> </template
        ></q-input>
      </div>
      <div class="search_item">
        <!-- <h3>학습유형</h3> -->
        <q-select
          class="box_m"
          v-model="searchstudyType"
          :options="searchstudyTypeOption"
          option-value="id"
          option-label="desc"
          option-disable="inactive"
          emit-value
          map-options
          dense
          outlined
          dropdown-icon="ion-ios-arrow-down"
        >
        </q-select>
      </div>
      <div class="search_item">
        <q-btn-toggle
          v-model="model"
          flat
          toggle-color="negative"
          class="custom_group_btn"
          :options="[
            { label: '전체', value: 'week' },
            { label: '월', value: 'mon' },
            { label: '화', value: 'tues' },
            { label: '수', value: 'wed' },
            { label: '목', value: 'thurs' },
            { label: '금', value: 'fri' },
          ]"
        />
      </div>
      <div class="search_item">
        <!-- <h3>계층/랭킹별 보기를 선택하세요</h3> -->
        <q-select
          class="box_m"
          v-model="searchTreeSelected"
          :options="searchtreeselectedOption"
          option-value="id"
          option-label="desc"
          option-disable="inactive"
          emit-value
          map-options
          dense
          outlined
          dropdown-icon="ion-ios-arrow-down"
        >
        </q-select>
      </div>

      <!-- 줄바꿈 -->
      <!-- <div class="line_break"></div> -->

      <div class="search_item">
        <!-- searchDate start.from -->
        <q-input outlined v-model="searchDate.from" class="inp_date">
          <template v-slot:append>
            <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
              <q-popup-proxy
                ref="qDateProxyFrom"
                cover
                transition-show="scale"
                transition-hide="scale"
              >
                <q-date minimal
                  mask="YYYY.MM.DD"
                  v-model="searchDate.from"
                  @update:model-value="
                    searchDate.from, $refs.qDateProxyFrom.hide()
                  "
                >
                </q-date>
              </q-popup-proxy>
            </q-icon>
          </template>
        </q-input>
        <!--// searchDate start.from -->
      </div>
      <div class="search_item">
        <q-checkbox
          v-model="dataCheck"
          label="교육지원비 적용"
          class="check_in_search"
        />
      </div>
      <div class="btn_area">
        <q-btn fill unelevated class="size_sm btn_search" label="조회" />
        <q-btn
          class="size_sm btn_reset"
          icon="ion-ios-refresh"
          outline
          label="초기화"
        />
      </div>
    </div>
    <!--// table_search_area type_02 -->

    <q-card class="wrap_table_box">
      <!-- general_table type_total -->
      <!-- 합계 있는 테이블 -->
      <div class="general_table type_total">
        <div class="btn_area">
          <q-space />
          <q-btn
            class="size_sm btn_down"
            outline
            icon=""
            label="엑셀 다운로드"
          />
        </div>
        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          row-key="idx"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th rowspan="3" key="section" class="">
                {{ props.cols[0].label }}
              </q-th>
              <q-th rowspan="1" colspan="3"> 조직규모 </q-th>
              <q-th rowspan="1" colspan="2"> 시장성 50% </q-th>


              <q-th rowspan="3" class="">
                {{ props.cols[7].label }}
              </q-th>
              <q-th rowspan="3" class="">
                {{ props.cols[8].label }}
              </q-th>
              <q-th rowspan="3" class="">
                {{ props.cols[8].label }}
              </q-th>
            </q-tr>
            <q-tr :props="props">

              <q-th rowspan="1" colspan="2"> 총원(과목) 10% </q-th>
              <q-th rowspan="1" colspan="2">교사수 10%</q-th>
              <q-th rowspan="1" colspan="1">러닝센터수 30%</q-th>
            </q-tr>
            <q-tr :props="props">
              <q-th rowspan="1">
                {{ props.cols[0].label }}
              </q-th>
              <q-th rowspan="1">
                {{ props.cols[1].label }}
              </q-th>
              <q-th rowspan="1">
                {{ props.cols[2].label }}
              </q-th>
              <q-th rowspan="1">
                {{ props.cols[3].label }}
              </q-th>
              <q-th rowspan="1">
                {{ props.cols[4].label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :class="props.row.state" :props="props">
              <q-td key="section" class="section">{{ props.row.section }}</q-td>
              <q-td key="branch" class="organization">
                {{ props.row.branch }}</q-td
              >
              <q-td key="team" class="team"> {{ props.row.team }}</q-td>
              <q-td key="chanel" class="chanel"> {{ props.row.chanel }}</q-td>
              <q-td key="teacher" class="teacher">
                {{ props.row.teacher }}</q-td
              >
              <q-td key="id" class="employee_number"> {{ props.row.id }}</q-td>
              <q-td key="countDayIn" class="join_per_day">
                {{ props.row.countDayIn }}</q-td
              >
              <q-td key="countDayIn2" class="change_per_day">
                {{ props.row.countDayIn2 }}</q-td
              >
              <q-td key="countDayOut" class="leave_per_day">
                {{ props.row.countDayOut }}</q-td
              >
            </q-tr>
          </template>
          <template v-slot:bottom-row>
            <q-tr class="tr_btm">
              <q-td colspan="6">합계</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
            </q-tr>
          </template>
        </q-table>

        <!-- <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.page"
            direction-links
            boundary-links
            :max-pages="10"
            :max="pagesNumber"
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
        </div> -->
      </div>
      <!--// general_table type_total-->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// table_search_area
// const searchSys = ref(['시스템유형을 선택하세요']);
// const searchSysOption = ref([
//   {
//     id: 'a',
//     desc: '유형 유형',
//   },
//   {
//     id: 'b',
//     desc: '시스템유형 ',
//   },
// ]);

const model = ref('tues');
const searchTreeSelected = ref(['계층/랭킹별 보기를 선택하세요']);
const searchtreeselectedOption = ref([
  {
    id: 'tree',
    desc: '계층',
  },
  {
    id: 'lanking',
    desc: '랭킹 ',
  },
]);
const searchstudyType = ref(['학습유형을 선택하세요']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
});

const dataCheck = ref(true);

//data테이블

const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'branch',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.branch,
  },
  {
    name: 'team',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.team,
  },
  {
    name: 'chanel',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.chanel,
  },
  {
    name: 'teacher',
    label: '선생님',
    field: 'teacher',
    sortable: false,
    align: 'center',
    field: (row) => row.teacher,
  },
  {
    name: 'id',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },

  {
    name: 'countDayIn',
    label: '일입회     ',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn,
  },
  {
    name: 'countDayIn2',
    label: '일전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn2,
  },
  {
    name: 'countDayOut',
    label: '일퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut,
  },
]);
const dataRows = ref([
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0000',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0001',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0002',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0003',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0004',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0005',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },

  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0006',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0007',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0007',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0008',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0001',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0009',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});
</script>
