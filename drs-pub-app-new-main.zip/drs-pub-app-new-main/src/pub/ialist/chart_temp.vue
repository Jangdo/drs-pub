<template>
  <q-breadcrumbs class="mb10">
    <q-breadcrumbs-el label="퍼블리싱 가이드" to="/pub/" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>
  <div class="row q-col-gutter-sm q-py-sm">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #ea4b64">
        <q-card-section class="text-h6 text-white">
          chart_column
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts
            :options="chart_column"

          ></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #666">
        <q-card-section class="text-h6 text-white">
          Column, line and pie
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts
            :options="chart_line"

          ></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #38b1c5">
        <q-card-section class="text-h6 text-white"> chart_bar </q-card-section>
        <q-card-section class="q-pa-none">
          <!-- <vue-highcharts
            style="width: 200vw"
            :options="chart_bubble"

          ></vue-highcharts> -->
        </q-card-section>
      </q-card>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #1e88e5">
        <q-card-section class="text-h6 text-white">
          chart_semiCircle
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts
            :options="chart_semiCircle"

          ></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #666">
        <q-card-section class="text-h6 text-white">
          Column, line and pie
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts
            :options="combination_1"

          ></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <q-card class="q-ma-xs" style="background-color: #fcb813">
        <q-card-section class="text-h6 text-white">
          Stacked and grouped column
        </q-card-section>
        <q-card-section class="q-pa-none">
          <vue-highcharts
            :options="group_column"

          ></vue-highcharts>
        </q-card-section>
      </q-card>
    </div>

  </div>
</template>
<script setup>
import VueHighcharts from 'vue3-highcharts';
import Highcharts from 'highcharts';
Highcharts.setOptions({
  colors: ['#f27321', '#fcb813', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'], // 차트 막대 색상
  lang: {
    thousandsSep: ',',
  },
});
const chart_column = {
  colors: ['#0964CE', '#BCD5F2', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'],
  chart: {
    type: 'column',
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 28,
    itemStyle: {
      color: '#000',
      fontWeight: 700,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  xAxis: {
    categories: ['입회', '퇴회', '순증', '현재총원'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: {
    min: 0,
    tickInterval: 100,
    title: false,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  tooltip: {
    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    pointFormat:
      '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
      '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
    footerFormat: '</table>',
    shared: true,
    useHTML: true,
  },
  plotOptions: {
    column: {
      pointPadding: 0.4,
      borderWidth: 0,
      borderRadius: 3,
      pointWidth: 7,
    },
  },

  series: [
    {
      name: '외방',
      data: [230, 110, 310, 480],
    },
    {
      name: '내방',
      data: [310, 40, 400, 550],
    },
  ],
};
const chart_line = {
  colors: ['#BCD5F2', '#9747FF', '#44b87b', '#FF6B23', '#555d67', '#c0c4cd'],
  chart: {
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,

  yAxis: {
    title: false,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  xAxis: {
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  plotOptions: {
    line: {
      marker: false,
    },
    series: {
      label: {
        connectorAllowed: false,
      },
      // pointStart: 2010,
    },
  },

  series: [
    {
      name: '회원매출액',
      data: [74000, 80000, 100000, 125000, 150000, 160000],
    },
    {
      name: '회원당매출액',
      data: [50000, 60000, 70000, 67000, 24000, 50000],
    },
    {
      name: '입금총액',
      data: [54000, 74000, 78000, 69000, 80000, 82000],
    },
    {
      name: '입금률(%)',
      data: [82000, 72000, 62000, 54000, 12000, 72000],
    },
  ],

  responsive: {
    rules: [
      {
        condition: {
          maxWidth: 500,
        },
        chartOptions: {
          legend: {
            //  layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            itemMarginTop: 0,
            itemMarginBottom: 28,
            itemStyle: {
              color: '#000',
              fontWeight: 700,
              fontFamily: 'Pretendard',
              fontSize: '14px',
            },
          },
        },
      },
    ],
  },
};


const chart_semiCircle = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
  },
  title: {
    text: 'Browser<br>shares<br>January<br>2022',
    align: 'center',
    verticalAlign: 'middle',
    y: 60,
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },

  plotOptions: {
    pie: {
      dataLabels: {
        enabled: true,
        distance: -50,
        style: {
          fontWeight: 'bold',
          color: 'white',
        },
      },
      startAngle: -90,
      endAngle: 90,
      center: ['50%', '75%'],
      size: '110%',
      states: {
        inactive: {
          opacity: 1, // 마우스오버 투명도
        },
      },
    },
    series: {
      states: {
        hover: {
          enabled: false, // 마우스오버효과
        },
      },
    },
  },
  series: [
    {
      type: 'pie',
      name: 'Browser share',
      innerSize: '50%',
      data: [
        ['Chrome', 73.86],
        ['Edge', 11.97],
        ['Firefox', 5.52],
        ['Safari', 2.98],
        ['Internet Explorer', 1.9],
        {
          name: 'Other',
          y: 3.77,
          dataLabels: {
            enabled: false,
          },
        },
      ],
    },
  ],
};

const combination_1 = {
  title: {
    text: 'Sales of petroleum products March, Norway',
    align: 'left',
  },
  xAxis: {
    categories: ['Jet fuel', 'Duty-free diesel', 'Petrol', 'Diesel', 'Gas oil'],
  },
  yAxis: {
    title: {
      text: 'Million liters',
    },
  },
  tooltip: {
    valueSuffix: ' million liters',
  },
  plotOptions: {
    column: {
      borderRadius: 5,
    },
  },
  series: [
    {
      type: 'column',
      name: '2020',
      data: [59, 83, 65, 228, 184],
    },
    {
      type: 'column',
      name: '2021',
      data: [24, 79, 72, 240, 167],
    },
    {
      type: 'column',
      name: '2022',
      data: [58, 88, 75, 250, 176],
    },
    {
      type: 'spline',
      name: 'Average',
      data: [47, 83.33, 70.66, 239.33, 175.66],
      marker: {
        lineWidth: 2,
        lineColor: Highcharts.getOptions().colors[3],
        fillColor: 'white',
      },
    },
    {
      type: 'pie',
      name: 'Total',
      className: 'com-pie',
      data: [
        {
          name: '2020',
          y: 6190,
          color: Highcharts.getOptions().colors[0], // 2020 color
          dataLabels: {
            enabled: true,
            distance: -50,
            format: '{point.total} M',
            style: {
              fontSize: '15px',
            },
          },
        },
        {
          name: '2021',
          y: 586,
          color: Highcharts.getOptions().colors[1], // 2021 color
        },
        {
          name: '2022',
          y: 647,
          color: Highcharts.getOptions().colors[2], // 2022 color
        },
      ],
      center: [75, 65],
      size: 90,
      innerSize: '60%',
      showInLegend: false,
      dataLabels: {
        enabled: false,
      },
    },
  ],
};

const group_column = {
  chart: {
    type: 'column',
  },
  title: {
    text: 'Olympic Games all-time medal table, grouped by continent',
  },
  xAxis: {
    categories: ['Gold', 'Silver', 'Bronze'],
  },
  yAxis: {
    allowDecimals: false,
    min: 0,
    title: {
      text: 'Count medals',
    },
  },
  legend: {
    // layout: 'vertical',
    align: 'right',
    verticalAlign: 'top',
    x: 0,
    y: 70,
    floating: true,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor:
      (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF',
    // shadow: true,
  },
  tooltip: {
    formatter: function () {
      return (
        '<b>' +
        this.x +
        '</b><br/>' +
        this.series.name +
        ': ' +
        this.y +
        '<br/>' +
        'Total: ' +
        this.point.stackTotal
      );
    },
  },
  plotOptions: {
    column: {
      stacking: 'normal',
      // borderRadius: 5,
      pointPadding: 0.05,
      groupPadding: 0.15,
    },
  },
  series: [
    {
      name: 'Norway',
      data: [148, 133, 124],
      stack: 'Europe',
      className: 'stack-column-round',
    },
    {
      name: 'Germany',
      data: [102, 98, 65],
      stack: 'Europe',
      // className: 'stack-column-round'
    },
    {
      name: 'United States',
      data: [113, 122, 95],
      stack: 'North America',
      className: 'stack-column-round',
    },
    {
      name: 'Canada',
      data: [77, 72, 80],
      stack: 'North America',
      // className: 'stack-column-round'
    },
  ],
};
</script>
<style lang="scss">
.vue-highcharts {
  width: 100%;
}
.my-card {
  width: 100%;
  max-width: 500px;
}

.circle_shape {
  height: 0;
  margin: 0 auto;
  width: 40%;
  padding-bottom: 40%;
  border-radius: 60px !important;
  outline: 1px solid #eee;
  border: 1px solid #aaa;
}

.stack-column-round .highcharts-axis-line {
  // stroke: #7cb5ec;
}
</style>
<style scoped>
.stack-column-round rect {
  rx: 5;
  ry: 5;
}
</style>
