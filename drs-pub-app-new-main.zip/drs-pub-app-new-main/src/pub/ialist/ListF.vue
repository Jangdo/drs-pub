<template>
  <div class="wrap_ia_list">
    <q-table
      title="[F]커뮤니티"
      :rows="rows"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td key="Infor" :class="getClass(props.row.Infor.state)">
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>

    <q-table
      title="커뮤니티 가이드 230504 이전"
      :rows="rows_old"
      :columns="columns"
      row-key="index"
      :pagination="initialPagination"
      class="table_01"
      wrap-cells
    >
      <template v-slot:body="props">
        <q-tr :class="getClass(props.row.Infor.state)" :props="props">
          <q-td key="index" class="text-center">
            {{ props.rowIndex + 1 }}
          </q-td>
          <q-td
            key="name"
            style="text-align: left !important; word-break: break-all"
          >
            {{ props.row.name }}
            {{ props.row.name2 }}
          </q-td>
          <q-td key="name" style="text-align: left !important">
            <router-link :to="`/pub/` + props.row.name.toLowerCase()">
              /pub/{{ props.row.name.toLowerCase() }}</router-link
            >
          </q-td>
          <q-td key="Depth2" style="text-align: left !important">
            {{ props.row.Depth2 }}
          </q-td>
          <q-td key="Depth3" style="text-align: left !important">
            {{ props.row.Depth3 }}
          </q-td>
          <q-td
            key="Infor"
            :class="getClass(props.row.Infor.state)"
            class="text-center"
          >
            {{ props.row.Infor.date }}
            <span v-if="props.row.Infor.state">/</span>

            {{ props.row.Infor.state }}
            <span v-if="props.row.Infor.state">/</span>
            {{ props.row.Infor.worker }}
          </q-td>
          <q-td key="Comment" style="text-align: left !important">
            {{ props.row.Comment }}
          </q-td>
        </q-tr>
      </template>
    </q-table>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// 테이블 헤더 설정
const columns = ref([
  {
    name: 'index',
    label: 'idx',
    align: 'center',
    sortable: false,
    field: (row) => row.rowIndex,
    headerStyle: 'width:78px',
  },
  {
    name: 'name',
    label: '화면번호',
    align: 'left',
    sortable: false,
    field: (row) => row.name2,
    headerStyle: 'width:200px',
  },
  {
    name: 'link',
    label: 'link',
    align: 'left',
    sortable: false,
    field: (row) => row.name,
    headerStyle: 'width:235px',
  },
  {
    name: 'Depth2',
    align: 'left',
    label: 'Depth2',
    field: 'Depth2',
    sortable: false,
    headerStyle: 'width:140px',
  },

  {
    name: 'Depth3',
    align: 'left',
    label: 'Depth3',
    field: 'Depth3',
    sortable: false,
    headerStyle: 'width:380px',
  },
  {
    name: 'infor',
    label: 'infor',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
    headerStyle: 'width:200px',
  },
  { name: 'Comment', align: 'left', label: 'Comment', field: 'Comment' },
]);

//  리스트 데이터
const rows = ref([
  {
    name: 'F0601010105',
    Depth2: '게시판관리',
    Depth3: '테이블 관리',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블, 체크박스, 버튼 컬러',
  },
  {
    name: 'F0201',
    Depth2: '소통게시판',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블',
  },
  {
    name: 'F06',
    Depth2: '게시판',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스, 버튼 컬러',
  },

  {
    name: 'F0601',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 게시판_화면구성',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '참고하세요, 하단 버튼',
  },
  {
    name: 'F060101P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 단일코드 코드 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'F060102P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 멀티코드 코드 선택',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'F0602',
    Depth2: '게시판관리',
    Depth3: '- 게시판관리 - 게시물조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '테이블, 체크박스, 하단 버튼',
  },
  {
    name: 'F060201P',
    Depth2: '게시판관리',
    Depth3: '게시판관리 - 목록 - 게시물관리 - 신고하기',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },

  {
    name: 'F0101030101P',
    name2: '(F0204010101P,F0403010101P)',

    Depth2: '공지사항',
    Depth3: '공지/행사/이벤트-검색',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'F0102010301P',
    name2: '(F0102020301P,F0102030301P)',
    Depth2: '공지사항',
    Depth3: '프로모션조회 - 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블, 체크박스',
  },
]);
const rows_old = ref([
  {
    name: 'F010101',
    name2: '(F0201)',
    Depth2: '공지사항',
    Depth3: '공지/행사/이벤트',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'F010102',
    name2: '(F0402)',
    Depth2: '',
    Depth3: '공지/행사/이벤트 상세',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'F01020101',
    name2: '(F01020201,F01020301)',
    Depth2: '',
    Depth3: '할인행사 공지-  프로모션조회',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
  {
    name: 'F01020302',
    name2: '(F01020202)',
    Depth2: '',
    Depth3: '할인행사 공지- 공공지원금 조회',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'F0202',
    Depth2: '소통게시판',
    Depth3: '등록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '하단 버튼',
  },
  {
    name: 'F0203',
    Depth2: '',
    Depth3: '상세',
    Infor: {
      date: '',
      state: '',
      worker: '',
    },
    Comment: '',
  },
  {
    name: 'F0401',
    Depth2: 'FAQ',
    Depth3: '목록',
    Infor: {
      date: '',
      state: '수정',
      worker: '',
    },
    Comment: '검색, 테이블',
  },
]);

// 테이블 설정
const initialPagination = ref({
  sortBy: 'desc',
  descending: true,
  page: 1,
  rowsPerPage: 0,
  // rowsNumber: xx if getting data from a server
});

//  클릭시점
// function clickSample(txt) {
//   console.log(txt);
// }
// 상태 클래스
function getClass(priority) {
  switch (priority) {
    case '재작업완료':
      return 'again_end';
    case '완료후 수정 예정':
      return 'rework';
    case '완료':
      return 'end';
    case '진행중':
      return 'ing';
    case '수정':
      return 'edit';
    case '삭제':
      return 'remove';
    default:
      return 'tobe';
  }
}
</script>
<style lang="scss">
.btn_inner_table {
  display: flex;
  justify-content: space-evenly;
}

.q-tr.end {
  background: rgb(240 248 255);
}
.q-tr.ing {
  td {
    background: rgb(204, 229, 250) !important;
  }
}
.q-tr.again_end {
  background: rgb(186 183 247 / 48%);
}

.q-tr.rework {
  background: rgb(76 175 80 / 8%);
}

.q-tr.remove {
  background: rgb(255 87 34 / 10%);
}
</style>
