<template>
  <div class="wrap_ia_list">
    <q-intersection transition="jump-up">
      <!-- 아이콘 -->
      <q-expansion-item
        default-opened
        icon="mood"
        label="Icon"
        header-class="text-primary"
      >
        <q-card>
          <q-card-section
            >Material Icons 아이콘 팩 사용 예정
            <br />https://fonts.google.com/icons?icon.set=Material+Icons
          </q-card-section>
        </q-card>
      </q-expansion-item>
      <!--// 아이콘 -->
      <q-separator />

      <q-expansion-item
        default-opened
        icon="format_size"
        label="Typhography"
        header-class="text-teal"
      >
        <q-card>
          <q-card-section>
            <div>
              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-h1
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    h1
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-h1" cursor-pointer>
                  <q-tooltip>
                    font-size: 30px; *가독성 폴백 <br />
                    font-size: 1.875rem; line-height: 2.625rem; font-weight:
                    900;
                  </q-tooltip>
                  Headline/Large 차세대드림스
                </div>
              </div>
              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-h2
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    h2
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-h2" cursor-pointer>
                  <q-tooltip>
                    font-size: 1.625rem; line-height: 2.25rem; font-weight: 700;
                  </q-tooltip>
                  Headline/Medium 차세대드림스
                </div>
              </div>
              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-h3
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    h3
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-h3" cursor-pointer>
                  <q-tooltip>
                    font-size: 22px; font-size: 1.375rem; line-height: 1.875rem;
                    font-weight: 500;
                  </q-tooltip>
                  Headline/Small 차세대드림스
                </div>
              </div>

              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-h4
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    h4
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-h4" cursor-pointer>
                  <q-tooltip>
                    font-size: 20px; font-size: 1.25rem; line-height: 29px;
                    font-weight: 700;
                  </q-tooltip>
                  Title/Large 차세대드림스
                </div>
              </div>

              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-h5
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    h5
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-h5" cursor-pointer>
                  <q-tooltip>
                    font-size: 18px; font-size: 1.8125rem; line-height:
                    1.5625rem; font-weight: 500;
                  </q-tooltip>
                  Title/Medium 차세대드림스
                </div>
              </div>

              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-body1
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    *
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-body1" cursor-pointer>
                  <q-tooltip>
                    font-size: 15px; font-size: 0.9375rem; line-height:
                    0.9375rem; font-weight: 500;
                  </q-tooltip>
                  Title/Small 차세대드림스
                </div>
              </div>

              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-body2
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    *
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-body2" cursor-pointer>
                  <q-tooltip>
                    font-size: 13px; font-size: 0.8125rem; line-height:
                    1.3125rem; font-weight: 500;
                  </q-tooltip>
                  Body/Large 차세대드림스
                </div>
              </div>
              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-body3
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    *
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-body3" cursor-pointer>
                  <q-tooltip
                    >font-size: 12px; font-size: 0.75rem; line-height: 1.25rem;
                    font-weight: 900;</q-tooltip
                  >
                  Body/Medium 차세대드림스
                </div>
              </div>
              <div class="row items-center q-mb-lg">
                <div class="col-sm-3 col-12">
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                    role="status"
                    cursor-pointer
                  >
                    text-body4
                    <q-tooltip> class </q-tooltip>
                  </div>
                  <div
                    class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                    role="status"
                    cursor-pointer
                  >
                    *
                    <q-tooltip> tag </q-tooltip>
                  </div>
                </div>
                <div class="col-sm-9 col-12 text-body4" cursor-pointer>
                  <q-tooltip>
                    font-size: 11px; font-size: 0.6875rem; line-height:
                    1.125rem; font-weight: 500;</q-tooltip
                  >
                  Body/Small 차세대드림스
                </div>
              </div>
            </div>
          </q-card-section>
        </q-card>
      </q-expansion-item>

      <q-separator />
      <!-- Color -->
      <q-expansion-item
        default-opened
        icon="palette"
        label="Color"
        header-class="text-purple"
      >
        <div class="q-pa-md row items-start q-gutter-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-10" cursor-pointer>
              <q-tooltip> $grey-10: #060606; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">Natural10</div>
              <div class="text-subtitle2">$grey-10: #060606;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-9" cursor-pointer>
              <q-tooltip> $grey-9: #090909; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">Natural20</div>
              <div class="text-subtitle2">$grey-9: #090909;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-8" cursor-pointer>
              <q-tooltip> $grey-8: #555d67; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">Natural30</div>
              <div class="text-subtitle2">$grey-8: #555d67;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-7" cursor-pointer>
              <q-tooltip> $grey-7: #c0c4cd; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">Natural40</div>
              <div class="text-subtitle2">$grey-7: #c0c4cd;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-6" cursor-pointer>
              <q-tooltip> $grey-6: #f4f5fb; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">Natural50</div>
              <div class="text-subtitle2">$grey-6: #f4f5fb;</div>
            </q-card-section>
          </q-card>
        </div>
        <div class="q-pa-md row items-start q-gutter-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-negative" cursor-pointer>
              <q-tooltip> $negative: #f27321; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">negative</div>
              <div class="text-subtitle2">$negative: #f27321;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-warning" cursor-pointer>
              <q-tooltip> $warning: #fcb813; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">warning</div>
              <div class="text-subtitle2">$warning: #fcb813;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-positive" cursor-pointer>
              <q-tooltip> $positive: #44b87b; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">positive</div>
              <div class="text-subtitle2">$positive: #44b87b;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-primary" cursor-pointer>
              <q-tooltip> $primary: #0080b6; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">primary</div>
              <div class="text-subtitle2">$primary: #0080b6;</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-white" cursor-pointer>
              <q-tooltip> $white: #f4f5fb; </q-tooltip>
            </div>

            <q-card-section>
              <div class="text-h6">white</div>
              <div class="text-subtitle2">$white: #fff;</div>
            </q-card-section>
          </q-card>
        </div>
      </q-expansion-item>
      <!-- //Color -->
      <q-separator />
      <!-- BUTTON -->
      <q-expansion-item default-opened icon="play_for_work" label="Button">
        <q-card class="">
          <div class="q-pa-md q-gutter-sm">
            <q-btn flat color="primary" label="Flat" />
            <q-btn flat rounded color="primary" label="Flat Rounded" />
            <q-btn flat round color="primary" icon="card_giftcard" />
            <br />
            <q-btn outline color="primary" label="Outline" />
            <q-btn outline rounded color="primary" label="Outline Rounded" />
            <q-btn outline round color="primary" icon="card_giftcard" />
            <br />
            <q-btn push color="primary" label="Push" />
            <q-btn push color="primary" round icon="card_giftcard" />
            <q-btn push color="white" text-color="primary" label="Push" />
            <q-btn
              push
              color="white"
              text-color="primary"
              round
              icon="card_giftcard"
            />
            <br />
            <q-btn unelevated color="primary" label="Unelevated" />
            <q-btn
              unelevated
              rounded
              color="primary"
              label="Unelevated Rounded"
            />
            <q-btn unelevated round color="primary" icon="card_giftcard" />
            <br />
            <q-btn no-caps color="primary" label="No caps" />
            <br />
            <q-btn class="glossy" color="secondary" label="Glossy" />
            <q-btn
              class="glossy"
              rounded
              color="negative"
              label="Glossy Rounded"
            />
            <q-btn class="glossy" round color="primary" icon="card_giftcard" />
            <q-btn
              class="glossy"
              round
              color="secondary"
              icon="local_florist"
            />
            <q-btn
              class="glossy"
              round
              color="negative"
              icon="local_activity"
            />
          </div>
        </q-card>
      </q-expansion-item>
      <!-- BUTTON -->
      <q-separator />
      <!-- Radio -->
      <q-expansion-item default-opened icon="keyboard" label="Radio">
        <q-card class="">
          <div class="q-pa-md q-gutter-sm">
            <q-radio
              v-model="dataRadio"
              val="primary"
              label="primary"
              color="primary"
            />
            <q-radio
              v-model="dataRadio"
              val="secondary"
              label="secondary"
              color="secondary"
            />
            <q-radio
              v-model="dataRadio"
              val="warning"
              label="warning"
              color="warning"
            />
            <q-radio
              v-model="dataRadio"
              val="negative"
              label="negative"
              color="negative"
            />
            <q-radio v-model="dataRadio" val="info" label="info" color="info" />
          </div>
        </q-card>
      </q-expansion-item>
      <!-- Radio -->
      <q-separator />
    </q-intersection>
  </div>
</template>

<script>
import { onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { useMeta } from 'quasar';
const metaData = {};

export default {
  components: {},
  data() {
    return {
      dataInput: '인풋테스트',
      dataRadio: 'primary',
      dataCheck: ['primary', 'secondary', 'negative'],
      optionsSelect: ['Google', 'Facebook', 'Twitter', 'Apple', 'Oracle'],
    };
  },
  setup() {
    const route = useRoute();
    onMounted(() => {
      metaData.title = route.name;
      // console.log(route.name);
      useMeta(metaData);
    });
    return {};
  },
  // mounted() {},
};
</script>

<style lang="scss">
.my-card {
  width: 100%;
  max-width: 250px;
}
.circle_shape {
  height: 0;
  margin: 0 auto;
  width: 40%;
  padding-bottom: 40%;
  border-radius: 60px !important;
  outline: 1px solid #eee;
  border: 1px solid #aaa;
}
</style>
