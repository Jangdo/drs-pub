<template>
  <div class="wrap_ia_list">
    <TestSnb />
    <h3 class="my25">가이드</h3>

    <!-- Dialogs -->
    <q-expansion-item
      :default-opened="false"
      icon="mode_comment"
      header-class="text-red-9"
      label="팝업 / Dialogs"
    >
      <div class="q-pa-xs bg-red-1">
        <div class="q-pa-md">
          <h4 class="q-py-sm text-red-9">반응형 팝업</h4>
          <q-btn
            unelevated
            class="ma10"
            label="responsePop inner_form"
            color="orange-6"
            @click="dataDialog.responsePop = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop 배경색"
            color="orange-6"
            @click="dataDialog.responsePopbg = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop type02 Small 580"
            color="orange-6"
            @click="dataDialog.responseType02SmallPop = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop type02 medium 760"
            color="orange-6"
            @click="dataDialog.responseType02MediumPop = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop type02 800"
            color="orange-6"
            @click="dataDialog.responseType02Pop = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop type02 large 1000"
            color="orange-6"
            @click="dataDialog.responseType02LargePop = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="responsePop type02 huge 1580"
            color="orange-6"
            @click="dataDialog.responseType02HugePop = true"
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-red-9">헤더 팝업(pc버전만 존재)</h4>
          <q-btn
            unelevated
            class="ma10"
            label="type_01"
            color="primary"
            @click="dataDialog.alert = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_01 버튼2개"
            color="primary"
            @click="dataDialog.alert2 = true"
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-red-9">파란배경 헤더 팝업(pc버전만 존재)</h4>
          <q-btn
            unelevated
            class="ma10"
            label="type_02 460"
            color="green-7"
            @click="dataDialog.type02 = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 middle 500"
            color="green-7"
            @click="dataDialog.middle = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 form 680"
            color="green-7"
            @click="dataDialog.inner = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 form medium 780"
            color="green-7"
            @click="dataDialog.medium = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 large 800"
            color="green-7"
            @click="dataDialog.large = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 double 980"
            color="green-7"
            @click="dataDialog.double = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 wide 1180"
            color="green-7"
            @click="dataDialog.wide = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 huge 1340"
            color="green-7"
            @click="dataDialog.huge = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="type_02 venti 1480"
            color="green-7"
            @click="dataDialog.venti = true"
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-red-9">그 외 팝업</h4>
          <q-btn
            unelevated
            class="ma10"
            label="Confirm"
            color="blue-9"
            @click="dataDialog.confirm = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="Prompt"
            color="blue-9"
            @click="dataDialog.prompt = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="bottomsheet"
            color="blue-9"
            @click="dataDialog.bottomsheet = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="검색옵션 선택(반응형)"
            color="indigo-7"
            @click="dataDialog.btm4 = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="장바구니 팝업(하단고정)"
            color="indigo-7"
            @click="dataDialog.btm5 = true"
          />
          <q-btn
            class="ma10"
            color="deep-purple-7"
            to="/sampleDialogform"
            target="_blank"
            label="sampleDialogform(새창)"
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-red-9">
            반응형 팝업 : 모바일에서 바텀시트 형태
          </h4>
          <q-btn
            unelevated
            class="ma10"
            label="하단팝업 트리"
            color="purple-8"
            @click="dataDialog.btm = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="하단팝업 타이틀라인"
            color="purple-8"
            @click="dataDialog.btm2 = true"
          />
          <q-btn
            unelevated
            class="ma10"
            label="하단팝업 타이틀없음"
            color="purple-8"
            @click="dataDialog.btm3 = true"
          />

          <q-dialog v-model="dataDialog.responsePop">
            <q-card class="respons_card inner_form">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response inner_form</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content">
                pop 컨텐츠 배경없음
                <section class="section_form">
                  1. section class section_form
                </section>
                <hr class="separator" />
                <section class="section_form">2</section>
              </q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responsePopbg">
            <q-card class="respons_card inner_form type_bg">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response 배경색</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content">
                <section class="section_form">section 1</section>
                <section class="section_form">
                  section 2

                  <div class="btn_area response mt60">
                    <q-btn
                      fill
                      unelevated
                      v-close-popup
                      color="black"
                      class="size_lg btn_apply"
                      label="확인"
                    />
                  </div>
                </section>
              </q-card-section>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responseType02Pop">
            <q-card class="respons_card type_02">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response Type02 800px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content">800</q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responseType02MediumPop">
            <q-card class="respons_card type_02 medium">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response Type02 Medium 760px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content"> 760 </q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responseType02SmallPop">
            <q-card class="respons_card type_02 small">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response Type02 small 580px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content"> 580 </q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responseType02LargePop">
            <q-card class="respons_card type_02 large">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response Type02 large 1000px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content">1000px</q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.responseType02HugePop">
            <q-card class="respons_card type_02 huge">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">response Type02 huge 1580px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>

              <q-card-section class="dialog_content">1580px</q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  class="size_sm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.alert">
            <q-card class="dialog_card type_01">
              <q-card-section class="dialog_title">
                공지사항 삭제
              </q-card-section>
              <q-card-section class="dialog_content">
                삭제 완료되었습니다.
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  text-color="white"
                  class="size_sm confirm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.alert2">
            <q-card class="dialog_card type_01">
              <q-card-section class="dialog_title">
                사용자 등록
              </q-card-section>
              <q-card-section class="dialog_content">
                입력하신 내용으로 등록합니다.<br />계속 진행하시겠습니까?
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  color="grey-4"
                  text-color="white"
                  class="size_sm confirm"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="primary"
                  text-color="white"
                  class="size_sm confirm"
                  label="확인"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.type02">
            <q-card class="dialog_card type_02">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">카테고리 검색</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="inner_tit">메시지 카테고리</p>
                내용
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.middle">
            <q-card class="dialog_card type_02 middle">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">middle 500</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p style="font-size: 28px; line-height: 2">
                  헤더 있는 타입 middle 500
                </p>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="저장"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.inner">
            <q-card class="dialog_card inner_form">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">메시지 등록</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="required_msg">
                  <span class="text-orange">* 항목</span>은 필수입력입니다
                </p>
                <!-- inner_list -->
                <ul class="inner_list">
                  <li>
                    <span class="as_dt required">메시지 명</span>
                    <q-input
                      v-model="dataFrom.name"
                      class="as_dd hide_label"
                      label="* 메시지 명"
                      outlined
                      placeholder="메시지 명을 입력하세요"
                      stack-label
                      dense
                    >
                      <template v-slot:label>메시지 명</template>
                    </q-input>
                  </li>
                  <li>
                    <span class="as_dt required">메시지 내용</span>
                    <q-input
                      class="as_dd hide_label"
                      outlined
                      placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
                      type="textarea"
                      v-model="dataFrom.txt"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </li>
                  <li>
                    <span class="as_dt required">구분</span>
                    <q-select
                      class="as_dd"
                      outlined
                      dense
                      v-model="dataFrom.state"
                      :options="stateSelectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                    ></q-select>
                  </li>
                  <li>
                    <span class="as_dt required">사용여부</span>
                    <div class="as_dd">
                      <q-radio
                        v-model="dataFrom.allow"
                        val="true"
                        label="사용"
                        color="negative"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataFrom.allow"
                        val="false"
                        label="사용안함"
                        color="negative"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </li>
                </ul>
                <!--// inner_list -->
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="저장"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.medium">
            <q-card class="dialog_card inner_form medium">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">미디움</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="required_msg">
                  <span class="text-orange">* 항목</span>은 필수입력입니다
                </p>
                <!-- inner_list -->
                <ul class="inner_list">
                  <li>
                    <span class="as_dt required">메시지 ID</span>
                    <q-input
                      v-model="dataFrom.id"
                      class="as_dd hide_label"
                      label="* 메시지 ID"
                      outlined
                      placeholder="메시지 명을 입력하세요"
                      stack-label
                      dense
                    >
                      <template v-slot:label>메시지 ID</template>
                    </q-input>
                  </li>
                  <li>
                    <span class="as_dt required">근무기간</span>
                    <div class="as_dd input_row">
                      <!-- searchDate start.from -->
                      <q-input outlined class="inp_date">
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date minimal mask="YYYY.MM.DD"> </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!--// searchDate start.from -->
                      <div class="tilde">
                        <span>~</span>
                      </div>
                      <!-- searchDate start.to -->
                      <q-input outlined class="inp_date">
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyto"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date minimal mask="YYYY.MM.DD"> </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!--// searchDate start.to -->
                    </div>
                  </li>
                  <li>
                    <span class="as_dt required">MOS 이용 설정</span>
                    <div class="as_dd input_row">
                      <q-input
                        class="as_dd hide_label"
                        label="시간/분을 입력하세요. (예: 1305)"
                        outlined
                        placeholder="시간/분을 입력하세요. (예: 1305)"
                        stack-label
                        dense
                      >
                        <template v-slot:label
                          >시간/분을 입력하세요. (예 : 1305)</template
                        >
                      </q-input>
                      <div class="tilde">
                        <span>~</span>
                      </div>
                      <q-input
                        class="as_dd hide_label"
                        label="시간/분을 입력하세요. (예: 1305)"
                        outlined
                        placeholder="시간/분을 입력하세요. (예: 1305)"
                        stack-label
                        dense
                      >
                        <template v-slot:label
                          >시간/분을 입력하세요. (예 : 1305)</template
                        >
                      </q-input>
                    </div>
                  </li>
                  <li>
                    <span class="as_dt required">사용여부</span>
                    <div class="as_dd">
                      <q-radio
                        v-model="dataFrom.allow"
                        val="true"
                        label="사용"
                        color="orange"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataFrom.allow"
                        val="false"
                        label="사용안함"
                        color="orange"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </li>
                </ul>
                <!--// inner_list -->
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="저장"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.large">
            <q-card class="dialog_card type_02 large">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">type02 large 800px</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                type02 large 800px
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.double">
            <q-card class="dialog_card type_02 double inner_form">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">더블</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <ul class="inner_list">
                  <li class="divide_form">
                    <div class="form_row">
                      <div class="form_item">
                        <span class="as_dt required">로그인 ID</span>
                        <q-input
                          class="as_dd hide_label"
                          label="로그인 ID"
                          outlined
                          placeholder="로그인 ID를 입력하세요"
                          stack-label
                          dense
                        >
                          <template v-slot:label>로그인 ID</template>
                        </q-input>
                      </div>
                      <div class="form_item">
                        <span class="as_dt required">이름</span>
                        <q-input
                          class="as_dd hide_label"
                          label="이름"
                          outlined
                          placeholder="이름을 입력하세요"
                          stack-label
                          dense
                        >
                          <template v-slot:label>이름</template>
                        </q-input>
                      </div>
                    </div>
                  </li>
                  <li class="divide_form">
                    <div class="form_row">
                      <div class="form_item">
                        <span class="as_dt required">사업부</span>
                        <div class="as_dd search_item">
                          <q-input
                            class="inp_search"
                            outlined
                            placeholder="사업부를 검색하세요"
                          >
                            <template v-slot:append>
                              <q-btn
                                icon="search"
                                flat
                                :ripple="false"
                                @click="test"
                              /> </template
                          ></q-input>
                        </div>
                      </div>
                      <div class="form_item">
                        <span class="as_dt required">영업조직</span>
                        <div class="as_dd search_item">
                          <q-input
                            class="inp_search"
                            outlined
                            placeholder="영업조직를 검색하세요"
                          >
                            <template v-slot:append>
                              <q-btn
                                icon="search"
                                flat
                                :ripple="false"
                                @click="test"
                              /> </template
                          ></q-input>
                        </div>
                      </div>
                    </div>
                  </li>
                </ul>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.wide">
            <q-card class="dialog_card type_02 wide">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">와이드</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="inner_tit">소제목</p>
                <ul>
                  <li>h020401p</li>
                  <li>h020601p</li>
                </ul>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.venti">
            <q-card class="dialog_card type_02 venti">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">venti 1480</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="inner_tit">venti</p>
                <ul>
                  <li>1480</li>
                  <li>1480</li>
                </ul>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.huge">
            <q-card class="dialog_card type_02 huge">
              <q-card-section class="pop_title_wrap">
                <h4 class="tit">huge</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="inner_tit">소제목</p>
                <ul>
                  <li>h02010302p</li>
                  <li>h020602p</li>
                </ul>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.confirm" persistent>
            <q-card class="dialog_card">
              <q-card-section class="dialog_title hasicon">
                <q-avatar icon="campaign" color="negative" text-color="white" />
                <span class="q-ml-sm">confirm ?</span>
              </q-card-section>

              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  color="grey06"
                  text-color="white"
                  class="cancel"
                  label="거절"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="negative"
                  text-color="white"
                  class="confirm"
                  label="동의"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.prompt" persistent>
            <q-card class="dialog_card">
              <q-card-section class="dialog_title">
                prompt 입력
              </q-card-section>
              <q-card-section class="dialog_content">
                <q-input
                  dense
                  v-model="dataDialog.prompt_input"
                  autofocus
                  @keyup.enter="dataDialog.prompt_input = false"
                />
              </q-card-section>
              <q-card-actions class="">
                <q-btn
                  unelevated
                  v-close-popup
                  color="grey-4"
                  text-color="white"
                  class="size_sm cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  color="black"
                  text-color="white"
                  class="size_sm confirm"
                  label="입력완료"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog
            v-model="dataDialog.bottomsheet"
            full-width
            position="bottom"
          >
            <q-card
              style="
                border-top-left-radius: 20px;
                border-top-right-radius: 20px;
              "
              v-touch-swipe.mouse="swipe_bottom"
            >
              <q-card-section class="row items-center no-wrap">
                <q-list>
                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-icon color="primary" name="bluetooth" />
                    </q-item-section>

                    <q-item-section>Icon as avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar
                        color="teal"
                        text-color="white"
                        icon="bluetooth"
                      />
                    </q-item-section>

                    <q-item-section>Avatar-type icon</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar
                        rounded
                        color="purple"
                        text-color="white"
                        icon="bluetooth"
                      />
                    </q-item-section>

                    <q-item-section>Rounded avatar-type icon</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar color="primary" text-color="white">
                        R
                      </q-avatar>
                    </q-item-section>

                    <q-item-section>Letter avatar-type</q-item-section>
                  </q-item>

                  <q-separator />

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png" />
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar square>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png" />
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image square avatar</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar rounded>
                        <img src="https://cdn.quasar.dev/img/boy-avatar.png" />
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>Image rounded avatar</q-item-section>
                  </q-item>

                  <q-separator />

                  <q-item clickable v-ripple>
                    <q-item-section avatar>
                      <q-avatar rounded>
                        <img src="https://cdn.quasar.dev/img/mountains.jpg" />
                      </q-avatar>
                    </q-item-section>
                    <q-item-section>List item</q-item-section>
                  </q-item>

                  <q-item clickable v-ripple>
                    <q-item-section thumbnail>
                      <img src="https://cdn.quasar.dev/img/mountains.jpg" />
                    </q-item-section>
                    <q-item-section>List item</q-item-section>
                  </q-item>
                </q-list>

                <q-space />
              </q-card-section>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.btm" class="dialog_btm m_change">
            <q-card class="respons_card type_tree">
              <q-card-section class="pop_title_wrap">
                <q-chip dense class="chip_line"></q-chip>
                <h4 class="tit">dialog_btm</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  outline
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <ul>
                  <li>모바일에서 하단팝업 / 피시에서 가운데</li>
                  <li>g0501010101p</li>
                  <li>g0501010103p</li>
                </ul>
                <q-list class="list_custom type01">
                  <q-expansion-item class="expansion_custom type05">
                    <template v-slot:header>
                      <q-item-section>
                        <div class="item_head">
                          <span class="title">채널</span>
                        </div>
                      </q-item-section>
                    </template>
                    <q-card>
                      <q-card-section>
                        <q-tree
                          :nodes="treeData1"
                          node-key="id"
                          text-color="grey-2"
                          selected-color="black"
                          class="tree type01"
                          v-model:selected="treeSelected1"
                          default-expand-all
                          @update:selected="temp('트리1', treeSelected1)"
                        >
                        </q-tree>
                      </q-card-section>
                    </q-card>
                  </q-expansion-item>
                </q-list>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_cancel"
                  label="취소"
                />
                <q-btn
                  unelevated
                  v-close-popup
                  class="size_sm btn_save"
                  label="설정"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.btm2" class="dialog_btm m_change">
            <q-card class="respons_card type_form">
              <q-card-section class="pop_title_wrap">
                <q-chip dense class="chip_line"></q-chip>
                <h4 class="tit">라인타이틀</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content"> 팝업내용 </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  fill
                  unelevated
                  v-close-popup
                  color="black"
                  class="size_sm btn_search"
                  label="버튼"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog
            v-model="dataDialog.btm3"
            class="dialog_btm m_change fit_contents"
          >
            <q-card class="respons_card type_form">
              <q-card-section class="pop_title_wrap">
                <q-chip dense class="chip_line"></q-chip>
                <h4 class="tit">타이틀없음</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content"> 팝업내용 </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  fill
                  unelevated
                  v-close-popup
                  color="black"
                  class="size_lg shadow w100p"
                  label="버튼"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <q-dialog v-model="dataDialog.btm4" class="dialog_btm m_change">
            <q-card class="respons_card type_form">
              <q-card-section class="pop_title_wrap">
                <q-chip dense class="chip_line"></q-chip>
                <h4 class="tit">상세 검색을 선택하세요</h4>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <!-- 검색옵션 선택 -->
                <div class="">
                  <!-- 학습선택 -->
                  <div class="serch_opt_group_custom">
                    <p class="opt_title">
                      <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      학습선택
                    </p>
                    <div class="serch_opt_group">
                      <div
                        class="opts"
                        v-for="(item, index) in searchOptGroup01Otions"
                        :key="index"
                      >
                        <q-checkbox
                          v-for="(checkItem, checkIndex) in item.group"
                          :key="checkIndex"
                          class="checkbox_button"
                          v-model="searchOptGroup01"
                          :label="checkItem.label"
                          :val="checkItem.value"
                          color="green"
                        />
                      </div>
                    </div>
                  </div>

                  <!-- 제품 -->
                  <div class="serch_opt_group_custom">
                    <p class="opt_title">
                      <q-icon name="icon-note" class="icon_svg"></q-icon> 제품
                    </p>
                    <div class="serch_opt_group">
                      <div
                        class="opts"
                        v-for="(item, index) in searchOptGroup02Otions"
                        :key="index"
                      >
                        <q-checkbox
                          v-for="(checkItem, checkIndex) in item.group"
                          :key="checkIndex"
                          class="checkbox_button"
                          v-model="searchOptGroup02"
                          :label="checkItem.label"
                          :val="checkItem.value"
                          color="green"
                        />
                      </div>
                    </div>
                  </div>

                  <!-- 학습형태 -->
                  <div class="serch_opt_group_custom">
                    <p class="opt_title">
                      <q-icon
                        name="icon-computer_graph"
                        class="icon_svg"
                      ></q-icon>
                      학습형태
                    </p>
                    <div class="serch_opt_group">
                      <div
                        class="opts"
                        v-for="(item, index) in searchOptGroup03Otions"
                        :key="index"
                      >
                        <q-checkbox
                          v-for="(checkItem, checkIndex) in item.group"
                          :key="checkIndex"
                          class="checkbox_button"
                          v-model="searchOptGroup03"
                          :label="checkItem.label"
                          :val="checkItem.value"
                          color="green"
                        />
                      </div>
                    </div>
                  </div>

                  <!-- 학습과목 -->
                  <div class="serch_opt_group_custom">
                    <p class="opt_title">
                      <q-icon name="icon-bookmark2" class="icon_svg"></q-icon>
                      학습과목
                    </p>
                    <div class="serch_opt_group">
                      <div
                        class="opts"
                        v-for="(item, index) in searchOptGroup04Otions"
                        :key="index"
                      >
                        <q-checkbox
                          v-for="(checkItem, checkIndex) in item.group"
                          :key="checkIndex"
                          class="checkbox_button"
                          v-model="searchOptGroup04"
                          :label="checkItem.label"
                          :val="checkItem.value"
                          color="green"
                        />
                      </div>
                    </div>
                  </div>

                  <!-- 가격 -->
                  <div class="serch_opt_group_custom">
                    <p class="opt_title">
                      <q-icon name="icon-card" class="icon_svg"></q-icon> 가격
                    </p>
                    <div class="serch_opt_group">
                      <div
                        class="opts"
                        v-for="(item, index) in searchOptGroup05Otions"
                        :key="index"
                      >
                        <q-checkbox
                          v-for="(checkItem, checkIndex) in item.group"
                          :key="checkIndex"
                          class="checkbox_button"
                          v-model="searchOptGroup05"
                          :label="checkItem.label"
                          :val="checkItem.value"
                          color="green"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </q-card-section>
              <q-card-actions class="dialog_actions">
                <q-btn
                  outline
                  v-close-popup
                  icon=""
                  class="size_lg btn_reset"
                  color="black"
                  label="초기화"
                />
                <q-btn
                  fill
                  unelevated
                  v-close-popup
                  color="black"
                  class="size_lg"
                  label="선택완료"
                />
              </q-card-actions>
            </q-card>
          </q-dialog>

          <!-- 장바구니 팝업 -->
          <q-dialog
            v-model="dataDialog.btm5"
            position="bottom"
            class="dialog_btm_cart"
          >
            <q-card>
              <q-card-section class="pop_title_wrap">
                <q-chip dense class="chip_line"></q-chip>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="dataDialog.btm5 = false"
                  unelevated
                  dense
                  ><b class="a11y">닫기</b></q-btn
                >
              </q-card-section>
              <q-card-section class="dialog_content">
                <p class="text-h2">김윤찬</p>
                <p class="title4 mt4">P159071234</p>
                <p class="body2 text-grey-3 mt8">강남교육국 외2</p>
                <q-separator class="mt10 mb10" />
                <p class="body2">눈높이수학 외 00개 상품이 있습니다</p>
              </q-card-section>
            </q-card>
          </q-dialog>
        </div>
      </div>
    </q-expansion-item>
    <!--// Dialogs -->
    <q-separator />

    <!-- Radio -->
    <q-expansion-item
      :default-opened="false"
      icon="radio_button_checked"
      label="인풋 라디오 / Radio"
      header-class="text-pink-8"
    >
      <q-card class="q-pa-xs bg-pink-1">
        <div class="q-pa-md">
          <q-radio
            v-model="dataRadio"
            val="positive"
            label="positive"
            color="positive"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="primary"
            label="primary"
            color="primary"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="negative"
            label="negative"
            color="negative"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="orange"
            label="orange"
            color="orange"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="warning"
            label="warning"
            color="warning"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="brown-2"
            label="brown-2"
            color="brown-2"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="grey-2"
            label="grey-2"
            color="grey-2"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
        </div>
        <q-separator />

        <div class="q-pa-md">
          <q-radio
            v-model="dataRadio"
            val="positive"
            label="selected disable"
            color="primary"
            disable
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="primary"
            label="disable"
            color="primary"
            disable
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
        </div>
        <q-separator />

        <div class="q-pa-md">
          <q-radio
            v-model="dataRadio"
            val="positive"
            label="dense첫번째"
            dense
            color="positive"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
          <q-radio
            v-model="dataRadio"
            val="primary"
            label="dense두번째"
            dense
            color="positive"
            checked-icon="trip_origin"
            unchecked-icon="radio_button_unchecked"
            class="check_to_radio"
          />
        </div>
      </q-card>
    </q-expansion-item>
    <!--// Radio -->
    <q-separator />

    <!-- checkbox -->
    <q-expansion-item
      :default-opened="false"
      icon="check_box"
      label="인풋 체크박스 / checkbox"
      header-class="text-pink-14"
    >
      <q-card class="q-pa-xs bg-pink-1">
        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-checkbox
              v-model="dataCheck.positive"
              label="positive"
              color="positive"
            />
            <q-checkbox
              v-model="dataCheck.primary"
              label="primary"
              color="primary"
            />
            <q-checkbox
              v-model="dataCheck.negative"
              label="negative"
              color="negative"
            />
            <q-checkbox
              v-model="dataCheck.orange"
              label="orange"
              color="orange"
            />
            <q-checkbox
              v-model="dataCheck.warning"
              label="warning"
              color="warning"
            />
            <q-checkbox
              v-model="dataCheck.brown"
              label="brown-2"
              color="brown-2"
            />
            <q-checkbox
              v-model="dataCheck.brown"
              label="라디오 모양 체크박스"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              class="check_to_radio"
              color="grey-2"
            />
          </div>
        </div>
        <q-separator />

        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-checkbox
              v-model="dataCheck.primary"
              label="checked disable"
              color="primary"
              disable
            />
            <q-checkbox
              v-model="dataCheck.primary2"
              label="disable"
              color="primary"
              disable
            />
          </div>
        </div>
        <q-separator />

        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-checkbox
              v-model="dataCheck.positive"
              label="dense첫번째"
              dense
              color="positive"
            />
            <q-checkbox
              v-model="dataCheck.primary"
              label="dense두번째"
              dense
              color="primary"
            />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //checkbox -->
    <q-separator />

    <!-- toggle -->
    <q-expansion-item
      :default-opened="false"
      icon="toggle_on"
      label="토글 / toggle"
      header-class="text-pink-9"
    >
      <q-card class="q-pa-xs bg-pink-1">
        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-toggle
              color="positive"
              label="positive"
              v-model="dataToggle"
              val="positive"
            />
            <q-toggle
              color="primary"
              label="primary"
              v-model="dataToggle"
              val="primary"
            />
            <q-toggle
              color="negative"
              label="negative"
              v-model="dataToggle"
              val="negative"
            />
            <q-toggle
              color="orange"
              label="orange"
              v-model="dataToggle"
              val="orange"
            />
            <q-toggle
              color="warning"
              label="warning"
              v-model="dataToggle"
              val="warning"
            />
            <q-toggle
              color="brown-2"
              label="brown-2"
              v-model="dataToggle"
              val="brown-2"
            />
            <q-toggle
              color="grey-2"
              label="grey-2"
              v-model="dataToggle"
              val="grey-2"
            />
          </div>
        </div>
        <q-separator />

        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-toggle
              color="brown-2"
              label="on disable"
              v-model="dataToggle"
              val="on"
              disable
            />
            <q-toggle
              color="brown-2"
              label="off disable"
              v-model="dataToggle"
              val="off"
              disable
            />
          </div>
        </div>
        <q-separator />

        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <q-toggle
              color="orange"
              label="dense1"
              dense
              v-model="dataToggle"
              val="orange"
            />
            <q-toggle
              color="orange"
              label="dense2"
              dense
              v-model="dataToggle"
              val="orange2"
            />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //toggle -->
    <q-separator />

    <!-- Dropdown -->
    <q-expansion-item
      :default-opened="false"
      icon="menu_open"
      label="드롭다운 세렉트 메뉴 / Dropdown"
      header-class="text-purple-9"
    >
      <q-card class="q-pa-xs bg-purple-1">
        <div class="q-pa-md">
          <h4 class="title3 text-purple-9">multiple</h4>
          <div class="w50p mb24">
            <q-select
              class="hide_label"
              label="선택하세요"
              v-model="dataSelect"
              :options="dataSelectOption"
              multiple
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
              <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
            </q-select>
          </div>
          <h4 class="title3 text-purple-9">default</h4>
          <div class="w50p mb24">
            <q-select
              class="hide_label"
              label="선택하세요"
              v-model="dataSelect"
              :options="dataSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
              <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
            </q-select>
          </div>

          <h4 class="title3 text-purple-9">error</h4>
          <div class="w50p mb24">
            <q-select
              outlined
              class="hide_label"
              label="선택하세요"
              v-model="dataSelect"
              :options="dataSelectOption"
              :rules="[
                (val, rules) => false || 'Please enter a valid email address',
              ]"
              dense
              dropdown-icon="ion-ios-arrow-down"
            >
              <template v-slot:hint> Field hint </template>
            </q-select>
          </div>

          <h4 class="title3 text-purple-9">disable</h4>
          <div class="w50p mb24">
            <q-select
              outlined
              disable
              class="hide_label"
              label="선택하세요"
              v-model="dataSelect"
              :options="dataSelectOption"
              dense
              dropdown-icon="ion-ios-arrow-down"
            ></q-select>
          </div>

          <h4 class="title3 text-purple-9">readonly</h4>
          <div class="w50p mb24">
            <q-select
              outlined
              readonly
              class="hide_label"
              label="선택하세요"
              v-model="dataSelect"
              :options="dataSelectOption"
              dense
              dropdown-icon="ion-ios-arrow-down"
            ></q-select>
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Dropdown -->
    <q-separator />

    <!-- Input Fields -->
    <q-expansion-item
      :default-opened="false"
      icon="input"
      label="인풋 필드 입력 폼 / Input Fields"
      header-class="text-deep-purple-9"
      @after-show="sampleFocus(testInput), (dataInput = '')"
    >
      <q-card class="row q-pa-xs bg-deep-purple-1">
        <div class="col q-pa-md" style="border-right: 1px dashed #aaa">
          <div class="row mb24">
            <h4 class="title1 text-deep-purple-5">하단 메시지 없는 타입</h4>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              default
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput2"
                placeholder="기본 인풋창"
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              read only
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput"
                placeholder="read only"
                dense
                readonly
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              read only style normal
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput0"
                placeholder="read only style normal"
                class="normal"
                dense
                readonly
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              focus
            </h5>
            <div class="col-8">
              <q-input
                class="hide_label"
                outlined
                ref="testInput"
                v-model="dataInput"
                label="Focus"
                stack-label
                dense
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              disable
            </h5>
            <div class="col-8">
              <q-input
                class="inp_search"
                disable
                for="test"
                outlined
                v-model="dataInput"
                label="Disable"
                dense
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              suffix
            </h5>
            <div class="col-8">
              <q-input
                class="inp_search"
                outlined
                v-model="dataInput"
                placeholder="Suffix"
                dense
                suffix="10점"
                id=""
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              icon
            </h5>
            <div class="col-8">
              <q-input
                class="inp_search"
                outlined
                dense
                placeholder="입력하세요"
              >
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              clear
            </h5>
            <div class="col-8">
              <q-input
                class="inp_search"
                outlined
                dense
                placeholder="입력하세요"
                v-model="inpClear"
              >
                <template v-slot:append v-if="inpClear !== ''">
                  <q-btn flat dense :ripple="false" class="btn_input_slot">
                    <q-icon name="icon-close" class="icon_svg" />
                  </q-btn>
                </template>
              </q-input>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              file
            </h5>
            <div class="col-8">
              <q-file
                outlined
                dense
                clearable
                v-model="dataFrom.information"
                placeholder="정보동의서를 선택"
                label="정보동의서를 선택"
                class="hide_label file_custom"
              >
                <template v-slot:after>
                  <q-btn
                    fill
                    unelevated
                    class="btn_file_select"
                    color="grey-2"
                    label="선택"
                  />
                </template>
                <template v-slot:append>
                  <q-btn flat dense :ripple="false" class="btn_input_slot">
                    <q-icon
                      v-if="dataFrom.information === null"
                      name="icon-search"
                      class="icon_svg"
                    ></q-icon>
                  </q-btn>
                </template>
              </q-file>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              file slector - type_short
            </h5>
            <div class="col-8">
              <!-- 파일 찾기 -->
              <q-file
                outlined
                dense
                clearable
                v-model="dataFrom.information"
                label=""
                class="hide_label file_custom type_short"
              >
                <template v-slot:after>
                  <q-badge color="brown-2" @click.stop>찾아보기</q-badge>
                </template>
              </q-file>
              <!-- // 파일 찾기 -->
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              input 정렬(quasar 제공) : 오른쪽
            </h5>
            <div class="col-8">
              <q-input
                class=""
                outlined
                placeholder="input-class 에 text-right"
                input-class="text-right"
              >
              </q-input>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              input 정렬(quasar 제공) : 가운데
            </h5>
            <div class="col-8">
              <q-input
                class=""
                outlined
                placeholder="input-class 에 text-center"
                input-class="text-center"
              >
              </q-input>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              input 정렬(quasar 제공) : 왼쪽
            </h5>
            <div class="col-8">
              <q-input
                class=""
                outlined
                placeholder="input-class 에 text-left"
                input-class="text-left"
              >
              </q-input>
            </div>
          </div>
        </div>

        <div class="col q-pa-md">
          <div class="row mb24">
            <h4 class="title1 text-deep-purple-5">하단 메시지 나오는 타입</h4>
          </div>
          <div class="row mb24">
            <h5 class="col-4 flex items-start title3 text-deep-purple-9">
              caption
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput"
                error
                :rules="[(val, rules) => false || '캡션 메시지 출력']"
                dense
                placeholder="캡션 인풋창"
                class="inp_caption"
              >
              </q-input>
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              Error
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput"
                placeholder="입력하면 에러메시지"
                error
                :rules="[(val, rules) => false || '에러 메시지 출력']"
                dense
                class="inp_error"
              />
            </div>
          </div>

          <div class="row mb24">
            <h5 class="col-4 flex items-center title3 text-deep-purple-9">
              success
            </h5>
            <div class="col-8">
              <q-input
                outlined
                v-model="dataInput"
                placeholder="입력하면 성공메시지"
                error
                :rules="[(val, rules) => false || '성공 메시지 출력']"
                dense
                class="inp_success"
              />
            </div>
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Input Fields -->
    <q-separator />

    <!-- Textarea -->
    <q-expansion-item
      :default-opened="false"
      icon="article"
      label="텍스트에어리어 필드 입력 폼 / TextArea"
      header-class="text-indigo-9"
    >
      <q-card class="q-pa-xs bg-indigo-1">
        <div class="q-pa-md">
          <div style="height: 100px">
            <q-input
              class="basic"
              outlined
              v-model="dataTextArea"
              placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
              type="textarea"
            >
              <template v-slot:label>메시지 내용</template>
            </q-input>
          </div>
        </div>
        <q-separator class="mt10" />
        <div class="q-pa-md">
          <p class="mb10 text-body1 text-indigo-9">readonly normal</p>
          <div style="height: 100px">
            <q-input
              class="basic normal"
              outlined
              v-model="dataTextArea"
              readonly
              placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
              type="textarea"
            >
              <template v-slot:label>메시지 내용</template>
            </q-input>
          </div>
        </div>
        <q-separator class="mt10" />

        <div class="q-pa-md">
          <p class="mb10 text-body1 text-indigo-9">
            textarea에 글자수 있는 타입 responsive.css 를 불러오면 스타일 제대로
            나옵니다
          </p>
          <!-- 내용 -->
          <div class="wrap_counsel_form">
            <div class="wrap_textarea">
              <q-input
                class="basic text-phara1"
                outlined
                v-model="dataTextArea"
                placeholder=""
                type="textarea"
              >
                <template v-slot:label>메시지 내용</template>
              </q-input>
              <div class="check_val"><span>1</span>/<span>1000자</span></div>
            </div>
          </div>
          <!-- // 내용 -->
        </div>
        <q-separator class="mt10" />

        <div class="q-pa-md">
          <p class="mb10 text-body1 text-indigo-9">
            textarea에 버튼 있는 타입 responsive.css 를 불러오면 스타일 제대로
            나옵니다
          </p>
          <!-- textarea 영역 -->
          <div class="wrap_counsel_form">
            <div class="wrap_textarea">
              <q-input
                class="basic text-phara1"
                outlined
                v-model="dataTextArea"
                placeholder="메모를 입력해주세요"
                type="textarea"
              >
              </q-input>
              <div class="btm_cont">
                <div class="btn_group">
                  <q-btn
                    class="size_sm"
                    color="grey-4"
                    fill
                    unelevated
                    label="사진촬영"
                  />
                  <q-btn
                    class="size_sm"
                    color="grey-4"
                    fill
                    unelevated
                    label="사진삽입"
                  />
                </div>
                <q-space />
                <div class="count">
                  <span class="text-black">0</span>/<span>3,000</span>
                </div>
              </div>
            </div>
          </div>
          <!-- // textarea 영역 -->
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Textarea -->
    <q-separator />

    <!-- 옵션 그룹 -->
    <q-expansion-item
      :default-opened="false"
      icon="fact_check"
      label="옵션 그룹 / Option Group"
      header-class="text-blue-9"
    >
      <q-card class="q-pa-xs" style="background-color: #f5f9fc">
        <div class="q-pa-md">
          <h4 class="q-py-sm text-blue-6">
            옵션 그룹 - 체크박스 - 디자인 커스텀 탭모양
          </h4>
          <div class="wrap_opt_group">
            <q-option-group
              class="opt_group_custom type01"
              :options="dayOption"
              type="checkbox"
              v-model="day"
            />
          </div>
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-blue-6">
            옵션 그룹 - 라디오 - 디자인 커스텀
          </h4>
          <div class="wrap_opt_radio">
            <q-option-group
              class="radio_group_custom type01"
              v-model="sendMsg"
              :options="sendMsgoptions"
            />
          </div>
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-blue-6">옵션 그룹 - 라디오</h4>
          <q-option-group
            v-model="group"
            :options="options"
            color="orange"
            inline
          />
          <q-option-group
            v-model="group"
            :options="options"
            color="grey-2"
            inline
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-blue-6">옵션 그룹 - 기본 체크 박스</h4>
          <q-option-group
            v-model="convenientOptionsGroup"
            :options="convenientOptions"
            color="brown-2"
            type="checkbox"
            inline
          />
        </div>
        <q-separator class="mt10 mb30" />

        <div class="q-pa-md">
          <h4 class="q-py-sm text-blue-6">옵션 그룹 - 토글</h4>
          추가
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //옵션 그룹 -->
    <q-separator />

    <!-- BUTTON -->
    <q-expansion-item
      :default-opened="false"
      icon="smart_button"
      label="버튼 / Button"
      header-class="text-light-blue-9"
    >
      <q-card class="q-pa-xs" style="background-color: #f5f9fc">
        <div class="q-pa-md">
          <p class="title3 mb30 text-pink-13">
            📌 q-btn의 리플 기능을 없애려면 q-btn tag 내에 :ripple="false"를
            넣으면 됩니다.
          </p>

          <!-- size_xxs -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_xxs(20px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_xxs" label="20" /> <span>xxs 20</span>
            <q-btn outline class="size_xxs circle" label=""
              ><q-icon name="icon-plus-grey" class="icon_svg"></q-icon
            ></q-btn>
            <span>xxs 20 circle</span>
            <q-btn outline class="size_xxs no_line" :ripple="false">
              <q-icon name="icon-trash-grey" class="icon_svg"></q-icon>
            </q-btn>
            <span>xxs 20 no_line</span>
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_xs -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_xs(32px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_xs" label="size_xs outline 32" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_xs"
              label="size_xs fill 32"
            />
            <q-btn
              outline
              class="size_xs btn_inner_table"
              label="q-table 내에 사용(배경색 신규일 경우 class 생성 필요) size_xs outline 32"
            />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_xs btn_inner_table"
              label="q-table 내에 사용 size_xs fill 32"
            />
            <q-btn class="size_xs btn_add_img" icon="" outline />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_sm -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_sm(40px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_sm" label="size_sm Outline 40" />
            <q-btn
              fill
              unelevated
              color="grey-2"
              class="size_sm"
              label="size_sm fill 40"
            />
            <q-btn class="size_sm shadow" unelevated label="size_sm shadow" />

            <q-btn fill unelevated class="size_sm btn_search" label="조회" />
            <q-btn outline class="size_sm btn_reset" icon="" label="초기화" />
            <q-btn
              icon=""
              class="size_sm btn_reset"
              unelevated
              fill
              label="초기화"
            />
            <q-btn
              outline
              class="size_sm btn_reset"
              icon=""
              label="전체 초기화"
            />
            <q-btn outline class="size_sm btn_row_add" icon="" label="행추가" />
            <q-btn fill unelevated class="size_sm btn_cancel" label="취소" />
            <q-btn fill unelevated class="size_sm btn_save" label="저장" />
            <q-btn
              class="size_sm btn_delete"
              outline
              icon=""
              label="선택삭제"
            />
            <q-btn class="size_sm btn_edit" outline icon="" label="선택삭제" />
            <q-btn class="size_sm btn_write" outline icon="" label="신규등록" />
            <q-btn
              fill
              unelevated
              class="size_sm btn_folder_add"
              color="black"
              icon=""
              label="폴더추가"
            />
            <q-btn class="size_sm btn_folder_modify" outline label="폴더수정" />
            <q-btn class="size_sm btn_folder_delete" outline label="폴더삭제" />
            <q-btn class="size_sm btn_excel" outline icon="" label="엑셀" />
            <q-btn class="size_sm btn_excel" outline icon="" label="엑셀" />
            <q-btn outline class="size_sm btn_search_m" icon="" label="검색" />
            <q-btn
              fill
              unelevated
              color="brown-2"
              class="size_sm btn_search_m"
              icon=""
              label="검색"
            />
            <q-btn
              class="size_sm btn_select_print"
              outline
              icon=""
              label="선택인쇄"
            />
            <q-btn
              class="size_sm btn_schedule"
              outline
              icon=""
              label="일정등록"
            />
            <q-btn class="size_sm btn_down" outline icon="" label="다운로드" />
            <q-btn
              fill
              unelevated
              icon=""
              color="grey-3"
              class="size_sm btn_down_white"
              label="Sample Download"
            />
            <q-btn class="size_sm btn_print" outline icon="" label="인쇄" />
            <q-btn
              class="size_sm btn_row_up"
              icon="keyboard_arrow_up"
              outline
              label=""
            />
            <q-btn
              class="size_sm btn_row_down"
              color="grey-7"
              icon="keyboard_arrow_down"
              outline
              label=""
            />
            <q-btn
              class="size_sm btn_row_up"
              icon="keyboard_arrow_left"
              outline
              label=""
            />
            <q-btn
              class="size_sm btn_row_down"
              color="grey-7"
              icon="keyboard_arrow_right"
              outline
              label=""
            />
            <q-btn
              outline
              class="size_sm btn_thumbUp"
              icon=""
              label="추천해요"
            />
            <q-btn
              outline
              class="size_sm btn_thumbDown"
              icon=""
              label="아쉬워요"
            />
            <q-btn outline class="size_sm upper" label="size_sm 대문자 upper" />
            <q-btn outline class="size_sm" label="size_sm 소문자" />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_md -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_md(44px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_md" label="size_md Outline 44" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_md"
              label="size_md fill 44"
            />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_lg -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_lg(48px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_lg" label="size_lg Outline 48" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_lg"
              label="size_lg fill 48"
            />
            <q-btn class="size_lg" label="size_lg Outline Shadow 48" />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_lg_rounded -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_lg_rounded</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline rounded color="grey-06" class="size_lg_rounded mt20">
              <div class="left">
                <span class="text-grey-3"> size_lg_rounded</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
              </div>
            </q-btn>
            <q-btn
              outline
              rounded
              color="grey-06"
              class="size_lg_rounded shadow mt20"
            >
              <div class="left">
                <span class="text-grey-3">size_lg_rounded shadow</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
              </div>
            </q-btn>
            <q-btn rounded color="green-2" class="size_lg_rounded shadow mt20">
              <div class="left">
                <span class="text-white">fill type</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-white" class="icon_svg"></q-icon>
              </div>
            </q-btn>
          </div>
          <q-separator class="mt10 mb30" />
          <!-- size_xl -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_xl(52px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_xl" label="size_xl Outline 52" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_xl"
              label="size_xl fill 52"
            />
            <q-btn outline class="size_xl shadow" label="size_xl shadow" />
            <q-btn outline class="size_xl title1" label="size_xl title1" />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_xxl -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_xxl(58px)</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_xxl" label="size_xxl Outline 58" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_xxl"
              label="size_xxl fill 58"
            />
            <q-btn outline class="size_xxl shadow" label="size_xxl shadow" />
            <q-btn outline class="size_xxl title1" label="size_xxl title1" />
            <q-btn
              unelevated
              class="size_xxl text-grey-1"
              color="white"
              label="size_xxl text-grey-1"
            />
            <q-btn
              unelevated
              class="size_xxl text-grey-1"
              color="white"
              label="size_xxl text-grey-1"
            >
              <q-icon
                name="icon-arrow-right"
                class="icon_svg ml8 filter-grey-3"
              ></q-icon>
            </q-btn>
            <q-btn
              unelevated
              class="size_xxl text-grey-1"
              color="white"
              label="버튼명이 길어질때 말줄임 처리됩니다 모바일에서 확인하세요"
            >
              <q-icon
                name="icon-arrow-right"
                class="icon_svg ml8 filter-grey-3"
              ></q-icon>
            </q-btn>
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_big -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_big</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline class="size_big" label="size_big" />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_big"
              label="size_big"
            />
            <q-btn
              class="size_big btn_quick_open"
              stack
              fill
              unelevated
              icon=""
              color="positive"
              label="바로가기"
            />
            <q-btn
              class="size_big btn_quick_close"
              stack
              fill
              unelevated
              icon=""
              color="positive"
              label="닫기"
            />
            <q-btn
              class="size_big btn_quick_edit"
              stack
              fill
              unelevated
              icon=""
              color="black"
              label="편집"
            />
            <q-btn
              class="size_big btn_quick_lms"
              stack
              fill
              unelevated
              icon=""
              color="black"
              label="lms"
            />
            <q-btn
              class="size_big btn_quick_attendance"
              stack
              fill
              unelevated
              icon=""
              color="black"
              label="출결"
            />
            <q-btn
              class="size_big btn_quick_content"
              stack
              fill
              unelevated
              icon=""
              color="black"
              label="콘텐츠"
            />
            <q-btn
              class="size_big btn_quick_new"
              stack
              fill
              unelevated
              icon=""
              color="black"
              label="새버튼"
            />
          </div>
          <q-separator class="mt10 mb30" />

          <!-- size_box -->
          <h4 class="q-py-sm text-light-blue-6 mt20">size_box</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn
              outline
              class="size_box experience_join"
              icon-right=""
              align="left"
              label="size_box"
            />
            <q-btn
              fill
              unelevated
              color="primary"
              class="size_box experience_join"
              icon-right=""
              align="left"
              label="size_box"
            />
            <q-btn outline class="size_box experience_join">
              <span>size_box<br />2번째줄 내용 </span>
              <q-icon right name="" />
            </q-btn>
            <q-btn
              fill
              unelevated
              color="deep-orange"
              class="size_box experience_join"
            >
              <span> 체험<br />입회 </span>
              <q-icon right name="" />
            </q-btn>
          </div>
          <q-separator class="mt10 mb30" />

          <!-- circle -->
          <h4 class="q-py-sm text-light-blue-6 mt20">circle</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn
              fill
              unelevated
              color="grey-5"
              class="btn_circle"
              label="circle"
            >
              <q-icon name="icon-user-white" class="icon_svg"></q-icon>
            </q-btn>
            <q-btn
              fill
              unelevated
              color="grey-5"
              class="btn_circle32"
              label="circle"
            >
              <q-icon name="icon-user-white" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <q-separator class="mt10 mb30" />

          <!-- 기타 -->
          <h4 class="q-py-sm text-light-blue-6 mt20">기타</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn
              align="between"
              fill
              unelevated
              color="positive"
              class="size_lg btn_shop_basket full-width"
            >
              <div class="left">
                <q-icon left name="" />
                <span>학습바구니</span>
              </div>
              <div class="right">
                <span>2개 제품이 있어요</span>
                <q-icon right name="" />
              </div>
            </q-btn>
            <q-btn class="btn_add_contents" />
            <q-btn class="btn_record" label="녹취" :ripple="false" />
            <q-btn class="btn_record on" label="녹취" :ripple="false" />
            (a 태그로 된 녹취 클릭 영역은 a030102 파일에 있습니다.)
          </div>
          <q-separator class="mt10 mb30" />

          <!-- 반응형 하단 버튼 -->
          <h4 class="q-py-sm text-light-blue-6 mt20">반응형 하단 버튼</h4>
          <div class="btn_area response">
            <q-btn
              unelevated
              color="grey-4"
              class="size_md btn_cancel"
              label="취소"
            />
            <q-btn
              unelevated
              color="primary"
              class="size_md btn_save"
              label="저장"
            />
            <q-btn
              unelevated
              color="grey-2"
              class="size_lg btn_position_end"
              label="목록"
            />
          </div>
          <q-separator class="mt10 mb30" />

          <h4 class="q-py-sm text-light-blue-6 mt20">
            아웃라인 없고 아이콘 있는 버튼
          </h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn unelevated class="btn_all_read" dense>
              <q-icon name="icon-check-grey" class="icon_svg" />
              <span class="body2 text-grey-3">모두 읽음 처리</span>
            </q-btn>
          </div>
          <q-separator class="mt10 mb30" />

          <h4 class="q-py-sm text-light-blue-6 mt20">파일삭제 버튼</h4>
          <div class="row q-py-sm q-gutter-sm">
            <q-btn outline type="button" class="del_file"> file.zip </q-btn>
          </div>
          <q-separator class="mt10 mb30" />

          <h4 class="q-py-sm text-light-blue-6 mt20">추가</h4>
          <div class="row q-py-sm q-gutter-sm"></div>
        </div>
      </q-card>
    </q-expansion-item>
    <!--// BUTTON -->
    <q-separator />

    <!-- 검색창 -->
    <q-expansion-item
      :default-opened="false"
      icon="search"
      header-class="text-cyan-9"
      label="테이블 검색 검색창 / Search Table"
    >
      <q-card class="q-pa-xs" style="background-color: #f0f9fa">
        <div class="q-pa-md">
          <h4 class="q-py-sm text-cyan-9">
            table_search_area type_01 : 가로 100%
          </h4>
          <!-- table_search_area type_01 -->
          <div class="table_search_area type_01">
            <div class="input_area">
              <q-select
                class="box_m hide_label"
                label="선택하세요"
                v-model="sysSelect"
                :options="sysSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
                :class="[sysSelect == 0 ? 'placehoder' : '']"
              >
              </q-select>
              <q-select
                class="box_m hide_label"
                label="선택하세요"
                v-model="dataSelect"
                :options="dataSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
                :class="[dataSelect == 0 ? 'placehoder' : '']"
              >
              </q-select>
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword"
                placeholder="코드 or 코드명을 입력하세요"
              />
            </div>
            <div class="btn_area">
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
              <q-btn icon="" class="size_sm btn_reset" outline label="초기화" />
            </div>
          </div>
          <!--// table_search_area type_01 -->
          <q-separator class="mt60 mb60" style="height: 0" />

          <h4 class="q-py-sm text-cyan-9">
            table_search_area type_01 no_border : 가로 100% 상하단 보더 없는
          </h4>
          <!-- table_search_area type_01 no_border -->
          <div class="table_search_area type_01 no_border">
            <div class="input_area">
              <q-input
                class="inp_search full-width"
                outlined
                dense
                placeholder="회원 이름, 초성으로 검색"
              >
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
            <div class="btn_area ml16">
              <q-btn
                unelevated
                dense
                color="black"
                class="size_sm btn_mem_search"
              >
                <q-icon
                  name="icon-settings-sliders"
                  class="icon_svg filter-white"
                  size="22px"
                ></q-icon>
              </q-btn>
            </div>
          </div>
          <!--// table_search_area type_01 no_border -->
          <q-separator class="mt60 mb60" style="height: 0" />

          <h4 class="q-py-sm text-cyan-9">
            H에서 사용 table_search_area type_02 : 왼쪽정렬 자동 줄바꿈
            <small>(줄바꿈할 위치에 line_break 요소 추가시 내려감)</small>
          </h4>
          <p class="mb30">
            여기에 있는
            <span class="text-orange"
              >searchDate ~ searchDate는 반응형이 아니니</span
            >
            H에서만 사용하시면 됩니다. G에서는 아래 반응형 버전을 사용하세요.
          </p>
          <!-- table_search_area type_02 -->
          <div class="table_search_area type_02">
            <div class="search_item">
              <!-- <h4 class="q-py-sm text-blue-grey-6">메시지명</h4> -->
              <q-input
                class="inp_msg_name"
                outlined
                v-model="msg_name"
                placeholder="메시지명을 입력하세요"
              />
            </div>
            <div class="search_item">
              <!-- <h4 class="q-py-sm text-blue-grey-6">등록자</h4> -->
              <q-input
                class="inp_author"
                outlined
                v-model="author"
                placeholder="등록자를 입력하세요"
              />
            </div>
            <div class="search_item">
              <!-- <h4 class="q-py-sm text-blue-grey-6">사용여부</h4> -->
              <q-select
                class="inp_use hide_label"
                v-model="searchUseSelected"
                :options="searchSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                label="사용여부를 선택하세요"
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="search_item">
              <!-- <h4 class="q-py-sm text-blue-grey-6">구분</h4> -->
              <q-select
                class="inp_msg_type hide_label"
                label="선택하세요"
                v-model="searchSelectChoice"
                :options="searchSelectChoiceOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <!-- <div class="line_break"></div> -->
            <div class="search_item wrap_date">
              <!-- <h4 class="q-py-sm text-blue-grey-6">일자</h4> -->
              <div class="inner_wrap">
                <!-- searchDate start.from -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!--// searchDate start.from -->
                <div class="tilde">
                  <span>~</span>
                </div>
                <!-- searchDate start.to -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyto"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          v-model="searchDate.to"
                          mask="YYYY.MM.DD"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyto.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!--// searchDate start.to -->
              </div>
            </div>
            <div class="search_item">
              <!-- searchDate start.fromto -->
              <q-input
                outlined
                :model-value="searchDate.from + '~' + searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate"
                        range
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <!--// searchDate start.fromto -->
            </div>
            <div class="btn_area">
              <q-btn fill unelevated class="size_sm btn_search" label="조회" />
              <q-btn class="size_sm btn_reset" icon="" outline label="초기화" />
            </div>
          </div>
          <!--// table_search_area type_02 -->
          <q-separator class="mt60 mb60" style="height: 0" />

          <h4 class="q-py-sm text-cyan-9">
            G에서 사용 table_search_area type_flexable : 반응형
            <small>(줄바꿈할 위치에 line_break 요소 추가시 내려감)</small>
          </h4>
          <p class="mb30">
            퍼블 가이드에서 responsive.scss파일을 불러오지 못해 화면이 제대로
            나오지 않습니다. 페이지 내에서는 정상으로 나옵니다.
          </p>
          <!-- table_search_area type_flexable -->
          <div class="table_search_area type_flexable">
            <div class="search_hide" v-if="searchExpand">
              <div class="search_item">
                <q-input
                  v-model="readonlyInput1"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item">
                <q-input
                  v-model="readonlyInput2"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item">
                <q-input
                  v-model="readonlyInput3"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item">
                <q-input
                  v-model="readonlyInput4"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item">
                <q-input
                  v-model="readonlyInput5"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item">
                <q-input
                  v-model="readonlyInput6"
                  class="box_m normal"
                  outlined
                  readonly
                />
              </div>
              <div class="search_item btn_area right">
                <q-btn
                  fill
                  unelevated
                  color="grey-3"
                  class="size_sm btn_search_m"
                  icon=""
                  label="검색"
                />
              </div>
              <!-- 줄바꿈 -->
              <div class="line_break"></div>
              <!-- date -->
              <div class="search_item">
                <div class="row-4">
                  <!-- 달력 인풋 -->
                  <q-input
                    outlined
                    v-model="searchDate.from"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.from"
                            @update:model-value="
                              searchDate.from, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!-- // 달력 인풋 -->
                  <span class="text-body2">~</span>
                  <!-- 달력 인풋 -->
                  <q-input
                    outlined
                    v-model="searchDate.to"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyTo"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.to"
                            @update:model-value="
                              searchDate.to, $refs.qDateProxyTo.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!-- // 달력 인풋 -->
                </div>
              </div>
              <!-- // date -->
              <!-- select -->
              <div class="search_item">
                <q-select
                  class="box_l"
                  v-model="dataFrom.state"
                  :options="stateSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <!-- // select -->
              <!-- 줄바꿈 -->
              <div class="line_break"></div>

              <div class="search_item">
                <q-input
                  class="box_l"
                  for=""
                  outlined
                  dense
                  v-model="keyword"
                  placeholder="주문자명을 입력하세요"
                />
              </div>
              <div class="search_item">
                <q-input
                  class="box_m"
                  outlined
                  dense
                  placeholder="이름을 입력하여 검색하세요"
                  v-model="keyword2"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="search_item mr20">
                <q-checkbox
                  v-model="dataCheck.gsearch"
                  label="교육지원비 적용"
                  color="grey-2"
                />
              </div>
              <div class="search_item btn_area">
                <q-btn
                  class="size_sm btn_reset"
                  icon=""
                  outline
                  label="초기화"
                />
                <q-btn
                  fill
                  unelevated
                  class="size_sm btn_search"
                  label="조회"
                />
              </div>
            </div>
            <div class="search_expand">
              <q-btn
                class="size_sm btn_contract"
                v-if="searchExpand"
                fill
                unelevated
                icon=""
                label="검색 닫기"
                @click="searchExpand = false"
              />
              <q-btn
                class="size_sm btn_expand"
                v-else
                fill
                unelevated
                icon=""
                label="검색 펼치기"
                @click="searchExpand = true"
              />
            </div>
          </div>
          <!--// table_search_area type_flexable -->
          <h5 class="q-py-sm text-cyan-9 title3 mt20">
            2등분(.box_half), 4등분(.box_quartering), 5등분(.box_20p),
            6등분(.box_divide6)
          </h5>
          <p class="mb30">
            4등분 search_item은 table_search_area 안에 4개, 5등분은 5개, 6등분은
            6개 넣어서 사용하면 됩니다.
            <br />
            맨 마지막 search_item에는 우측 여백이 0이 되기 설정해두었습니다.
            <br />
            각 클래스는 단독으로 사용 가능합니다.
          </p>
          <!-- table_search_area type_flexable -->
          <div class="table_search_area type_flexable">
            <div class="search_hide" v-if="searchExpand">
              <!-- select -->
              <div class="search_item box_quartering">
                <q-select
                  class="hide_label"
                  label="경기본부"
                  v-model="dataFrom.state"
                  :options="stateSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                  readonly
                >
                </q-select>
              </div>
              <!-- // select -->
              <!-- select -->
              <div class="search_item box_quartering">
                <q-select
                  class="hide_label"
                  label="경기병점교육국"
                  v-model="dataFrom.state"
                  :options="stateSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                  readonly
                >
                </q-select>
              </div>
              <!-- // select -->
              <!-- select -->
              <div class="search_item box_quartering">
                <q-select
                  class="hide_label"
                  label="팀 전체"
                  v-model="dataFrom.state"
                  :options="stateSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <!-- // select -->
              <!-- select -->
              <div class="search_item box_quartering">
                <q-select
                  class="hide_label"
                  label="채널 전체"
                  v-model="dataFrom.state"
                  :options="stateSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <!-- // select -->
              <!-- 줄바꿈 -->
              <div class="line_break"></div>

              <div class="search_item box_half">
                <q-input
                  v-model="keyword"
                  class=""
                  outlined
                  dense
                  placeholder="이름, 회원번호 검색"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="search_item btn_area">
                <q-btn
                  class="size_sm btn_reset"
                  icon=""
                  outline
                  label="초기화"
                />
                <q-btn
                  fill
                  unelevated
                  class="size_sm btn_search"
                  label="조회"
                />
              </div>
            </div>
            <div class="search_expand">
              <q-btn
                class="size_sm btn_contract"
                v-if="searchExpand"
                fill
                unelevated
                icon=""
                label="검색 닫기"
                @click="searchExpand = false"
              />
              <q-btn
                class="size_sm btn_expand"
                v-else
                fill
                unelevated
                icon=""
                label="검색 펼치기"
                @click="searchExpand = true"
              />
            </div>
          </div>
          <!--// table_search_area type_flexable -->
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //검색창 -->
    <q-separator />

    <!-- 탭 -->
    <q-expansion-item
      :default-opened="false"
      icon="tab"
      label="탭 / Tab"
      header-class="text-teal-9"
    >
      <q-card class="q-pa-xs" style="background-color: #eff5f5">
        <div class="q-pa-md">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              dense
              class="tab_basic"
              active-bg-color="primary"
              active-color="white"
              indicator-color="transparent"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="upper" label="기본탭" :ripple="false" />
              <q-tab name="downer" label="기본탭" :ripple="false" />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="upper"> 내용1 </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="downer"> 내용2 </q-tab-panel>
              <!--// tab2 컨텐츠 -->
            </q-tab-panels>
          </div>
        </div>
        <div class="q-pa-md">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              dense
              class="tab_round"
              active-bg-color="black"
              active-color="white"
              indicator-color="transparent"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="upper" label="라운드 검색탭" :ripple="false" />
              <q-tab name="downer" label="라운드 검색탭" :ripple="false" />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="upper"> 라운드 내용1 </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="downer"> 라운드 내용2 </q-tab-panel>
              <!--// tab2 컨텐츠 -->
            </q-tab-panels>
          </div>
        </div>
        <div class="q-pa-md">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              dense
              inline-label
              class="tab_box"
              active-bg-color="beige02"
              active-color="brown"
              indicator-color="transparent"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab
                name="upper"
                label="체크박스 검색탭"
                :ripple="false"
                icon="check"
              />
              <q-tab
                name="downer"
                label="체크박스 검색탭"
                :ripple="false"
                icon="check"
              />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="upper"> 체크박스 내용1 </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="downer">
                <!-- wrap_table_divide -->
                체크박스 내용2
              </q-tab-panel>
              <!--// tab2 컨텐츠 -->
            </q-tab-panels>
          </div>
        </div>
        <div class="q-pa-md">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              inline-label
              class="tab_line"
              active-bg-color="white"
              active-color="primary"
              indicator-color="primary"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="upper" label="하단라인 탭1" :ripple="false" />
              <q-tab name="tab2" label="하단라인 탭2" :ripple="false" />
              <q-tab name="tab3" label="하단라인 탭3" :ripple="false" />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="upper">하단라인 내용1 </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="tab2"> 하단라인 내용2 </q-tab-panel>
              <!--// tab2 컨텐츠 -->
              <!-- tab3 컨텐츠 -->
              <q-tab-panel name="tab3"> 하단라인 내용3 </q-tab-panel>
              <!--// tab3 컨텐츠 -->
            </q-tab-panels>
          </div>
        </div>

        <div class="q-pa-md">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              inline-label
              class="tab_line type02 type_fix"
              active-bg-color="white"
              active-color="primary"
              indicator-color="primary"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab
                name="upper"
                label="상하단라인 좌측여백 fix 탭1"
                :ripple="false"
              />
              <q-tab
                name="tab2"
                label="상하단라인 좌측여백 fix 탭2"
                :ripple="false"
              />
              <q-tab
                name="tab3"
                label="상하단라인 좌측여백 fix 탭3"
                :ripple="false"
              />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="upper"
                >상하단라인 좌측여백 fix 내용1
              </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="tab2">
                상하단라인 좌측여백 fix 내용2
              </q-tab-panel>
              <!--// tab2 컨텐츠 -->
              <!-- tab3 컨텐츠 -->
              <q-tab-panel name="tab3">
                상하단라인 좌측여백 fix 내용3
              </q-tab-panel>
              <!--// tab3 컨텐츠 -->
            </q-tab-panels>
          </div>
        </div>

        <div class="q-pa-md">
          <div class="wrap_table_box type_tab">
            <div class="wrapper_tab">
              <q-tabs
                v-model="tab"
                inline-label
                class="tab_line type_fix"
                active-bg-color="white"
                active-color="primary"
                indicator-color="primary"
                align="justify"
                narrow-indicator
                outside-arrows
              >
                <q-tab name="upper" label="AS관리" :ripple="false" />
                <q-tab name="tab2" label="배송관리" :ripple="false" />
              </q-tabs>
              <q-tab-panels v-model="tab" animated>
                <!-- tab1 컨텐츠 -->
                <q-tab-panel name="upper">
                  wrap_table_box 박스 안에 들어가는 하단라인 탭
                </q-tab-panel>
                <!--// tab1 컨텐츠 -->

                <!-- tab2 컨텐츠 -->
                <q-tab-panel name="tab2">
                  wrap_table_box 박스 안에 들어가는 하단라인 탭 2
                </q-tab-panel>
                <!--// tab2 컨텐츠 -->
              </q-tab-panels>
            </div>
          </div>
        </div>

        <div class="q-pa-md">
          <div class="wrapper_tab">
            <!-- wrap_multi_tab -->
            <div class="wrap_multi_tab">
              <q-tabs
                v-model="tab"
                class="col4"
                active-color="positive"
                indicator-color="positive"
                align="justify"
                narrow-indicator
                outside-arrows
              >
                <q-tab name="upper" label="회원정보" />
                <q-tab name="tab2" label="학습현황" />
                <q-tab name="tab3" label="회비현황" />
                <q-tab name="tab4" label="이력관리" />
              </q-tabs>

              <q-separator />
            </div>
            <!--// wrap_multi_tab -->
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //탭 -->
    <q-separator />

    <!-- 아이콘 -->
    <q-expansion-item
      :default-opened="false"
      icon="mood"
      label="아이콘(매터리얼, 아이온) / Icon"
      header-class="text-green-8"
    >
      <q-card class="q-pa-xs bg-green-1">
        <q-card-section class="q-pa-md">
          <h4 class="q-py-sm text-green-6 mt20">
            1. Material Icons
            <a
              class="text-body2"
              target="_blank"
              href="https://fonts.google.com/icons?icon.set=Material+Icons&icon.platform=web"
              >[Material Icons로 이동]</a
            >
          </h4>
          <div class="text-primary q-gutter-md" style="font-size: 32px">
            <q-icon color="negative" name="search"></q-icon>
            <q-icon color="yellow" name="home"></q-icon>
            <q-icon color="positive" name="settings"></q-icon>
            <q-icon color="primary" name="more_vert"></q-icon>
            <q-icon color="negative" name="settings"></q-icon>
            <q-icon color="grey-10" name="menu"></q-icon>
            <q-icon color="grey-1" name="refresh"></q-icon>
            <q-icon color="grey-2" name="close"></q-icon>
          </div>
        </q-card-section>
        <q-card-section class="q-pa-md">
          <h4 class="q-py-sm text-green-6 mt20">
            2.Ion Icons
            <a
              class="text-body2"
              target="_blank"
              href="https://ionic.io/ionicons/v4"
              >[Ion Icons로 이동]</a
            >
          </h4>
          <div class="text-primary q-gutter-md" style="font-size: 32px">
            <q-icon color="negative" name="ion-ios-search"></q-icon>
            <q-icon color="yellow" name="ion-ios-home"></q-icon>
            <q-icon color="positive" name="ion-ios-settings"></q-icon>
            <q-icon color="primary" name="ion-ios-more"></q-icon>
            <q-icon color="negative" name="ion-ios-settings"></q-icon>
            <q-icon color="grey-10" name="ion-ios-menu"></q-icon>
            <q-icon color="grey-1" name="ion-ios-more"></q-icon>
            <q-icon color="grey-2" name="ion-ios-close"></q-icon>
          </div>
        </q-card-section>
        <q-card-section class="q-pa-md">
          <h4 class="q-py-sm text-green-6 mt20">3.svg Icons</h4>
          <div class="text-primary q-gutter-sm q-py-sm" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg"></q-icon>
            <q-icon name="icon-home" class="icon_svg"></q-icon>
            <q-icon name="icon-chat" class="icon_svg"></q-icon>
            <q-icon name="icon-study" class="icon_svg"></q-icon>
            <q-icon name="icon-search" class="icon_svg"></q-icon>
            <q-icon name="icon-layers" class="icon_svg"></q-icon>
            <q-icon name="icon-community" class="icon_svg"></q-icon>
            <q-icon name="icon-group" class="icon_svg"></q-icon>
            <q-icon name="icon-me" class="icon_svg"></q-icon>
            <q-icon name="icon-chart" class="icon_svg"></q-icon>
            <q-icon name="icon-info" class="icon_svg"></q-icon>
            <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-schedule" class="icon_svg"></q-icon>
            <q-icon name="icon-calendar" class="icon_svg"></q-icon>
            <q-icon name="icon-subtitles" class="icon_svg"></q-icon>
            <q-icon name="icon-photo" class="icon_svg"></q-icon>
            <q-icon name="icon-xl" class="icon_svg"></q-icon>
            <q-icon name="icon-excel-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-edit" class="icon_svg"></q-icon>
            <q-icon name="icon-delete" class="icon_svg"></q-icon>
            <q-icon name="icon-printing" class="icon_svg"></q-icon>
            <q-icon name="icon-rotate" class="icon_svg"></q-icon>
            <q-icon name="icon-close" class="icon_svg"></q-icon>
            <q-icon name="icon-check" class="icon_svg"></q-icon>
            <q-icon name="icon-check-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-right" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-left" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-up" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-up-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-down" class="icon_svg"></q-icon>
            <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-add" class="icon_svg"></q-icon>
            <q-icon name="icon-minus" class="icon_svg"></q-icon>
            <q-icon name="icon-external-link" class="icon_svg"></q-icon>
            <q-icon name="icon-document-check" class="icon_svg"></q-icon>
            <q-icon name="icon-favorite" class="icon_svg"></q-icon>
          </div>
          <div class="text-primary q-gutter-sm q-py-sm" style="font-size: 24px">
            <q-icon name="icon-class-calendar" class="icon_svg"></q-icon>
            <q-icon name="icon-menu" class="icon_svg"></q-icon>
            <q-icon name="icon-app-add" class="icon_svg"></q-icon>
            <q-icon name="icon-bookmark" class="icon_svg"></q-icon>
            <q-icon name="icon-time-check" class="icon_svg"></q-icon>
            <q-icon name="icon-folder_add" class="icon_svg"></q-icon>
            <q-icon name="icon-graduation" class="icon_svg"></q-icon>
            <q-icon name="icon-clipboard" class="icon_svg"></q-icon>
            <q-icon name="icon-card" class="icon_svg"></q-icon>
            <q-icon name="icon-computer" class="icon_svg"></q-icon>
            <q-icon name="icon-search-alt" class="icon_svg"></q-icon>
            <q-icon name="icon-coin" class="icon_svg"></q-icon>
            <q-icon name="icon-graph" class="icon_svg"></q-icon>
            <q-icon name="icon-id" class="icon_svg"></q-icon>
            <q-icon name="icon-hand" class="icon_svg"></q-icon>
            <q-icon name="icon-cake" class="icon_svg"></q-icon>
            <q-icon name="icon-map" class="icon_svg"></q-icon>
            <q-icon name="icon-mail" class="icon_svg"></q-icon>
            <q-icon name="icon-mail-white" class="icon_svg"></q-icon>
            <q-icon name="icon-back" class="icon_svg"></q-icon>
            <q-icon name="icon-book-alt" class="icon_svg"></q-icon>
            <q-icon name="icon-book-alt-black" class="icon_svg"></q-icon>
            <q-icon name="icon-note" class="icon_svg"></q-icon>
            <q-icon name="icon-chevron_left" class="icon_svg"></q-icon>
            <q-icon name="icon-chevron_right" class="icon_svg"></q-icon>
            <q-icon name="icon-chevron_up" class="icon_svg"></q-icon>
            <q-icon name="icon-chevron_down" class="icon_svg"></q-icon>
            <q-icon name="icon-user_outline" class="icon_svg"></q-icon>
            <q-icon name="icon-lock_outline" class="icon_svg"></q-icon>
            <q-icon name="icon-question" class="icon_svg"></q-icon>
            <q-icon name="icon-smile" class="icon_svg"></q-icon>
            <q-icon name="icon-smile-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-sad" class="icon_svg"></q-icon>
            <q-icon name="icon-up" class="icon_svg"></q-icon>
            <q-icon name="icon-shopping_cart" class="icon_svg"></q-icon>
            <q-icon name="icon-print" class="icon_svg"></q-icon>
            <q-icon name="icon-tooltip2" class="icon_svg"></q-icon>
            <q-icon name="icon-tooltip2-grey" class="icon_svg"></q-icon>
          </div>
          <div class="text-primary q-gutter-sm q-py-sm" style="font-size: 24px">
            <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
            <q-icon name="icon-user_add" class="icon_svg"></q-icon>
            <q-icon name="icon-user_add-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-user_add-green" class="icon_svg"></q-icon>
            <q-icon name="icon-message" class="icon_svg"></q-icon>
            <q-icon name="icon-user" class="icon_svg"></q-icon>
            <q-icon name="icon-write" class="icon_svg"></q-icon>
            <q-icon name="icon-book" class="icon_svg"></q-icon>
            <q-icon name="icon-edit_square" class="icon_svg"></q-icon>
            <q-icon name="icon-plus" class="icon_svg"></q-icon>
            <q-icon name="icon-plus-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-circle-minus-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-plus_square" class="icon_svg"></q-icon>
            <q-icon name="icon-computer_graph" class="icon_svg"></q-icon>
            <q-icon name="icon-bookmark2" class="icon_svg"></q-icon>
            <q-icon name="icon-call" class="icon_svg"></q-icon>
            <q-icon name="icon-settings-sliders" class="icon_svg"></q-icon>
            <q-icon name="icon-document" class="icon_svg"></q-icon>
            <q-icon name="icon-folder" class="icon_svg"></q-icon>
            <q-icon name="icon-download" class="icon_svg"></q-icon>
            <q-icon name="icon-download-white" class="icon_svg"></q-icon>
            <q-icon name="icon-link" class="icon_svg"></q-icon>
            <q-icon name="icon-info02" class="icon_svg"></q-icon>
            <q-icon name="icon-profile_icon" class="icon_svg"></q-icon>
            <q-icon name="icon-Dot" class="icon_svg"></q-icon>
            <q-icon name="icon-Moniter" class="icon_svg"></q-icon>
            <q-icon name="icon-admin" class="icon_svg"></q-icon>
            <q-icon name="icon-time_past" class="icon_svg"></q-icon>
            <q-icon name="icon-user-info" class="icon_svg"></q-icon>
            <q-icon name="icon-file" class="icon_svg"></q-icon>
            <q-icon name="icon-file-2" class="icon_svg"></q-icon>
            <q-icon name="icon-pay" class="icon_svg"></q-icon>
            <q-icon name="icon-lock" class="icon_svg"></q-icon>
            <q-icon name="icon-login-user" class="icon_svg"></q-icon>
            <q-icon name="icon-close_m" class="icon_svg"></q-icon>
            <q-icon name="icon-search_m" class="icon_svg"></q-icon>
            <q-icon name="icon-search" class="icon_svg"></q-icon>
            <q-icon name="icon-user_check" class="icon_svg"></q-icon>
            <q-icon name="icon-user_check-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-user_check-green" class="icon_svg"></q-icon>
            <q-icon name="icon-memo" class="icon_svg"></q-icon>
            <q-icon name="icon-clock" class="icon_svg"></q-icon>
            <q-icon name="icon-clock-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-pause-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-download" class="icon_svg"></q-icon>
            <q-icon name="icon-change" class="icon_svg"></q-icon>
            <q-icon name="icon-change-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-place" class="icon_svg"></q-icon>
          </div>
          <div class="text-primary q-gutter-sm q-py-sm" style="font-size: 24px">
            <q-icon name="icon-thumbup-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-thumbdown-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-reply-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-record" class="icon_svg"></q-icon>
            <q-icon name="icon-record-on" class="icon_svg"></q-icon>
            <q-icon name="icon-star" class="icon_svg"></q-icon>
            <q-icon name="icon-trash-grey" class="icon_svg"></q-icon>
            <q-icon name="icon-leader-star" class="icon_svg"></q-icon>
            <q-icon name="icon-leader" class="icon_svg"></q-icon>
            <q-icon name="icon-manager" class="icon_svg"></q-icon>
            <q-icon name="icon-manager-flag" class="icon_svg"></q-icon>
          </div>
        </q-card-section>
        <q-card-section class="q-pa-md">
          <h4 class="q-py-sm text-green-6 mt20">4.Icons Color Filter</h4>
          <div class="row q-gutter-sm q-mb-xs" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg filter-black"></q-icon>
            <p class="body2">filter-black / #000</p>
          </div>
          <div class="row q-gutter-sm q-mb-xs" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg filter-white"></q-icon>
            <p class="body2">filter-white / #fff</p>
          </div>
          <div class="row q-gutter-sm q-mb-xs" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg filter-grey-3"></q-icon>
            <p class="body2">filter-grey-3 / #767676</p>
          </div>
          <div class="row q-gutter-sm q-mb-xs" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg filter-grey-6"></q-icon>
            <p class="body2">filter-grey-6 / #d7d7d7</p>
          </div>
          <div class="row q-gutter-sm q-mb-xs" style="font-size: 24px">
            <q-icon name="icon-alarm" class="icon_svg filter-positive"></q-icon>
            <p class="body2">filter-positive / #339f63</p>
          </div>
        </q-card-section>
        <!-- <q-card-section class="q-pa-md">
          <h4>
            3.Ion Icons
            <p class="text-body2">mos 아이콘-디자인팀</p>
          </h4>
          <div class="text-primary q-gutter-md" style="font-size: 32px">
            <q-icon color="negative" name="app: mos-add"></q-icon>
            <q-icon color="yellow" name="app: mos-alarm"></q-icon>
            <q-icon color="positive" name="app: mos-arrow-left"></q-icon>
            <q-icon color="grey-2" name="app: mos-alarm_noti"></q-icon>
            <q-icon color="negative" name="app: mos-arrow-down"></q-icon>
            <q-icon color="grey-2" name="app: mos-arrow-right"></q-icon>
            <q-icon color="yellow" name="app: mos-calendar"></q-icon>
            <q-icon color="grey-2" name="app: mos-arrow-up"></q-icon>
            <q-icon color="negative" name="app: mos-chart"></q-icon>
            <q-icon color="grey-2" name="app: mos-check"></q-icon>
            <q-icon color="yellow" name="app: mos-chat"></q-icon>
            <q-icon color="grey-2" name="app: mos-close"></q-icon>
            <q-icon color="grey-2" name="app: mos-community"></q-icon>
            <q-icon color="negative" name="app: mos-data"></q-icon>
            <q-icon color="grey-2" name="app: mos-group"></q-icon>
            <q-icon color="yellow" name="app: mos-info"></q-icon>
            <q-icon color="grey-2" name="app: mos-home"></q-icon>
            <q-icon color="primary" name="app: mos-layers"></q-icon>
            <q-icon color="grey-2" name="app: mos-me"></q-icon>
            <q-icon color="primary" name="app: mos-photo"></q-icon>
            <q-icon color="grey-2" name="app: mos-printing"></q-icon>
            <q-icon color="grey-2" name="app: mos-reload"></q-icon>
            <q-icon color="primary" name="app: mos-search"></q-icon>
            <q-icon color="grey-2" name="app: mos-study"></q-icon>
            <q-icon color="primary" name="app: mos-subtitles"></q-icon>
            <q-icon color="grey-2" name="app: mos-xl"></q-icon>
          </div>
        </q-card-section> -->
      </q-card>
    </q-expansion-item>
    <!--// 아이콘 -->
    <q-separator />

    <!-- Typhography -->
    <q-expansion-item
      :default-opened="false"
      icon="format_size"
      label="타이포그라피 타이포그래피 헤딩태그 폰트속성/ Typhography"
      header-class="text-light-green-8"
    >
      <q-card class="q-pa-xs bg-light-green-1">
        <q-card-section class="q-pa-xs">
          <div class="q-pa-md">
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-h1
                  <q-tooltip> class </q-tooltip>
                </div>
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status"
                  cursor-pointer
                >
                  h1
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h1" cursor-pointer>
                <q-tooltip>
                  font-size: 28px/ line-height: 32px/ font-weight: 600/
                </q-tooltip>
                Headline 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-h2
                  <q-tooltip> class </q-tooltip>
                </div>
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status"
                  cursor-pointer
                >
                  h2
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h2" cursor-pointer>
                <q-tooltip>
                  font-size: 24px/ line-height: 28px/ font-weight: 700/
                </q-tooltip>
                Headline 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-h4
                  <q-tooltip> class </q-tooltip>
                </div>
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-secondary q-ml-sm"
                  role="status"
                  cursor-pointer
                >
                  h4
                  <q-tooltip> tag </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h4" cursor-pointer>
                <q-tooltip>
                  font-weight: 600/ font-size: 22px/ line-height: 26px/
                </q-tooltip>
                Headline 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title1
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-h4" cursor-pointer>
                <q-tooltip>
                  font-weight: 600/ font-size: 20px/ line-height: 22px/
                </q-tooltip>
                title 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title2
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title2" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 20px/ line-height: 22px/
                </q-tooltip>
                title 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title3
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title3" cursor-pointer>
                <q-tooltip>
                  font-weight: 600; font-size: 18px; line-height: 20px;
                </q-tooltip>
                title 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title4
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title4" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 18px/ line-height: 20px/
                </q-tooltip>
                title 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-phara1
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-phara1" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 18px/ line-height: 26px/
                </q-tooltip>
                text-phara1 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-phara2
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-phara2" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 16px/ line-height: 24px/
                </q-tooltip>
                text-phara2 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-body1
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body1" cursor-pointer>
                <q-tooltip>
                  font-weight: 600/ font-size: 16px/ line-height: 18px/
                </q-tooltip>
                body 차세대드림스
              </div>
            </div>

            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-body2
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body2" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 16px/ line-height: 18px/
                </q-tooltip>
                body 차세대드림스
              </div>
            </div>
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  text-body3
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 text-body3" cursor-pointer>
                <q-tooltip>
                  font-weight: 400/ font-size: 14px/ line-height: 16px/
                </q-tooltip>
                body 차세대드림스
              </div>
            </div>
          </div>
        </q-card-section>
        <q-separator />
        <q-card-section class="q-pa-xs">
          <div class="q-pa-md">
            <!-- title1 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title1
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title1" cursor-pointer>
                title1 20px 600
              </div>
            </div>

            <!-- title2 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title2
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title2" cursor-pointer>
                title2 20px 400
              </div>
            </div>

            <!-- title3 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div
                  class="q-badge flex inline items-center no-wrap q-badge--single-line bg-brand-primary"
                  role="status"
                  cursor-pointer
                >
                  title3
                  <q-tooltip> class </q-tooltip>
                </div>
              </div>
              <div class="col-sm-9 col-12 title3" cursor-pointer>
                title3 18px 600
              </div>
            </div>

            <!-- title4 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline no-wrap bg-brand-primary">
                  title4
                </div>
              </div>
              <div class="col-sm-9 col-12 title4" cursor-pointer>
                title4 18px 400
              </div>
            </div>

            <!-- body1 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline no-wrap bg-brand-primary">
                  body1
                </div>
              </div>
              <div class="col-sm-9 col-12 body1" cursor-pointer>
                body1 16px 600
              </div>
            </div>

            <!-- body2 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline no-wrap bg-brand-primary">
                  body2
                </div>
              </div>
              <div class="col-sm-9 col-12 body2" cursor-pointer>
                body2 16px 400
              </div>
            </div>

            <!-- body3 -->
            <div class="row items-center q-mb-lg">
              <div class="col-sm-3 col-12">
                <div class="q-badge flex inline no-wrap bg-brand-primary">
                  body3
                </div>
              </div>
              <div class="col-sm-9 col-12 body3" cursor-pointer>
                body3 14px 400
              </div>
            </div>
          </div>
        </q-card-section>
        <q-separator />
        <q-card-section class="q-pa-xs">
          <div class="q-pa-md">
            <h4 class="q-py-sm text-light-green-8">
              📝 color 사용 방법 : class에 text-색상함수 사용하면 됩니다.<small
                >(색상 함수는 아래 섹션에 나와있습니다.)</small
              >
            </h4>
            <p class="mb10 text-body2 text-primary">text-primary</p>
            <p class="mb10 text-body2 text-orange">text-orange</p>
            <p class="mb10 text-body2 text-grey-3">text-grey-3</p>
            <p class="mb10 text-body2 text-brown-2">text-brown-2</p>
          </div>
        </q-card-section>
      </q-card>
    </q-expansion-item>
    <!--// Typhography -->
    <q-separator />

    <!-- Color -->
    <q-expansion-item
      :default-opened="false"
      icon="palette"
      label="색상 컬러 / Color"
      header-class="text-lime-9"
    >
      <q-card class="q-pa-xs bg-lime-1">
        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-positive" cursor-pointer>
              <q-tooltip> $positive: #339f63; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">positive</div>
              <div class="text-subtitle2">#339f63</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-primary" cursor-pointer>
              <q-tooltip> $primary: #2e9dd1; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">primary</div>
              <div class="text-subtitle2">#2e9dd1</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-negative" cursor-pointer>
              <q-tooltip> $negative: #ED1C24; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">negative</div>
              <div class="text-subtitle2">#ED1C24</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-orange" cursor-pointer>
              <q-tooltip> $orange: #ff6b23; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">orange</div>
              <div class="text-subtitle2">#ff6b23</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-warning" cursor-pointer>
              <q-tooltip> $warning: #fda306; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">warning</div>
              <div class="text-subtitle2">#fda306</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-green" cursor-pointer>
              <q-tooltip> $green: #2B8252; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">green</div>
              <div class="text-subtitle2">#2B8252</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-positive" cursor-pointer>
              <q-tooltip> $positive: #339f63; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">positive</div>
              <div class="text-subtitle2">#339f63</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-green-3" cursor-pointer>
              <q-tooltip> $green-3: #eaf5ef; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">green-3</div>
              <div class="text-subtitle2">#eaf5ef</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-blue" cursor-pointer>
              <q-tooltip> $blue: #137AAF; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">blue</div>
              <div class="text-subtitle2">#137AAF</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-primary" cursor-pointer>
              <q-tooltip> $primary: #2e9dd1; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">primary</div>
              <div class="text-subtitle2">#2e9dd1</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-blue-3" cursor-pointer>
              <q-tooltip> $blue-3: #f1f7fb; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">blue-3</div>
              <div class="text-subtitle2">#f1f7fb</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-brown" cursor-pointer>
              <q-tooltip> $brown: #6E6058; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">brown</div>
              <div class="text-subtitle2">#6E6058</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-brown-2" cursor-pointer>
              <q-tooltip> $brown-2: #af9582; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">brown-2</div>
              <div class="text-subtitle2">#af9582</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-beige" cursor-pointer>
              <q-tooltip> $beige: #fff6e6; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">beige</div>
              <div class="text-subtitle2">#fff6e6</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-beige-2" cursor-pointer>
              <q-tooltip> $beige-2: #eeeae4; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">beige-2</div>
              <div class="text-subtitle2">#eeeae4</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-beige-3" cursor-pointer>
              <q-tooltip> $beige-3: #e8ddcc; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">beige-3</div>
              <div class="text-subtitle2">#e8ddcc</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div
              class="circle_shape bg-grey"
              cursor-pointer
              @click="colorClick = false"
            >
              <q-tooltip> $grey: #262626; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey</div>
              <div class="text-subtitle2">#262626</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-2" cursor-pointer>
              <q-tooltip> $grey-2: #545454; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-2</div>
              <div class="text-subtitle2">#545454</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-3" cursor-pointer>
              <q-tooltip> $grey-3: #767676; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-3</div>
              <div class="text-subtitle2">#767676</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-4" cursor-pointer>
              <q-tooltip> $grey-4: #999999; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-4</div>
              <div class="text-subtitle2">#999999</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-5" cursor-pointer>
              <q-tooltip> $grey-5: #bbbbbb; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-5</div>
              <div class="text-subtitle2">#bbbbbb</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-6" cursor-pointer>
              <q-tooltip> $grey-6: #d7d7d7; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-6</div>
              <div class="text-subtitle2">#d7d7d7</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-7" cursor-pointer>
              <q-tooltip> $grey-7: #ededed; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-7</div>
              <div class="text-subtitle2">#ededed</div>
            </q-card-section>
          </q-card>
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-grey-8" cursor-pointer>
              <q-tooltip> $grey-8: #f7f7f7; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">grey-8</div>
              <div class="text-subtitle2">#f7f7f7</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div class="circle_shape bg-white" cursor-pointer>
              <q-tooltip> $white: #ffffff; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">WHITE</div>
              <div class="text-subtitle2">#ffffff</div>
            </q-card-section>
          </q-card>
        </div>

        <div class="row q-gutter-sm q-pa-md">
          <q-card class="my-card q-pa-sm">
            <div
              class="circle_shape bg-black"
              cursor-pointer
              @click="colorClick = true"
            >
              <q-tooltip> $black : #000000; </q-tooltip>
            </div>
            <q-card-section class="text-center">
              <div class="text-h6">black</div>
              <div class="text-subtitle2">#000000</div>
            </q-card-section>
          </q-card>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //Color -->
    <q-separator />

    <!-- 그룹 버튼 토글 -->
    <q-expansion-item
      :default-opened="false"
      icon="checklist_rtl"
      label="그룹 버튼 토글 / Group Button Toggle"
      header-class="text-yellow-8"
    >
      <q-card class="q-pa-xs" style="background-color: #fff6e9">
        <div class="q-pa-md">
          <h4 class="q-py-sm text-yellow-10">
            그룹 버튼 토글 - 하나만 선택(요일 선택, 월화수목금)
          </h4>
          <div>
            <q-btn-toggle
              v-model="week"
              toggle-color="brown-2"
              class="btn_toggle_custom type01"
              :options="[
                { label: '전체', value: '전체' },
                { label: '월', value: '월' },
                { label: '화', value: '화' },
                { label: '수', value: '수' },
                { label: '목', value: '목' },
                { label: '금', value: '금' },
              ]"
            />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //그룹 버튼 토글 -->
    <q-separator />

    <!-- 툴팁 -->
    <q-expansion-item
      :default-opened="false"
      icon="quiz"
      label="툴팁 말풍선 / Tooltip"
      header-class="text-amber-8"
    >
      <q-card class="q-pa-xs bg-amber-1">
        <div class="q-pa-md">
          <div class="q-gutter-sm">
            <!-- tooltip_down -->
            <q-fab direction="left" hide-icon class="tooltip_down" flat>
              <q-fab-action square label="" label-position="left">
                <span class="btn_close"></span>
                <p class="txt text-body2">
                  [눈높이역사, 눈높이사회]
                  <span class="text-orange"> 결합상품 </span>입니다.
                </p>
              </q-fab-action>
            </q-fab>
            <!--// tooltip_down -->
            <!-- tooltip_down -->
            <q-fab
              direction="left"
              hide-icon
              class="tooltip_down type_black"
              flat
            >
              <q-fab-action
                square
                label=""
                label-position="left"
                style="width: 400px"
              >
                <span class="btn_close"></span>
                <p class="txt text-body2">
                  블랙 느낌표 타입<br />
                  이동예정일은 영업일 기준 D+3인 경우만 승인 요청 가능합니다.
                  이동선생님의 구성원등록 처리는 회원 이동 예정일 전에 필히
                  처리하시기 바랍니다.
                </p>
              </q-fab-action>
            </q-fab>
            <!--// tooltip_down -->
            <!-- tooltip_down -->
            <q-fab direction="left" hide-icon class="tooltip_down" flat>
              <q-fab-action
                square
                label=""
                label-position="left"
                style="width: 400px"
              >
                <span class="btn_close"></span>
                <p class="txt text-body2">
                  블랙 느낌표 타입<br />
                  이동예정일은 영업일 기준 D+3인 경우만 승인 요청 가능합니다.
                  이동선생님의 구성원등록 처리는 회원 이동 예정일 전에 필히
                  처리하시기 바랍니다.
                </p>
              </q-fab-action>
            </q-fab>
            <!--// tooltip_down -->
            <!-- tooltip_down type_question -->
            <q-fab
              direction="up"
              hide-icon
              class="tooltip_down type_question"
              flat
            >
              <q-fab-action
                square
                label=""
                label-position="left"
                color="primary"
                style="width: 200px"
              >
                <span class="btn_close"></span>
                <p class="txt text-body2">물음표 타입</p>
              </q-fab-action>
            </q-fab>
            <!--// tooltip_down type_question -->
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- 툴팁 -->
    <q-separator />

    <!-- 뱃지 -->
    <q-expansion-item
      :default-opened="false"
      icon="badge"
      label="뱃지 라벨 / Badge"
      header-class="text-deep-orange-7"
    >
      <q-card class="q-pa-xs bg-deep-orange-1">
        <div class="q-pa-md">
          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">badge20(20px)</h4>
            <q-badge class="badge20" rounded color="brown-2" label="badge20" />
            <q-badge
              outline
              color="red"
              class="badge20"
              label="badge20 outline"
            />
            <q-badge
              outline
              color="grey-3"
              class="badge20"
              label="badge20 outline"
            />
          </div>
          <q-separator class="mt10 mb30" />

          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">small(20px)</h4>
            <q-badge color="orange" class="small">미납</q-badge>
            <q-badge color="grey-4" class="small">결제대기</q-badge>
            <q-badge outline color="grey-3" class="small">아웃라인</q-badge>
          </div>
          <q-separator class="mt10 mb30" />

          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">medium(26px)</h4>
            <q-badge color="orange" class="medium">미납</q-badge>
            <q-badge color="grey-4" class="medium">결제대기</q-badge>
            <q-badge outline color="grey-3" class="medium">아웃라인</q-badge>
          </div>
          <q-separator class="mt10 mb30" />

          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">square small(20px)</h4>
            <q-badge color="orange" class="square_sm">미납</q-badge>
            <q-badge color="grey-4" class="square_sm">결제대기</q-badge>
            <q-badge outline color="grey-3" class="square_sm">아웃라인</q-badge>
          </div>
          <q-separator class="mt10 mb30" />

          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">square(24px)</h4>
            <q-badge color="orange" class="square">미납</q-badge>
            <q-badge color="grey-4" class="square">결제대기</q-badge>
            <q-badge outline color="grey-3" class="square">아웃라인</q-badge>
          </div>
          <q-separator class="mt10 mb30" />

          <div class="q-py-sm q-gutter-sm">
            <h4 class="q-py-sm text-deep-orange-6">large(36px)</h4>
            <q-badge color="orange" class="large">미납</q-badge>
            <q-badge color="grey-4" class="large">결제대기</q-badge>
            <q-badge outline color="grey-3" class="large">아웃라인</q-badge>
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //뱃지 -->
    <q-separator />

    <!-- 스탭퍼 -->
    <q-expansion-item
      :default-opened="false"
      icon="storage"
      label="스탭퍼 스테퍼 / Stepper"
      header-class="text-deep-orange-10"
    >
      <div class="q-pa-xs bg-deep-orange-1">
        <div class="q-pa-md">
          <q-stepper
            v-model="step"
            ref="stepper"
            flat
            header-nav
            active-color="positive"
            inactive-color="black"
            header-class="step_type00"
            inactive-icon="none"
            done-icon="none"
            active-icon="none"
            animated
          >
            <q-step :name="1" title="STEP 1 기본정보" :done="step > 1">
              For each ad campaign that you create, you can control how much
              you're willing to spend on clicks and conversions, which networks
              and geographical locations you want your ads to show on, and more.
            </q-step>

            <q-step :name="2" title="STEP 2 보호자정보" :done="step > 2">
              An ad group contains one or more ads which target a shared set of
              keywords.
            </q-step>

            <template v-slot:navigation>
              <q-stepper-navigation>
                <div class="wrap_fixed_bottom">
                  <div class="btn_area" style="">
                    <q-btn
                      v-if="step > 1"
                      outline
                      @click="$refs.stepper.previous()"
                      class="size_lg"
                      color="black"
                      label="이전"
                    />
                    <q-btn
                      fill
                      unelevated
                      color="black"
                      class="size_lg"
                      @click="$refs.stepper.next()"
                      :label="step === 2 ? '등록신청' : '다음'"
                    />
                  </div>
                </div>
              </q-stepper-navigation>
            </template>
          </q-stepper>
        </div>
      </div>
    </q-expansion-item>
    <!-- //스태퍼 -->
    <q-separator />

    <!-- pagination -->
    <q-expansion-item
      :default-opened="false"
      icon="pin"
      label="페이지네이션 페이징 페이지 / pagination"
      header-class="text-brown-8"
    >
      <q-card class="q-pa-xs bg-brown-1">
        <div class="q-pa-md">
          <div class="pagination_container">
            <q-pagination
              v-model="paginationSample"
              :max="5"
              direction-links
              boundary-links
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              icon-prev="keyboard_arrow_left"
              icon-next="keyboard_arrow_right"
              class="custom_pagination type_01"
            />
          </div>
        </div>
      </q-card>
    </q-expansion-item>
    <!-- //pagination -->
    <q-separator />

    <!-- Snackbars -->
    <q-expansion-item
      :default-opened="false"
      icon="breakfast_dining"
      header-class="text-brown-10"
      label="스낵바 알림 토스트 팝업 / Snackbars"
    >
      <div class="q-pa-xs bg-brown-1">
        <div class="q-pa-md">
          <q-btn
            unelevated
            color="yellow-9"
            @click="showNotif"
            label="Snackbars"
          />
        </div>
      </div>
    </q-expansion-item>
    <!--// Snackbars -->
    <q-separator />

    <!-- gray_roundbox -->
    <q-expansion-item
      :default-opened="false"
      icon="sort"
      label="라이너 프로그레스 막대 / gray_roundbox linear_progress"
      header-class="text-blue-grey-9"
    >
      <div class="q-pa-xs bg-blue-grey-1">
        <div class="gray_roundbox">
          <div class="linear_progress mb24">
            <div class="pointer" :style="{ width: progress + '%' }"></div>
          </div>
          <div class="linear_progress green mb24">
            <div class="pointer" :style="{ width: progress + '%' }"></div>
          </div>
          <div class="linear_progress yellow mb24">
            <div class="pointer" :style="{ width: progress + '%' }"></div>
          </div>
          <div class="linear_progress orange mb24">
            <div class="pointer" :style="{ width: progress + '%' }"></div>
          </div>
        </div>
      </div>
    </q-expansion-item>
    <!-- //gray_roundbox -->
    <q-separator />

    <!-- balloon -->
    <q-expansion-item
      :default-opened="false"
      icon="forum"
      label="말풍선 풍선배경 / balloon"
      header-class="text-blue-grey-13"
    >
      <div class="q-pa-xs bg-blue-grey-1">
        <div class="q-pa-md">
          <div class="balloon">26 <span class="unit">%</span></div>
        </div>
      </div>
    </q-expansion-item>
    <!-- //balloon -->
    <q-separator />

    <!-- sampleDialogform -->
    <!--
    <q-expansion-item
      :default-opened="false"
      icon="fullscreen"
      label="dialog form"
      header-class="text-blue-8"
    >
      <div class="q-pa-xs bg-grey-8">
        <div class="q-pa-md">
          <q-btn color="brown" to="/sampleDialogform">sampleDialogform</q-btn>
        </div>
      </div>
    </q-expansion-item>
    -->
    <!-- //sampleDialogform -->
    <!--<q-separator />-->
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { useQuasar, useMeta } from 'quasar';
const progress = ref('26');
const metaData = {};
const route = useRoute();
const $q = useQuasar();
const tab = ref('upper');
const colorClick = ref();
const dataSelect = ref(['']);
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const keyword = ref(null);
const keyword2 = ref(null);
const testInput = ref(null);
const dataInput = ref('');
const dataInput2 = ref('');
const dataInput0 = ref('리드온리 밸류값');
const dataTextArea = ref(
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in ex '
);
const dataRadio = ref('positive');
const dataCheck = ref({
  primary: true,
  primary2: false,
  positive: false,
  negative: true,
  orange: false,
  warning: true,
  brown: true,
  gsearch: true,
});
const dataDialog = ref({
  responsePop: false,
  responsePopbg: false,
  responseType02Pop: false,
  responseType02MediumPop: false,
  responseType02LargePop: false,
  responseType02SmallPop: false,
  responseType02HugePop: false,
  alert: false,
  alert2: false,
  type02: false,
  inner: false,
  middle: false,
  medium: false,
  double: false,
  large: false,
  wide: false,
  venti: false,
  huge: false,
  confirm: false,
  prompt: false,
  prompt_input: '...',
  bottomsheet: false,
  btm: false,
  btm2: false,
  btm3: false,
  btm4: false,
  btm5: false,
  bottomsheet_drag: null,
});

// inner_form
const popForm = ref(true);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  information: null,
  category: '카테고리를 선택하세요',
  state: '선택하세요',
  allow: 'true',
});
//
const stateSelectOption = ref([
  {
    id: 'confirm',
    desc: '확인',
  },
  {
    id: 'alert',
    desc: '알림',
  },
]);
// 스텝
const step = ref(1);
// 스크롤탑
// function scrolTop() {
//     window.scrollTo({
//       top: 0,
//       behavior: 'smooth',
//     });
//   }
function swipe_bottom({ ...newInfo }) {
  dataDialog.value.bottomsheet_drag = newInfo;
  if (
    dataDialog.value.bottomsheet_drag.direction == 'down' &&
    dataDialog.value.bottomsheet_drag.distance.y > 8
  ) {
    dataDialog.value.bottomsheet = false;
  }
}
const dataToggle = ref([
  'primary',
  'negative',
  'orange',
  'warning',
  'positive',
  'brown-2',
  'grey-2',
  'on',
]);
// setTimeout(() => {
//   testInput.value.focus();
// }, 30);

onMounted(() => {
  metaData.title = route.name;
  // console.log(route.name);
  useMeta(metaData);
});

function showNotif() {
  $q.notify({
    timeout: 0, // 알림 시간 3초 -> 팝업 사라지기까지 대기하는 시간, 0 일 경우 자동으로 안 닫힘
    message: '학습일정 변경이 완료되었습니다',
    html: true,
    color: 'grey-1',
    multiLine: false,
    avatar: '',
    icon: 'check',
    class: 'icon_svg',
    progress: false,
    badgeStyle: 'opacity: 0', // 클릭한 수만큰 숫자가 표기되는 뱃지가 안 보이게

    onDismiss: () => {
      console.log('Dismissed');
    },
    // actions: [
    //   {
    //     label: '버튼 예시',
    //     color: 'yellow',
    //     handler: () => {
    //       console.log('버튼 이벤트');
    //     },
    //   },
    //   {
    //     label: '닫기',
    //     color: 'white',
    //     handler: () => {
    //       console.log('닫기');
    //     },
    //   },
    // ],
  });
}
function sampleFocus(_target) {
  console.log('값', _target.modelValue);
  _target.focus();
}

const readonlyInput1 = ref('부문');
const readonlyInput2 = ref('본부');
const readonlyInput3 = ref('지점');
const readonlyInput4 = ref('팀');
const readonlyInput5 = ref('채널');
const readonlyInput6 = ref('선생님');

// table_search_area
const sysSelect = ref('');
const sysSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const searchUseSelected = ref(['']);
const searchSelectOption = ref([
  {
    id: 'Y',
    desc: '사용',
  },
  {
    id: 'N',
    desc: '미사용',
  },
]);
const searchSelectChoice = ref(['']);
const searchSelectChoiceOption = ref([
  {
    id: 'A',
    desc: '전체',
    // disable 옵션 샘플
    // inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const author = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const msg_name = ref('');

//pagination
const paginationSample = ref(5);

const day = ref(['tues']);
const dayOption = ref([
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
// 전체 버튼 클릭 이벤트
// const dayAll = ref(false);
// function clickDayAll() {
//   if (dayAll.value == false) {
//     day.value = ['tues', 'mon', 'wed', 'thurs', 'fri'];
//     dayAll.value = true;
//   } else {
//     day.value = [];
//     dayAll.value = false;
//   }
// }
//버튼 상태 체크
// function checkDayAll() {
//   console.log(day.value.length);
//   if (day.value.length == 5) {
//     dayAll.value = true;
//   } else {
//     dayAll.value = false;
//   }
// }
const week = ref(null);

// radio group - customize
const sendMsg = ref('op1');
const sendMsgoptions = ref([
  {
    label: '해피콜[학습신청안내]',
    value: 'op1',
  },
  {
    label: '회비안내[추가이체안내_눈높이_눈높이_눈높이_눈높이_눈높이]',
    value: 'op2',
  },
  {
    label: '해피콜[전입_눈높이]',
    value: '3',
  },
  {
    label: '해피콜[눈높이]',
    value: 'op4',
  },
  {
    label: '해피콜[전입_눈높이]',
    value: 'op5',
  },
  {
    label: '해피콜[눈높이]',
    value: 'op6',
  },
  {
    label: '',
    value: 'op7',
    disable: true,
  },
  {
    label: '',
    value: 'op8',
    disable: true,
  },
]);

// radio group
const group = ref('op1');
const options = ref([
  {
    label: '부문',
    value: 'op1',
  },
  {
    label: '본부',
    value: 'op2',
  },
  {
    label: '조직',
    value: 'op3',
  },
  {
    label: '지원팀',
    value: 'op4',
  },
]);

// tree
const treeData1 = [
  {
    label: '눈높이',
    id: 'a_1',
    img: '/icons/icon-tree-folder.svg',
    children: [
      {
        id: 'a_2',
        label: 'HC',
      },
      {
        label: 'LC',
        id: 'a_7',
      },
      {
        label: 'YC',
        id: 'a_4',
      },
      {
        label: 'OC',
        id: 'a_5',
      },
      {
        label: 'SC',
        id: 'a_6',
      },
    ],
  },
];

const convenientOptionsGroup = ref(['op1']);
const convenientOptions = ref([
  {
    label: '주차',
    value: 'op1',
  },
  {
    label: '학부모 대기공간',
    value: 'op2',
  },
  {
    label: '멀티학습관',
    value: 'op3',
  },
]);

const treeSelected1 = ref('');
const inpClear = ref('');

// 상세 검색 옵션 선택
// 학습선택
const searchOptGroup01Otions = ref([
  {
    group: [
      {
        label: '만2세~6세',
        value: 'child',
      },
    ],
  },
  {
    group: [
      {
        label: '초1',
        value: 'e1',
      },
      {
        label: '초2',
        value: 'e2',
      },
      {
        label: '초3',
        value: 'e3',
      },
      {
        label: '초4',
        value: 'e4',
      },
      {
        label: '초5',
        value: 'e5',
      },
      {
        label: '초6',
        value: 'e6',
      },
    ],
  },
  {
    group: [
      {
        label: '중1',
        value: 'm1',
      },
      {
        label: '중2',
        value: 'm2',
      },
      {
        label: '중3',
        value: 'm3',
      },
    ],
  },
  {
    group: [
      {
        label: '고1',
        value: 'h1',
      },
      {
        label: '고2',
        value: 'h2',
      },
      {
        label: '고3',
        value: 'h4',
      },
    ],
  },
  {
    group: [
      {
        label: '성인',
        value: 'adult',
      },
    ],
  },
]);

const searchOptGroup01 = ref(['child', 'e1']);

// 제품
const searchOptGroup02Otions = ref([
  {
    group: [
      {
        label: '눈높이',
        value: 'p1',
      },
      {
        label: '솔루니',
        value: 'p2',
      },
      {
        label: '다이렉트',
        value: 'p3',
      },
      {
        label: '드림멘토',
        value: 'p4',
      },
      {
        label: '올인원',
        value: 'p5',
      },
      {
        label: '패키지',
        value: 'p6',
      },
    ],
  },
]);
const searchOptGroup02 = ref(['p1']);

// 학습형태
const searchOptGroup03Otions = ref([
  {
    group: [
      {
        label: '방문수업',
        value: 't1',
      },
      {
        label: '센터학원수업',
        value: 't2',
      },
      {
        label: '비대면체험',
        value: 't3',
      },
      {
        label: '일반도서',
        value: 't4',
      },
      {
        label: '바우처',
        value: 't5',
      },
      {
        label: '온라인수업',
        value: 't6',
      },
      {
        label: '통신교재',
        value: 't7',
      },
      {
        label: '셀프러닝',
        value: 't8',
      },
    ],
  },
]);
const searchOptGroup03 = ref(['t1']);

// 학습과목
const searchOptGroup04Otions = ref([
  {
    group: [
      {
        label: '국어',
        value: 's1',
      },
      {
        label: '수학',
        value: 's2',
      },
      {
        label: '영어',
        value: 's3',
      },
      {
        label: '글자/숫자',
        value: 's4',
      },
      {
        label: '사회',
        value: 's5',
      },
      {
        label: '역사',
        value: 's6',
      },
      {
        label: '과학',
        value: 's7',
      },
      {
        label: '한자',
        value: 's8',
      },
      {
        label: '셀프러닝',
        value: 's9',
      },
    ],
  },
]);
const searchOptGroup04 = ref(['s3']);

// 가격
const searchOptGroup05Otions = ref([
  {
    group: [
      {
        label: '10,000~30,000원',
        value: 'p1',
      },
      {
        label: '30,000~50,000원',
        value: 'p2',
      },
      {
        label: '50,000~100,000원',
        value: 'p3',
      },
    ],
  },
]);
const searchOptGroup05 = ref(['p2']);
const searchExpand = ref(true);
</script>

<style lang="scss">
.q-expansion-item.q-expansion-item--expanded {
  // background: rgb(232 232 232 / 30%);
}

.my-card {
  width: 100%;
  max-width: 200px;

  .text-subtitle2 {
    text-transform: uppercase;
  }
}

.circle_shape {
  height: 0;
  margin: 0 auto;
  width: 40%;
  padding-bottom: 40%;
  border-radius: 60px !important;
  outline: 1px solid #eee;
  // border: 1px solid #aaa;
}

.q-card {
  .q-card__section--vert {
    // padding: 0;
    // text-align: center;
  }
}
</style>
