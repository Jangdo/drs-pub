<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card inner_form">
        <!-- 팝업 제목 영역 -->
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">
            금칙어명 등록
            <!-- 금칙어명 수정 -->
          </h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 -->
        <q-card-section class="dialog_content">
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">금칙어명</span>
                  <q-input
                    v-model="dataFrom.forbidden"
                    class="hide_label inp_search"
                    label="금칙어명"
                    outlined
                    placeholder="금칙어명을 입력하세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>

        <!-- 팝업 버튼 -->
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;

      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
      text-align: left;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  category: '',
  forbidden: '',
});
</script>
