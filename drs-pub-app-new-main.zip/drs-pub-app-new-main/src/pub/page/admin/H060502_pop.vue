<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">조직 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-select
                    class="hide_label"
                    label="본부 선택"
                    v-model="officeSelect"
                    :options="officeSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="조직명"
                  >
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="row mt20">
            <!-- 테이블 -->
            <div class="w497half table_dk">
              <h4 class="title1 mb24">검색 사용자</h4>
              <q-table
                class="scrollable sticky_table_header"
                :rows="userRows"
                :columns="userColumns"
                v-model:selected="userSelected"
                row-key="idx"
                v-model:pagination="userPagination"
                hide-bottom
                hide-pagination
                selection="multiple"
                separator="cell"
                color="black"
                style="height: 450px"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th class="select">선택</q-th>
                    <q-th
                      v-for="col in props.cols"
                      :key="col.name"
                      :props="props"
                    >
                      {{ col.label }}
                    </q-th>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!-- // 테이블 -->

            <!-- 버튼 -->
            <div class="column mr20 ml20 justify-center">
              <div>
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="추가"
                />
              </div>
              <div class="mt10">
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="삭제"
                />
              </div>
            </div>
            <!-- // 버튼 -->

            <!-- 테이블 -->
            <div class="w497half table_dk">
              <h4 class="title1 mb24">설정 사용자</h4>
              <q-table
                class="scrollable sticky_table_header"
                :rows="settingRows"
                :columns="settingColumns"
                v-model:selected="settingSelected"
                row-key="idx"
                v-model:pagination="settingPagination"
                hide-bottom
                hide-pagination
                selection="multiple"
                separator="cell"
                color="black"
                style="height: 450px"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th class="select">선택</q-th>
                    <q-th
                      v-for="col in props.cols"
                      :key="col.name"
                      :props="props"
                    >
                      {{ col.label }}
                    </q-th>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!-- // 테이블 -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const officeSelect = ref(['본부 선택']);
const officeSelectOption = ref([
  {
    id: 'office1',
    desc: '본부1',
  },
  {
    id: 'office2',
    desc: '본부2',
  },
]);
const keyword = ref('');

const userSelected = ref([]);
const userPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 16,
});
const userColumns = ref([
  {
    name: 'tdata1',
    label: '상위조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '타입',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '조직명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
]);
const userRows = ref([
  {
    idx: 11,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 10,
    tdata1: '눈높이 > 본부 ABCDE > 교육국 AAAAA',
    tdata2: '교육국교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 9,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 8,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 7,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 5,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 4,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 5,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 4,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 3,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 2,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 1,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
]);

const settingSelected = ref([]);
const settingPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 16,
});
const settingColumns = ref([
  {
    name: 'tdata1',
    label: '상위조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '타입',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '조직명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
]);
const settingRows = ref([
  {
    idx: 11,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 10,
    tdata1: '눈높이 > 본부 ABCDE > 교육국 AAAAA',
    tdata2: '교육국교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 9,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 11,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 10,
    tdata1: '눈높이 > 본부 ABCDE > 교육국 AAAAA',
    tdata2: '교육국교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 9,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 8,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 7,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 5,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 4,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 3,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 2,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 1,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
]);
</script>
