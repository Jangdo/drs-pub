<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 huge">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한이력 - 서북지원팀 김길동</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-12">
                  <q-input
                    class="box_l inp_search"
                    for=""
                    outlined
                    dense
                    placeholder="권한명을 입력하여 검색하세요"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <q-table
            :rows="userRows"
            :columns="userColumns"
            row-key="code"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="path" class="idx">{{ props.row.idx }}</q-td>
                <q-td key="category" class="category">
                  {{ props.row.category }}</q-td
                >
                <q-td key="name" class="authority_name">
                  {{ props.row.name }}</q-td
                >
                <q-td key="permission" class="permission">
                  {{ props.row.permission }}</q-td
                >
                <q-td key="worker" class="worker"> {{ props.row.worker }}</q-td>
                <q-td key="date" class="working_day">
                  {{ props.row.date }}</q-td
                >
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const userColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },

  {
    name: 'name',
    label: '권한명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'permission',
    label: '권한여부',
    field: 'permission',
    sortable: false,
    align: 'center',
    field: (row) => row.permission,
  },
  {
    name: 'worker',
    label: '작업자',
    align: 'center',
    sortable: false,
    field: (row) => row.worker,
  },
  {
    name: 'date',
    label: '작업일',
    align: 'center',
    sortable: false,
    field: (row) => row.date,
  },
]);

const userRows = ref([
  {
    idx: 100,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 99,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 98,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 97,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 96,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
  {
    idx: 95,
    category: '시스템관리자',
    name: '인사회계_개발자',
    permission: '생성',
    worker: '김길동',
    date: '2022.11.02',
  },
]);

const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

// dialog
const popForm = ref(true);

//  table
</script>
