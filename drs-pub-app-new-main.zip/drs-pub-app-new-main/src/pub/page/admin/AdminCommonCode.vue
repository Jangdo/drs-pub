<template>
  <q-breadcrumbs active-color="#666" class="mb10">
    <template v-slot:separator>
      <q-icon size="1.5em" name="chevron_right" />
    </template>
    <q-breadcrumbs-el label="HOME" to="/pub-admin/" />
    <q-breadcrumbs-el label="공통관리" to="/pub/pub-admin" />
    <q-breadcrumbs-el :label="$route.name" />
  </q-breadcrumbs>

  <div>
    <q-tabs
      v-model="tab"
      dense
      class="text-grey"
      active-color="primary"
      indicator-color="primary"
      align="justify"
      narrow-indicator outside-arrows
    >
      <q-tab name="upper" label="상위코드" />
      <q-tab name="downer" label="하위코드" />
    </q-tabs>
    <q-tab-panels v-model="tab" animated>
      <q-tab-panel name="upper">
        <!-- table_serch_area type_01 -->
        <div class="table_serch_area type_01">
          <div class="input_area">
            <q-select
              class="box_m"
              v-model="dataSelect"
              :options="dataSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
              :class="[dataSelect == 0 ? 'placehoder' : '']"
            >
            </q-select>
            <q-input
              class="box_l"
              for=""
              outlined
              dense
              v-model="keyword"
              placeholder="코드 or 코드명을 입력하세요"
            />
          </div>
          <div class="btn_area">
            <q-btn class="btn_fill" dense flat label="조회" />
            <q-btn
              class="btn_txt"
              icon="ion-ios-refresh"
              dense
              outline
              label="초기화"
            />
          </div>
        </div>
        <!--// table_serch_area type_01 -->
        <div class="edite_table type_01">
          <q-table
            :rows="rows"
            :columns="columns"
            row-key="code"
            v-model:selected="selected"
            selection="multiple"
            v-model:pagination="pagination"
            hide-pagination
          >
            <template v-slot:body="props">
              <q-tr :class="props.row.state" :props="props">
                <q-td>
                  <q-toggle v-model="props.selected" />
                </q-td>
                <q-td key="code">
                  {{ props.row.code }}
                  <q-popup-edit
                    v-model="props.row.code"
                    buttons
                    label-set="확인"
                    label-cancel="취소"
                    v-slot="scope"
                  >
                    <q-input v-model="scope.value" dense autofocus />
                  </q-popup-edit>
                </q-td>
                <q-td key="name">
                  {{ props.row.name }}
                  <q-popup-edit
                    v-model="props.row.name"
                    buttons
                    label-set="확인"
                    label-cancel="취소"
                    v-slot="scope"
                  >
                    <q-input v-model="scope.value" dense autofocus />
                  </q-popup-edit>
                </q-td>
                <q-td key="state" class="text-center">
                  {{ tdState(props.row.state) }}</q-td
                >
                <q-td key="allow" :props="props">
                  <q-toggle v-model="props.row.allow" color="negative" />
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <q-pagination
            v-model="pagination.page"
            :max="pagesNumber"
            :max-pages="11"
            :ellipses="false"
            :boundary-numbers="true"
            direction-links
            boundary-links
            icon-first="skip_previous"
            icon-last="skip_next"
            icon-prev="fast_rewind"
            icon-next="fast_forward"
          />
        </div>
      </q-tab-panel>

      <q-tab-panel name="downer">
        <div class="text-h6">Alarms</div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
      </q-tab-panel>
    </q-tab-panels>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue';

// tab
const tab = ref('upper');
// dropdown
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: '',
    desc: '코드를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
// serchbox input
const keyword = ref('');

// table
const selected = ref([]);
const columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: true,
    field: (row) => row.code,
    align: 'left',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: true,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: true,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: true,
    field: (row) => row.allow,
  },
]);

const rows = ref([
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_17',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_18',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_19',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_20',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_21',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_22',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_23',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_24',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_25',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_26',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_27',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_28',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_29',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_30',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_31',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_32',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_33',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_34',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_35',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_36',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_37',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_38',
    name: 'name_SALE_001',
    state: 'add:',
    allow: false,
  },
  {
    code: 'SALE_39',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_40',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_41',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_42',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_43',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_44',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_45',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_46',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_47',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_48',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_49',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
  {
    code: 'SALE_50',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
]);
const pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});
const pagesNumber = computed(() =>
  Math.ceil(rows.value.length / pagination.value.rowsPerPage)
);

// function rowState(priority) {
//   switch (priority) {
//     case 'add':
//       return '추가';
//     case '진행중':
//       return 'ing';
//     case '수정':
//       return 'edit';
//     default:
//       return '';
//   }
// }

function tdState(priority) {
  switch (priority) {
    case 'add':
      return '추가';
    case 'edit':
      return '수정';
    default:
      return '';
  }
}
</script>
<style lang="scss"></style>
