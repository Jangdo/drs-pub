<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large inner_form">
        <!-- 팝업 제목 영역 -->
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">신고하기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 영역 -->
        <q-card-section class="dialog_content">
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">제목</span>
                  <div class="as_dd">
                    {{ inpSubject }}
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">등록자</span>
                  <div class="as_dd">
                    {{ inpAuthor }}
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">신고사유</span>
                  <q-select
                    class="as_dd hide_label w280"
                    label="선택하세요"
                    v-model="authorityGroupSelect"
                    :options="authorityGroupSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
              </div>
            </li>

            <li class="hastextarea">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">신고내용</span>
                  <div class="as_dd wrap_counsel_form">
                    <div class="wrap_textarea mt15 mb15">
                      <q-input
                        class="basic text-phara1 medium"
                        outlined
                        v-model="dataTextArea"
                        placeholder="입력하세요"
                        type="textarea"
                      >
                      </q-input>
                      <div class="check_val">
                        <span>0</span>/<span>1,000</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>

        <!-- 버튼 -->
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            outline
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="신고하기"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const inpSubject = ref('0524_긴급공지');
const inpAuthor = ref('이포탈');

const authorityGroupSelect = ref(['']);
const authorityGroupSelectOption = ref([
  {
    id: 'N',
    desc: '불건전내용',
  },
  {
    id: 'G',
    desc: '보안내용',
  },
  {
    id: 'C',
    desc: '도배',
  },
  {
    id: 'M',
    desc: '기타',
  },
]);
</script>
