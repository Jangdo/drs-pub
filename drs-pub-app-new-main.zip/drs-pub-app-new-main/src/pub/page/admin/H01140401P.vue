<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메시지알림 발송대상 조회</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m hide_label"
                    label="본부 선택"
                    v-model="headquartersSelect"
                    :options="headquartersSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m hide_label"
                    label="지점 선택"
                    v-model="branchSelect"
                    :options="branchSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="userSearch"
                    placeholder="사번, 성명"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <q-space class="sp30" />
          <!-- selectable_table type_01 -->
          <div class="selectable_table">
            <!-- general_table -->
            <div class="table_dk">
              <q-table
                :rows="dataRows"
                :columns="dataColumns"
                v-model:pagination="dataPagination"
                hide-bottom
                hide-pagination
                separator="cell"
                auto-width="true"
              >
              </q-table>
            </div>
            <!--// general_table-->

            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
          <!--// selectable_table type_01-->
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

// 검색옵션
const headquartersSelect = ref('본부 선택');
const headquartersSelectOption = ref([
  {
    id: 'N',
    desc: '본부1',
  },
]);
const branchSelect = ref('지점 선택');
const branchSelectOption = ref([
  {
    id: 'N',
    desc: '지점1',
  },
]);

const userSearch = ref('');

// 테이블 데이터
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '발송시간',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '지점',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata3',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata3',
    label: '성명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata3',
    label: '성공여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const dataRows = ref([
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
  {
    tdata1: '100',
    tdata2: '2022.11.01 18:48:55',
    tdata3: '경북본부',
    tdata4: '대구남부 교육국',
    tdata5: 'P117050002',
    tdata6: '홍길동',
    tdata7: '성공',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
