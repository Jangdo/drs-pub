<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02">
        <div class="table_search_area"></div>
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <!--  table_search_area type_03-->
          <div class="table_search_area type_03">
            <q-input
              class="box_l"
              for=""
              outlined
              dense
              placeholder="검색어를 입력하세요"
            />
            <div class="btn_area">
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <!-- // table_search_area type_03-->
          <!-- table -->
          <q-table
            title="검색 코드"
            :rows="rows"
            :columns="columns"
            row-key="code"
            :pagination="initialPagination"
            selection="multiple"
            v-model:selected="selected"
            separator="cell"
            hide-pagination
            hide-bottom
            class="table_01"
          >
            <template v-slot:header-selection="scope">
              <q-toggle v-model="scope.selected" v-if="false" />
            </template>
            <template v-slot:body-selection="scope">
              <q-checkbox v-model="scope.selected" />
            </template>
          </q-table>
          <!--// table -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

//  table
const columns = ref([
  {
    name: 'code',
    label: '코드',
    align: 'left',
    sortable: false,
    field: (row) => row.code,
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
  },
]);
const initialPagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const rows = ref([
  {
    code: 'SALE_001',
    name: '결산 실행상태',
  },
  {
    code: 'SALE_002',
    name: '결산 실행상태',
  },
  {
    code: 'SALE_003',
    name: '결산 실행상태',
  },
  {
    code: 'SALE_004',
    name: '결산 실행상태',
  },

  {
    code: 'SALE_005',
    name: '결산 실행상태',
  },
]);
const selected = ref([]);
</script>
