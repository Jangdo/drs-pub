<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">공통코드관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="upper" label="상위코드" :ripple="false" />
        <q-tab name="downer" label="하위코드" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- table_search_area type_01 -->
      <div class="table_search_area type_01">
        <div class="input_area">
          <q-select
            class="box_m"
            v-model="sysSelect"
            :options="sysSelectOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
            :class="[sysSelect == 0 ? 'placehoder' : '']"
          >
          </q-select>
          <q-select
            class="box_m"
            v-model="dataSelect"
            :options="dataSelectOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
            :class="[dataSelect == 0 ? 'placehoder' : '']"
          >
          </q-select>
          <q-input
            class="box_l"
            for=""
            outlined
            dense
            v-model="keyword"
            placeholder="코드 or 코드명을 입력하세요"
          />
        </div>
        <div class="btn_area">
          <q-btn
            class="size_sm btn_search"
            color="black"
            fill
            unelevated
            label="조회"
          />
          <q-btn
            icon="ion-ios-refresh"
            class="size_sm btn_reset"
            color="grey-9"
            outline
            label="초기화"
          />
        </div>
      </div>
      <!--// table_search_area type_01 -->
      <!-- <q-separator /> -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 상위코드 tab 컨텐츠 -->
        <q-tab-panel name="upper">
          <!-- editable_table -->
          <div class="editable_table type_01">
            <div class="btn_area">
              <q-btn
                class="size_sm btn_row_add"
                icon="ion-ios-add"
                dense
                outline
                label="행추가"
              />
              <!-- <q-btn
                class="size_sm row_remove"
                color="grey-9"
                icon="ion-ios-remove"
                dense
                outline
                label="행삭제"
              /> -->
              <q-space />
              <q-btn class="size_sm btn_cancel" unelevated label="취소" />
              <q-btn class="size_sm btn_save" unelevated label="저장" />
            </div>
            <q-table
              :rows="rows"
              :columns="columns"
              row-key="code"
              v-model:selected="selected"
              selection="multiple"
              v-model:pagination="pagination"
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td class="select">
                    <template v-if="props.row.state == 'add'">
                      <q-btn
                        icon="ion-ios-close"
                        dense
                        flat
                        label=""
                        size="36px"
                      />
                    </template>
                    <template v-else>
                      <q-checkbox v-model="props.selected" color="black" />
                    </template>
                  </q-td>
                  <q-td key="systemSelect" class="type hasinput">
                    <template v-if="props.row.state == 'add'">
                      <q-select
                        class="box_m"
                        v-model="props.row.systemSelect"
                        :options="SystemSelectionOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </template>
                    <template v-else>
                      {{ props.row.systemSelect }}
                      <q-popup-edit
                        v-model="props.row.systemSelect"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-select
                          class="box_m"
                          v-model="scope.value"
                          autofocus
                          :options="SystemSelectionOption"
                          option-value="desc"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          :class="[dataSelect == 0 ? 'placehoder' : '']"
                        >
                        </q-select>
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="upperCodeSelect" class="code_type hasinput">
                    <template v-if="props.row.state == 'add'">
                      <q-select
                        class="box_m"
                        v-model="props.row.upperCodeSelect"
                        :options="UppercodeSelectionOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </template>
                    <template v-else>
                      {{ props.row.upperCodeSelect }}
                      <q-popup-edit
                        v-model="props.row.upperCodeSelect"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-select
                          class="box_m"
                          v-model="scope.value"
                          autofocus
                          :options="UppercodeSelectionOption"
                          option-value="desc"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          :class="[dataSelect == 0 ? 'placehoder' : '']"
                        >
                        </q-select>
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="code" class="code hasinput">
                    <template v-if="props.row.state == 'add'">
                      <q-input
                        outlined
                        v-model="props.row.code"
                        :error="props.row.code.sample_err"
                        placeholder="코드 입력"
                        dense
                      >
                        <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                      </q-input>
                    </template>
                    <template v-else>
                      {{ props.row.code }}
                      <q-popup-edit
                        v-model="props.row.code"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" dense autofocus />
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="name" class="code_name hasinput">
                    <template v-if="props.row.state == 'add'">
                      <q-input
                        outlined
                        v-model="props.row.name"
                        :error="props.row.name.sample_err"
                        placeholder="코드명 입력"
                        dense
                      >
                        <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                      </q-input>
                    </template>
                    <template v-else>
                      {{ props.row.name }}
                      <q-popup-edit
                        v-model="props.row.name"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" dense autofocus />
                      </q-popup-edit>
                    </template>
                  </q-td>
                  <q-td key="state" class="state">
                    <template v-if="props.row.state == 'edit'">
                      <q-icon name="done"></q-icon>
                      {{ tdState(props.row.state) }}
                    </template>
                    <template v-else>
                      {{ tdState(props.row.state) }}
                    </template>
                  </q-td>
                  <q-td key="allow" :props="props" class="allow">
                    <q-toggle v-model="props.row.allow" color="black" />
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!--// editable_table -->
        </q-tab-panel>
        <!--// 상위코드 tab 컨텐츠 -->
        <!-- 하위코드 tab 컨텐츠 -->
        <q-tab-panel name="downer">
          <!-- wrap_table_divide -->
          <div class="wrap_table_divide">
            <div class="col_left">
              <!-- 상위코드 선택 table -->
              <div class="error_msg">
                <p class="title">상위코드를 먼저 선택해 주세요</p>
              </div>
              <div class="editable_table type_01 downer_table_left">
                <q-table
                  :rows="upper_choice_rows"
                  :columns="upper_choice_columns"
                  row-key="code"
                  v-model:pagination="upper_choice_pagination"
                  hide-pagination
                  separator="cell"
                  class="scrollable"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="systemSelect" class="system_select">
                        {{ props.row.systemSelect }}
                      </q-td>
                      <q-td key="upperCodeSelect" class="upper_code_select">
                        {{ props.row.upperCodeSelect }}
                      </q-td>
                      <q-td key="code" class="code">
                        {{ props.row.code }}
                      </q-td>
                      <q-td key="name">
                        {{ props.row.name }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 상위코드 선택 table -->
            </div>
            <div class="col_right">
              <!-- 하위코드 editable_table -->
              <div class="editable_table type_01 downer_table_right">
                <div class="btn_area">
                  <q-btn
                    class="size_sm btn_row_add"
                    icon="ion-ios-add"
                    dense
                    outline
                    label="행추가"
                  />
                  <!-- <q-btn
                    class="size_sm row_up"
                    color="grey-9"
                    icon="keyboard_arrow_up"
                    dense
                    outline
                    label="위로 이동"
                  />
                  <q-btn
                    class="size_sm row_down"
                    color="grey-9"
                    icon="keyboard_arrow_down"
                    dense
                    outline
                    label="아래로 이동"
                  /> -->
                  <!-- <q-btn
                    class="size_sm row_remove"
                    color="grey-9"
                    icon="ion-ios-remove"
                    dense
                    outline
                    label="행삭제"
                  /> -->
                  <q-space />
                  <q-btn class="size_sm btn_cancel" unelevated label="취소" />
                  <q-btn class="size_sm btn_save" unelevated label="저장" />
                </div>
                <q-table
                  :rows="downer_rows"
                  :columns="downer_columns"
                  row-key="code"
                  v-model:selected="downer_selected"
                  selection="multiple"
                  v-model:pagination="downer_pagination"
                  hide-pagination
                  separator="cell"
                  class="scrollable"
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td class="select">
                        <template v-if="props.row.state == 'add'">
                          <q-btn
                            icon="ion-ios-close"
                            dense
                            flat
                            label=""
                            size="36px"
                          />
                        </template>
                        <template v-else>
                          <q-checkbox
                            v-model="props.selected"
                            color="negative"
                          />
                        </template>
                      </q-td>
                      <q-td key="code" class="code hasinput">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.code"
                            :error="props.row.code.sample_err"
                            dense
                            placeholder="코드 입력"
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.code }}
                          <q-popup-edit
                            v-model="props.row.code"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" dense autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="name" class="code_name hasinput">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.name"
                            :error="props.row.name.sample_err"
                            dense
                            placeholder="코드명 입력"
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.name }}
                          <q-popup-edit
                            v-model="props.row.name"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" dense autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="idx" class="index hasinput">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.idx"
                            :error="props.row.idx.sample_err"
                            dense
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.idx }}
                          <q-popup-edit
                            v-model="props.row.idx"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="state" class="state">
                        <template v-if="props.row.state == 'edit'">
                          <q-icon name="done"></q-icon>
                          {{ tdState(props.row.state) }}
                        </template>
                        <template v-else>
                          {{ tdState(props.row.state) }}
                        </template>
                      </q-td>
                      <q-td key="allow" :props="props" class="allow">
                        <q-toggle v-model="props.row.allow" color="black" />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 하위코드 editable_table -->
            </div>
          </div>
        </q-tab-panel>
        <!--// 하위코드 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
// const tab = ref('upper');
const tab = ref('downer');
// dropdown
const sysSelect = ref('');
const sysSelectOption = ref([
  {
    id: '',
    desc: '시스템 유형을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: '',
    desc: '코드 유형을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
// serchbox input
const keyword = ref('');
// tab upper
//상위코드 edit_table데이터
const selected = ref([]);
const columns = ref([
  {
    name: 'systemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const rows = ref([
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_01',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_02',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_03',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_05',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_06',
    name: 'name_SALE_001',
    state: 'edit',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_07',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_08',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_09',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_10',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_11',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_12',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_13',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_14',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_15',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_16',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
]);
const SystemSelectionOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '시스템 눈높이(N)',
  },
  {
    id: 'G',
    desc: '시스템 학원(G)',
  },
  {
    id: 'C',
    desc: '시스템 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '시스템 MOS(M)',
  },
]);
const UppercodeSelectionOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '상위 눈높이(N)',
  },
  {
    id: 'G',
    desc: '상위 학원(G)',
  },
  {
    id: 'C',
    desc: '상위 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '상위 MOS(M)',
  },
]);
const pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

// tab downer
//하위코드 edit_ table데이터

const downer_selected = ref([]);
const downer_columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'idx',
    label: '순서',
    field: 'idx',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const downer_rows = ref([
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_01',
    name: 'name_SALE_001',
    idx: '',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_02',
    upperCodeSelect: '상위 CODE TYPE_02',
    code: 'CODE_02',
    name: 'name_SALE_002',
    idx: '',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_03',
    upperCodeSelect: '상위 CODE TYPE_03',
    code: 'CODE_03',
    name: 'name_SALE_003',
    idx: '',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_04',
    upperCodeSelect: '상위 CODE TYPE_04',
    code: 'CODE_04',
    name: 'name_SALE_004',
    idx: '',
    state: 'add',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_05',
    upperCodeSelect: '상위 CODE TYPE_05',
    code: 'CODE_05',
    name: 'name_SALE_005',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_06',
    upperCodeSelect: '상위 CODE TYPE_06',
    code: 'CODE_06',
    name: 'name_SALE_006',
    idx: '',
    state: 'edit',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_07',
    upperCodeSelect: '상위 CODE TYPE_07',
    code: 'CODE_07',
    name: 'name_SALE_007',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_08',
    upperCodeSelect: '상위 CODE TYPE_08',
    code: 'CODE_08',
    name: 'name_SALE_008',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_09',
    upperCodeSelect: '상위 CODE TYPE_09',
    code: 'CODE_09',
    name: 'name_SALE_009',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_10',
    upperCodeSelect: '상위 CODE TYPE_10',
    code: 'CODE_10',
    name: 'name_SALE_010',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_11',
    upperCodeSelect: '상위 CODE TYPE_11',
    code: 'CODE_11',
    name: 'name_SALE_011',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_12',
    upperCodeSelect: '상위 CODE TYPE_12',
    code: 'CODE_12',
    name: 'name_SALE_012',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_13',
    upperCodeSelect: '상위 CODE TYPE_13',
    code: 'CODE_13',
    name: 'name_SALE_013',
    idx: '',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_14',
    upperCodeSelect: '상위 CODE TYPE_14',
    code: 'CODE_14',
    name: 'name_SALE_014',
    idx: '14',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_15',
    upperCodeSelect: '상위 CODE TYPE_15',
    code: 'CODE_15',
    name: 'name_SALE_015',
    idx: '15',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_16',
    upperCodeSelect: '상위 CODE TYPE_16',
    code: 'CODE_16',
    name: 'name_SALE_016',
    idx: '16',
    state: '',
    allow: false,
  },
]);
const downer_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

//상위코드 선택 table 데이터
const upper_choice_columns = ref([
  {
    name: 'systemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
]);
const upper_choice_rows = ref([
  {
    systemSelect: '시스템 TYPE_01',
    upperCodeSelect: '상위 CODE TYPE_01',
    code: 'CODE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_02',
    upperCodeSelect: '상위 CODE TYPE_02',
    code: 'CODE_02',
    name: 'name_SALE_002',
    state: '',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_03',
    upperCodeSelect: '상위 CODE TYPE_03',
    code: 'CODE_03',
    name: 'name_SALE_003',
    state: '',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_04',
    upperCodeSelect: '상위 CODE TYPE_04',
    code: 'CODE_04',
    name: 'name_SALE_004',
    state: 'edit',
    allow: true,
  },
  {
    systemSelect: '시스템 TYPE_05',
    upperCodeSelect: '상위 CODE TYPE_05',
    code: 'CODE_05',
    name: 'name_SALE_005',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_06',
    upperCodeSelect: '상위 CODE TYPE_06',
    code: 'CODE_06',
    name: 'name_SALE_006',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_07',
    upperCodeSelect: '상위 CODE TYPE_07',
    code: 'CODE_07',
    name: 'name_SALE_007',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_08',
    upperCodeSelect: '상위 CODE TYPE_08',
    code: 'CODE_08',
    name: 'name_SALE_008',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_09',
    upperCodeSelect: '상위 CODE TYPE_09',
    code: 'CODE_09',
    name: 'name_SALE_009',
    state: '',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_10',
    upperCodeSelect: '상위 CODE TYPE_10',
    code: 'CODE_10',
    name: 'name_SALE_010',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_11',
    upperCodeSelect: '상위 CODE TYPE_11',
    code: 'CODE_11',
    name: 'name_SALE_11',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_12',
    upperCodeSelect: '상위 CODE TYPE_12',
    code: 'CODE_12',
    name: 'name_SALE_12',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_13',
    upperCodeSelect: '상위 CODE TYPE_13',
    code: 'CODE_13',
    name: 'name_SALE_013',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_14',
    upperCodeSelect: '상위 CODE TYPE_14',
    code: 'CODE_14',
    name: 'name_SALE_14',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_15',
    upperCodeSelect: '상위 CODE TYPE_15',
    code: 'CODE_15',
    name: 'name_SALE_15',
    state: 'add',
    allow: false,
  },
  {
    systemSelect: '시스템 TYPE_16',
    upperCodeSelect: '상위 CODE TYPE_16',
    code: 'CODE_16',
    name: 'name_SALE_16',
    state: 'add',
    allow: false,
  },
]);
const upper_choice_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

// td 상태값
function tdState(priority) {
  switch (priority) {
    case 'add':
      return '신규';
    case 'edit':
      return '수정중';
    default:
      return '';
  }
}
</script>
