<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">게시판 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content" style="overflow-x: auto">
          <div class="row-2">
            <!-- 테이블 -->
            <div class="w280">
              <h4 class="title1 mb24">게시판 양식 목록</h4>

              <div class="warp_orderboradbox">
                <q-input
                  class="inp_search"
                  outlined
                  dense
                  placeholder="게시판 양식명을 검색하세요"
                  v-model="dataInput"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
                <q-list dense bordered padding class="orderborad small">
                  <q-item>
                    <q-item-section>
                      <q-checkbox
                        v-model="dataCheck.check1"
                        val="primary"
                        color="black"
                      >
                        <q-item-label class="text-black text-body2"
                          >양식 제목</q-item-label
                        ></q-checkbox
                      >
                    </q-item-section>
                  </q-item>
                  <q-item>
                    <q-item-section>
                      <q-checkbox
                        v-model="dataCheck.check2"
                        val="primary"
                        color="black"
                      >
                        <q-item-label class="text-black text-body2"
                          >연차신청서</q-item-label
                        ></q-checkbox
                      >
                    </q-item-section>
                  </q-item>
                  <q-item>
                    <q-item-section>
                      <q-checkbox
                        v-model="dataCheck.check3"
                        val="primary"
                        color="black"
                      >
                        <q-item-label class="text-black text-body2"
                          >test1</q-item-label
                        ></q-checkbox
                      >
                    </q-item-section>
                  </q-item>
                  <q-item>
                    <q-item-section>
                      <q-checkbox
                        v-model="dataCheck.check4"
                        val="primary"
                        color="black"
                      >
                        <q-item-label class="text-black text-body2"
                          >test2</q-item-label
                        ></q-checkbox
                      >
                    </q-item-section>
                  </q-item>
                  <q-item>
                    <q-item-section>
                      <q-checkbox
                        v-model="dataCheck.check5"
                        val="primary"
                        color="black"
                      >
                        <q-item-label class="text-black text-body2"
                          >test3</q-item-label
                        ></q-checkbox
                      >
                    </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>
            <!-- // 테이블 -->

            <!-- 테이블 -->
            <div class="w440">
              <h4 class="title1 mb24">선택된 게시판 양식 보기</h4>
              <div class="warp_orderboradbox">
                <q-list dense bordered padding class="orderborad bg_white">
                  <q-item>
                    <q-item-section> test01 </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>
            <!-- // 테이블 -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
const dataInput = ref('');
const dataCheck = ref({
  check1: false,
  check2: false,
  check3: true,
  check4: true,
  check5: true,
});
</script>
<style lang="scss" scoped>
.control_box {
  .q-btn.btn_tbl_add {
    width: 72px;
    padding: 0;
  }
}
.w280 {
  width: 280px;
}
.w440 {
  width: 440px;
}
.warp_orderboradbox {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 360px;
  .orderborad {
    border-radius: 6px;
    display: block;
    min-height: 360px;
    padding: 24px 20px;
    background: #f7f7f7;
    overflow: auto;
    overflow-x: hidden;
    &.bg_white {
      background: #fff;
    }
    &.small {
      min-height: 304px;
      height: 304px;
    }
    .q-item {
      padding: 0;
      .q-btn.inner_oderbox {
        font-size: 16px;
        align-items: flex-start;
        flex-direction: column;
        color: #262626;
        line-height: 18px;
        margin-bottom: 4px;
        padding: 5px 6px;
        &.on {
          background: #ededed;
          border-radius: 4px;
        }
      }
    }
  }
}
</style>
