<template>
  <!-- dialog -->
  <q-dialog v-model="popCategory" @hide="popForm = true">
    <q-card class="flex column justify-between" style="flex-wrap: nowrap">
      <q-card-section class="dialog_title" align="left">
        공지사항 등록
      </q-card-section>
      <q-card-section
        class="q-pt-none dialog_content"
        align="center"
        style="
          height: calc(100vh - 380px);
          overflow-y: auto;
          margin-bottom: 30px;
        "
      >
        <q-tree
          :nodes="tree_data"
          node-key="id"
          selected-color="primary"
          class=""
          v-model:selected="tree_selected"
          default-expand-all
          @update:selected="temp(tree_selected)"
        />
      </q-card-section>
      <q-card-actions align="center" class="row item-end">
        <q-btn
          unelevated
          v-close-popup
          color="grey-4"
          text-color="white"
          class="size_sm cancel"
          label="취소"
        />
        <q-btn
          unelevated
          v-close-popup
          color="positive"
          text-color="white"
          class="size_sm confirm"
          label="확인"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>

  <!--// dialog -->
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popCategory = ref(true);

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: 'home',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const tree_selected = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
</script>
