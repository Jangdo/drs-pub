<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">팝업공지등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">팝업 기간</span>
                  <div class="as_dd space10">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <q-select
                      style="width: 110px"
                      outlined
                      dense
                      v-model="dataFrom.selectStartTime"
                      :options="selectTimeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                    <span>~</span>
                    <div class="search_item">
                      <q-input
                        outlined
                        v-model="searchDate.to"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.to"
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                    <q-select
                      style="width: 110px"
                      outlined
                      dense
                      v-model="dataFrom.selectEndTime"
                      :options="selectTimeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                  </div>
                </div>
              </div>
            </li>

            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">팝업창 위치</span>
                  <q-select
                    class="as_dd"
                    outlined
                    dense
                    v-model="dataFrom.dialogPosition"
                    :options="dialogPositionOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dropdown-icon="ion-ios-arrow-down"
                  ></q-select>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">팝업 사이즈</span>
                  <div class="as_dd inner_col2">
                    <div class="row">
                      <span class="inner_title">Width</span>
                      <div class="inner_data">
                        <q-input
                          style="width: 140px"
                          v-model="dataFrom.width"
                          class="as_dd hide_label"
                          label="width"
                          outlined
                          placeholder="800"
                          stack-label
                          dense
                        >
                          <template v-slot:label>width</template>
                        </q-input>
                        <span class="text-gray1 ml10">px</span>
                      </div>
                    </div>
                    <div class="row">
                      <span class="inner_title">Height</span>
                      <div class="inner_data">
                        <q-input
                          style="width: 140px"
                          v-model="dataFrom.height"
                          class="as_dd hide_label"
                          label="width"
                          outlined
                          placeholder="800"
                          stack-label
                          dense
                        >
                          <template v-slot:label>height</template>
                        </q-input>
                        <span class="text-gray1 ml10">px</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">팝업 오픈설정</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="항상"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="최초1회"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
const selectTimeOption = ref([
  {
    id: 'type00',
    desc: '오전 9시',
  },
  {
    id: 'type01',
    desc: '오전 11시',
  },
  {
    id: 'type02',
    desc: '오전 12시',
  },
  {
    id: 'type03',
    desc: '오후 1시',
  },
  {
    id: 'type04',
    desc: '오후 2시',
  },
  {
    id: 'type05',
    desc: '오후 3시',
  },
  {
    id: 'type06',
    desc: '오후 4시',
  },
  {
    id: 'type07',
    desc: '오후 5시',
  },
  {
    id: 'type08',
    desc: '오후 6시',
  },
]);
const dialogPositionOption = ref([
  {
    id: 'type00',
    desc: '중앙',
  },
  {
    id: 'type01',
    desc: '상단 중앙',
  },
  {
    id: 'type02',
    desc: '상단 왼쪽',
  },
  {
    id: 'type03',
    desc: '상단 오른쪽',
  },
]);
const dataFrom = ref({
  selectStartTime: 'type00',
  selectEndTime: 'type00',
  dialogPosition: '위치를 선택하세요',
  width: '800',
  height: '800',
  allow: 'true',
});
</script>

<style lang="scss" scoped></style>
