<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">일정등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-6">
                  <q-input
                    class="box_l inp_search"
                    for=""
                    outlined
                    dense
                    placeholder="양식명을 입력하세요"
                  />
                </div>
                <div class="col-12 col-md-6">
                  <q-input
                    class="box_l inp_search"
                    for=""
                    outlined
                    dense
                    placeholder="메뉴명을 입력하세요"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!--table -->
          <q-table
            class="before_table scrollable"
            :rows="scheduleRows"
            :columns="scheduleColumns"
            row-key="code"
            :pagination="initialPagination"
            selection="multi"
            v-model:selected="scheduleSelected"
            separator="cell"
            hide-pagination
            hide-bottom
          >
            <template v-slot:header-selection="scope">
              <q-toggle v-model="scope.selected" v-if="false" />
            </template>
          </q-table>
          <!--// table -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

//  table
const scheduleColumns = ref([
  {
    name: 'code',
    label: '코드',
    align: 'center',
    sortable: false,
    field: (row) => row.code,
  },
  {
    name: 'name',
    label: '코드명',
    align: 'center',
    field: 'name',
    sortable: false,
  },
  {
    name: 'author',
    label: '등록자',
    align: 'center',
    field: 'author',
    sortable: false,
  },
]);

const scheduleRows = ref([
  {
    code: 'SALE_001',
    name: '공휴일',
    author: '김길동',
  },
  {
    code: 'SALE_002',
    name: '공휴일',
    author: '김길동',
  },
  {
    code: 'SALE_003',
    name: '공휴일',
    author: '김길동',
  },
  {
    code: 'SALE_004',
    name: '공휴일',
    author: '김길동',
  },
  {
    code: 'SALE_005',
    name: '공휴일',
    author: '김길동',
  },
  {
    code: 'SALE_006',
    name: '공휴일',
    author: '김길동',
  },
]);
const initialPagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const scheduleSelected = ref([]);
</script>
