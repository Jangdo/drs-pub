<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">메시지(알림)관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <table class="table_row_admin">
        <colgroup>
          <col style="width: 180px" />
          <col />
          <col style="width: 180px" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th class="required">제목</th>
            <td colspan="3">
              <q-input
                class="box_xl inp_search"
                outlined
                placeholder="제목을 입력하세요"
              >
              </q-input>
            </td>
          </tr>
          <tr>
            <th class="required">발송구분</th>
            <td colspan="3">
              <q-option-group
                v-model="typeGroup"
                :options="typeOptions"
                color="black"
                inline
              />
            </td>
          </tr>
          <tr>
            <th>대상</th>
            <td>
              <div class="row justify-between">
                <!--
                  메시지 수정인 경우 노출
                  <p>1명</p>
                -->
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_sm"
                  label="대상선택"
                />
              </div>
            </td>
            <th class="line_l">직책</th>
            <td>
              <q-option-group
                v-model="positionGroup"
                :options="positionOptions"
                color="black"
                type="checkbox"
                inline
              />
            </td>
          </tr>
          <tr>
            <th>발송 URL</th>
            <td>
              <q-btn
                unelevated
                color="grey-2"
                class="size_sm"
                label="발송 URL찾기"
              />
            </td>
            <th class="line_l">분야</th>
            <td>
              <!-- 드롭다운 -->
              <div class="search_item type_fix_full">
                <q-select
                  class=""
                  v-model="searchBranchType"
                  :options="searchBranchTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  multiple
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <!-- // 드롭다운 -->
            </td>
          </tr>
          <tr>
            <th>메시지 알림 이미지</th>
            <td colspan="3">test.jpg</td>
          </tr>
          <tr>
            <th>예약발송</th>
            <td colspan="3">
              <div class="row">
                <q-checkbox v-model="revCheck" color="black" dense />
                <!-- 달력 -->
                <div class="search_item ml10">
                  <q-input
                    outlined
                    v-model="searchDate.to"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.to"
                            @update:model-value="
                              searchDate.to, $refs.qDateProxyTo.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
                <!-- // 달력 -->

                <!-- 발송시간 설정 -->
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="예약 발송 시간을 4자리로 입력하세요"
                  >
                  </q-input>
                </div>
                <!-- // 발송시간 설정 -->
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline color="grey-4" class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="발송" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// 발송구분
const typeGroup = ref('op1');
const typeOptions = ref([
  {
    label: '공지',
    value: 'op1',
  },
  {
    label: '지식정보',
    value: 'op2',
  },
  {
    label: '설문조사',
    value: 'op3',
  },
]);

// 직책
const positionGroup = ref([]);
const positionOptions = ref([
  {
    label: '국장',
    value: 'op1',
  },
  {
    label: '팀장',
    value: 'op2',
  },
  {
    label: '교사',
    value: 'op3',
  },
]);

const searchBranchType = ref(['분야를 선택하세요']);
const searchBranchTypeOption = ref([
  {
    id: 'type1',
    desc: '분야1',
  },
  {
    id: 'type2',
    desc: '분야2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});

const revCheck = ref(true);
</script>
