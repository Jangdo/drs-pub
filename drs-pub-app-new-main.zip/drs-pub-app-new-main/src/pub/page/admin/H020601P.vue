<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한변경 - 서북지원팀 홍길동</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <!-- table_search_area type_03 -->
          <div class="table_search_area type_03">
            <!-- <h3>권한명 입력</h3> -->
            <q-input
              class="inp_search"
              for=""
              outlined
              dense
              v-model="authorSearch"
              placeholder="권한명을 입력하여 검색하세요"
            />
            <div class="btn_area">
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <!--// table_search_area type_03 -->
          <div class="wrap_tree_table">
            <!-- sm_area 트리 영역 -->
            <div class="sm_area">
              <div class="tree_container">
                <q-tree
                  :nodes="tree_data"
                  node-key="id"
                  selected-color="primary"
                  class="category popup_tree"
                  v-model:selected="tree_selected"
                  default-expand-all
                  @update:selected="temp(tree_selected)"
                />
              </div>
            </div>
            <!--// sm_area 트리 영역 -->
            <!-- main_area 테이블 영역 -->
            <div class="main_area">
              <!-- wrap_table_column 세로 type -->
              <div class="wrap_table_column">
                <!-- selectable_table -->
                <div class="selectable_table">
                  <q-table
                    :rows="settingUserRows"
                    :columns="settingUserColumns"
                    row-key="idx"
                    v-model:selected="settingUserSelected"
                    selection="multiple"
                    hide-bottom
                    hide-pagination
                    v-model:pagination="settingUser_pagination"
                    separator="cell"
                    class="scrollable"
                  >
                    <template v-slot:header="props">
                      <q-tr :props="props">
                        <q-th class="select"
                          ><q-checkbox v-model="props.selected" color="black"
                        /></q-th>
                        <q-th class="">카테고리</q-th>
                        <q-th class="">권한명</q-th>
                      </q-tr>
                    </template>
                    <template v-slot:body="props">
                      <q-tr :props="props">
                        <q-td class="select"
                          ><q-checkbox v-model="props.selected" color="black"
                        /></q-td>
                        <q-td key="category" class="categoryquarters">{{
                          props.row.category
                        }}</q-td>
                        <q-td key="name" class="authority_name">
                          {{ props.row.name }}</q-td
                        >
                      </q-tr>
                    </template>
                  </q-table>
                </div>
                <div class="tbl_btn_group">
                  <q-space />
                  <div class="btn_area">
                    <q-btn class="size_sm" outline label="추가" />
                    <q-btn class="size_sm" outline label="삭제" />
                  </div>
                </div>
                <!--// selectable_table-->
                <div class="wrap_select_list">
                  <ul class="select_list">
                    <li
                      :class="item.state"
                      v-for="(item, index) in selectedData"
                      :key="index"
                    >
                      {{ item.category }} > {{ item.name }}
                    </li>
                  </ul>
                </div>
              </div>
              <!-- //wrap_table_column 세로 type -->
            </div>
            <!--// main_area 테이블 영역 -->
          </div>
          <q-separator class="popup_btm_line" />
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// menu

const authorSearch = ref('');
// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

//settingUser_table데이터
//authority_table데이터
const settingUserSelected = ref([]);

const settingUserColumns = ref([
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'name',
    label: '권한명',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
]);
const settingUserRows = ref([
  { idx: '1', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '2', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '3', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '4', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '5', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '6', category: '시스템관리자', name: '인사회계_개발자' },
]);
// selectedData
const selectedData = ref([
  { idx: '1', category: '시스템관리자', name: '인사회계_개발자', state: 'add' },
  { idx: '2', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '3', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '4', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '5', category: '시스템관리자', name: '인사회계_개발자' },
  { idx: '6', category: '시스템관리자', name: '인사회계_개발자' },
]);

const settingUser_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});
</script>
