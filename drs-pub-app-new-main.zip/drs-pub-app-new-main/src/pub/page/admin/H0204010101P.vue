<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 middle">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한그룹 등록/수정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales w120_pc mb0">
            <tbody>
              <tr>
                <th>카테고리</th>
                <td>
                  <div class="search_item type_full">
                    <q-select
                      class="hide_label"
                      label="전체"
                      v-model="categorySelected"
                      :options="categorySelectedOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>권한코드</th>
                <td>
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="keyword"
                      placeholder="입력하세요"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>권한명</th>
                <td>
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="keyword2"
                      placeholder="입력하세요"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>권한설명</th>
                <td>
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="keyword3"
                      placeholder="입력하세요"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>리드온니 타입</th>
                <td>
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      placeholder="입력하세요"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>사용여부</th>
                <td>
                  <q-option-group
                    v-model="useGroup"
                    :options="useGroupOptions"
                    color="black"
                    inline
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const categorySelected = ref(['']);
const categorySelectedOption = ref([
  {
    id: 's1',
    desc: '시스템 운영1',
  },
  {
    id: 's2',
    desc: '시스템 운영2',
  },
]);

// radio group
const useGroup = ref('op1');
const useGroupOptions = ref([
  {
    label: '사용',
    value: 'op1',
  },
  {
    label: '미사용',
    value: 'op2',
  },
]);

const keyword = ref('0012');
const keyword2 = ref('제작매체_운영자');
const keyword3 = ref('제작매체 관련 시스템을 담당');
</script>
