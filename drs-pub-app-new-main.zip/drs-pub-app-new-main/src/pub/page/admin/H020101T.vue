<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">사용자정보관리</h2>
      <Breadcrumbs />
    </div>

    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-12">
            <div class="search_group">
              <!-- 검색팝업 완료시 class placeholder 삭제 -->
              <div class="placeholder">
                <span>부문</span>
                <span>본부</span>
                <span>조직</span>
                <span>팀</span>
                <span>채널</span>
                <span>선생님</span>
              </div>
              <q-icon name="icon-search" class="icon_svg" />
            </div>
          </div>
        </div>
        <div class="row q-col-gutter-sm" v-if="stateHandle">
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="가입유형 전체"
              v-model="sysSelect"
              :options="sysSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="사용유무 전체"
              v-model="authoritySelect"
              :options="authoritySelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="inp_search full-width"
              outlined
              dense
              placeholder="권한"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="inp_search full-width"
              outlined
              dense
              placeholder="ID/성함"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>
    <q-btn
      class="btn_search_handle"
      fill
      color="grey-5"
      unelevated
      @click="actionHandle"
    >
      <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
      <q-icon color="white" name="ion-ios-arrow-down" v-else />
    </q-btn>

    <div class="wrap_table_box">
      <!-- selectable_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" outline label="선택삭제" />
            <q-btn class="size_sm" unelevated color="black" label="신규등록" />
          </div>
        </div>
        <q-table
          :rows="sysUserRows"
          :columns="sysUserColumns"
          row-key="idx"
          v-model:selected="sysUserSelected"
          selection="multiple"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th><q-checkbox v-model="props.selected" color="black" /></q-th>
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-td>
              <q-td key="idx" class="idx">{{ props.row.idx }}</q-td>
              <q-td key="id" class="login_id">{{ props.row.id }}</q-td>
              <q-td key="userNumber" class="user_number">{{
                props.row.userNumber
              }}</q-td>
              <q-td key="name" class="menu_name"> {{ props.row.name }}</q-td>
              <q-td key="site" class="site"> {{ props.row.site }}</q-td>
              <q-td key="group" class="authorization_group">{{
                props.row.group
              }}</q-td>
              <q-td key="workPart" class="business_part">{{
                props.row.workPart
              }}</q-td>
              <q-td key="workTeam" class="business_team">{{
                props.row.workTeam
              }}</q-td>
              <q-td key="accessDate" class="last_access">
                {{ props.row.accessDate }}</q-td
              >
              <q-td key="allow" class="allow">
                <q-toggle
                  v-model="props.row.allow"
                  class="custom_tgl"
                  color="black"
                />
              </q-td>
              <q-td key="btn" :props="props" class="hasbtn">
                <q-btn
                  outline
                  class="size_xxs btn_detail_view"
                  label="보기"
                  @click="tableEvt(props.row.idx)"
                >
                </q-btn>
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!--// selectable_table -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const authoritySelect = ref('');
const authoritySelectOption = ref([
  {
    id: 'N',
    desc: '선생님(N)',
  },
  {
    id: 'G',
    desc: '선생님1(G)',
  },
  {
    id: 'C',
    desc: '임시(C) ',
  },
  {
    id: 'M',
    desc: '임시2(M)',
  },
]);
const sysSelect = ref('');
const sysSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이 교사 SITE(N)',
  },
  {
    id: 'G',
    desc: '학원 SITE(G)',
  },
  {
    id: 'C',
    desc: '공통코드 SITE(C) ',
  },
  {
    id: 'M',
    desc: 'MOS (M)',
  },
]);
//sys_user_tab table데이터
const sysUserSelected = ref([]);
const sysUserColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
  },
  {
    name: 'id',
    label: '로그인ID',
    sortable: false,
    align: 'center',
  },
  {
    name: 'userNumber',
    label: '고객번호',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    label: '이름',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'site',
    label: '사이트',
    sortable: false,
    align: 'center',
  },
  {
    name: 'group',
    label: '권한그룹',
    sortable: false,
    align: 'center',
  },
  {
    name: 'workPart',
    label: '사업부',
    sortable: false,
    align: 'center',
  },
  {
    name: 'workTeam',
    label: '사업팁',
    sortable: false,
    align: 'center',
  },
  {
    name: 'accessDate',
    label: '최근접속일',
    sortable: false,
    align: 'center',
  },
  {
    name: 'allow',
    label: '사용여부',
    field: 'allow',
    sortable: false,
    align: 'center',
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const sysUserRows = ref([
  {
    idx: '100',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: true,
  },
  {
    idx: '99',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: true,
  },
  {
    idx: '98',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: false,
  },
  {
    idx: '97',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: false,
  },
  {
    idx: '96',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: false,
  },
  {
    idx: '95',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: false,
  },
  {
    idx: '94',
    id: 'test12345',
    userNumber: '123456789',
    name: '홍길동',
    site: '눈높이 교사 SITE',
    group: '선생님',
    workPart: '사업부',
    workTeam: '사업팀',
    accessDate: '2022.02.10  13:00',
    allow: false,
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
// tab teacher_tab

function tableEvt(id) {
  console.log('테이블  인덱스 :' + id + '상세보기');
}

const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
<style>
.colum {
  display: flex;
  flex-direction: row;
}
</style>
