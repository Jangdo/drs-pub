<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">
            말머리 등록<!-- 수정일 경우 타이틀 : 말머리 수정 -->
          </h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales border_t_grey mb0">
            <tbody>
              <tr>
                <th>말머리명</th>
                <td>
                  <div class="search_item">
                    <q-input
                      class="w280"
                      for=""
                      outlined
                      dense
                      v-model="keyword"
                      placeholder="말머리명을 입력하세요"
                    >
                    </q-input>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            outline
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const keyword = ref('');
</script>
