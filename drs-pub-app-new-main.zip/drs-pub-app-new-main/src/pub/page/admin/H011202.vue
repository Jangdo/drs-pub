<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">공지사항관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <!-- sales_subtit_area -->
      <div class="sales_subtit_area">
        <h3 class="title1">공지사항 등록</h3>
      </div>
      <!-- //sales_subtit_area -->

      <table class="table_row_admin mb30">
        <colgroup>
          <col style="width: 180px" />
          <col />
          <col style="width: 180px" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th><span class="required">브랜드</span></th>
            <td colspan="3">
              <div class="row-4">
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck.check1"
                  label="눈높이"
                  color="black"
                  dense
                />
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck.check2"
                  label="차이홍"
                  color="black"
                  dense
                />
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck.check3"
                  label="LC"
                  color="black"
                  dense
                />
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="required">제목</span></th>
            <td colspan="3">
              <q-input
                class="inp_search"
                outlined
                dense
                placeholder="입력하세요"
                v-model="inpClear"
              >
              </q-input>
            </td>
          </tr>
          <tr>
            <th><span class="required">중요공지</span></th>
            <td>
              <div class="row-4">
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck2.check1"
                  label="긴급"
                  color="black"
                  dense
                />
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck2.check2"
                  label="공지"
                  color="black"
                  dense
                />
              </div>
            </td>
            <th><span class="">팝업공지</span></th>
            <td>
              <div class="row-4">
                <q-radio
                  class="mr10"
                  v-model="dataRadio"
                  val="true"
                  label="사용"
                  color="black"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  dense
                />
                <q-radio
                  class="mr10"
                  v-model="dataRadio"
                  val="false"
                  label="사용안함"
                  color="black"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  dense
                />
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="">내용</span></th>
            <td colspan="3">
              <q-editor
                v-model="qeditor"
                :toolbar="[
                  [
                    {
                      label: $q.lang.editor.align,
                      icon: $q.iconSet.editor.align,
                      fixedLabel: true,
                      // list: 'only-icons',
                      options: ['left', 'center', 'right', 'justify'],
                    },
                  ],
                  [
                    'bold',
                    'italic',
                    'strike',
                    'underline',
                    'subscript',
                    'superscript',
                  ],
                  ['token', 'hr', 'link', 'custom_btn'],
                  ['print', 'fullscreen'],
                  [
                    {
                      label: $q.lang.editor.formatting,
                      icon: $q.iconSet.editor.formatting,
                      list: 'no-icons',
                      options: [
                        'p',
                        'h1',
                        'h2',
                        'h3',
                        'h4',
                        'h5',
                        'h6',
                        'code',
                      ],
                    },
                    {
                      label: $q.lang.editor.fontSize,
                      icon: $q.iconSet.editor.fontSize,
                      fixedLabel: true,
                      fixedIcon: true,
                      list: 'no-icons',
                      options: [
                        'size-1',
                        'size-2',
                        'size-3',
                        'size-4',
                        'size-5',
                        'size-6',
                        'size-7',
                      ],
                    },
                    {
                      label: $q.lang.editor.defaultFont,
                      icon: $q.iconSet.editor.font,
                      fixedIcon: true,
                      list: 'no-icons',
                      options: [
                        'default_font',
                        'arial',
                        'arial_black',
                        'comic_sans',
                        'courier_new',
                        'impact',
                        'lucida_grande',
                        'times_new_roman',
                        'verdana',
                      ],
                    },
                    'removeFormat',
                  ],
                  ['undo', 'redo'],
                  ['viewsource'],
                ]"
                :fonts="{
                  arial: 'Arial',
                  arial_black: 'Arial Black',
                  comic_sans: 'Comic Sans MS',
                  courier_new: 'Courier New',
                  impact: 'Impact',
                  lucida_grande: 'Lucida Grande',
                  times_new_roman: 'Times New Roman',
                  verdana: 'Verdana',
                }"
              />
            </td>
          </tr>
          <tr>
            <th>첨부파일</th>
            <td colspan="3">
              <div class="row-4">
                <div class="search_item type_large">
                  <q-input
                    v-model="searchInput"
                    class=""
                    placeholder="입력하세요"
                    outlined
                  />
                </div>
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_sm"
                  label="파일 업로드"
                />
              </div>
              <div class="row mt10">
                <q-icon name="icon-info02" class="icon_svg"></q-icon>
                <span class="ml4">
                  500MB 이하 용량 / doc, docx, hwp 파일만 등록 가능합니다.
                </span>
              </div>
              <ul class="attach_file_list mt30">
                <li v-for="(item, index) in files" :key="index">
                  <q-btn outline type="button" class="del_file">
                    {{ item.name }}
                  </q-btn>
                </li>
              </ul>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 하단 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
td + th {
  border-left: 1px solid #ddd;
}

.q-editor {
  height: 400px;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const inpClear = ref('');
const dataCheck = ref({
  check1: true,
  check2: false,
  check3: false,
});
const dataCheck2 = ref({
  check1: false,
  check2: false,
});
const dataRadio = ref('true');
const qeditor = ref('sample editor');
const files = ref([
  {
    name: 'document.hwp',
  },
  {
    name: 'document1.hwp',
  },
  {
    name: 'document3.hwp',
  },
]);
const searchInput = ref('');
</script>
