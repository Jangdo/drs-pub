<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">메뉴구조관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-select
              class=""
              label="메뉴를 선택하세요"
              v-model="menuSelect"
              :options="menuSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
              :class="[menuSelect == 0 ? 'placehoder' : '']"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-9">
            <q-input
              class="box_l"
              for=""
              outlined
              dense
              v-model="menuSearch"
              placeholder="메뉴명 or 메뉴ID를 입력하세요"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_divide wrap_table_box">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="btn_area">
          <q-btn
            fill
            unelevated
            class="size_sm btn_folder_add"
            icon="ion-ios-add"
            label="폴더추가"
          />
          <q-btn class="size_sm btn_folder_modify" outline label="폴더수정" />
          <q-btn class="size_sm btn_folder_delete" outline label="폴더삭제" />
        </div>
        <div class="tree_container">
          <q-tree
            :nodes="tree_data"
            node-key="id"
            selected-color="primary"
            class="category"
            v-model:selected="tree_selected"
            default-expand-all
            @update:selected="temp(tree_selected)"
          />
        </div>
      </div>
      <!--// sm_area 트리 영역 -->

      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- selectable_table type_01 -->
        <div class="selectable_table type_01">
          <div class="btn_area">
            <q-btn class="size_sm btn_delete" outline icon="" label="삭제" />
            <q-btn class="size_sm btn_write" outline icon="" label="신규등록" />
            <q-btn fill unelevated class="size_sm btn_save" label="저장" />
            <!-- <q-space /> -->
          </div>
          <q-table
            :rows="msgRows"
            :columns="msgColumns"
            row-key="code"
            v-model:selected="msgSelected"
            selection="multiple"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:header="props">
              <q-tr :props="props">
                <q-th class="select"
                  ><q-checkbox v-model="props.selected" color="black"
                /></q-th>
                <!-- <q-th class="">메뉴 경로</q-th>
                <q-th class="">메뉴 코드</q-th>
                <q-th class="">메뉴명</q-th>
                <q-th class="">등록자</q-th>
                <q-th class="">사용여부</q-th>
                <q-th class="">메뉴설정</q-th> -->
                <q-th v-for="col in props.cols" :key="col.name" :props="props">
                  {{ col.label }}
                </q-th>
              </q-tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td class="select">
                  <q-checkbox v-model="props.selected" color="black" />
                </q-td>
                <q-td key="path" class="path">{{ props.row.path }}</q-td>
                <q-td key="code" class="menu_code"> {{ props.row.code }}</q-td>
                <q-td key="name" class="name"> {{ props.row.name }}</q-td>
                <q-td key="author" class="author"> {{ props.row.author }}</q-td>
                <q-td key="allow" class="allow">
                  <q-toggle
                    v-model="props.row.allow"
                    class="custom_tgl"
                    color="black"
                  />
                </q-td>
                <q-td key="btn" :props="props" class="hasbtn">
                  <q-btn
                    outline
                    class="size_sm btn_detail_view"
                    label="설정"
                    @click="tableEvt(props.row.code)"
                  >
                  </q-btn>
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
        </div>
        <!--// selectable_table type_01-->
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: '',
    // avatar: '/icons/icon-tree-home.svg',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
              { id: 'a_5', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
            ],
          },
          { id: 'a_6', label: '뎁스3', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

// menu
const menuSelect = ref('');
const menuSelectOption = ref([
  // {
  //   id: '',
  //   desc: '메뉴를 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: 'N',
    desc: '메뉴(N)',
  },
  {
    id: 'G',
    desc: '메뉴(G)',
  },
  {
    id: 'C',
    desc: '메뉴(C) ',
  },
  {
    desc: '메뉴(M)',
  },
]);
const menuSearch = ref('');
// msgDialog
const msgDialog = ref({
  open: false,
  id: 0,
});

//msg_table데이터
const msgSelected = ref([]);
const msgColumns = ref([
  {
    name: 'path',
    label: '메뉴 경로',
    sortable: false,
    align: 'center',
    field: (row) => row.path,
  },
  {
    name: 'code',
    label: '메뉴 코드',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },
  {
    name: 'name',
    label: '메뉴명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'author',
    label: '등록자',
    field: 'author',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'allow',
    label: '사용여부',
    field: 'allow',
    sortable: false,
    align: 'center',
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '메뉴설정',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msgRows = ref([
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A001',
    name: '회원정보',
    author: '홍길동',
    allow: true,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A002',
    name: '회원정보',
    author: '홍길동',
    allow: true,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A003',
    name: '회원정보',
    author: '홍길동',
    allow: false,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A004',
    name: '회원정보',
    author: '홍길동',
    allow: false,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A005',
    name: '회원정보',
    author: '홍길동',
    allow: false,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A006',
    name: '회원정보',
    author: '홍길동',
    allow: false,
  },
  {
    path: '학습상담 > 내교실 > 회원정보',
    code: 'A007',
    name: '회원정보',
    author: '홍길동',
    allow: false,
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
  msgDialog.value.idx = id;
  msgDialog.value.open = true;
}
</script>
