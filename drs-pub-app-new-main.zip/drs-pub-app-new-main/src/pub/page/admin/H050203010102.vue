<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <table class="table_row_admin">
        <colgroup>
          <col width="168px" />
          <col width="auto" />
          <col width="168px" />
          <col width="auto" />
        </colgroup>
        <tbody>
          <tr>
            <th>
              <span class="required">제목</span>
            </th>
            <td colspan="3">
              <div class="">
                <q-input
                  class="inp_search"
                  outlined
                  placeholder="테이블명(물리)을 입력하세요"
                >
                </q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th>
              <span class="required">게시대상</span>
            </th>
            <td>
              <div class="">
                <q-btn
                  class="size_sm"
                  label="게시대상"
                  color="grey-2"
                  fill
                  unelevated
                ></q-btn>
              </div>
            </td>
            <th class="line_l">
              <span class="required">게시옵션</span>
            </th>
            <td>
              <div class="row">
                <q-checkbox
                  v-model="dataCheck.check1"
                  label="긴급"
                  color="black"
                />
                <q-checkbox
                  v-model="dataCheck.check2"
                  label="공지"
                  color="black"
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>
              <span class="required">게시예약일</span>
            </th>
            <td colspan="3">
              <div class="row">
                <q-checkbox
                  v-model="dataCheck.reserve"
                  label=""
                  color="black"
                />
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date ml_0 normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <q-select
                  class="w280 hide_label"
                  label="AM 12"
                  v-model="timeHours"
                  :options="timeHoursOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
                <q-select
                  class="w280 hide_label"
                  label="00"
                  v-model="timeMinute"
                  :options="timeMinuteOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="btn_area center">
        <q-btn
          fill
          unelevated
          color="grey-4"
          class="size_sm btn_cancel"
          label="취소"
        />
        <q-btn
          unelevated
          color="primary"
          class="size_sm btn_save"
          label="저장"
        />
        <q-btn outline class="size_sm btn_save" label="임시저장" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataCheck = ref({
  check1: true,
  check2: false,
  reserve: false,
});

const timeHours = ref(['']);
const timeHoursOption = ref([
  {
    id: 'type1',
    desc: 'AM 12',
  },
  {
    id: 'type2',
    desc: 'AM 01',
  },
  {
    id: 'type3',
    desc: 'AM 02',
  },
]);

const timeMinute = ref(['']);
const timeMinuteOption = ref([
  {
    id: 'type1',
    desc: '00',
  },
  {
    id: 'type2',
    desc: '01',
  },
  {
    id: 'type3',
    desc: '02',
  },
]);

const searchDate = ref({
  from: '2023.04.17',
  to: '2019.02.02',
});
</script>
