<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">담당자 지정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    label="부서"
                    :class="[dataSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-checkbox
                    class="ml10"
                    v-model="dataCheck.check1"
                    label="R"
                    color="black"
                  />
                  <q-checkbox
                    class="ml20"
                    v-model="dataCheck.check2"
                    label="W"
                    color="black"
                  />
                </div>
              </div>
            </div>
          </div>

          <div class="wrap_tree_table mt20">
            <!-- sm_area 트리 영역 -->
            <div class="sm_area w280">
              <div class="tree_container">
                <q-tree
                  :nodes="treeData"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree hastbltit"
                  v-model:selected="treeSelected"
                  default-expand-all
                  @update:selected="temp1(treeSelected)"
                  style="height: 348px"
                >
                </q-tree>
              </div>
            </div>
            <!--// sm_area 트리 영역 -->
            <div class="wrap_insert_table table_dk">
              <!-- btn_area -->
              <div class="btn_area pt0 pl0 mr10">
                <q-btn
                  class="size_sm"
                  dense
                  fill
                  unelevated
                  color="grey-3"
                  label="추가"
                />
                <q-btn
                  class="size_sm ml_0 mt10"
                  dense
                  fill
                  unelevated
                  color="grey-3"
                  label="삭제"
                />
              </div>
              <!--// btn_area -->
              <!-- set_user_table -->
              <q-table
                class="set_user_table scrollable sticky_table_header"
                :rows="rows"
                :columns="columns"
                row-key="idx"
                :pagination="initialPagination"
                selection="multiple"
                v-model:selected="selected"
                separator="cell"
                hide-pagination
                hide-bottom
              >
                <template v-slot:header-selection="scope">
                  <q-toggle v-model="scope.selected" v-if="false" />
                </template>
                <template v-slot:body-selection="scope">
                  <q-checkbox
                    v-model="scope.selected"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                    color="black"
                  />
                </template>
              </q-table>
              <!--// set_user_table -->
            </div>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            outline
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataSelect = ref(['부서 전체']);
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '부서 A(N)',
  },
  {
    id: 'G',
    desc: '부서 A(G)',
  },
  {
    id: 'C',
    desc: '부서 A(C) ',
  },
  {
    desc: '부서 A(M)',
  },
]);
const dataCheck = ref({
  check1: true,
  check2: true,
});
// tree
const treeData = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp1(target) {
  console.log('셀렉트 이벤트 발생', target);
}
//  table
const columns = ref([
  {
    name: 'tdata1',
    label: '상위조직',
    align: 'center',
    sortable: false,
    field: 'tdata1',
  },
  {
    name: 'tdata2',
    label: '타입',
    align: 'center',
    field: 'tdata2',
    sortable: false,
  },
  {
    name: 'tdata3',
    label: '조직명',
    align: 'center',
    field: 'tdata3',
    sortable: false,
  },
]);
const initialPagination = ref({
  sortBy: 'workerNumber',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const rows = ref([
  {
    idx: 1,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 2,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 3,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 4,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 5,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
  {
    idx: 6,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
]);

const selected = ref([
  {
    idx: 1,
    tdata1: '눈높이 > 본부 A > 교육국 A',
    tdata2: '교육국',
    tdata3: '교육국 A',
  },
]);
</script>
