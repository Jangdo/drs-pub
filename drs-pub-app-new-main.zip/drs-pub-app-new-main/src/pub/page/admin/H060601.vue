<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">말머리 관리</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_divide wrap_table_box">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="h40 mb16">
          <!-- 뭔가 들어올 수도 있는 영역이라고......... -->
        </div>
        <div class="tree_container">
          <q-tree
            :nodes="tree_data"
            node-key="id"
            selected-color="primary"
            class="category type_tbl10"
            v-model:selected="tree_selected"
            default-expand-all
            @update:selected="temp(tree_selected)"
            style="max-height: 580px; min-height: 580px"
          />
        </div>
      </div>
      <!--// sm_area 트리 영역 -->

      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- selectable_table type_01 -->
        <div class="table_dk mt10">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm" outline label="폴더 삭제" />
              <q-btn class="size_sm" outline label="폴더 수정" />
              <q-btn class="size_sm" outline label="폴더 등록" />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_sm"
                label="말머리 등록"
              />
            </div>
          </div>

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            hide-bottom
            hide-pagination
            separator="cell"
            class="scrollable sticky_table_header"
            :rows-per-page-options="[0]"
            style="max-height: 580px"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="text-left">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="edit" class="text-center">
                  <q-btn
                    outline
                    class="size_xxs btn_inner_table"
                    label="수정"
                  />
                </q-td>
                <q-td key="delete" class="text-center w150">
                  <q-btn
                    outline
                    class="size_xxs btn_inner_table"
                    label="삭제"
                  />
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '말머리 폴더',
    id: 'treeAll',
    icon: '',
    children: [
      {
        id: 'treeSub1',
        label: '말머리 그룹1',
        children: [
          {
            id: 'treeSub1_1',
            label: '하위1',
            children: [
              {
                id: 'treeSub1_1_1',
                label: '하위1_1',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'treeSub1_1_2',
                label: '하위1_2',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'treeSub1_2',
            label: '하위2',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '그룹2',
        id: 'treeSub2',
        children: [
          {
            label: '하위1',
            id: 'treeSub2_1',
            children: [
              { id: 'treeSub2_1_1', label: '하위1-1' },
              { id: 'treeSub2_1_2', label: '하위1-1' },
            ],
          },
          { id: 'treeSub2_2', label: '하위2' },
        ],
      },
      {
        label: '그룹3',
        id: 'treeSub3',
        children: [
          { id: 'treeSub3_1', label: '하위1' },
          { id: 'treeSub3_2', label: '하위2' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('말머리 폴더');

//data테이블

const dataColumns = ref([
  {
    name: 'tdata1',
    label: '말머리 폴더명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'edit',
    label: '수정',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'delete',
    label: '삭제',
    sortable: false,
    align: 'center',
    field: (row) => row.delete,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '말머리 테스트 1',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 9,
    tdata1: '말머리 테스트 말머리 테스트 말머리 테스트',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 10,
    tdata1: '말머리 테스트 1',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 9,
    tdata1: '말머리 테스트 말머리 테스트 말머리 테스트',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 10,
    tdata1: '말머리 테스트 1',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 9,
    tdata1: '말머리 테스트 말머리 테스트 말머리 테스트',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 10,
    tdata1: '말머리 테스트 1',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 9,
    tdata1: '말머리 테스트 말머리 테스트 말머리 테스트',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 8,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 7,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 6,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 5,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 4,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 3,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 2,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
  {
    idx: 1,
    tdata1: '말머리',
    tdata2: '홍길동',
    tdata3: '2022.11.01',
    edit: '',
    delete: '',
  },
]);
</script>
