<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">그룹별사용자관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-select
              class="box_m"
              v-model="userSelect"
              :options="userSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
              :class="[userSelect == 0 ? 'placehoder' : '']"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-9">
            <q-input
              class="box_xl inp_search"
              for=""
              outlined
              dense
              v-model="userSearch"
              placeholder="ID, 사용자명, 부서명을 입력하여 검색하세요"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box wrap_table_divide">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="btn_area">
          <q-btn
            fill
            unelevated
            class="size_sm btn_folder_add"
            icon="ion-ios-add"
            label="폴더추가"
          />
          <q-btn class="size_sm btn_folder_modify" outline label="폴더수정" />
          <q-btn class="size_sm btn_folder_delete" outline label="폴더삭제" />
        </div>
        <div class="tree_container">
          <q-tree
            :nodes="tree_data"
            node-key="id"
            selected-color="primary"
            class="category type_tbl_only type_tbl10"
            v-model:selected="tree_selected"
            default-expand-all
            @update:selected="temp(tree_selected)"
          />
        </div>
      </div>
      <!--// sm_area 트리 영역 -->

      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- general_table -->
        <div class="general_table type_01">
          <!-- <div class="btn_area">
            <q-btn
              class="size_sm btn_delete"
              outline
              icon="delete_outline"
              label="삭제"
            />
            <q-btn
              class="size_sm btn_new_add"
              outline
              icon="ion-ios-add"
              label="신규등록"
            />
            <q-btn
              fill
              unelevated
              class="size_sm btn_save"
              label="저장"
            />
          </div> -->
          <q-table
            :rows="userRows"
            :columns="userColumns"
            row-key="code"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
            class="mt60"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="path" class="idx">{{ props.row.idx }}</q-td>
                <q-td key="code" class="employee_number">
                  {{ props.row.code }}</q-td
                >
                <q-td key="local" class="branch"> {{ props.row.local }}</q-td>
                <q-td key="name" class="user_name"> {{ props.row.name }}</q-td>
                <q-td key="author" class="setting_authority">
                  {{ props.row.author }}</q-td
                >
                <q-td key="btnAuthor" class="hasbtn"
                  ><q-btn
                    outline
                    class="size_xs btn_detail_view"
                    label="변경"
                    @click="tableEvt(props.row.code, '변경')"
                  >
                  </q-btn
                ></q-td>
                <q-td key="btnHistory" :props="props" class="">
                  <q-btn
                    outline
                    class="size_xs btn_detail_view"
                    label="설정"
                    @click="tableEvt(props.row.code, '설정')"
                  >
                  </q-btn>
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
        </div>
        <!--// general_table -->
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

// menu
const userSelect = ref('');
const userSelectOption = ref([
  {
    id: '',
    desc: '사용자를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '사용자(N)',
  },
  {
    id: 'G',
    desc: '사용자(G)',
  },
  {
    id: 'C',
    desc: '사용자(C) ',
  },
  {
    desc: '사용자(M)',
  },
]);
const userSearch = ref('');
// msgDialog
const msgDialog = ref({
  open: false,
  id: 0,
});

const userColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'code',
    label: '사원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },
  {
    name: 'local',
    label: '지점',
    sortable: false,
    align: 'center',
    field: (row) => row.local,
  },

  {
    name: 'name',
    label: '이름',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'author',
    label: '설정권한',
    field: 'author',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'btnAuthor',
    label: '권한변경',
    align: 'center',
    sortable: false,
    field: (row) => row.btnAuthor,
  },
  {
    name: 'btnHistory',
    label: '권한이력',
    align: 'center',
    sortable: false,
    field: (row) => row.btnHistory,
  },
]);

const userRows = ref([
  {
    idx: 100,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 99,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 98,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 97,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 96,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 95,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 94,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 93,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 92,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 91,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 90,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 89,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
  {
    idx: 88,
    code: 'P057040001',
    local: '지점',
    name: '홍길동',
    author: '전사담당자, 온라인담당자',
  },
]);

const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id, txt) {
  console.log('테이블  id :' + id + txt + '보기');
  msgDialog.value.idx = id;
  msgDialog.value.open = true;
}
</script>
