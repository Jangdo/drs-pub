<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">팝업관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-4">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="boardName"
                placeholder="제목을 입력하세요"
              />
            </div>
            <div class="col-12 col-md-4">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="writer"
                placeholder="등록자를 입력하세요"
              />
            </div>
            <div class="col-12 col-md-4">
              <q-input
                outlined
                :model-value="searchDate.from + '~' + searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate"
                        range
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- editable_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn
                class="size_sm btn_delete"
                color="grey-7"
                outline
                label="선택삭제"
              />
              <q-btn
                class="size_sm btn_edit"
                color="grey-7"
                outline
                label="수정"
              />
              <q-btn
                class="size_sm btn_write"
                unelevated
                color="black"
                label="신규등록"
              />
            </div>
          </div>

          <q-table
            :rows="tableRows"
            :columns="tableColumns"
            row-key="idx"
            v-model:selected="table_selected"
            selection="multiple"
            v-model:pagination="table_pagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:header="props">
              <q-tr :props="props">
                <q-th v-for="col in props.cols" :key="col.name" :props="props">
                  {{ col.label }}
                </q-th>
              </q-tr>
            </template>
            <template v-slot:body="props">
              <q-tr :class="props.row.state" :props="props">
                <q-td class="select">
                  <q-checkbox v-model="props.selected" color="black" />
                </q-td>
                <q-td key="tableName" class="text-center">
                  {{ props.row.tableName }}
                </q-td>
                <q-td key="name">
                  {{ props.row.name }}
                </q-td>
                <q-td key="popup" class="author"> {{ props.row.popup }}</q-td>
                <q-td key="period" class="date text-center" style="width">
                  {{ props.row.period }}</q-td
                >
                <q-td class="select">
                  <q-toggle
                    v-model="props.row.allow"
                    class="custom_tgl"
                    color="black"
                  />
                </q-td>
                <q-td key="btn" :props="props.btn" class="hasbtn detail">
                  <q-btn
                    outline
                    class="size_xxs btn_detail_view"
                    label="미리보기"
                  >
                  </q-btn>
                </q-td>
                <q-td key="author" class="author"> {{ props.row.author }}</q-td>
                <q-td key="date" class="author"> {{ props.row.date }}</q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
        </div>
        <!--// editable_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const boardName = ref(['']);
const writer = ref(['']);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

//table데이터
const table_selected = ref([]);

const tableColumns = ref([
  {
    name: 'check',
    label: '선택',
    sortable: false,
    align: 'center',
    field: (row) => row.check,
  },
  {
    name: 'tableName',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName,
  },
  {
    name: 'name',
    label: '게시물 제목',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'popup',
    label: '팝업명',
    sortable: false,
    align: 'center',
    field: (row) => row.popup,
  },
  {
    name: 'period',
    label: '기간',
    sortable: false,
    align: 'center',
    field: (row) => row.period,
  },
  {
    name: 'allow',
    label: '사용여부',
    sortable: false,
    align: 'center',
    field: (row) => row.allow,
  },
  {
    name: 'preview',
    label: '미리보기',
    sortable: false,
    align: 'center',
    field: (row) => row.preview,
  },
  {
    name: 'author',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'date',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
]);

const tableRows = ref([
  {
    idx: '1',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: true,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '2',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '3',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '4',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '5',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '6',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '7',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '8',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '9',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '10',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '11',
    tableName: '공지사항',
    name: '휴가 기간 연장안',
    popup: 'POPUP_FAC',
    period: '2022.11.01 ~ 2022.12.01',
    allow: false,
    author: '홍길동',
    date: '2022.11.01',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
