<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 inner_form large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">신고게시물 보기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row-4">
            <q-icon name="icon-star" class="icon_svg"></q-icon>
            <h4 class="title1">신고게시물 보기</h4>
          </div>

          <div class="post_infor">
            <span class="name">이포탈</span>
            <span class="date">2023-02-02 15:59</span>
            <dl>
              <dt>추천수</dt>
              <dd>5</dd>
              <dt>조회수</dt>
              <dd>32</dd>
            </dl>
          </div>

          <table class="table_row_sales w200_pc mb10">
            <tbody>
              <tr>
                <th><b class="essential">게시대상</b></th>
                <td><span>눈높이</span> > <span>본부A</span></td>
                <th class="line_l"><b class="essential">게시옵션</b></th>
                <td>
                  <q-option-group
                    v-model="postOptionsGroup"
                    :options="postOptions"
                    color="black"
                    type="checkbox"
                    inline
                  />
                </td>
              </tr>
              <tr>
                <th><b class="essential">게시예약일</b></th>
                <td colspan="3">2023-02-02 00:00</td>
              </tr>
            </tbody>
          </table>

          <p class="text-body2 text-grey-3">미리보기 테스트 조회 화면입니다.</p>

          <ul class="inner_list mt60">
            <li>
              <a href="#" class="file_down">
                <q-icon
                  name="icon-document"
                  class="icon_svg filter-grey-3"
                ></q-icon>
                <span class="file_name">작업20230404_v12.5.txt</span>
              </a>
            </li>
            <li>
              <a href="#" class="file_down on"
                ><!-- on class -->
                <q-icon
                  name="icon-document "
                  class="icon_svg filter-grey-3"
                ></q-icon>
                <span class="file_name">작업20230404_v12.5.txt</span>
              </a>
            </li>
            <li>
              <a href="#" class="file_down">
                <q-icon
                  name="icon-document"
                  class="icon_svg filter-grey-3"
                ></q-icon>
                <span class="file_name">작업20230404.txt</span>
              </a>
            </li>
          </ul>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="선택"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const postOptionsGroup = ref(['op1']);
const postOptions = ref([
  {
    label: '긴급',
    value: 'op1',
  },
  {
    label: '공지',
    value: 'op2',
  },
]);
</script>
