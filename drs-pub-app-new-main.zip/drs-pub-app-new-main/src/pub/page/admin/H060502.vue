<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">팝업관리</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_box">
      <table class="table_row_sales">
        <tbody>
          <tr>
            <th class="w150"><b class="essential">팝업명</b></th>
            <td>
              <div class="search_item type_full">
                <q-input
                  v-model="dataInput1"
                  class=""
                  outlined
                  placeholder="팝업명을 입력하세요."
                ></q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th class="w150"><b class="essential">팝업게시물</b></th>
            <td>
              <div class="row-4">
                <!-- select -->
                <div class="search_item type_fix">
                  <q-select
                    class="hide_label"
                    label="게시물"
                    v-model="popupNotice"
                    :options="popupNoticeOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <!-- // select -->
                <!-- input -->
                <div class="search_item type_large">
                  <q-input
                    v-model="dataInput2"
                    class=""
                    outlined
                    placeholder=""
                  ></q-input>
                </div>
                <!-- // input -->
                <q-btn
                  class="size_sm"
                  fill
                  color="grey-3"
                  unelevated
                  label="선택"
                />
              </div>
            </td>
          </tr>

          <tr>
            <th class="w150"><b class="essential">팝업기간</b></th>
            <td>
              <div class="row items-center">
                <div class="search_item type_fix">
                  <!-- searchDate start.from -->
                  <q-input
                    outlined
                    v-model="searchDate.from"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.from"
                            @update:model-value="
                              searchDate.from, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!--// searchDate start.from -->
                </div>
                <div class="text-body3 text-grey-3 ml10 mr10">~</div>
                <div class="search_item type_fix">
                  <!-- searchDate start.to -->
                  <q-input
                    outlined
                    v-model="searchDate.to"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyto"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            v-model="searchDate.to"
                            mask="YYYY.MM.DD"
                            @update:model-value="
                              searchDate.to, $refs.qDateProxyto.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!--// searchDate start.to -->
                </div>
              </div>
            </td>
          </tr>

          <tr>
            <th class="w150"><b class="essential">팝업오픈설정</b></th>
            <td>
              <div class="search_item">
                <q-select
                  class="hide_label w180"
                  label="접속시 항상 설정"
                  v-model="popupOpen"
                  :options="popupOpenViewOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </td>
          </tr>
          <tr>
            <th class="w150"><b class="essential">팝업 사이즈</b></th>
            <td>
              <div class="row items-center">
                <span class="text-body2 text-grey-2 mr20">팝업창 넓이</span>
                <div class="search_item type_small">
                  <q-input
                    class=""
                    outlined
                    v-model="dataInput3"
                    placeholder=""
                    input-class="text-right"
                  />
                </div>

                <span class="text-body2 text-grey-2 pl40 mr20"
                  >팝업창 높이</span
                >
                <div class="search_item type_small">
                  <q-input
                    class=""
                    outlined
                    v-model="dataInput4"
                    placeholder=""
                    input-class="text-right"
                  />
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th class="w150"><b class="essential">권한설정</b></th>
            <td>
              <q-btn
                class="size_sm"
                fill
                color="grey-3"
                unelevated
                label="설정"
              />
            </td>
          </tr>
          <tr>
            <th class="w150"><b class="essential">화면 출력옵션</b></th>
            <td>
              <q-checkbox
                v-model="dataCheck"
                label="본문만 출력"
                color="black"
              />
            </td>
          </tr>
          <tr>
            <th class="w150"><b class="essential">사용여부</b></th>
            <td>
              <q-option-group
                v-model="useSelect"
                :options="useSelectoptions"
                color="black"
                inline
              />
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
      <!-- // 버튼 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataInput1 = ref();
const dataInput2 = ref();
const dataInput3 = ref('0');
const dataInput4 = ref('0');

const dataCheck = ref(true);

// radio group
const useSelect = ref('op1');
const useSelectoptions = ref([
  {
    label: '사용',
    value: 'op1',
  },
  {
    label: '미사용',
    value: 'op2',
  },
]);

const popupOpen = ref('');
const popupOpenViewOption = ref([
  {
    id: 'open1',
    desc: '접속시 항상 설정',
  },
  {
    id: 'open2',
    desc: '설정2',
  },
]);

const popupNotice = ref('');
const popupNoticeOption = ref([
  {
    id: 'notice1',
    desc: '게시물',
  },
  {
    id: 'notice2',
    desc: '게시물2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
</script>
