<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">테이블 관리</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_box">
      <table class="table_row_sales">
        <tbody>
          <tr>
            <th><b class="essential">테이블명(물리)</b></th>
            <td>
              <div class="row items-center">
                <span class="text-body2 flex_no">tbcmm_bbs_</span>
                <div class="search_item ml10 flex_auto">
                  <q-input
                    v-model="keyword"
                    class="inp_search"
                    outlined
                    placeholder="테이블명(물리)를 입력하세요"
                  ></q-input>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th><b class="essential">테이블명(논리)</b></th>
            <td>
              <div class="search_item type_full">
                <q-input
                  v-model="keyword2"
                  class="inp_search"
                  outlined
                  placeholder="테이블명(논리)를 입력하세요."
                ></q-input>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <div class="general_table">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" color="" outline label="추가" />
          </div>
        </div>
        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          row-key="idx"
          v-model:selected="dataSlected"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th key="tdata1"
                >테이블 컬럼명 <span class="text-orange">*</span></q-th
              >
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="tdata1" class="text-center">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword3"
                  placeholder="테이블 컬럼명을 입력하세요."
                />
              </q-td>
              <q-td key="tdata2" class="text-center">
                <q-input
                  class="w180"
                  for=""
                  outlined
                  dense
                  v-model="keyword4"
                  placeholder="항목명을 입력하세요."
                />
              </q-td>
              <q-td key="tdata3" class="text-center">
                <q-input
                  class="w180"
                  for=""
                  outlined
                  dense
                  v-model="keyword5"
                  placeholder="컬럼길이를 입력하세요."
                />
              </q-td>
              <q-td key="tdata4" class="w320 text-left">
                <div class="row-2">
                  <template v-if="props.row.tdata4 == 'default'">
                    <q-select
                      class="hide_label w137"
                      label="선택하세요"
                      v-model="columnSelect"
                      :options="columnSelectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </template>

                  <template v-if="props.row.tdata4 == 'type1'">
                    <q-select
                      class="hide_label w137"
                      label="코드(콤보)"
                      v-model="columnSelect2"
                      :options="columnSelect2Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                    <q-select
                      class="hide_label w137"
                      label="유저구분"
                      v-model="columnSelect3"
                      :options="columnSelect3Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </template>

                  <template v-if="props.row.tdata4 == 'type2'">
                    <q-select
                      class="hide_label w137"
                      label="코드(콤보)"
                      v-model="columnSelect2"
                      :options="columnSelect2Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                    <q-select
                      class="hide_label w137"
                      label="노드1"
                      v-model="columnSelect4"
                      :options="columnSelect4Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </template>
                </div>
              </q-td>
              <q-td key="tdata5" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c1" label="" color="black" />
              </q-td>
              <q-td key="tdata6" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c2" label="" color="black" />
              </q-td>
              <q-td key="tdata7" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c3" label="" color="black" />
              </q-td>
              <q-td key="tdata8" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c4" label="" color="black" />
              </q-td>
              <q-td key="tdata9" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c5" label="" color="black" />
              </q-td>
              <q-td key="delete" class="text-center">
                <q-btn outline class="size_xs btn_inner_table" label="삭제" />
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>

      <!-- 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline color="grey-4" class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
      <!-- // 버튼 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword = ref('');
const keyword2 = ref('');
const keyword3 = ref('');
const keyword4 = ref('');
const keyword5 = ref('');

//data테이블
const dataSlected = ref([]);
const dataCheck = ref({
  c1: true,
  c2: false,
  c3: false,
  c4: true,
  c5: false,
});
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const columnSelect = ref(['']);
const columnSelectOption = ref([
  {
    id: 's1',
    desc: '속성1',
  },
  {
    id: 's2',
    desc: '속성2',
  },
]);
const columnSelect2 = ref(['']);
const columnSelect2Option = ref([
  {
    id: 's21',
    desc: '속성21',
  },
  {
    id: 's22',
    desc: '속성22',
  },
]);
const columnSelect3 = ref(['']);
const columnSelect3Option = ref([
  {
    id: 's31',
    desc: '속성31',
  },
  {
    id: 's32',
    desc: '속성32',
  },
]);
const columnSelect4 = ref(['']);
const columnSelect4Option = ref([
  {
    id: 's41',
    desc: '속성41',
  },
  {
    id: 's42',
    desc: '속성42',
  },
]);
const dataColumns = ref([
  {
    name: 'tdata2',
    label: '항목명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '컬럼길이',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '컬럼속성',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '필수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '목록',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '등록',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '수정',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '조회',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'delete',
    label: '삭제',
    sortable: false,
    align: 'center',
    field: (row) => row.delete,
  },
]);
const dataRows = ref([
  {
    idx: 12,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 11,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'type1',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 10,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'type2',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 9,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 8,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 7,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 6,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 5,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 4,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 3,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 2,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
  {
    idx: 1,
    tdata1: '',
    tdata2: '',
    tdata3: '',
    tdata4: 'default',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
    delete: '',
  },
]);
</script>
