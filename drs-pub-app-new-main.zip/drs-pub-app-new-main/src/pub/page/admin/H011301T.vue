<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">메시지(탬플릿)관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb24"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="upper" label="문자패턴관리" :ripple="false" />
        <q-tab name="downer" label="방문시간 안내 멘트" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 문자패턴관리 tab 컨텐츠 -->
        <q-tab-panel name="upper">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    label="구분 선택"
                    v-model="brandSelect"
                    :options="brandSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="카테고리"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    label="사용여부 전체"
                    v-model="useSelect"
                    :options="useSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    label="문자유형 전체"
                    v-model="typeSelect"
                    :options="typeSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
              </div>
              <div class="row q-col-gutter-sm" v-if="stateHandle">
                <div class="col-12 col-md-3">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="검색어"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <q-btn
            class="btn_search_handle"
            fill
            color="grey-5"
            unelevated
            @click="actionHandle"
          >
            <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
            <q-icon color="white" name="ion-ios-arrow-down" v-else />
          </q-btn>

          <div class="wrap_table_box">
            <div class="table_dk">
              <div class="table_top">
                <div class="btn_wrap col-12 gap10">
                  <q-btn
                    class="size_sm btn_save"
                    color="black"
                    unelevated
                    label="신규등록"
                  />
                </div>
              </div>
              <q-table
                :rows="msgRows"
                :columns="msgColumns"
                row-key="idx"
                selection="multiple"
                v-model:pagination="dataPagination"
                hide-bottom
                hide-pagination
                separator="cell"
                wrap-cells
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th
                      v-for="col in props.cols"
                      :key="col.name"
                      :props="props"
                    >
                      {{ col.label }}
                    </q-th>
                  </q-tr>
                </template>
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td key="idx" class="text-center">{{
                      props.row.idx
                    }}</q-td>
                    <q-td key="brand" class="text-center">
                      {{ props.row.brand }}</q-td
                    >
                    <q-td key="type" class="text-center">{{
                      props.row.type
                    }}</q-td>
                    <q-td key="cate" class="text-center">
                      {{ props.row.cate }}</q-td
                    >
                    <q-td key="msg" class="msg eli">{{ props.row.msg }}</q-td>
                    <q-td key="use" class="arrow" :props="props">
                      <q-toggle
                        v-model="props.row.use"
                        false-value="N"
                        true-value="Y"
                        color="black"
                      />
                    </q-td>
                    <q-td key="preview" :props="props" class="hasbtn detail">
                      <q-btn
                        outline
                        class="size_xxs btn_detail_view"
                        label="보기"
                      >
                      </q-btn>
                    </q-td>
                    <q-td key="update" :props="props" class="hasbtn detail">
                      <q-btn
                        outline
                        class="size_xxs btn_detail_view"
                        label="수정"
                      >
                      </q-btn>
                    </q-td>
                    <q-td key="del" :props="props" class="hasbtn detail">
                      <q-btn
                        outline
                        class="size_xxs btn_detail_view"
                        label="삭제"
                      >
                      </q-btn>
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>

            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
        </q-tab-panel>
        <!--// 문자패턴관리 tab 컨텐츠 -->
        <!-- 방문시간 안내 멘트 tab 컨텐츠 -->
        <q-tab-panel name="downer"> 방문시간 안내 멘트 : H011302T </q-tab-panel>
        <!--// 방문시간 안내 멘트 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('upper');

// 검색옵션
// 브랜드
const brandSelect = ref('구분 선택');
const brandSelectOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  { id: 'A', desc: '전체' },
  { id: 'B', desc: '눈높이' },
  { id: 'C', desc: '차이홍' },
]);

// 사용유무
const useSelect = ref('사용여부 전체');
const useSelectOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  { id: 'Y', desc: '사용' },
  { id: 'N', desc: '미사용' },
]);
// 문자유형
const typeSelect = ref('문자유형 전체');
const typeSelectOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  { id: 'A', desc: '전체' },
  { id: 'B', desc: 'SMS' },
  { id: 'C', desc: 'MMs' },
]);
// 검색어
const keyword = ref('');

// 테이블 데이터
const msgColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'brand',
    label: '브랜드',
    sortable: false,
    align: 'center',
    field: (row) => row.brand,
  },
  {
    name: 'type',
    label: '유형',
    sortable: false,
    align: 'center',
    field: (row) => row.type,
  },
  {
    name: 'cate',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.cate,
  },
  {
    name: 'msg',
    label: '메시지명',
    sortable: false,
    align: 'left',
    field: (row) => row.msg,
  },
  {
    name: 'use',
    label: '사용여부',
    sortable: false,
    align: 'left',
    field: (row) => row.use,
  },
  {
    name: 'preview',
    label: '미리보기',
    align: 'center',
    sortable: false,
    field: (row) => row.preview,
  },
  {
    name: 'update',
    label: '수정',
    align: 'center',
    sortable: false,
    field: (row) => row.update,
  },
  {
    name: 'del',
    label: '삭제',
    align: 'center',
    sortable: false,
    field: (row) => row.del,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    brand: '눈높이',
    type: 'MMS',
    cate: '카테고리',
    msg: '안녕하세요? 5월 가정의달을 맞아 5/3(화) 오후2시~5시까지 센터근처(GS마트앞) 야외에서 어린이날 행사(바람개비 만들기,마스크페이팅 등)를 합니다. -눈높이최강러닝센터-',
    use: 'N',
    preview: '',
    update: '',
    del: '',
  },
  {
    idx: '2',
    brand: '눈높이',
    type: 'MMS',
    cate: '카테고리',
    msg: '안녕하세요? 5월 가정의달을 맞아 5/3(화) 오후2시~5시까지 센터근처(GS마트앞) 야외에서 어린이날 행사(바람개비 만들기,마스크페이팅 등)를 합니다. -눈높이최강러닝센터-',
    use: 'Y',
    preview: '',
    update: '',
    del: '',
  },
  {
    idx: '3',
    brand: '눈높이',
    type: 'MMS',
    cate: '카테고리',
    msg: '안녕하세요? 5월 가정의달을 맞아 5/3(화) 오후2시~5시까지 센터근처(GS마트앞) 야외에서 어린이날 행사(바람개비 만들기,마스크페이팅 등)를 합니다. -눈높이최강러닝센터-',
    use: 'N',
    preview: '',
    update: '',
    del: '',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
<style lang="scss" scoped>
.msg {
  max-width: 500px;
}
</style>
