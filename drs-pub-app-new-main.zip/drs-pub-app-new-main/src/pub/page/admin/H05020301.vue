<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-6">
            <q-input
              class="box_l"
              outlined
              v-model="boardName"
              placeholder="게시판명을 입력하세요"
            />
          </div>
          <div class="col-12 col-md-6">
            <q-input
              class="box_l"
              outlined
              v-model="tbName"
              placeholder="테이블명(논리)를 입력하세요"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <!-- selectable_table type_01 -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm btn_delete" outline label="선택삭제" />
            <q-btn class="size_sm btn_edit" outline label="수정" />
            <q-btn
              class="size_sm btn_write"
              unelevated
              color="black"
              label="신규등록"
            />
          </div>
        </div>
        <q-table
          :rows="msgRows"
          :columns="msgColumns"
          row-key="idx"
          v-model:selected="table_selected"
          selection="multiple"
          v-model:pagination="table_pagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :class="props.row.state" :props="props">
              <q-td class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-td>
              <q-td key="idx" class="name">{{ props.row.name }}</q-td>
              <q-td key="type" class="type text-left">
                {{ props.row.type }}</q-td
              >
              <q-td key="tableName" class="tableName">
                {{ props.row.tableName }}</q-td
              >
              <q-td key="author" class="author"> {{ props.row.author }}</q-td>
              <q-td key="date" class="date text-center">
                {{ props.row.date }}</q-td
              >

              <q-td key="btn" :props="props.btn" class="hasbtn detail">
                <q-btn
                  outline
                  class="size_xxs btn_detail_view"
                  label="열기"
                  @click="tableEvt(props.row.idx)"
                >
                </q-btn>
              </q-td>
            </q-tr>
          </template>
        </q-table>

        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
      </div>
      <!--// selectable_table type_01-->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const boardName = ref(['']);
const tbName = ref(['']);

// msg_dialog
const msg_dialog = ref({
  open: false,
  id: 0,
});

//msg_table데이터
const table_selected = ref([]);

const msgColumns = ref([
  {
    name: 'check',
    label: '선택',
    sortable: false,
    align: 'center',
    field: (row) => row.check,
  },

  {
    name: 'name',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'type',
    label: '게시판종류',
    sortable: false,
    align: 'center',
    field: (row) => row.type,
  },
  {
    name: 'tableName',
    label: '테이블명',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName,
  },
  {
    name: 'author',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'date',
    label: '등록일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },

  {
    name: 'btn',
    label: '바로가기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    name: '대교게시판',
    type: '목록형 / 영구',
    tableName: 'TBBS_HELPDESKFAQ',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '2',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '3',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '4',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '5',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '6',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },

  {
    idx: '7',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '8',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '9',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '10',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '11',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '12',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '10',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '11',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '12',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '10',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '11',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
  {
    idx: '12',
    name: '대교게시판',
    type: '목록형 / 영구',
    author: '홍길동',
    date: '2022.11.01',
    btn: '',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
  msg_dialog.value.idx = id;
  msg_dialog.value.open = true;
}
</script>
