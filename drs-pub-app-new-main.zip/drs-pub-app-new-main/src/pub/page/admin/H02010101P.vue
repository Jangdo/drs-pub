<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">로그인 ID</span>
                  <q-input
                    class="as_dd hide_label"
                    label="로그인 ID"
                    outlined
                    placeholder="로그인 ID를 입력하세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">이름</span>
                  <q-input
                    class="as_dd hide_label"
                    label="이름"
                    outlined
                    placeholder="이름을 입력하세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">권한그룹 </span>
                  <q-select
                    class="as_dd"
                    v-model="authorityGroupSelect"
                    :options="authorityGroupSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[authorityGroupSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="form_item">
                  <span class="as_dt required">사이트</span>
                  <q-select
                    class="as_dd"
                    v-model="pathSelect"
                    :options="pathSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[pathSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">이메일</span>
                  <q-input
                    class="as_dd hide_label"
                    label="이메일"
                    type="email"
                    outlined
                    placeholder="이메일를 입력하세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">패스워드</span>
                  <q-input
                    class="as_dd hide_label"
                    type="password"
                    label="패스워드"
                    outlined
                    placeholder="패스워드을 입력하세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">사업부</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="사업부를 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">영업조직</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="영업조직를 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">지점</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="지점를 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">사업팀</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="사업팀을 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">고객구분</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.customer"
                      val="true"
                      label="영업고객"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.customer"
                      val="false"
                      label="고객아님"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">고객번호</span>
                  <q-input
                    class="as_dd hide_label"
                    type="text"
                    label="고객번호"
                    outlined
                    placeholder="고객번호을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>패스워드</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">제품군</span>
                  <q-select
                    class="as_dd"
                    v-model="productSelect"
                    :options="productSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[productSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="form_item">
                  <span class="as_dt required">입금구분</span>
                  <q-select
                    class="as_dd"
                    v-model="depositSelect"
                    :options="depositSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[deposit == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">계정그룹</span>
                  <q-select
                    class="as_dd"
                    v-model="accountGroupSelect"
                    :options="accountGroupSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[accountGroupSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="form_item">
                  <span class="as_dt required">사용여부</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="사용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="사용안함"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">에듀피아ID</span>
                  <q-input
                    class="as_dd hide_label"
                    label="에듀피아ID"
                    outlined
                    placeholder="에듀피아ID를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>에듀피아ID</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">에듀피아PW</span>
                  <q-input
                    class="as_dd hide_label"
                    type="password"
                    label="에듀피아PW"
                    outlined
                    placeholder="에듀피아PW을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>에듀피아PW</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">그룹웨어ID</span>
                  <q-input
                    class="as_dd hide_label"
                    label="그룹웨어ID"
                    outlined
                    placeholder="그룹웨어ID를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>그룹웨어ID</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">그룹웨어PW</span>
                  <q-input
                    class="as_dd hide_label"
                    type="password"
                    label="그룹웨어PW"
                    outlined
                    placeholder="그룹웨어PW을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>그룹웨어PW</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">52 시작시간</span>
                  <q-input
                    class="as_dd hide_label"
                    label="52 시작시간"
                    outlined
                    placeholder="52 시작시간를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>52 시작시간</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">52 종료시간</span>
                  <q-input
                    class="as_dd hide_label"
                    label="52 종료시간"
                    outlined
                    placeholder="52 종료시간을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>52 종료시간 *</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">접속회수</span>
                  <span class="as_dd">111111</span>
                </div>
                <div class="form_item">
                  <span class="as_dt">최근접속일</span>
                  <span class="as_dd">220911</span>
                </div>
              </div>
            </li>

            <li class="hastextarea">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">비고</span>
                  <div class="mt15 mb15 full-width">
                    <q-input
                      class="as_dd hide_label"
                      outlined
                      placeholder="비고를 입력하세요"
                      type="textarea"
                      v-model="dataFrom.txt"
                    >
                      <template v-slot:label>비고를 입력하세요</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const authorityGroupSelect = ref(['선택하세요']);
const authorityGroupSelectOption = ref([
  {
    id: 'N',
    desc: '권한(N)',
  },
  {
    id: 'G',
    desc: '권한(G)',
  },
  {
    id: 'C',
    desc: '권한(C) ',
  },
  {
    id: 'M',
    desc: '권한(M)',
  },
]);
const pathSelect = ref(['메뉴경로를 입력하세요']);
const pathSelectOption = ref([
  {
    id: 'N',
    desc: '사이트(N)',
  },
  {
    id: 'G',
    desc: '사이트(G)',
  },
  {
    id: 'C',
    desc: '사이트(C) ',
  },
  {
    id: 'M',
    desc: '사이트(M)',
  },
]);
const productSelect = ref(['선택해주세요']);
const productSelectOption = ref([
  {
    id: 'N',
    desc: '제품(N)',
  },
  {
    id: 'G',
    desc: '제품(G)',
  },
  {
    id: 'C',
    desc: '제품(C) ',
  },
  {
    id: 'M',
    desc: '제품(M)',
  },
]);

const depositSelect = ref(['선택해주세요']);
const depositSelectOption = ref([
  {
    id: 'N',
    desc: '입금(N)',
  },
  {
    id: 'G',
    desc: '입금(G)',
  },
  {
    id: 'C',
    desc: '입금(C) ',
  },
  {
    id: 'M',
    desc: '입금(M)',
  },
]);
const accountGroupSelect = ref(['선택해주세요']);
const accountGroupSelectOption = ref([
  {
    id: 'N',
    desc: '계정그룹(N)',
  },
  {
    id: 'G',
    desc: '계정그룹(G)',
  },
  {
    id: 'C',
    desc: '계정그룹(C) ',
  },
  {
    id: 'M',
    desc: '계정그룹(M)',
  },
]);

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  customer: 'true',
  url: '',
});
function test() {
  console.log('btn_test');
}
</script>

<style lang="scss"></style>
