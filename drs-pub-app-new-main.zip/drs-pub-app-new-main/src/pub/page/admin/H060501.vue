<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">팝업관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <div class="row-calendar">
              <q-input
                outlined
                v-model="searchDate.from"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <span class="text-body2">~</span>
              <!-- 달력 인풋 -->
              <q-input
                outlined
                v-model="searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyTo"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.to"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyTo.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="keyword"
              placeholder="제목"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="keyword2"
              placeholder="등록자"
            >
            </q-input>
          </div>

          <div class="col-12 col-md-3">
            <q-checkbox
              class="mr10"
              v-model="dataCheck"
              label="등록일자 조회 제외"
              color="black"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <div class="wrap_table_box">
      <!-- general_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" color="" outline label="선택삭제" />
            <q-btn class="size_sm" color="" outline label="수정" />
            <q-btn class="size_sm" color="" outline label="신규등록" />
          </div>
        </div>
        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          v-model:selected="tblRowSelected"
          row-key="idx"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          selection="multiple"
          separator="cell"
          color="black"
        >
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="check" class="select text-center">
                <q-checkbox v-model="props.selected" color="black" />
              </q-td>
              <q-td key="tdata1" class="text-center">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="text-left">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="text-center">
                {{ props.row.tdata3 }}
              </q-td>
              <q-td key="tdata4" class="text-center">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="toggle" :props="props" class="text-center">
                <q-toggle
                  color="black"
                  v-model="props.row.toggle"
                  false-value="n"
                  true-value="y"
                />
              </q-td>
              <q-td key="preview" class="text-center">
                <q-btn
                  outline
                  class="size_xxs btn_inner_table w60"
                  label="미리보기"
                />
              </q-td>
              <q-td key="tdata5" class="text-center">
                {{ props.row.tdata5 }}
              </q-td>
              <q-td key="tdata6" class="text-center">
                {{ props.row.tdata6 }}
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <!-- pagination -->
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!-- // pagination -->
      <!--// general_table -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword = ref('');
const keyword2 = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const dataCheck = ref(true);

//data테이블
const tblRowSelected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '게시물 제목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '팝업명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '기간',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'toggle',
    label: '사용여부',
    sortable: false,
    align: 'center',
    field: (row) => row.toggle,
  },
  {
    name: 'preview',
    label: '미리보기',
    sortable: false,
    align: 'center',
    field: (row) => row.preview,
  },
  {
    name: 'tdata5',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가 기간 연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'y',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 9,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC11',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'y',
    preview: '',
    tdata5: '길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 8,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 7,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 6,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 5,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 4,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 3,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 2,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'n',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
  {
    idx: 1,
    check: '',
    tdata1: '공지사항',
    tdata2: '휴가연장안',
    tdata3: 'POPUP_FAC',
    tdata4: '2022.11.01 ~ 2022.12.01',
    toggle: 'y',
    preview: '',
    tdata5: '홍길동',
    tdata6: '2022.11.01',
  },
]);
</script>
