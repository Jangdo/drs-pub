<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">컬럼 속성관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb24"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="게시판 신고유형" :ripple="false" />
        <q-tab name="tab2" label="게시판 단일 코드" :ripple="false" />
        <q-tab name="tab3" label="게시판 멀티 코드" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->

      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <!-- 버튼 -->
            <div class="row-2">
              <div class="row-4">
                <q-input
                  class="w380 inp_search"
                  outlined
                  placeholder="조직코드 및 조직명을 입력하세요"
                >
                </q-input>
                <q-btn
                  class="size_sm btn_reset"
                  icon=""
                  outline
                  label="초기화"
                />
                <q-btn
                  fill
                  unelevated
                  class="size_sm btn_search"
                  label="조회"
                />
              </div>
              <div class="row-6">
                <q-btn
                  class="size_sm"
                  color="grey-7"
                  outline
                  label="폴더삭제"
                />
                <q-btn
                  class="size_sm"
                  color="grey-7"
                  outline
                  label="폴더수정"
                />
                <q-btn
                  class="size_sm"
                  color="black"
                  unelevated
                  label="폴더등록"
                />
              </div>
            </div>
            <!-- // 버튼 -->

            <!-- tree -->
            <div class="tree_container bg_white mt15">
              <q-tree
                :nodes="tree_data"
                node-key="id"
                selected-color="primary"
                class="tree type_01 height600"
                v-model:selected="tree_selected"
                default-expand-all
                @update:selected="temp(tree_selected)"
              />
            </div>
            <!-- // tree -->
          </div>
        </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->

        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3"> tab3 </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab1');

const tree_data = [
  {
    label: '게시판 멀티코드(BBS_COLUMN_CODE_M)',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '노드 1',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '노드 2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '노드 3',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
</script>
