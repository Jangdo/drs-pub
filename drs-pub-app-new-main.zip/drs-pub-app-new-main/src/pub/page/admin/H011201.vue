<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">공지사항관리</h2>
      <Breadcrumbs />
    </div>

    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <div class="row-4">
              <q-input
                outlined
                v-model="searchDate.from"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <!--// searchDate start.from -->
              <div class="tilde">
                <span>~</span>
              </div>
              <!-- searchDate start.to -->
              <q-input
                outlined
                v-model="searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyto"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        v-model="searchDate.to"
                        mask="YYYY.MM.DD"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyto.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_xl"
              for=""
              outlined
              dense
              v-model="keyword"
              placeholder="사업부"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="브랜드 전체"
              v-model="searchCategory"
              :options="searchCategoryOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <div class="wrap_table_box">
      <!-- general_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" color="" outline label="선택삭제" />
            <q-btn class="size_sm" color="" outline label="신규등록" />
          </div>
        </div>
        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          :pagination="dataPagination"
          v-model:selected="tblRowSelected"
          row-key="tdata1"
          hide-bottom
          hide-pagination
          selection="multiple"
          separator="cell"
          color="black"
          ><template v-slot:header="props">
            <q-tr :props="props">
              <q-th class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-th>
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr> </template
          ><template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="check" class="select text-center">
                <q-checkbox v-model="props.selected" color="black" />
              </q-td>
              <q-td key="tdata1" class="text-center">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="text-center">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="">
                <div class="td_inner_badge_flex">
                  <q-badge
                    v-if="props.row.mark_noti"
                    color="orange"
                    class="small"
                    >공지</q-badge
                  >
                  <q-badge v-if="props.row.mark_warn" color="red" class="small"
                    >긴급</q-badge
                  >

                  {{ props.row.tdata3 }}
                </div>
              </q-td>
              <q-td key="tdata4" class="text-center">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="tdata5" class="text-center">
                {{ props.row.tdata5 }}
              </q-td>
              <q-td key="tdata6" class="text-center">
                {{ props.row.tdata6 }}
              </q-td>
              <q-td key="btn" class="hasbtn">
                <q-btn
                  outline
                  class="size_xxs btn_detail_view"
                  label="보기"
                  @click="tableEvt(props.row.tdata1)"
                >
                </q-btn>
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <!-- pagination -->
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!-- // pagination -->
      <!--// general_table -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const searchCategory = ref(['']);
const searchCategoryOption = ref([
  {
    id: 'a',
    desc: '브랜드1',
  },
  {
    id: 'b',
    desc: '브랜드2',
  },
]);

//data테이블
const tblRowSelected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '브랜드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '서식명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },

  {
    name: 'tdata4',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '조회수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'btn',
    label: '상세보기',
    sortable: false,
    align: 'center',
    field: (row) => row.btn,
  },
]);
const dataRows = ref([
  {
    tdata1: 100,
    mark_noti: true,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 99,
    mark_noti: false,
    mark_warn: true,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 98,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 97,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 96,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 95,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 94,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 93,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 92,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
  {
    tdata1: 91,
    mark_noti: false,
    mark_warn: false,
    tdata2: '눈높이',
    tdata3: '드림스 사용 주의사항',
    tdata4: '홍길동',
    tdata5: '2022.11.01',
    tdata6: '999',
  },
]);

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
}
</script>
