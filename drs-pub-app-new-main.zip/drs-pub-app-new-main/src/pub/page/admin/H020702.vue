<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">겸직 로그인 관리</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_box">
      <table class="table_row_sales">
        <tbody>
          <tr>
            <th><span class="required">위임지점</span></th>
            <td>
              <div class="search_item">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword"
                  placeholder="지점을 검색하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </td>
            <th class="line_l">지점명</th>
            <td>
              <div class="search_item">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword2"
                  placeholder=""
                >
                </q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="required">위임받을 ID</span></th>
            <td>
              <div class="search_item">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword3"
                  placeholder="지점을 검색하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </td>
            <th class="line_l">이름</th>
            <td>
              <div class="search_item">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword4"
                  placeholder=""
                >
                </q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="required">권한이름</span></th>
            <td colspan="3">
              <div class="search_item">
                <q-input
                  class="w350"
                  for=""
                  outlined
                  dense
                  v-model="keyword5"
                  placeholder="지점을 검색하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="required">위임할 팀</span></th>
            <td colspan="3">
              <div class="search_item">
                <q-select
                  class="hide_label w350"
                  label="선택하세요"
                  v-model="teamSelected"
                  :options="teamSelectedOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="required">위임일자</span></th>
            <td colspan="3">
              <div class="row items-center">
                <div class="search_item type_fix">
                  <!-- searchDate start.from -->
                  <q-input
                    outlined
                    v-model="searchDate.from"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.from"
                            @update:model-value="
                              searchDate.from, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!--// searchDate start.from -->
                </div>
                <div class="text-body3 text-grey-3 ml10 mr10">~</div>
                <div class="search_item type_fix">
                  <!-- searchDate start.to -->
                  <q-input
                    outlined
                    v-model="searchDate.to"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyto"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            v-model="searchDate.to"
                            mask="YYYY.MM.DD"
                            @update:model-value="
                              searchDate.to, $refs.qDateProxyto.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                  <!--// searchDate start.to -->
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th>비고</th>
            <td colspan="3">
              <div class="search_item type_full">
                <q-input
                  class="box_l"
                  for=""
                  outlined
                  dense
                  v-model="keyword6"
                  placeholder="입력하세요"
                />
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="발송" />
      </div>
      <!-- // 버튼 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword = ref('');
const keyword2 = ref('남춘천교육국');
const keyword3 = ref('');
const keyword4 = ref('홍길동');
const keyword5 = ref('');
const keyword6 = ref('');

const teamSelected = ref(['']);
const teamSelectedOption = ref([
  {
    id: 's1',
    desc: '팀1',
  },
  {
    id: 's2',
    desc: '팀이름2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
</script>
