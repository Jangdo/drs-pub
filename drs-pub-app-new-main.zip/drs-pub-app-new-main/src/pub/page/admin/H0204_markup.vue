<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">권한그룹관리</h2>
      <Breadcrumbs />
    </div>

    <!-- table_search_area type_02 -->
    <div class="table_search_area type_02">
      <div class="inline">
        <div class="wrap_item_input">
          <!-- <h3>메시지명</h3> -->
          <q-select
            class="box_m"
            v-model="authoritySelect"
            :options="authoritySelectOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
            :class="[authoritySelect == 0 ? 'placehoder' : '']"
          >
          </q-select>
        </div>
        <div class="wrap_item_input">
          <!-- <h3>메시지명</h3> -->
          <q-input
            class="box_l"
            for=""
            outlined
            dense
            v-model="authoritySearch"
            placeholder="권한명 또는 권한코드를 입력하여 검색하세요"
          />
        </div>
        <div class="btn_area">
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
          <q-btn
            icon="ion-ios-refresh"
            class="size_sm btn_reset"
            outline
            label="초기화"
          />
        </div>
      </div>
    </div>
    <!--// table_search_area type_02 -->
    <q-card class="row row-2 card_page">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="btn_area">
          <q-btn
            fill
            unelevated
            class="size_sm btn_folder_add"
            icon="ion-ios-add"
            label="폴더추가"
          />
          <q-btn class="size_sm btn_folder_modify" outline label="폴더수정" />
          <q-btn class="size_sm btn_folder_delete" outline label="폴더삭제" />
        </div>
        <q-tree
          :nodes="tree_data"
          node-key="id"
          selected-color="primary"
          class="category"
          v-model:selected="tree_selected"
          default-expand-all
          @update:selected="temp(tree_selected)"
        />
      </div>
      <!--// sm_area 트리 영역 -->
      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- selectable_table type_01 -->
        <div class="selectable_table type_01">
          <div class="btn_area">
            <q-btn class="size_sm btn_delete" outline icon="" label="엑셀" />
            <q-btn
              class="size_sm btn_delete"
              outline
              icon="delete_outline"
              label="삭제"
            />
            <q-btn class="size_sm btn_search" fill unelevated label="등록" />
            <q-btn
              unelevated
              v-close-popup
              class="size_sm btn_save"
              label="저장"
            />

            <q-space />
          </div>
          <q-table
            :rows="authorityRows"
            :columns="authorityColumns"
            row-key="code"
            v-model:selected="authoritySelected"
            selection="multiple"
            v-model:pagination="authority_pagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td class="select"
                  ><q-checkbox v-model="props.selected"
                /></q-td>
                <q-td key="category" class="category">{{
                  props.row.category
                }}</q-td>
                <q-td key="code" class=""> {{ props.row.code }}</q-td>
                <q-td key="name" class="name"> {{ props.row.name }}</q-td>

                <q-td key="btnDetail" class="hasbtn">
                  <q-btn
                    outline
                    class="size_sm btn_detail_view"
                    label="보기"
                    @click="tableEvt(props.row.code, props.row.btn.detail)"
                  >
                  </q-btn>
                </q-td>
                <q-td key="btnUser" class="hasbtn">
                  <q-btn
                    outline
                    class="size_sm btn_detail_view"
                    label="보기"
                    @click="tableEvt(props.row.code, props.row.btn.user)"
                  >
                  </q-btn>
                </q-td>
                <q-td key="btnDetail" class="hasbtn">
                  <q-btn
                    outline
                    class="size_sm btn_detail_view"
                    label="보기"
                    @click="tableEvt(props.row.code, props.row.btn.menu)"
                  >
                  </q-btn>
                </q-td>

                <q-td key="allow" :props="props" class="allow">
                  <q-toggle v-model="props.row.allow" color="brown-4" />
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="authority_pagination.page"
              direction-links
              boundary-links
              :max-pages="10"
              :max="pagesNumber"
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              icon-prev="keyboard_arrow_left"
              icon-next="keyboard_arrow_right"
              class="custom_pagination type_01"
            />
          </div>
        </div>
        <!--// selectable_table type_01-->
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: 'home',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

// menu
const authoritySelect = ref('');
const authoritySelectOption = ref([
  {
    id: '',
    desc: '권한을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '권한(N)',
  },
  {
    id: 'G',
    desc: '권한(G)',
  },
  {
    id: 'C',
    desc: '권한(C) ',
  },
  {
    desc: '권한(M)',
  },
]);
const authoritySearch = ref('');
// authorityDialog
// const authorityDialog = ref({
//   open: false,
//   id: 0,
// });

//authority_table데이터
const authoritySelected = ref([]);
const pagesNumber = computed(() =>
  Math.ceil(authorityRows.value.length / authority_pagination.value.rowsPerPage)
);
const authorityColumns = ref([
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.path,
  },
  {
    name: 'code',
    label: '권한 코드',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },

  {
    name: 'name',
    label: '메뉴명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'btnDetail',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn.detail,
  },
  {
    name: 'btnUser',
    label: '사용자설정',
    align: 'center',
    sortable: false,
    field: (row) => row.btn.user,
  },
  {
    name: 'btnMenu',
    label: '메뉴설정',
    align: 'center',
    sortable: false,
    field: (row) => row.btn.menu,
  },

  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const authorityRows = ref([
  {
    category: '시스템관리자',
    code: 'MA001',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA002',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA003',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA004',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA005',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA006',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA007',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA008',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA009',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA010',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
  {
    category: '시스템관리자',
    code: 'MA011',
    name: '인사회계 개발자',
    btn: {
      detail: 'detail',
      user: 'user',
      menu: 'menu',
    },
    allow: true,
  },
]);
const authority_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(code, menu) {
  console.log('테이블  id :' + code + menu + '상세보기');
}
</script>
