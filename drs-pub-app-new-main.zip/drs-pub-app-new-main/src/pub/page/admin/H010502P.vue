<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog v-model="popCategory" @hide="popForm = true">
      <q-card class="dialog_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">카테고리 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            outline
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="inner_tit">메시지 카테고리</p>
          <div class="tree_container">
            <q-tree
              :nodes="tree_data"
              node-key="id"
              selected-color="primary"
              class="popup_tree category"
              v-model:selected="tree_selected"
              default-expand-all
              @update:selected="temp(tree_selected)"
            />
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popCategory = ref(true);

// tree
const tree_data = [
  {
    label: '대교드림스',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '권한 정보',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
              { id: 'a_5', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
            ],
          },
          { id: 'a_6', label: '뎁스3', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '결제 관련',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const tree_selected = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
</script>
