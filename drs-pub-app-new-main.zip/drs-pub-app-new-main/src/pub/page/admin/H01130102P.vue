<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog v-model="popCategory" @hide="popForm = true">
      <q-card class="dialog_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">문자패턴미리보기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            outline
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="preview_msg">
            <img src="/img/img-phone.svg" alt="" />
            <div class="msg_inner">
              <div class="msg">{{ previewMsg }}</div>
              <p class="msg_size text-body3">186 byte(MMS)</p>
            </div>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popCategory = ref(true);

const previewMsg =
  '학부모님 눈높이 남구교육국입니다. 1월 2일 월요일 발송해드린 <눈높이고객설문조사> 마감일입니다. 미참여하신 학부모님께서는 1분만 시간을 할애하시어, 자녀의 더 나은 학습을 위해 참여를 부탁드립니다. 늘 자녀를 우선하는 눈높이 교육이 되겠습니다. 감사합니다.-교사별 평가이니, 담당 교사가 두 분인 경우는 2회 모두 실시 부탁드립니다.';
</script>

<style lang="scss" scoped>
.preview_msg {
  position: relative;
  max-width: 338px;
  margin: 0 auto;
  text-align: center;
  img {
    max-width: 100%;
  }
  .msg_inner {
    position: absolute;
    top: 60px;
    bottom: 53px;
    left: 32px;
    right: 32px;
    padding-bottom: 50px;
    text-align: left;
    .msg {
      max-height: 100%;
      padding: 30px 20px 0;
      overflow-y: scroll;
    }
    .msg_size {
      position: absolute;
      bottom: 13px;
      right: 20px;
      opacity: 0.4;
    }
  }
}
</style>
