<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">캘린더 관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <div class="wrap_table_box">
        <h3 class="title3 bold">2022.11.22(수) 시스템 배치작업</h3>
        <table class="table_row_admin mt30">
          <colgroup>
            <col width="168px" />
            <col width="auto" />
            <col width="168px" />
            <col width="auto" />
          </colgroup>
          <tbody>
            <tr>
              <th>
                <span class="text-body2">시작일</span>
              </th>
              <td>2023년 1월 12일 오후 3시부터</td>
              <th class="line_l">
                <span class="text-body2">모듈 구분</span>
              </th>
              <td>공통모듈</td>
            </tr>
            <tr>
              <th>
                <span class="text-body2">종료일</span>
              </th>
              <td>2023년 1월 20일 오후 11시까지</td>
              <th class="line_l">
                <span class="text-body2">일정구분</span>
              </th>
              <td>-</td>
            </tr>
            <tr>
              <th>
                <span class="">반복</span>
              </th>
              <td colspan="3">매일</td>
            </tr>
            <tr>
              <th>
                <span class="">반복종료 </span>
              </th>
              <td colspan="3">2023년 1월 12일</td>
            </tr>
            <tr>
              <th>
                <span class="">영업일 </span>
              </th>
              <td colspan="3">시작일 기준 3일</td>
            </tr>
            <tr>
              <th>
                <span class="">메모</span>
              </th>
              <td colspan="3">
                <div class="">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="메모를 입력하세요"
                    :model-value="memo"
                    type="textarea"
                  ></q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="btn_area response mt50">
          <q-btn outline class="size_lg wide" label="임시저장" />
          <q-btn unelevated color="black" class="size_lg wide" label="제출" />
          <q-btn
            unelevated
            color="grey-2"
            class="size_lg btn_position_end"
            label="목록"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const memo = ref(
  '시스템 배치작업을 아래와 같이 수행합니다.시스템 배치작업을 아래와 같이 수행합니다.시스템 배치작업을아래와 같이 수행합니다.시스템 배치작업을 아래와 같이 수행합니다.'
);
</script>
