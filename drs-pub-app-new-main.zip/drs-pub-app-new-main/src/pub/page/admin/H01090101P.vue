<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 inner_form large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">일정등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">제목</span>
                  <q-input
                    v-model="dataFrom.txt"
                    class="as_dd hide_label"
                    label="* 제목"
                    placeholder="제목을 입력하세요"
                    outlined
                    stack-label
                    dense
                  >
                  </q-input>
                </div>
              </div>
            </li>

            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">일정 기간</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="하루종일"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="시간지정"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">영업일 기준 선택</span>
                  <div class="as_dd">
                    <q-select
                      style="width: 180px"
                      outlined
                      dense
                      v-model="dataFrom.selectStartStanardDate"
                      :options="StartStanardDateOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                    <q-input
                      outlined
                      v-model="dataFrom.startStandardDate"
                      class="hide_label inp_date"
                      style="width: 180px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              v-model="dataFrom.startStandardDate"
                            >
                              <div class="row items-center justify-end">
                                <q-btn
                                  v-close-popup
                                  label="확인"
                                  color="primary"
                                  flat
                                />
                              </div>
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">시작</span>
                  <div class="as_dd">
                    <q-input
                      outlined
                      v-model="dataFrom.startDate"
                      class="hide_label inp_date"
                      style="width: 180px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date minimal v-model="dataFrom.startDate">
                              <div class="row items-center justify-end">
                                <q-btn
                                  v-close-popup
                                  label="확인"
                                  color="primary"
                                  flat
                                />
                              </div>
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <q-select
                      style="width: 180px"
                      outlined
                      dense
                      v-model="dataFrom.selectTime"
                      :options="selectTimeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">종료</span>
                  <div class="as_dd">
                    <q-input
                      outlined
                      v-model="dataFrom.endDate"
                      class="hide_label inp_date"
                      style="width: 180px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date minimal v-model="dataFrom.endDate">
                              <div class="row items-center justify-end">
                                <q-btn
                                  v-close-popup
                                  label="확인"
                                  color="primary"
                                  flat
                                />
                              </div>
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <q-select
                      style="width: 180px"
                      outlined
                      dense
                      v-model="dataFrom.selectTime"
                      :options="selectTimeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                    <q-checkbox
                      v-model="dataFrom.lastDay"
                      dense
                      color="black"
                      class="inp_check"
                      label="말일"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">반복</span>
                  <div class="as_dd">
                    <q-select
                      style="width: 180px"
                      outlined
                      dense
                      v-model="dataFrom.selectRepeat"
                      :options="selectRepeatOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    ></q-select>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form" v-if="dataFrom.selectRepeat !== 'type01'">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">반복 종료</span>
                  <div class="as_dd">
                    <q-input
                      outlined
                      v-model="dataFrom.repeatEndDate"
                      class="hide_label inp_date"
                      style="width: 180px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date minimal v-model="dataFrom.repeatEndDate">
                              <div class="row items-center justify-end">
                                <q-btn
                                  v-close-popup
                                  label="확인"
                                  color="primary"
                                  flat
                                />
                              </div>
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>

            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">모듈구분</span>
                  <q-select
                    class="as_dd hide_label"
                    outlined
                    dense
                    label="선택하세요"
                    v-model="dataFrom.module"
                    :options="moduleOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dropdown-icon="ion-ios-arrow-down"
                  ></q-select>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">일정구분</span>
                  <q-select
                    class="as_dd hide_label"
                    outlined
                    dense
                    label="선택하세요"
                    v-model="dataFrom.schedule"
                    :options="scheduleOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dropdown-icon="ion-ios-arrow-down"
                  ></q-select>
                </div>
              </div>
            </li>

            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">비고</span>
                  <div class="mt15 mb15 full-width">
                    <q-input
                      class="as_dd hide_label"
                      outlined
                      placeholder="비고를 입력하세요"
                      type="textarea"
                      v-model="dataFrom.txt"
                    >
                      <template v-slot:label>비고</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
    .as_dd {
      display: flex;
      gap: 0 10px;
    }
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataFrom = ref({
  selectStartStanardDate: '시작일 기준',
  startStandardDate: '2022.01.02',
  selectDate: '시작일 기준',
  startDate: '2022.01.02',
  endDate: '2022.01.02',
  selectTime: '오전 11시',

  selectRepeat: 'type02',
  repeatEndDate: '2022.01.02',
  schedule: '',
  module: '',
  allow: 'false',
  lastDay: true,
});
const StartStanardDateOption = ref([
  {
    id: 'type01',
    desc: '시작일 기준',
  },
  {
    id: 'type02',
    desc: '종료일 기준',
  },
]);
const selectTimeOption = ref([
  {
    id: 'type01',
    desc: '오전 11시',
  },
  {
    id: 'type02',
    desc: '오전 12시',
  },
  {
    id: 'type03',
    desc: '오후 1시',
  },
  {
    id: 'type04',
    desc: '오후 2시',
  },
  {
    id: 'type05',
    desc: '오후 3시',
  },
  {
    id: 'type06',
    desc: '오후 4시',
  },
  {
    id: 'type07',
    desc: '오후 5시',
  },
  {
    id: 'type08',
    desc: '오후 6시',
  },
]);
const selectRepeatOption = ref([
  {
    id: 'type01',
    desc: '반복없음',
  },
  {
    id: 'type02',
    desc: '매일',
  },
  {
    id: 'type03',
    desc: '매달',
  },
  {
    id: 'type04',
    desc: '매년',
  },
]);
const scheduleOption = ref([
  {
    id: 'type01',
    desc: '타입1',
  },
  {
    id: 'type02',
    desc: '타입2',
  },
]);
const moduleOption = ref([
  {
    id: 'type01',
    desc: '타입1',
  },
  {
    id: 'type02',
    desc: '타입2',
  },
]);
</script>
