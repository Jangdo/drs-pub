<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tabHead"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
        <q-tab name="downer" label="화면구성" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tabHead" animated>
        <!-- tab1 tab 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <table class="table_form">
              <tbody>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시판명</span
                    >
                  </th>
                  <td colspan="3">
                    <div class="search_item type_full">
                      <q-input
                        class="box_xl inp_search"
                        placeholder="게시판명을 입력하세요."
                        outlined
                      >
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시판 설명</span
                    >
                  </th>
                  <td colspan="3">
                    <div style="height: 180px">
                      <q-input
                        outlined
                        placeholder="선택하세요"
                        type="textarea"
                      >
                        <template v-slot:label>게시판 설명</template>
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시판 타이틀</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >타이틀 형태</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시판 테이블</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >권한지정</span
                    >
                  </th>
                  <td colspan="1">
                    <q-btn
                      fill
                      unelevated
                      color="grey-2"
                      class="size_sm"
                      label="권한 설정"
                    />
                  </td>
                </tr>

                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시물카테고리
                    </span>
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >권한지정</span
                    >
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >게시판유형
                    </span>
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >단답형게시판여부</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >변경이력관리사용
                    </span>
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup2"
                      :options="radioGroupoptions2"
                      color="black"
                      inline
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >비인증게시판지정</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="search_item type_full">
                      <q-select
                        class="box_m"
                        v-model="dataSelect"
                        :options="dataSelectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >담당자 지정</span
                    >
                  </th>
                  <td colspan="3">
                    <div class="form_tree_selection">
                      <div class="row">
                        <q-option-group
                          v-model="radioGroup3"
                          :options="radioGroupoptions3"
                          color="black"
                          inline
                        />
                      </div>
                      <div class="tree_area">
                        <q-btn
                          fill
                          unelevated
                          color="grey-2"
                          class="size_sm"
                          label="대상선택"
                        />
                        <q-tree
                          style="height: 200px"
                          :nodes="treeData"
                          node-key="id"
                          text-color="grey-2"
                          selected-color="black"
                          class="tree type01"
                          v-model:selected="treeSelected"
                          default-expand-all
                          @update:selected="temp('트리2', treeSelected)"
                        >
                        </q-tree>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >보관기한설정여부</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="row">
                      <q-select
                        style="width: 280px"
                        class="box_m"
                        v-model="dataSelect2"
                        :options="dataSelectOption2"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect2 == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                      <q-select
                        style="width: 100px"
                        class="box_m"
                        v-model="dataSelect5"
                        :options="dataSelectOption5"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                      <p class="ml10">개월</p>
                    </div>
                  </td>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >신규게시물표시</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="row">
                      <q-option-group
                        v-model="radioGroup1"
                        :options="radioGroupoptions1"
                        color="black"
                        inline
                      />
                      <q-input
                        style="width: 100px"
                        class="box_xl inp_search"
                        placeholder="0"
                        outlined
                      >
                      </q-input>
                      <span class="ml10"> 일 이내 표기 </span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >첨부사이즈제한</span
                    >
                  </th>
                  <td colspan="3">
                    <div class="row">
                      <q-select
                        style="width: 280px"
                        class="box_m"
                        v-model="dataSelect3"
                        :options="dataSelectOption3"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect3 == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                      <q-input
                        style="width: 400px"
                        class="box_xl inp_search text-right"
                        placeholder="0"
                        model-value="10485760"
                        outlined
                      >
                      </q-input>
                      <span class="ml10">byte</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >첨부 확장자 제한(blacklist)</span
                    >
                  </th>
                  <td colspan="3">
                    <div class="row">
                      <q-select
                        style="width: 280px"
                        class="box_m"
                        v-model="dataSelect3"
                        :options="dataSelectOption3"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        :class="[dataSelect3 == 0 ? 'placehoder' : '']"
                      >
                      </q-select>
                      <q-input
                        style="width: 400px"
                        class="box_xl inp_search"
                        placeholder="0"
                        model-value="bat,exe,cat"
                        outlined
                      >
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >금칙어사용여부
                    </span>
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >이전/다음</span
                    >
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >말머리사용
                    </span>
                  </th>
                  <td colspan="1">
                    <div class="row">
                      <q-option-group
                        v-model="radioGroup1"
                        :options="radioGroupoptions1"
                        color="black"
                        inline
                      />
                    </div>
                    <div class="row">
                      <q-checkbox
                        v-model="dataCheck01[0]"
                        color="black"
                        label="제목"
                      />
                      <q-checkbox
                        v-model="dataCheck01[1]"
                        color="black"
                        label="덧글"
                      />
                      <q-input
                        style="width: 280px"
                        class="box_xl inp_search text-right ml40"
                        placeholder="0"
                        model-value="1"
                        outlined
                      >
                      </q-input>
                      <q-btn
                        fill
                        unelevated
                        color="grey-2"
                        class="size_sm ml10"
                        label="선택"
                      />
                    </div>
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >붐업여부</span
                    >
                  </th>
                  <td colspan="1">
                    <div class="row">
                      <q-option-group
                        v-model="radioGroup1"
                        :options="radioGroupoptions1"
                        color="black"
                        inline
                      />
                    </div>
                    <div class="row">
                      <div class="row">
                        <span class="ml10">추천수</span>
                        <q-input
                          style="width: 100px"
                          class="box_xl inp_search text-right ml10"
                          placeholder="0"
                          model-value="1"
                          outlined
                        >
                        </q-input>
                        <span class="ml40">조회수</span>
                        <q-input
                          style="width: 100px"
                          class="box_xl inp_search text-right ml10"
                          placeholder="0"
                          model-value="1"
                          outlined
                        >
                        </q-input>
                        <span class="ml10">(두조건만족)</span>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >덧글사용
                    </span>
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >찬반여부</span
                    >
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >목록게시물수
                    </span>
                  </th>
                  <td colspan="1">
                    <q-input
                      style="width: 280px"
                      class="box_xl inp_search text-right ml10"
                      placeholder="20"
                      model-value="20"
                      outlined
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >신고기능여부</span
                    >
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>
                </tr>
                <tr class="col2">
                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >목록검색기간
                    </span>
                  </th>
                  <td colspan="1">
                    <q-input
                      style="width: 280px"
                      class="box_xl inp_search text-right ml10"
                      placeholder="20"
                      model-value="20"
                      outlined
                    />
                  </td>

                  <th colspan="1">
                    <span class="text-body2 required upper_right"
                      >신고기능여부</span
                    >
                  </th>
                  <td colspan="1">
                    <q-option-group
                      v-model="radioGroup1"
                      :options="radioGroupoptions1"
                      color="black"
                      inline
                    />
                  </td>
                </tr>
              </tbody>
            </table>

            <div class="btn_area">
              <q-btn unelevated class="size_md btn_cancel" label="취소" />
              <q-btn unelevated class="size_md btn_save" label="저장" />
              <q-btn
                unelevated
                color="grey-2"
                class="size_lg btn_position_end"
                label="목록"
              />
            </div>
          </div>
        </q-tab-panel>
        <!--// tab1 tab 컨텐츠 -->
        <!-- tab2 tab 컨텐츠 -->
        <q-tab-panel name="tab2"></q-tab-panel>
        <!--// tab2 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tabHead = ref('tab1');
const radioGroup1 = ref('op1');
const radioGroupoptions1 = ref([
  {
    label: '사용안함',
    value: 'op1',
  },
  {
    label: '사용',
    value: 'op2',
  },
]);
const radioGroup2 = ref('op1');
const radioGroupoptions2 = ref([
  {
    label: '관리안함',
    value: 'op1',
  },
  {
    label: '관리',
    value: 'op2',
  },
]);
const radioGroup3 = ref('op2');
const radioGroupoptions3 = ref([
  {
    label: '지정안함',
    value: 'op1',
  },
  {
    label: '지정',
    value: 'op2',
  },
]);
const treeSelected = ref('id_1');

const treeData = [
  {
    label: '홍길동',
    id: 'id_1',
  },
  {
    label: '홍길동',
    id: 'id_2',
  },
  {
    label: '홍길동',
    id: 'id_3',
  },
  {
    label: '홍길동',
    id: 'id_5',
  },
  {
    label: '홍길동',
    id: 'id_6',
  },
  {
    label: '홍길동',
    id: 'id_7',
  },
];
const dataSelect = ref(['선택하세요']);
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);

const dataSelect2 = ref(['영구보관']);
const dataSelectOption2 = ref([
  {
    id: 'N',
    desc: '영구보관(N)',
  },
  {
    id: 'G',
    desc: '영구보관(G)',
  },
  {
    id: 'C',
    desc: '영구보관(C) ',
  },
  {
    id: 'M',
    desc: '영구보관(M)',
  },
]);

const dataSelect3 = ref(['기본값사용']);
const dataSelectOption3 = ref([
  {
    id: 'N',
    desc: '기본값사용(N)',
  },
  {
    id: 'G',
    desc: 'temp(G)',
  },
  {
    id: 'C',
    desc: 'temp(C) ',
  },
  {
    id: 'M',
    desc: 'temp(M)',
  },
]);

const dataSelect5 = ref(['1']);
const dataSelectOption5 = ref([
  {
    id: 'N',
    desc: '1',
  },
  {
    id: 'G',
    desc: '3',
  },
  {
    id: 'C',
    desc: '5',
  },
  {
    id: 'M',
    desc: '6',
  },
]);
const dataCheck01 = ref([true, false]);
// 트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}
</script>
<style lang="scss">
.ml40 {
  margin-left: 40px;
}
label.text-right input {
  text-align: right;
}

.form_tree_selection {
  .tree_area {
    margin-top: 14px;
    > .q-btn {
      margin-bottom: 24px;
    }
    > .q-tree {
      border: 1px solid rgba(0, 0, 0, 0.2);
      border-radius: 6px;
      padding: 24px 20px;
      background: #f7f7f7;
      overflow: auto;
      .q-tree__node {
        margin-bottom: 15px;
      }
    }
  }
}

span.required {
  &.upper_right {
    &:after {
      display: inline-block;
      content: '*';
      padding-right: 2px;
      color: #ff6b23;
    }
  }
}
</style>
