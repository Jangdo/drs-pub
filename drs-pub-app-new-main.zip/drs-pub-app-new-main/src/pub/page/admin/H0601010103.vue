<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">신고게시물 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class="box_l inp_search"
              outlined
              placeholder="제목을입력하세요"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_l inp_search"
              outlined
              placeholder="등록자를 입력하세요"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_l inp_search"
              outlined
              placeholder="신고자를 입력하세요"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              outlined
              :model-value="searchDate.from + ' ~ ' + searchDate.to"
              class="box_l inp_date normal"
              readonly
            >
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      mask="YYYY.MM.DD"
                      v-model="searchDate"
                      range
                      @update:model-value="
                        searchDate.from, $refs.qDateProxyFrom.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <div class="selectable_table type_01">
        <div class="btn_area">
          <q-space />
          <q-btn class="size_sm" outline label="선택삭제" />
          <q-btn class="size_sm" outline label="신고해제" />
        </div>

        <!-- markup-table body rowspan -->
        <q-markup-table
          separator="cell"
          class="combine_table mt20"
          wrap-cells
          v-model:pagination="dataPagination"
        >
          <thead>
            <tr>
              <th class="">선택</th>
              <th class="">게시판명 / 말머리</th>
              <th class="">게시물 제목 / 내용</th>
              <th class="">신고자</th>
              <th class="">신고일자</th>
              <th class="">등록자</th>
              <th class="">등록일</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="2">
                <q-checkbox v-model="dataCheck.d1" color="black" label="" />
              </td>
              <td>신고</td>
              <td class="text-left">신고 테스트</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.11.01 ~ 2022.12.01</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.12.01</td>
            </tr>
            <tr>
              <td class="row_first">[기타]</td>
              <td class="text-left">
                직원 xxx에 대한 비방글... 신고게시물 내용 테스트입니다.
              </td>
            </tr>

            <tr>
              <td rowspan="2">
                <q-checkbox v-model="dataCheck.d2" color="black" label="" />
              </td>
              <td>신고</td>
              <td class="text-left">테스트</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.11.01 ~ 2022.12.01</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.12.01</td>
            </tr>
            <tr>
              <td class="row_first">[기타]</td>
              <td class="text-left">
                신고게시물 제목에 대한 글자수 제한이 있지 않을까? 안 그럼 끝도
                없는데
              </td>
            </tr>

            <tr>
              <td rowspan="2">
                <q-checkbox v-model="dataCheck.d1" color="black" label="" />
              </td>
              <td>신고</td>
              <td class="text-left">신고 테스트</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.11.01 ~ 2022.12.01</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.12.01</td>
            </tr>
            <tr>
              <td class="row_first">[기타]</td>
              <td class="text-left">
                직원 xxx에 대한 비방글... 신고게시물 내용 테스트입니다.
              </td>
            </tr>

            <tr>
              <!-- 맨 마지막 줄 tr의 로우스팬이 있는 td에는 border_btm_0 이라는 class가 반드시! 있어야 합니다. -->
              <td rowspan="2" class="border_btm_0">
                <q-checkbox v-model="dataCheck.d2" color="black" label="" />
              </td>
              <td>신고</td>
              <td class="text-left">테스트</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.11.01 ~ 2022.12.01</td>
              <td rowspan="2">홍길동</td>
              <td rowspan="2">2022.12.01</td>
            </tr>
            <tr>
              <td class="row_first">[기타]</td>
              <td class="text-left">
                신고게시물 제목에 대한 글자수 제한이 있지 않을까? 안 그럼 끝도
                없는데
              </td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- //markup-table body rowspan -->

        <!-- pagination_container -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // pagination_container -->
      </div>
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const searchDate = ref({
  from: '2020.07.08',
  to: '2020.07.17',
});

const dataCheck = ref({
  d1: true,
  d2: true,
  d3: true,
  d4: true,
});

const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
