<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <table class="table_row_admin">
        <colgroup>
          <col width="168px" />
          <col width="auto" />
          <col width="168px" />
          <col width="auto" />
        </colgroup>
        <tbody>
          <tr>
            <th>
              <span class="required">게시대상</span>
            </th>
            <td>
              <div class=""></div>
            </td>
            <th class="line_l">
              <span class="required">게시옵션</span>
            </th>
            <td>
              <div class="row">
                <q-checkbox
                  v-model="dataCheck.check1"
                  label="긴급"
                  color="black"
                />
                <q-checkbox
                  v-model="dataCheck.check2"
                  label="공지"
                  color="black"
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>
              <span class="required">게시예약일</span>
            </th>
            <td colspan="3">
              <div class="row"></div>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="btn_area right">
        <q-btn
          fill
          unelevated
          color="grey-2"
          class="size_sm btn_list"
          label="목록"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataCheck = ref({
  check1: true,
  check2: false,
  reserve: false,
});
</script>
