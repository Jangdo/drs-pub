<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한설정이력_사용자</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <!-- wrapper_tab -->
          <div class="wrapper_tab">
            <!-- 탭 버튼 -->
            <q-tabs
              v-model="tab"
              dense
              class="tab_basic"
              color="white"
              active-color="white"
              active-bg-color="primary"
              indicator-color="transparent"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="user" label="사용자" :ripple="false" />
              <q-tab name="firm" label="조직" :ripple="false" />
              <q-tab name="menu" label="메뉴" :ripple="false" />
            </q-tabs>
            <!--// 탭 버튼 -->
            <q-tab-panels v-model="tab" animated>
              <!-- 탭 내용 사용자 tab 컨텐츠 -->
              <q-tab-panel name="user">
                <div class="search_wrap">
                  <div class="search_cnt">
                    <div class="row q-col-gutter-sm">
                      <div class="col-12 col-md-4">
                        <q-input
                          class="box_xl"
                          for=""
                          outlined
                          dense
                          v-model="userSearch"
                          placeholder="사번, 이름"
                        />
                      </div>
                    </div>
                  </div>
                  <div class="btn_area">
                    <q-btn outline class="size_sm btn_reset" icon="" label="">
                      <span class="a11y">초기화</span>
                    </q-btn>
                    <q-btn
                      class="size_sm btn_search"
                      fill
                      unelevated
                      label="조회"
                    />
                  </div>
                </div>

                <div class="wrap_tree_table mt20">
                  <!-- sm_area 트리 영역 -->
                  <div class="sm_area">
                    <div class="input_area">
                      <q-input
                        class="inp_search mb16"
                        outlined
                        dense
                        placeholder="조직명을 검색하세요"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <!-- <h3>지점을 선택하세요</h3> -->
                    <div class="tree_container">
                      <q-tree
                        :nodes="treeData"
                        node-key="id"
                        selected-color="primary"
                        class="category popup_tree type_tbl10"
                        v-model:selected="treeSelected"
                        default-expand-all
                        @update:selected="temp1(treeSelected)"
                        style="max-height: 581px; min-height: 581px"
                      >
                      </q-tree>
                    </div>
                  </div>
                  <!--// sm_area 트리 영역 -->
                  <!-- main_area 테이블 영역 -->
                  <div class="main_area">
                    <!-- general_table -->
                    <div class="table_dk">
                      <div class="table_top mb0">
                        <div class="info_wrap col-12 col-md-4">
                          <div class="h56 pt10 text-body2">
                            <span class="text-primary"
                              >총 <span>67</span>건</span
                            >이 조회되었습니다.
                          </div>
                        </div>
                      </div>
                      <q-table
                        class="scrollable sticky_table_header"
                        :rows-per-page-options="[0]"
                        style="max-height: 581px"
                        :rows="historyUserRows"
                        :columns="historyUserColumns"
                        row-key="code"
                        hide-bottom
                        hide-pagination
                        v-model:pagination="dataPagination"
                        separator="cell"
                      >
                        <template v-slot:body="props">
                          <q-tr>
                            <q-td key="idx" class="idx">
                              {{ props.row.idx }}
                            </q-td>
                            <q-td key="head" class="headquarters">{{
                              props.row.head
                            }}</q-td>
                            <q-td key="branch" class="branch">{{
                              props.row.branch
                            }}</q-td>
                            <q-td key="code" class="employee_num">
                              {{ props.row.code }}</q-td
                            >
                            <q-td key="name" class="user_name">
                              {{ props.row.name }}</q-td
                            >
                            <q-td key="authority" class="permission">
                              {{ tdAuthority(props.row.authority) }}
                            </q-td>
                          </q-tr>
                        </template>
                      </q-table>
                    </div>
                    <!--// general_table -->
                  </div>
                  <!--// main_area 테이블 영역 -->
                </div>
              </q-tab-panel>
              <!-- //탭 내용 사용자 tab 컨텐츠 -->
              <!-- 탭 내용 메뉴 tab 컨텐츠 -->
              <q-tab-panel name="firm">
                <div class="search_wrap">
                  <div class="search_cnt">
                    <div class="row q-col-gutter-sm">
                      <div class="col-12 col-md-4">
                        <q-input
                          class="box_xl"
                          for=""
                          outlined
                          dense
                          v-model="userSearch"
                          placeholder="조직"
                        />
                      </div>
                    </div>
                  </div>
                  <div class="btn_area">
                    <q-btn outline class="size_sm btn_reset" icon="" label="">
                      <span class="a11y">초기화</span>
                    </q-btn>
                    <q-btn
                      class="size_sm btn_search"
                      fill
                      unelevated
                      label="조회"
                    />
                  </div>
                </div>

                <div class="wrap_tree_table mt20">
                  <!-- sm_area 트리 영역 -->
                  <div class="sm_area">
                    <div class="input_area">
                      <q-input
                        class="inp_search mb16"
                        outlined
                        dense
                        placeholder="조직명을 검색하세요"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="tree_container">
                      <q-tree
                        :nodes="treeDataMenu"
                        node-key="id"
                        selected-color="primary"
                        class="category popup_tree"
                        v-model:selected="treeMenuSelected"
                        default-expand-all
                        @update:selected="temp1(treeMenuSelected)"
                        style="max-height: 581px; min-height: 581px"
                      />
                    </div>
                  </div>
                  <!--// sm_area 트리 영역 -->
                  <!-- main_area 테이블 영역 -->
                  <div class="main_area">
                    <!-- general_table -->
                    <div class="table_dk">
                      <div class="table_top mb0">
                        <div class="info_wrap col-12 col-md-4">
                          <div class="h56 pt10 text-body2">
                            <span class="text-primary"
                              >총 <span>67</span>건</span
                            >이 조회되었습니다.
                          </div>
                        </div>
                      </div>
                      <q-table
                        class="scrollable sticky_table_header"
                        :rows-per-page-options="[0]"
                        style="max-height: 581px"
                        :rows="historyMenuRows"
                        :columns="historyMenuColumns"
                        row-key="code"
                        hide-bottom
                        hide-pagination
                        v-model:pagination="dataPagination"
                        separator="cell"
                      >
                        <template v-slot:body="props">
                          <q-tr>
                            <q-td key="idx" class="idx">
                              {{ props.row.idx }}
                            </q-td>
                            <q-td key="path" class="menu_path">{{
                              props.row.path
                            }}</q-td>
                            <q-td key="name" class="menu_name">
                              {{ props.row.name }}</q-td
                            >
                            <q-td key="authority" class="authority">
                              <span class="tag" v-if="props.row.authority.add"
                                >등록</span
                              >
                              <span class="tag" v-if="props.row.authority.edit"
                                >수정</span
                              >
                              <span class="tag" v-if="props.row.authority.del"
                                >삭제</span
                              >
                              <span
                                class="tag"
                                v-if="props.row.authority.search"
                                >조회</span
                              ></q-td
                            >
                            <q-td key="worker" class="worker">
                              {{ props.row.worker }}</q-td
                            >
                          </q-tr>
                        </template>
                      </q-table>
                    </div>
                    <!--// general_table -->
                  </div>
                  <!--// main_area 테이블 영역 -->
                </div>
              </q-tab-panel>
              <!-- //탭 내용 메뉴 tab 컨텐츠 -->
              <!-- 탭 내용 메뉴 tab 컨텐츠 -->
              <q-tab-panel name="menu">
                <div class="search_wrap">
                  <div class="search_cnt">
                    <div class="row q-col-gutter-sm">
                      <div class="col-12 col-md-4">
                        <q-input
                          class="box_xl"
                          for=""
                          outlined
                          dense
                          v-model="menuSearch"
                          placeholder="메뉴"
                        />
                      </div>
                    </div>
                  </div>
                  <div class="btn_area">
                    <q-btn outline class="size_sm btn_reset" icon="" label="">
                      <span class="a11y">초기화</span>
                    </q-btn>
                    <q-btn
                      class="size_sm btn_search"
                      fill
                      unelevated
                      label="조회"
                    />
                  </div>
                </div>

                <div class="wrap_tree_table mt20">
                  <!-- sm_area 트리 영역 -->
                  <div class="sm_area">
                    <div class="input_area">
                      <q-input
                        class="inp_search mb16"
                        outlined
                        dense
                        placeholder="조직명을 검색하세요"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="tree_container">
                      <q-tree
                        :nodes="treeDataMenu"
                        node-key="id"
                        selected-color="primary"
                        class="category popup_tree"
                        v-model:selected="treeMenuSelected"
                        default-expand-all
                        @update:selected="temp1(treeMenuSelected)"
                        style="max-height: 581px; min-height: 581px"
                      />
                    </div>
                  </div>
                  <!--// sm_area 트리 영역 -->
                  <!-- main_area 테이블 영역 -->
                  <div class="main_area">
                    <!-- general_table -->
                    <div class="table_dk">
                      <div class="table_top mb0">
                        <div class="info_wrap col-12 col-md-4">
                          <div class="h56 pt10 text-body2">
                            <span class="text-primary"
                              >총 <span>67</span>건</span
                            >이 조회되었습니다.
                          </div>
                        </div>
                      </div>
                      <q-table
                        class="scrollable sticky_table_header"
                        :rows-per-page-options="[0]"
                        style="max-height: 581px"
                        :rows="historyMenuRows"
                        :columns="historyMenuColumns"
                        row-key="code"
                        hide-bottom
                        hide-pagination
                        v-model:pagination="dataPagination"
                        separator="cell"
                      >
                        <template v-slot:body="props">
                          <q-tr>
                            <q-td key="idx" class="idx">
                              {{ props.row.idx }}
                            </q-td>
                            <q-td key="path" class="menu_path">{{
                              props.row.path
                            }}</q-td>
                            <q-td key="name" class="menu_name">
                              {{ props.row.name }}</q-td
                            >
                            <q-td key="authority" class="authority">
                              <span class="tag" v-if="props.row.authority.add"
                                >등록</span
                              >
                              <span class="tag" v-if="props.row.authority.edit"
                                >수정</span
                              >
                              <span class="tag" v-if="props.row.authority.del"
                                >삭제</span
                              >
                              <span
                                class="tag"
                                v-if="props.row.authority.search"
                                >조회</span
                              ></q-td
                            >
                            <q-td key="worker" class="worker">
                              {{ props.row.worker }}</q-td
                            >
                          </q-tr>
                        </template>
                      </q-table>
                    </div>
                    <!--// general_table -->
                  </div>
                  <!--// main_area 테이블 영역 -->
                </div>
              </q-tab-panel>
              <!-- //탭 내용 메뉴 tab 컨텐츠 -->
            </q-tab-panels>
          </div>
        </q-card-section>
        <!-- <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions> -->
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

// tab
const tab = ref('user');
// user
// const headSelect = ref('');
// const headSelectOption = ref([
//   {
//     id: '',
//     desc: '본부를 선택하세요',
//     // disable 옵션 샘플
//     inactive: true,
//   },
//   {
//     id: 'N',
//     desc: '서울강북본부1',
//   },
//   {
//     id: 'G',
//     desc: '서울강북본부2',
//   },
//   {
//     id: 'C',
//     desc: '서울강북본부3',
//   },
//   {
//     desc: '서울강북본부4',
//   },
// ]);

const userSearch = ref('');
// tree
const treeData = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              { id: 'a_5', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
            ],
          },
          { id: 'a_6', label: '뎁스3', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];

const treeSelected = ref('메시지 카테고리');
//historyUser_table데이터
const historyUserColumns = ref([
  {
    name: 'idx',
    label: '순번',
    align: 'center',
    sortable: false,
    field: (row) => row.idx,
  },
  {
    name: 'head',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.head,
  },
  {
    name: 'branch',
    label: '지점',
    sortable: false,
    align: 'center',
    field: (row) => row.head,
  },
  {
    name: 'employeeNumber',
    label: '사원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },
  {
    name: 'name',
    label: '이름',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'permission',
    label: '권한여부',
    sortable: false,
    align: 'center',
    field: (row) => row.head,
  },
]);
const historyUserRows = ref([
  {
    idx: 100,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 99,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 98,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 97,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 96,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
  {
    idx: 95,
    head: '서울강북본부',
    branch: '서울강북지점',
    code: 'PCG7040001',
    name: '홍길동',
    authority: 'add',
  },
]);
// const dataPagination = ref({
//   current: 1,
//   sortBy: 'idx',
//   descending: true,
//   page: 1,
//   rowsPerPage: 17,
// });
// td 상태값
function tdAuthority(authority) {
  switch (authority) {
    case 'add':
      return '생성';
    case 'del':
      return '삭제';
    default:
      return '';
  }
}
// menu
const menuSearch = ref('');
// treeDataMenu
const treeDataMenu = [
  {
    label: '메뉴 카테고리',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '시스템관리자',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
              { id: 'a_5', label: '뎁스4', img: '/icons/icon-tree-folder.svg' },
            ],
          },
          { id: 'a_6', label: '뎁스3', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeMenuSelected = ref('메시지 카테고리');

//historyUser_table데이터
const historyMenuColumns = ref([
  {
    name: 'idx',
    label: '순번',
    align: 'center',
    sortable: false,
    field: (row) => row.idx,
  },
  {
    name: 'path',
    label: '메뉴경로',
    sortable: false,
    align: 'center',
    field: (row) => row.path,
  },
  {
    name: 'name',
    label: '메뉴명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'authority',
    label: '권한',
    sortable: false,
    align: 'center',
  },
  {
    name: 'worker',
    label: '작업자',
    sortable: false,
    align: 'center',
  },
]);
const historyMenuRows = ref([
  {
    idx: 100,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 99,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 98,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 97,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 96,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
  {
    idx: 95,
    path: '학습상담 > 내교실 > 학습콘텐츠',
    name: '회원정보',
    authority: { add: true, edit: true, del: true, search: true },
    worker: '홍길동',
  },
]);
//  트리 셀렉트 이벤트
function temp1(target) {
  console.log('셀렉트 이벤트 발생', target);
}
</script>
