<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb40"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
        <q-tab name="tab3" label="화면구성" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1"> tab1 </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->

        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3">
          <q-card class="wrap_table_box">
            <h3 class="title1 mb20">목록화면</h3>
            <q-markup-table separator="cell" wrap-cells>
              <thead>
                <tr>
                  <th class="">제목</th>
                  <th class="">등록 패스워드</th>
                  <th class="">생성일</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="제목을 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="등록 패스워드를 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="생성일을 입력하세요"
                      />
                    </div>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>

            <div class="row-2 mt60 mb20">
              <h3 class="title1">등록화면</h3>
              <div class="btn_area">
                <q-btn
                  class="size_sm"
                  color="grey-7"
                  outline
                  label="1칼럼 추가"
                />
                <q-btn
                  class="size_sm ml10"
                  color="grey-7"
                  outline
                  label="2칼럼 추가"
                />
              </div>
            </div>
            <table class="table_row_sales">
              <colgroup>
                <col />
                <col style="width: 180px" />
              </colgroup>
              <tbody>
                <tr>
                  <td>
                    <div class="search_item">
                      <q-select
                        class=""
                        v-model="titleSelect"
                        :options="titleSelectOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <td class="line_l text_center">
                    <q-btn
                      outline
                      class="size_xs btn_inner_table"
                      label="삭제"
                    />
                  </td>
                </tr>

                <tr>
                  <td>
                    <div class="search_item">
                      <q-select
                        class=""
                        v-model="ctSelect"
                        :options="ctSelectOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <td class="line_l text_center">
                    <q-btn
                      outline
                      class="size_xs btn_inner_table"
                      label="삭제"
                    />
                  </td>
                </tr>

                <tr>
                  <td>
                    <div class="search_item">
                      <q-select
                        class=""
                        v-model="categorySelect"
                        :options="categorySelectOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <td class="line_l text_center">
                    <q-btn
                      outline
                      class="size_xs btn_inner_table"
                      label="삭제"
                    />
                  </td>
                </tr>

                <tr>
                  <td>
                    <div class="row-4">
                      <div class="search_item">
                        <q-select
                          class=""
                          v-model="targetSelect"
                          :options="targetSelectOpt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                      <div class="search_item m0">
                        <q-select
                          class=""
                          v-model="optionSelect"
                          :options="optionSelectOpt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </div>
                  </td>
                  <td class="line_l text_center">
                    <q-btn
                      outline
                      class="size_xs btn_inner_table"
                      label="삭제"
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </q-card>
        </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab3');

const titleSelect = ref(['제목']);
const titleSelectOpt = ref([
  {
    id: 'tt1',
    desc: '제목1',
  },
  {
    id: 'tt2',
    desc: '제목12',
  },
]);

const ctSelect = ref(['본문']);
const ctSelectOpt = ref([
  {
    id: 'ct1',
    desc: '본문1',
  },
  {
    id: 'ct2',
    desc: '본문2',
  },
]);

const categorySelect = ref(['카테고리']);
const categorySelectOpt = ref([
  {
    id: 'category1',
    desc: '카테고리1',
  },
  {
    id: 'category2',
    desc: '카테고리2',
  },
]);

const targetSelect = ref(['게시대상']);
const targetSelectOpt = ref([
  {
    id: 'target1',
    desc: '게시대상1',
  },
  {
    id: 'target2',
    desc: '게시대상2',
  },
]);

const optionSelect = ref(['게시옵션']);
const optionSelectOpt = ref([
  {
    id: 'option1',
    desc: '게시옵션1',
  },
  {
    id: 'option2',
    desc: '게시옵션2',
  },
]);
</script>
