<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">시스템메시지 관리</h2>
      <Breadcrumbs />
    </div>

    <!-- table_search_area type_02 -->
    <div class="table_search_area type_02">
      <div class="inline">
        <div class="wrap_item_input">
          <!-- <h3>메시지명</h3> -->
          <q-input
            class="inp_msg_name"
            outlined
            v-model="msg_name"
            placeholder="메시지명을 입력하세요"
          />
        </div>
        <div class="wrap_item_input">
          <!-- <h3>등록자</h3> -->
          <q-input
            class="inp_author"
            outlined
            v-model="author"
            placeholder="등록자를 입력하세요"
          />
        </div>
        <div class="wrap_item_input">
          <!-- <h3>사용여부</h3> -->
          <q-select
            class="inp_use"
            v-model="searchUseSelected"
            :options="searchSelectOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
      </div>

      <div class="inline">
        <div class="wrap_item_input">
          <!-- <h3>구분</h3> -->
          <q-select
            class="inp_msg_type"
            v-model="searchSelectChoice"
            :options="searchSelectChoiceOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
        <div class="wrap_item_input">
          <!-- <h3>일자</h3> -->
          <div class="inner_wrap">
            <!-- searchDate start.from -->
            <q-input outlined v-model="searchDate.from" class="inp_date">
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      mask="YYYY.MM.DD"
                      v-model="searchDate.from"
                      @update:model-value="
                        searchDate.from, $refs.qDateProxyFrom.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
            <!--// searchDate start.from -->
            <div class="tilde">
              <span>~</span>
            </div>
            <!-- searchDate start.to -->
            <q-input outlined v-model="searchDate.to" class="inp_date">
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyto"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      v-model="searchDate.to"
                      mask="YYYY.MM.DD"
                      @update:model-value="
                        searchDate.to, $refs.qDateProxyto.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
            <!--// searchDate start.to -->
          </div>
        </div>
        <div class="btn_area">
          <q-btn fill unelevated class="size_sm btn_search" label="조회" />
          <q-btn
            class="size_sm btn_reset"
            icon="ion-ios-refresh"
            outline
            label="초기화"
          />
        </div>
      </div>
    </div>
    <!--// table_search_area type_02 -->
    <q-card class="row row-2 wrap_table_box">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="btn_area">
          <q-btn
            fill
            unelevated
            class="size_sm btn_folder_add"
            icon="ion-ios-add"
            label="폴더추가"
          />
          <q-btn class="size_sm btn_folder_modify" outline label="폴더수정" />
          <q-btn class="size_sm btn_folder_delete" outline label="폴더삭제" />
        </div>
        <q-tree
          :nodes="tree_data"
          node-key="id"
          selected-color="primary"
          class="category"
          v-model:selected="tree_selected"
          default-expand-all
          @update:selected="temp(tree_selected)"
        />
      </div>
      <!--// sm_area 트리 영역 -->
      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- selectable_table type_01 -->
        <div class="selectable_table type_01">
          <div class="btn_area">
            <q-btn
              class="size_sm btn_delete"
              outline
              icon=""
              label="선택삭제"
            />
            <q-btn
              class="size_sm btn_write"
              outline
              icon="ion-ios-add"
              label="신규등록"
            />
            <q-space />
          </div>
          <q-table
            :rows="msg_rows"
            :columns="msg_columns"
            row-key="idx"
            v-model:selected="msg_selected"
            selection="multiple"
            v-model:pagination="msg_pagination"
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :class="props.row.state" :props="props">
                <q-td class="select"
                  ><q-checkbox v-model="props.selected"
                /></q-td>
                <q-td key="idx" class="idx">{{ props.row.idx }}</q-td>
                <q-td key="category" class="category">
                  {{ props.row.category }}</q-td
                >
                <q-td key="id" class="msg_id"> {{ props.row.id }}</q-td>
                <q-td key="name" class="name"> {{ props.row.name }}</q-td>
                <q-td key="author" class="author"> {{ props.row.author }}</q-td>
                <q-td key="state" class="state">
                  {{ tdState(props.row.state) }}
                </q-td>
                <q-td key="allow" :props="props" class="allow">
                  <q-toggle v-model="props.row.allow" class="custom_tgl" />
                </q-td>
                <q-td key="btn" :props="props" class="hasbtn">
                  <q-btn
                    outline
                    class="size_sm btn_detail_view"
                    label="보기"
                    @click="tableEvt(props.row.idx)"
                  >
                  </q-btn>
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="msg_pagination.page"
              direction-links
              boundary-links
              :max-pages="10"
              :max="pagesNumber"
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              icon-prev="keyboard_arrow_left"
              icon-next="keyboard_arrow_right"
              class="custom_pagination type_01"
            />
          </div>
        </div>
        <!--// selectable_table type_01-->
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: 'home',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');
table_search_area;
const searchUseSelected = ref(['사용여부를 선택하세요']);
const searchSelectOption = ref([
  {
    id: 'Y',
    desc: '사용',
  },
  {
    id: 'N',
    desc: '미사용',
  },
]);
const searchSelectChoice = ref(['구분을 선택하세요']);
const searchSelectChoiceOption = ref([
  {
    id: 'A',
    desc: '전체',
    // disable 옵션 샘플
    // inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const author = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const msg_name = ref('');

// msg_dialog
const msg_dialog = ref({
  open: false,
  id: 0,
});

//msg_table데이터
const msg_selected = ref([]);
const pagesNumber = computed(() =>
  Math.ceil(msg_rows.value.length / msg_pagination.value.rowsPerPage)
);
const msg_columns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'id',
    label: '메시지 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },
  {
    name: 'name',
    label: '메시지 명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'author',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'state',
    label: '구분',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msg_rows = ref([
  {
    idx: '1',
    category: '권한정보',
    id: 'MSG_C0000',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '2',
    category: '결제관련',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'alert',
    allow: true,
  },
  {
    idx: '3',
    category: '결제관련',
    id: 'MSG_C0002',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'alert',
    allow: false,
  },
  {
    idx: '4',
    category: '권한정보',
    id: 'MSG_C0003',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'alert',
    allow: false,
  },
  {
    idx: '5',
    category: '권한정보',
    id: 'MSG_C0004',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'alert',
    allow: false,
  },
  {
    idx: '6',
    category: '권한정보',
    id: 'MSG_C0005',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: true,
  },

  //
  {
    idx: '7',
    category: '권한정보',
    id: 'MSG_C0006',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '8',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '9',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '10',
    category: '권한정보',
    id: 'MSG_C0008',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '11',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '12',
    category: '권한정보',
    id: 'MSG_C0009',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
]);
const msg_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});
// td 상태값
function tdState(priority) {
  switch (priority) {
    case 'confirm':
      return '확인';
    case 'alert':
      return '알림';
    default:
      return '';
  }
}

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
  msg_dialog.value.idx = id;
  msg_dialog.value.open = true;
}
</script>
