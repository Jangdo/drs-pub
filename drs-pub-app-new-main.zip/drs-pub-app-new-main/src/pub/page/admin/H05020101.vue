<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">카테고리관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class="box_xl inp_search"
              for=""
              outlined
              dense
              v-model="categorySearch"
              placeholder="카테고리명"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box wrap_table_divide">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="btn_area">
          <q-btn
            fill
            unelevated
            color="black"
            class="size_sm"
            label="폴더추가"
          />
          <q-btn class="size_sm" outline label="폴더수정" />
          <q-btn class="size_sm" outline label="폴더삭제" />
        </div>
        <div class="tree_container">
          <q-tree
            :nodes="tree_data"
            node-key="id"
            selected-color="primary"
            class="category type_tbl_only"
            v-model:selected="tree_selected"
            default-expand-all
            @update:selected="temp(tree_selected)"
            style="max-height: 657px; min-height: 657px"
          />
        </div>
      </div>
      <!--// sm_area 트리 영역 -->

      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- general_table -->
        <div class="table_dk">
          <!-- <div class="btn_area">
            <q-btn
              class="size_sm btn_delete"
              outline
              icon="delete_outline"
              label="삭제"
            />
            <q-btn
              class="size_sm btn_new_add"
              outline
              icon="ion-ios-add"
              label="신규등록"
            />
            <q-btn
              fill
              unelevated
              class="size_sm btn_save"
              label="저장"
            />
          </div> -->
          <q-table
            :rows="categoryRows"
            :columns="categoryColumns"
            row-key="idx"
            v-model:selected="categorySelected"
            selection="multiple"
            hide-bottom
            hide-pagination
            separator="cell"
            color="black"
            class="scrollable sticky_table_header mt50"
            :rows-per-page-options="[0]"
            style="max-height: 657px"
          >
            <!-- <template v-slot:header="props">
              <q-tr :props="props">
                <q-th class="select"><q-checkbox v-model="props.selected" color="black" /></q-th>
                <q-th class="">카테고리 ID</q-th>
                <q-th class="">경로</q-th>
                <q-th class="">카테고리명</q-th>
                <q-th class="">등록자</q-th>
                <q-th class="">사용여부</q-th>
              </q-tr>
            </template> -->
            <template v-slot:body="props">
              <q-tr :class="props.row.state" :props="props">
                <q-td class="select"
                  ><q-checkbox v-model="props.selected" color="black"
                /></q-td>
                <q-td key="idx" class="id">{{ props.row.id }}</q-td>
                <q-td key="path" class=""> {{ props.row.path }}</q-td>
                <q-td key="name" class="name"> {{ props.row.name }}</q-td>
                <q-td key="author" class="msg_author text-center">
                  {{ props.row.author }}
                </q-td>
                <q-td key="allow" :props="props" class="allow">
                  <q-toggle
                    v-model="props.row.allow"
                    class="custom_tgl"
                    color="black"
                  />
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table -->
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: '',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

// menu

// const userSearch = ref('');

const categorySearch = ref('');
const categoryColumns = ref([
  {
    name: 'id',
    label: '카테고리 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },
  {
    name: 'path',
    label: '경로',
    sortable: false,
    align: 'center',
    field: (row) => row.path,
  },
  {
    name: 'name',
    label: '카테고리명',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },

  {
    name: 'author',
    label: '등록자',
    sortable: false,
    align: 'center',
  },
  {
    name: 'allow',
    label: '사용여부',
    field: 'allow',
    sortable: false,
    align: 'center',
  },
]);

const categoryRows = ref([
  {
    idx: 100,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 99,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 98,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 97,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 96,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
  {
    idx: 95,
    id: 'P057040001',
    path: 'Help Desk FAQ > IT보안',
    name: 'IT보안',
    author: '관리자',
    allow: false,
  },
]);

const categorySelected = ref([]);
</script>
