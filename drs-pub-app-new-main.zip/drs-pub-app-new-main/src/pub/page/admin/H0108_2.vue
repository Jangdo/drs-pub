<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 inner_form large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메뉴 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 영역 -->
        <q-card-section class="dialog_content">
          <!-- table_search_area type_03 -->
          <div class="table_search_area type_03">
            <!-- <h3>검색어를 입력하세요</h3> -->
            <q-input
              class="inp_search"
              for=""
              outlined
              dense
              v-model="dataFrom.search"
              placeholder="검색어를 입력하세요"
            />
            <div class="btn_area">
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <!--// table_search_area type_03 -->
          <!-- inner_list -->
          <ul class="inner_list">
            <li>
              <span class="as_dt">도로명(지번) 주소</span>
              <div class="as_dd">서울특별시 관악구 보라매로 3길 12</div>
            </li>
            <li>
              <span class="as_dt">상세주소입력</span>
              <div class="as_dd">
                <q-input
                  v-model="dataFrom.address"
                  class="hide_label"
                  label="PATH"
                  outlined
                  placeholder="32번지 3층"
                  stack-label
                  dense
                >
                </q-input>
                <p class="mt6">(봉천동)</p>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  address: '32번지 3층',
});
</script>
