<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">채점교사 상세</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="mb40">
            <div class="mb16">
              <span class="title1">채점교사</span>
            </div>
            <!-- inner_list -->
            <ul class="inner_list">
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">이름</span>
                    <div class="as_dd">
                      {{ inpName }}
                    </div>
                  </div>
                  <div class="form_item">
                    <span class="as_dt">LC/YC 구분</span>
                    <div class="as_dd">
                      {{ inp02 }}
                    </div>
                  </div>
                </div>
              </li>
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">휴대폰번호</span>
                    <div class="as_dd">
                      {{ inpPhone }}
                    </div>
                  </div>
                  <div class="form_item">
                    <span class="as_dt">생년월일</span>
                    <div class="as_dd">
                      {{ inpBirth }}
                    </div>
                  </div>
                </div>
              </li>
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">소속</span>
                    <div class="as_dd">
                      {{ inp03 }}
                    </div>
                  </div>
                  <div class="form_item">
                    <span class="as_dt">사용여부</span>
                    <div class="as_dd">
                      {{ inpUse }}
                    </div>
                  </div>
                </div>
              </li>
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">근무기간</span>
                    <div class="as_dd">
                      {{ inpWork }}
                    </div>
                  </div>
                  <div class="form_item">
                    <span class="as_dt">이용시간</span>
                    <div class="as_dd">
                      {{ inpUseTime }}
                    </div>
                  </div>
                </div>
              </li>
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">배포앱 버전</span>
                    <span class="as_dd">3.8.1</span>
                  </div>
                  <div class="form_item">
                    <span class="as_dt">콘텐츠 버전</span>
                    <span class="as_dd">3.8.1</span>
                  </div>
                </div>
              </li>
              <li class="divide_form">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt">단말고유키</span>
                    <div class="as_dd row al_center">
                      <span class="mr10">6123434dfa546g43645t1</span>
                      <q-btn
                        outline
                        color="grey-2"
                        class="size_xs btn_inner_table"
                        label="초기화"
                      />
                    </div>
                  </div>
                </div>
              </li>
              <li class="hastextarea">
                <div class="form_row">
                  <div class="form_item">
                    <span class="as_dt required">비고</span>
                    <div class="as_dd wrap_counsel_form">
                      <div class="wrap_textarea mt15 mb15">
                        <q-input
                          class="basic text-phara1 medium"
                          outlined
                          v-model="dataTextArea"
                          placeholder="입력하세요"
                          type="textarea"
                        >
                          <template v-slot:label>메시지 내용</template>
                        </q-input>
                        <div class="check_val">
                          <span>0</span>/<span>1,000</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <!--// inner_list -->
          </div>
          <div class="">
            <div class="row mb16 al_center">
              <span class="title1 mr15">월별 작업내역</span>
              <div class="row">
                <q-select
                  class="hide_label mr15 year"
                  v-model="searchYearType"
                  :options="searchYearTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  label=""
                  dropdown-icon="ion-ios-arrow-down"
                >
                  <template v-slot:after> 년 </template>
                </q-select>
                <q-select
                  class="hide_label month"
                  v-model="selectMonth"
                  :options="selectMonthOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  label=""
                  dropdown-icon="ion-ios-arrow-down"
                >
                  <template v-slot:after> 월 </template>
                </q-select>
              </div>
            </div>
            <q-markup-table separator="cell" wrap-cells>
              <colgroup>
                <col style="width: 140px" />
                <col style="width: 140px" />
                <col />
              </colgroup>
              <tbody>
                <tr>
                  <td class="text-center">3일(금)</td>
                  <td class="text-center">소속</td>
                  <td class="pa20">
                    1. 김한별(P1) - M<br />
                    2. 김한별(P1) - M<br />
                    3. 김한별(P1) - M
                  </td>
                </tr>
                <tr>
                  <td class="text-center">3일(금)</td>
                  <td class="text-center">소속</td>
                  <td class="pa20">
                    1. 김한별(P1) - M<br />
                    2. 김한별(P1) - M<br />
                    3. 김한별(P1) - M
                  </td>
                </tr>
              </tbody>
            </q-markup-table>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn outline unelevated class="size_lg" label="비밀번호 초기화" />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const inpName = ref('홍길동');
const inp02 = ref('LC 채점교사');
const inpPhone = ref('010-1234-5678');
const inpBirth = ref('2023년 06월 01일');
const inp03 = ref('경기본부 안산교육국 원곡');
const inpUse = ref('사용중');
const inpWork = ref('2023.01.12 ~ 2023.06.11');
const inpUseTime = ref('09:00 ~ 17:00');

const searchYearType = ref(['']);
const searchYearTypeOption = ref([
  {
    id: 'year1',
    desc: '2023',
  },
  {
    id: 'year1',
    desc: '2024',
  },
]);

const selectMonth = ref(['']);
const selectMonthOption = ref([
  {
    id: 'm1',
    desc: '01',
  },
  {
    id: 'm2',
    desc: '02',
  },
  {
    id: 'm3',
    desc: '03',
  },
  {
    id: 'm4',
    desc: '04',
  },
  {
    id: 'm5',
    desc: '05',
  },
  {
    id: 'm6',
    desc: '06',
  },
  {
    id: 'm7',
    desc: '07',
  },
  {
    id: 'm8',
    desc: '08',
  },
  {
    id: 'm9',
    desc: '09',
  },
  {
    id: 'm10',
    desc: '10',
  },
  {
    id: 'm11',
    desc: '11',
  },
  {
    id: 'm12',
    desc: '12',
  },
]);

const dataTextArea = ref('');
</script>
