<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="wrap_table_box">
      <table class="table_row_admin mb20">
        <colgroup>
          <col style="width: 180px" />
          <col />
          <col style="width: 180px" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th>제목</th>
            <td colspan="3">
              <div class="row">
                <q-select
                  class="w280 hide_label"
                  label="말머리"
                  v-model="searchCategory"
                  :options="searchCategoryOption"
                  option-value="sysytemCategory"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
                <q-input
                  class="inp_search"
                  outlined
                  dense
                  placeholder="입력해주세요"
                  v-model="inpClear"
                >
                </q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th>게시 카테고리</th>
            <td colspan="3">
              <div class="row">
                <q-btn
                  unelevated
                  color="grey-3"
                  class="size_sm"
                  label="카테고리 선택"
                />
                <span class="ml10 body2 text-black">123123</span>
              </div>
            </td>
          </tr>
          <tr>
            <th>게시 대상</th>
            <td>
              <div class="row">
                <q-btn
                  unelevated
                  color="grey-3"
                  class="size_sm"
                  label="게시 대상"
                />
                <span class="ml10 body2 text-black">게시 대상</span>
              </div>
            </td>
            <th><span class="required">게시 옵션</span></th>
            <td>
              <div class="row-4">
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck2.check1"
                  label="긴급"
                  color="black"
                  dense
                />
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck2.check2"
                  label="공지"
                  color="black"
                  dense
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>게시 예약일</th>
            <td colspan="3">
              <div class="row">
                <q-checkbox
                  class="mr10"
                  v-model="dataCheck2.check3"
                  color="black"
                  dense
                />
                <div class="row items-center">
                  <div class="search_item type_fix">
                    <!-- searchDate start.from -->
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!--// searchDate start.from -->
                  </div>
                </div>
                <div class="row items-center ml10">
                  <div class="search_item type_medium">
                    <q-select
                      class="hide_label"
                      label=""
                      v-model="revHour"
                      :options="revHourOpt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <div class="search_item type_medium">
                    <q-select
                      class="hide_label"
                      label=""
                      v-model="revMinute"
                      :options="revMinuteOpt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th>텍스트 한줄</th>
            <td colspan="3">
              <q-input
                class="inp_search"
                outlined
                dense
                placeholder="입력해주세요"
                v-model="inpClear"
              >
              </q-input>
            </td>
          </tr>
          <tr>
            <th>텍스트 여러줄</th>
            <td colspan="3">
              <q-input
                class="basic text-phara1"
                outlined
                v-model="dataTextArea"
                placeholder="입력해주세요"
                type="textarea"
              >
              </q-input>
            </td>
          </tr>
          <tr>
            <th>콤보 코드</th>
            <td colspan="3">
              <div class="row">
                <q-btn
                  unelevated
                  color="grey-3"
                  class="size_sm"
                  label="코드선택"
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>멀티콤보 코드</th>
            <td colspan="3">
              <div class="row">
                <q-btn
                  unelevated
                  color="grey-3"
                  class="size_sm"
                  label="코드선택"
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>내용</th>
            <td colspan="3">
              <q-editor
                v-model="qeditor"
                :toolbar="[
                  [
                    {
                      label: $q.lang.editor.align,
                      icon: $q.iconSet.editor.align,
                      fixedLabel: true,
                      // list: 'only-icons',
                      options: ['left', 'center', 'right', 'justify'],
                    },
                  ],
                  [
                    'bold',
                    'italic',
                    'strike',
                    'underline',
                    'subscript',
                    'superscript',
                  ],
                  ['token', 'hr', 'link', 'custom_btn'],
                  ['print', 'fullscreen'],
                  [
                    {
                      label: $q.lang.editor.formatting,
                      icon: $q.iconSet.editor.formatting,
                      list: 'no-icons',
                      options: [
                        'p',
                        'h1',
                        'h2',
                        'h3',
                        'h4',
                        'h5',
                        'h6',
                        'code',
                      ],
                    },
                    {
                      label: $q.lang.editor.fontSize,
                      icon: $q.iconSet.editor.fontSize,
                      fixedLabel: true,
                      fixedIcon: true,
                      list: 'no-icons',
                      options: [
                        'size-1',
                        'size-2',
                        'size-3',
                        'size-4',
                        'size-5',
                        'size-6',
                        'size-7',
                      ],
                    },
                    {
                      label: $q.lang.editor.defaultFont,
                      icon: $q.iconSet.editor.font,
                      fixedIcon: true,
                      list: 'no-icons',
                      options: [
                        'default_font',
                        'arial',
                        'arial_black',
                        'comic_sans',
                        'courier_new',
                        'impact',
                        'lucida_grande',
                        'times_new_roman',
                        'verdana',
                      ],
                    },
                    'removeFormat',
                  ],
                  ['undo', 'redo'],
                  ['viewsource'],
                ]"
                :fonts="{
                  arial: 'Arial',
                  arial_black: 'Arial Black',
                  comic_sans: 'Comic Sans MS',
                  courier_new: 'Courier New',
                  impact: 'Impact',
                  lucida_grande: 'Lucida Grande',
                  times_new_roman: 'Times New Roman',
                  verdana: 'Verdana',
                }"
              />
            </td>
          </tr>
          <tr>
            <th><span class="">키워드</span></th>
            <td colspan="3">
              <q-input
                class="w600"
                outlined
                dense
                placeholder="내용을 입력해주세요"
                v-model="keyWord"
              >
                <template v-slot:after>
                  <q-btn
                    unelevated
                    color="grey-3"
                    class="size_sm"
                    label="나의 키워드"
                  />
                </template>
              </q-input>
              <div class="mt10 row q-gutter-x-sm">
                <q-badge color="black" class="large">키워드</q-badge>
                <q-badge outline color="grey-3" class="large">키워드</q-badge>
                <q-badge color="black" class="large">키워드</q-badge>
                <q-badge outline color="grey-3" class="large">키워드</q-badge>
              </div>
            </td>
          </tr>
          <tr>
            <th>첨부파일</th>
            <td colspan="3">
              <div class="row-4">
                <!-- <div class="search_item type_large">
                  <q-input v-model="searchInput" class="" placeholder="입력해주세요" outlined />
                </div> -->
                <q-btn
                  unelevated
                  color="grey-3"
                  class="size_sm"
                  label="파일 선택"
                />
              </div>
              <!-- <div class="row mt10">
                <q-icon name="icon-info02" class="icon_svg"></q-icon>
                <span class="ml4">
                  500MB 이하 용량 / doc, docx, hwp 파일만 등록 가능합니다.
                </span>
              </div> -->
              <!-- <ul class="attach_file_list mt10">
                <li v-for="(item, index) in files" :key="index">
                  <q-btn outline type="button" class="del_file">
                    {{ item.name }}
                  </q-btn>
                </li>
              </ul> -->
              <div class="attach_file_list row mt10 q-gutter-x-lg">
                <div v-for="(item, index) in files" :key="index">
                  {{ item.name }}
                  <q-btn outline class="size_xxs" color="grey-3"
                    ><q-icon
                      name="icon-close"
                      class="icon_svg filter-grey-3"
                    ></q-icon
                  ></q-btn>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th><span class="">조직</span></th>
            <td colspan="3">
              <div class="row gap10">
                <div class="col col-md">
                  <q-select
                    class="hide_label"
                    label="본부전체"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col col-md">
                  <q-select
                    class="hide_label"
                    label="교육국 전체"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col col-md">
                  <q-select
                    class="hide_label"
                    label="팀 전체"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col col-md">
                  <q-select
                    class="hide_label"
                    label="채널 전체"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 참고하세요 -->
      <div class="wrap_info_box">
        <div class="tit_area">
          <q-icon name="info" class="icon_svg filter-grey-3" />
          <span>참고하세요</span>
        </div>
        <div class="content">
          <ul class="ul_custom disc text-grey-3">
            <li>
              게시물을 등록하기 전에 게시판 양식을 선택해 주시기 바랍니다.
            </li>
          </ul>
        </div>
      </div>
      <!-- // 참고하세요 -->

      <!-- 하단 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline class="size_lg" label="취소" />
        <q-btn outline class="size_lg" label="임시저장" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
td + th {
  border-left: 1px solid #ddd;
}

.q-editor {
  height: 400px;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchCategory = ref(['']);
const searchCategoryOption = ref([
  {
    id: 'a',
    desc: '말머리1',
  },
  {
    id: 'b',
    desc: '말머리2',
  },
]);

const inpClear = ref('');
const keyWord = ref('');

const dataTextArea = ref('');

// 게시예약일 시간선택
const revHour = ref('h00');
const revHourOpt = ref([
  {
    id: 'h00',
    desc: 'AM 12',
  },
]);

// 게시예약일 분선택
const revMinute = ref('m00');
const revMinuteOpt = ref([
  {
    id: 'm00',
    desc: '00',
  },
]);

const dataCheck2 = ref({
  check1: false,
  check2: false,
  check3: false,
});
// const dataRadio = ref('true');
const qeditor = ref('sample editor');
const files = ref([
  {
    name: 'document.hwp',
  },
  {
    name: 'document1.hwp',
  },
  {
    name: 'document3.hwp',
  },
]);
const searchDate = ref({
  from: '2023.06.26',
  to: '2023.06.26',
});
const dataSelect = ref(['']);
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
</script>
