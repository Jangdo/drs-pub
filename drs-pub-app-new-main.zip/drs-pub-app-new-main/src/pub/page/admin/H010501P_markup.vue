<template>
  <!-- dialog -->
  <q-dialog :modelValue="popForm">
    <q-card class="inner_form">
      <q-card-section class="pop_title_wrap" align="left">
        <h3 class="tit">메시지 등록</h3>
        <q-btn icon="close" flat @click="popForm = false"
          ><b class="a11y">닫기</b></q-btn
        >
      </q-card-section>
      <q-card-section class="q-pt-none dialog_content" align="center">
        <!-- inner_list -->
        <ul class="inner_list">
          <li>
            <span class="as_dt">* 메시지 ID</span>
            <q-input
              v-model="dataFrom.id"
              class="as_dd hide_label"
              label="* 메시지 ID"
              outlined
              placeholder="메시지 명을 입력하세요"
              stack-label
              dense
            >
              <template v-slot:label>* 메시지 ID</template>
            </q-input>
          </li>
          <li>
            <span class="as_dt">* 메시지 명</span>
            <q-input
              v-model="dataFrom.name"
              class="as_dd hide_label"
              label="* 메시지 명"
              outlined
              placeholder="메시지 명을 입력하세요"
              stack-label
              dense
            >
              <template v-slot:label>* 메시지 명</template>
            </q-input>
          </li>
          <li>
            <span class="as_dt">* 메시지 내용</span>
            <q-input
              class="as_dd hide_label"
              outlined
              placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
              type="textarea"
              v-model="dataFrom.txt"
            >
              <template v-slot:label>* 메시지 내용</template>
            </q-input>
          </li>
          <li>
            <span class="as_dt">* 카테고리</span>
            <q-btn
              class="ad_dd"
              icon="ion-ios-list"
              :label="dataFrom.category"
              @click="clickCategory()"
            />
          </li>
          <li>
            <span class="as_dt">* 구분</span>
            <q-select
              class="as_dd"
              outlined
              dense
              v-model="dataFrom.state"
              :options="stateSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
            ></q-select>
          </li>
          <li>
            <span class="as_dt">* 사용여부</span>
            <div class="as_dd">
              <q-radio
                v-model="dataFrom.allow"
                val="true"
                label="사용"
                color="primary"
              />
              <q-radio
                v-model="dataFrom.allow"
                val="false"
                label="사용안함"
                color="primary"
              />
            </div>
          </li>
        </ul>
        <!--// inner_list -->
      </q-card-section>
      <q-card-actions align="center" class="row item-end">
        <q-btn
          unelevated
          v-close-popup
          color="grey-4"
          text-color="white"
          class="size_sm cancel"
          label="취소"
        />
        <q-btn
          unelevated
          icon="ion-ios-save"
          v-close-popup
          color="positive"
          text-color="white"
          class="size_sm confirm"
          label="저장"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
  <!--// dialog -->
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  category: '카테고리를 선택하세요',
  state: '선택하세요',
  allow: 'true',
});
//
const stateSelectOption = ref([
  {
    id: 'confirm',
    desc: '확인',
  },
  {
    id: 'alert',
    desc: '알림',
  },
]);

function clickCategory() {
  console.log('카테고리 팝업 호출');
}
</script>

<style lang="scss">
.a11y {
  @extend %a11y;
}
%a11y {
  overflow: hidden;
  position: absolute;
  clip: rect(0, 0, 0, 0);
  clip-path: circle(0);
  width: 1px;
  height: 1px;
  margin: -1px;
  border: 0;
  padding: 0;
  white-space: nowrap;
  background: transparent;
}

body .q-input.hide_label {
  .q-field__inner {
    .q-placeholder {
      padding: 0;
    }
    .q-field__label {
      @extend %a11y;
    }
  }
}
body .q-textarea .q-field__native {
  color: #aaa;
}
.q-dialog .q-dialog__inner .q-card.inner_form {
  max-width: 500px;
  width: 100%;
  .tit_area {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;

    & > button {
      width: 50px;
      height: 50px;
      box-sizing: border-box;
      font-size: 24px;
      padding: 0;
    }
  }
  .inner_list {
    opacity: 1;
    li {
      display: flex;
      justify-content: space-between;
      align-items: center;
      & > .as_dt {
        width: 130px;
        text-align: left;
      }
      & > .as_dd {
        width: calc(100% - 150px);
      }
    }
  }
}
</style>
