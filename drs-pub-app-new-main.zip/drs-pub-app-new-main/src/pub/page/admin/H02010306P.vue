<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">채점교사 수정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">이름</span>
                  <q-input
                    class="as_dd hide_label"
                    label="이름"
                    outlined
                    placeholder="이름을 입력하세요"
                    stack-label
                    dense
                    v-model="inpName"
                  >
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">LC/YC 구분</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="LC채점교사"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="YC채점교사"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">휴대폰번호</span>
                  <q-input
                    class="as_dd hide_label"
                    label="휴대폰번호"
                    outlined
                    placeholder="입력하세요"
                    stack-label
                    dense
                    v-model="inpPhone"
                  >
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">생년월일</span>
                  <q-input
                    class="as_dd hide_label"
                    label="생년월일"
                    outlined
                    placeholder="입력하세요"
                    stack-label
                    dense
                    v-model="inpBirth"
                  >
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">본부</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        /> </template
                    ></q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">조직</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">채널</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">팀</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">근무기간</span>
                  <div class="as_dd row">
                    <!-- searchDate start.from -->
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="w180 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!--// searchDate start.from -->
                    <div class="tilde ml8 mr8">
                      <span>~</span>
                    </div>
                    <!-- searchDate start.to -->
                    <q-input
                      outlined
                      v-model="searchDate.to"
                      class="w180 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyto"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              v-model="searchDate.to"
                              mask="YYYY.MM.DD"
                              @update:model-value="
                                searchDate.to, $refs.qDateProxyto.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!--// searchDate start.to -->
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">이용시간</span>
                  <div class="as_dd row">
                    <q-select
                      class="hide_label mr10"
                      v-model="hour"
                      :options="hourOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      label=""
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <template v-slot:after> 시 </template>
                    </q-select>
                    <q-select
                      class="hide_label mr10"
                      v-model="minute"
                      :options="minuteOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      label=""
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <template v-slot:after> 분 </template>
                    </q-select>
                    <div class="tilde mr8">
                      <span>~</span>
                    </div>
                    <q-select
                      class="hide_label mr10"
                      v-model="hour2"
                      :options="hourOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      label=""
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <template v-slot:after> 시 </template>
                    </q-select>
                    <q-select
                      class="hide_label mr10"
                      v-model="minute2"
                      :options="minuteOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      label=""
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <template v-slot:after> 분 </template>
                    </q-select>
                  </div>
                </div>
              </div>
            </li>

            <li class="hastextarea">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">비고</span>
                  <div class="as_dd wrap_counsel_form">
                    <div class="wrap_textarea mt15 mb15">
                      <q-input
                        class="basic text-phara1 medium"
                        outlined
                        v-model="dataTextArea"
                        placeholder="입력하세요"
                        type="textarea"
                      >
                        <template v-slot:label>메시지 내용</template>
                      </q-input>
                      <div class="check_val">
                        <span>0</span>/<span>1,000</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            class="size_lg"
            color="black"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const inpName = ref('');
const inpPhone = ref('');
const inpBirth = ref('');

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  customer: 'true',
  url: '',
});
function test() {
  console.log('btn_test');
}

const searchDate = ref({
  from: '2023.06.01',
  to: '2023.06.01',
});

const hour = ref(['']);
const hour2 = ref(['']);
const hourOption = ref([
  {
    id: 'h1',
    desc: '09',
  },
  {
    id: 'h2',
    desc: '10',
  },
  {
    id: 'h3',
    desc: '11',
  },
  {
    id: 'h4',
    desc: '12',
  },
  {
    id: 'h5',
    desc: '13',
  },
  {
    id: 'h6',
    desc: '14',
  },
  {
    id: 'h7',
    desc: '15',
  },
  {
    id: 'h8',
    desc: '16',
  },
  {
    id: 'h9',
    desc: '17',
  },
]);

const minute = ref(['']);
const minute2 = ref(['']);
const minuteOption = ref([
  {
    id: 'h1',
    desc: '10',
  },
  {
    id: 'h2',
    desc: '20',
  },
  {
    id: 'h3',
    desc: '30',
  },
  {
    id: 'h4',
    desc: '40',
  },
  {
    id: 'h5',
    desc: '50',
  },
  {
    id: 'h6',
    desc: '00',
  },
]);

const dataTextArea = ref('');
</script>
