<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">시스템메시지 관리</h2>
      <Breadcrumbs />
    </div>

    <!-- table_search_area type_02 -->
    <div class="table_search_area type_02">
      <div class="inline">
        <div class="wrap_item_input">
          <!-- <h3>메시지명</h3> -->
          <q-input
            class="inp_msg_name"
            outlined
            v-model="msgName"
            placeholder="메시지명을 입력하세요"
          />
        </div>
        <div class="wrap_item_input">
          <!-- <h3>메시지 ID</h3> -->
          <q-input
            class="inp_author"
            outlined
            v-model="msgId"
            placeholder="메시지 ID를 입력하세요"
          />
        </div>
        <div class="wrap_item_input">
          <!-- <h3>시스템 유형을 선택하세요</h3> -->
          <q-select
            class="inp_use"
            v-model="searchSys"
            :options="searchSysOption"
            option-value="sysytemCategory"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
        <div class="wrap_item_input">
          <!-- <h3>카테고리</h3> -->
          <q-input
            class="inp_author"
            outlined
            v-model="msgCategory"
            placeholder="카테고리를 검색하세요"
          >
            <template v-slot:append>
              <q-icon
                name="icon-search"
                class="icon_svg"
                flat
                :ripple="false"
              /> </template
          ></q-input>
        </div>
      </div>

      <div class="inline">
        <div class="wrap_item_input">
          <!-- <h3>메시지구분</h3> -->
          <q-select
            class="inp_use"
            v-model="searchMsgType"
            :options="searchMsgTypeOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
        <div class="wrap_item_input">
          <!-- <h3>사용여부</h3> -->
          <q-select
            class="inp_use"
            v-model="searchUseSelected"
            :options="searchSelectOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>

        <div class="btn_area">
          <q-btn fill unelevated class="size_sm btn_search" label="조회" />
          <q-btn
            class="size_sm btn_reset"
            icon="ion-ios-refresh"
            outline
            label="초기화"
          />
        </div>
      </div>
    </div>
    <!-- selectable_table type_01 -->
    <div class="selectable_table type_01">
      <div class="btn_area">
        <q-btn class="size_sm btn_delete" outline icon="" label="선택삭제" />
        <q-btn
          class="size_sm btn_write"
          outline
          icon="ion-ios-add"
          label="신규등록"
        />
        <q-space />
      </div>
      <q-table
        :rows="msgRows"
        :columns="msgColumns"
        row-key="idx"
        v-model:selected="msg_selected"
        selection="multiple"
        v-model:pagination="msg_pagination"
        hide-bottom
        hide-pagination
        separator="cell"
      >
        <template v-slot:body="props">
          <q-tr :class="props.row.state" :props="props">
            <q-td class="select"><q-checkbox v-model="props.selected" /></q-td>
            <q-td key="idx" class="idx">{{ props.row.idx }}</q-td>
            <q-td key="sys" class=""> {{ props.row.sys }}</q-td>
            <q-td key="category" class="category">
              {{ props.row.category }}</q-td
            >

            <q-td key="id" class="msgId"> {{ props.row.id }}</q-td>
            <q-td key="name" class="name"> {{ props.row.name }}</q-td>
            <q-td key="type" class=""> {{ props.row.type }}</q-td>

            <q-td key="allow" :props="props" class="allow">
              <q-toggle v-model="props.row.allow" class="custom_tgl" />
            </q-td>
            <q-td key="btn" :props="props" class="hasbtn">
              <q-btn
                outline
                class="size_sm btn_detail_view"
                label="보기"
                @click="tableEvt(props.row.idx)"
              >
              </q-btn>
            </q-td>
          </q-tr>
        </template>
      </q-table>

      <div class="pagination_container">
        <q-pagination
          v-model="msg_pagination.page"
          direction-links
          boundary-links
          :max-pages="10"
          :max="pagesNumber"
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          icon-prev="keyboard_arrow_left"
          icon-next="keyboard_arrow_right"
          class="custom_pagination type_01"
        />
      </div>
    </div>
    <!--// selectable_table type_01-->
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchSys = ref(['시스템유형을 선택하세요']);
const msgName = ref(['']);
const msgId = ref(['']);
const msgCategory = ref('');
const searchSysOption = ref([
  {
    id: 'a',
    desc: '유형 유형',
  },
  {
    id: 'b',
    desc: '시스템유형 ',
  },
]);
const searchUseSelected = ref(['사용여부를 선택하세요']);
const searchSelectOption = ref([
  {
    id: 'Y',
    desc: '사용',
  },
  {
    id: 'N',
    desc: '사용안함 ',
  },
]);
const searchMsgType = ref(['메시지 구분을 선택하세요']);
const searchMsgTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

// msg_dialog
const msg_dialog = ref({
  open: false,
  id: 0,
});

//msg_table데이터
const msg_selected = ref([]);
const pagesNumber = computed(() =>
  Math.ceil(msgRows.value.length / msg_pagination.value.rowsPerPage)
);
const msgColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },

  {
    name: 'sys',
    label: '시스템유형',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'id',
    label: '메시지 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },
  {
    name: 'name',
    label: '메시지 명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'type',
    label: '구분',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    category: '권한정보',
    id: 'MSG_C0000',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '확인',
    allow: false,
  },
  {
    idx: '2',
    category: '결제관련',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '확인',
    allow: false,
  },
  {
    idx: '3',
    category: '결제관련',
    id: 'MSG_C0002',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '확인',
    allow: false,
  },
  {
    idx: '4',
    category: '권한정보',
    id: 'MSG_C0003',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    type: '확인',
    sys: '눈높이',
    allow: false,
  },
  {
    idx: '5',
    category: '권한정보',
    id: 'MSG_C0004',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',

    type: '확인',
    sys: '눈높이',
    allow: false,
  },
  {
    idx: '6',
    category: '권한정보',
    id: 'MSG_C0005',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',

    type: '확인',
    sys: '눈높이',
    allow: true,
  },

  {
    idx: '7',
    category: '권한정보',
    id: 'MSG_C0006',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '8',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '9',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '10',
    category: '권한정보',
    id: 'MSG_C0008',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '11',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '12',
    category: '권한정보',
    id: 'MSG_C0009',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
]);
const msg_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
  msg_dialog.value.idx = id;
  msg_dialog.value.open = true;
}
</script>
