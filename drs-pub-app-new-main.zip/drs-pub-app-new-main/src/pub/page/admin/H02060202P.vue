<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한이력 - 서북지원팀 홍길동</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="권한명"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!-- general_table -->
          <div class="table_dk pt20">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                <div class="text-body2">
                  <span class="text-primary">총 <span>67</span>건</span>이
                  조회되었습니다.
                </div>
              </div>
            </div>
            <q-table
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
              color="grey-2"
            >
            </q-table>

            <!-- pagination -->
            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
            <!-- // pagination -->
          </div>
          <!-- // general_table -->
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const keyword = ref('');

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '카테고리',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '권한명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '권한설정',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '이력',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '작업자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '작업일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 9,
    tdata1: '시스템관리자',
    tdata2: '일반 사용자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자',
    tdata6: '2022.11.01',
  },
  {
    idx: 8,
    tdata1: '인사',
    tdata2: '인사담당자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 7,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 6,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 5,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 4,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 3,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 2,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
  {
    idx: 1,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
    tdata3: '허용',
    tdata4: '생성',
    tdata5: '관리자 2',
    tdata6: '2022.11.01',
  },
]);
</script>
