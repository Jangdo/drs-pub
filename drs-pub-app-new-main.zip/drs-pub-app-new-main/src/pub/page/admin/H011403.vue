<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">메시지(알림)관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <table class="table_row_admin">
        <colgroup>
          <col style="width: 180px" />
          <col />
          <col style="width: 180px" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th>제목</th>
            <td colspan="3">Member Delete</td>
          </tr>
          <tr>
            <th>작성일자</th>
            <td>2023.01.01</td>
            <th class="line_l">작성자</th>
            <td>Mosadmin</td>
          </tr>
          <tr>
            <th>발송구분</th>
            <td>회원데이터 삭제</td>
            <th class="line_l">발송대상</th>
            <td>
              <div class="row items-center">
                1명
                <q-space />
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_sm"
                  label="상세조회"
                />
              </div>
            </td>
          </tr>
          <tr>
            <th>발송 URL</th>
            <td>발송 URL</td>
            <th class="line_l">직책</th>
            <td>국장/팀장</td>
          </tr>
          <tr>
            <th>메시지 알림 이미지</th>
            <td>test.jpg</td>
            <th class="line_l">분야</th>
            <td>어문, 종합, L/C종합, 미포함</td>
          </tr>
          <tr>
            <th>예약발송</th>
            <td colspan="3"></td>
          </tr>
        </tbody>
      </table>
      <div class="btn_area response">
        <q-btn color="black" class="size_lg btn_cancel wide" label="재발송" />
        <q-btn
          unelevated
          color="grey-2"
          class="size_lg btn_position_end"
          label="목록"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
