<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <div class="row-calendar">
              <q-input
                outlined
                v-model="searchDate.from"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <span class="text-body2">~</span>
              <!-- 달력 인풋 -->
              <q-input
                outlined
                v-model="searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyTo"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.to"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyTo.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              outlined
              v-model="inputSubject"
              placeholder="제목"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              outlined
              v-model="inputAuthor"
              placeholder="등록자"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="box_m hide_label"
              label="답변여부 전체"
              v-model="dataSelect"
              :options="dataSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <div class="wrap_table_box">
      <!-- editable_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm btn_delete" outline label="선택삭제" />
            <q-btn class="size_sm btn_row_edit" outline label="수정" />
            <q-btn
              class="size_sm btn_add"
              unelevated
              color="black"
              label="신규등록"
            />
          </div>
        </div>

        <q-table
          :rows="rows"
          :columns="columns"
          row-key="idx"
          v-model:selected="selected"
          selection="multiple"
          hide-bottom
          v-model:pagination="dataPagination"
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th class="select">
                <!-- <q-checkbox v-model="props.selected" color="black" /> -->
                선택
              </q-th>
              <q-th class="">제목</q-th>
              <q-th class="">첨부</q-th>
              <q-th class="">조회</q-th>
              <q-th class="">등록자</q-th>
              <q-th class="">등록일</q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td class="select">
                <q-checkbox v-model="props.selected" color="black" />
              </q-td>
              <q-td key="tdata1" class="subject">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="file text-center">
                <template v-if="props.row.tdata2 == 'Y'">
                  <q-icon name="icon-document" class="icon_svg"></q-icon>
                </template>
                <template v-else> </template>
              </q-td>
              <q-td key="count" class="count text-center">
                {{ props.row.count }}
              </q-td>
              <q-td key="author" class="author text-center">
                {{ props.row.author }}
              </q-td>
              <q-td key="date" class="date text-center">
                {{ props.row.date }}
              </q-td>
            </q-tr>
          </template>
        </q-table>
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
      </div>
      <!--// editable_table -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const inputSubject = ref('');
const inputAuthor = ref('');
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);

const selected = ref([]);

const searchDate = ref({
  from: '2023.02.01',
  to: '2023.02.20',
});

const columns = ref([
  {
    name: 'systemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const rows = ref([
  {
    idx: '1',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '2',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: '',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '3',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '4',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: '',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '5',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '6',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: '',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '7',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '8',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: '',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '9',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '10',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: '',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '11',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
  {
    idx: '12',
    tdata1: '게시 대상 확인 테스트 게시 대상 확인 테스트 게시 대상 확인 테스트',
    tdata2: 'Y',
    count: '01',
    author: '김김김',
    date: '2023.04.17',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
