<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">게시판 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row-2">
            <!-- 테이블 -->
            <div class="tbl_item">
              <h4 class="title1 mb24">전체 게시판 목록</h4>
              <div class="warp_orderboradbox">
                <q-list dense bordered padding class="orderborad">
                  <q-item>
                    <q-item-section>
                      <q-btn
                        flat
                        class="inner_oderbox"
                        v-for="(item, index) in listBoard"
                        :key="index"
                        dense
                        :class="[item.state ? 'on' : '']"
                        @click="item.state = !item.state"
                        >{{ item.txt }}</q-btn
                      >
                    </q-item-section>
                  </q-item>

                  <q-item>
                    <q-item-section> Item </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>
            <!-- // 테이블 -->

            <!-- 버튼 -->
            <div class="column mr20 ml20 justify-center control_box">
              <div>
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="추가"
                />
              </div>
              <div class="mt10">
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="삭제"
                />
              </div>
              <div class="mt60">
                <q-btn
                  outline
                  unelevated
                  class="size_xs btn_tbl_add"
                  color=""
                  label="위로"
                />
              </div>
              <div class="mt10">
                <q-btn
                  outline
                  unelevated
                  class="size_xs btn_tbl_add"
                  color=""
                  label="아래로"
                />
              </div>
            </div>
            <!-- // 버튼 -->

            <!-- 테이블 -->
            <div class="tbl_item">
              <h4 class="title1 mb24">선택 게시판 목록</h4>
              <div class="warp_orderboradbox">
                <q-list dense bordered padding class="orderborad">
                  <q-item>
                    <q-item-section>
                      <q-btn
                        flat
                        class="inner_oderbox"
                        v-for="(item, index) in listBoardAfter"
                        :key="index"
                        dense
                        :class="[item.state ? 'on' : '']"
                        @click="item.state = !item.state"
                        >{{ item.txt }}</q-btn
                      >
                    </q-item-section>
                  </q-item>

                  <q-item>
                    <q-item-section> Item </q-item-section>
                  </q-item>
                </q-list>
              </div>
            </div>
            <!-- // 테이블 -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const listBoard = ref([
  {
    txt: '상상예찬[상상예찬]',
    state: true,
  },
  {
    txt: '주말주차신청[주말주차신청]',
    state: true,
  },
  {
    txt: '흑백복합기 사용신청[흑백복합기 사용신청]',
    state: false,
  },
  {
    txt: '통합컨설팅 공지[기본게시판]',
    state: false,
  },
  {
    txt: '통합컨설팅 QnA[기본게시판]',
    state: false,
  },
  {
    txt: 'BIM 공지사항[기본게시판]',
    state: false,
  },
  {
    txt: '기획/홍보[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
  {
    txt: '인사관리[기본게시판]',
    state: false,
  },
]);
const listBoardAfter = ref([
  {
    txt: '알림방 [기본게시판]',
    state: true,
  },
  {
    txt: '약관관리[기본게시판]',
    state: true,
  },
  {
    txt: '전사자료실[기본게시판]',
    state: false,
  },
  {
    txt: '양식자료실[기본게시판]',
    state: false,
  },
  {
    txt: '개발자료실[기본게시판]',
    state: false,
  },
]);
</script>
<style lang="scss" scoped>
.control_box {
  .q-btn.btn_tbl_add {
    width: 72px;
    padding: 0;
  }
}

.warp_orderboradbox {
  .orderborad {
    border-radius: 6px;
    display: block;
    min-height: 354px;
    padding: 26px 20px;
    background: #f7f7f7;
    height: 354px;
    overflow: auto;
    overflow-x: hidden;
    .q-item {
      padding: 0;
      .q-btn.inner_oderbox {
        font-size: 16px;
        align-items: flex-start;
        flex-direction: column;
        color: #262626;
        line-height: 18px;
        margin-bottom: 4px;
        padding: 5px 6px;
        &.on {
          background: #ededed;
          border-radius: 4px;
        }
      }
    }
  }
}
</style>
