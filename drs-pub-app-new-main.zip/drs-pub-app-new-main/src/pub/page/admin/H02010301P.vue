<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-input
                    class="box_l inp_search"
                    for=""
                    outlined
                    dense
                    placeholder="사번, 성명"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="wrap_tree_table">
            <!-- sm_area 트리 영역 -->
            <!-- <div class="sm_area">
              <div class="tree_container">
                <q-tree
                  :nodes="treeData"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree hastbltit"
                  v-model:selected="treeSelected"
                  default-expand-all
                  @update:selected="temp1(treeSelected)"
                >
                </q-tree>
              </div>
            </div> -->
            <!--// sm_area 트리 영역 -->
            <!-- main_area 테이블 영역 -->
            <div class="table_dk full-width">
              <!-- search_user_table -->
              <q-table
                :rows="rows"
                :columns="columns"
                row-key="workerNumber"
                :pagination="initialPagination"
                selection="single"
                v-model:selected="selected"
                separator="cell"
                hide-pagination
                hide-bottom
                wrap-cells
                class="scrollable"
              >
                <!-- <template v-slot:header-selection="scope">
                  <q-toggle v-model="scope.selected" v-if="false" />
                </template> -->
                <!-- <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th style="width:72px;">선택</q-th>
                    <q-th style="width:354px;">부서 정보</q-th>
                    <q-th style="width:165px;">사번</q-th>
                    <q-th style="width:131px;">이름</q-th>
                  </q-tr>
                </template> -->
                <template v-slot:body-selection="scope">
                  <q-checkbox
                    v-model="scope.selected"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                    color="black"
                  />
                </template>
              </q-table>
              <!--// search_user_table -->
            </div>
            <!--// main_area 테이블 영역 -->
          </div>
          <!-- <q-separator class="popup_btm_line" /> -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// tree
// const treeData = [
//   {
//     label: '사용자 카테고리',
//     id: 'a_1',
//     icon: 'tree',
//     // img: '/icons/icon-tree-home.svg',
//     children: [
//       {
//         id: 'a_2',
//         label: '권한 정보_뎁스2',
//         children: [
//           {
//             id: 'a_3',
//             label: '뎁스3',
//             children: [
//               {
//                 id: 'a_4',
//                 class: 'color_grey',
//                 label: '뎁스4',
//                 img: '/icons/icon-tree-folder.svg',
//               },
//               {
//                 id: 'a_5',
//                 label: '뎁스4',
//                 img: '/icons/icon-tree-folder.svg',
//               },
//             ],
//           },
//           {
//             id: 'a_6',
//             label: '뎁스3',
//             img: '/icons/icon-tree-folder.svg',
//           },
//         ],
//       },
//       {
//         label: '결제 관련/뎁스2',
//         id: 'a_7',
//         children: [
//           {
//             label: '뎁스3',
//             id: 'a_8',
//             children: [
//               { id: 'a_9', label: '뎁스4' },
//               { id: 'a_10', label: '뎁스4' },
//             ],
//           },
//           { id: 'a_11', label: '뎁스3' },
//         ],
//       },
//       {
//         label: '기타 관련',
//         id: 'a_12',
//         children: [
//           { id: 'a_13', label: '뎁스4' },
//           { id: 'a_14', label: '뎁스4' },
//         ],
//       },
//     ],
//   },
// ];
// const treeSelected = ref('메시지 카테고리');
// //  트리 셀렉트 이벤트
// function temp1(target) {
//   console.log('셀렉트 이벤트 발생', target);
// }
// table
const columns = ref([
  {
    name: 'infor',
    label: '부서 정보',
    align: 'left',
    sortable: false,
    field: (row) => row.infor,
    headerStyle: 'width: 354px',
  },
  {
    name: 'workerNumber',
    label: '사번',
    align: 'center',
    field: 'workerNumber',
    sortable: false,
    headerStyle: 'width: 165px',
  },
  {
    name: 'name',
    align: 'center',
    label: '이름',
    field: 'name',
    sortable: false,
    headerStyle: 'width: 131px',
  },
]);
const initialPagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const rows = ref([
  {
    infor: '서울 강서 본점 > 화곡 지점서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12345',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12346',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12347',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12348',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12349',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123410',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12311',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12312',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12313',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12314',
    name: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a12315',
    name: '홍길동',
  },
]);
const selected = ref([]);

// dialog
const popForm = ref(true);

//  table
</script>
