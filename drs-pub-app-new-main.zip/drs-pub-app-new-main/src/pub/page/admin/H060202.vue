<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">양식관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrap_table_box">
      <!-- sales_subtit_area -->
      <div class="sales_subtit_area">
        <h3 class="title1">기본정보</h3>
      </div>
      <!-- //sales_subtit_area -->

      <table class="table_row_admin mb10">
        <tbody>
          <tr>
            <th>양식 제목</th>
            <td>재무 관리 양식</td>
          </tr>
          <!-- <tr>
            <td colspan="2">
            </td>
          </tr> -->
        </tbody>
      </table>

      <div class="mb50">
        <q-editor
          v-model="qeditor"
          :toolbar="[
            [
              {
                label: $q.lang.editor.align,
                icon: $q.iconSet.editor.align,
                fixedLabel: true,
                // list: 'only-icons',
                options: ['left', 'center', 'right', 'justify'],
              },
            ],
            [
              'bold',
              'italic',
              'strike',
              'underline',
              'subscript',
              'superscript',
            ],
            ['token', 'hr', 'link', 'custom_btn'],
            ['print', 'fullscreen'],
            [
              {
                label: $q.lang.editor.formatting,
                icon: $q.iconSet.editor.formatting,
                list: 'no-icons',
                options: ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'code'],
              },
              {
                label: $q.lang.editor.fontSize,
                icon: $q.iconSet.editor.fontSize,
                fixedLabel: true,
                fixedIcon: true,
                list: 'no-icons',
                options: [
                  'size-1',
                  'size-2',
                  'size-3',
                  'size-4',
                  'size-5',
                  'size-6',
                  'size-7',
                ],
              },
              {
                label: $q.lang.editor.defaultFont,
                icon: $q.iconSet.editor.font,
                fixedIcon: true,
                list: 'no-icons',
                options: [
                  'default_font',
                  'arial',
                  'arial_black',
                  'comic_sans',
                  'courier_new',
                  'impact',
                  'lucida_grande',
                  'times_new_roman',
                  'verdana',
                ],
              },
              'removeFormat',
            ],
            ['undo', 'redo'],
            ['viewsource'],
          ]"
          :fonts="{
            arial: 'Arial',
            arial_black: 'Arial Black',
            comic_sans: 'Comic Sans MS',
            courier_new: 'Courier New',
            impact: 'Impact',
            lucida_grande: 'Lucida Grande',
            times_new_roman: 'Times New Roman',
            verdana: 'Verdana',
          }"
        />
      </div>

      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline color="grey-4" class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const qeditor = ref('sample editor');
</script>
