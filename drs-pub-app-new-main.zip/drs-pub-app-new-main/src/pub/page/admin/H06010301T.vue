<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="wrapper_tab">
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb40"
        active-bg-color="primary"
        active-color="white"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
      </q-tabs>
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <h3 class="mb20 title1 text-grey-1">기본정보</h3>
            <table class="table_row_admin">
              <colgroup>
                <col style="width: 180px" />
                <col />
                <col style="width: 180px" />
                <col />
              </colgroup>
              <tbody>
                <tr>
                  <th><span class="required">게시판명</span></th>
                  <td colspan="3">
                    <div class="search_item type_full">
                      <q-input
                        v-model="searchInput1"
                        class=""
                        outlined
                        placeholder="게시판명"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시판 설명</span></th>
                  <td colspan="3">
                    <!-- <div class="search_item type_full">
                      <q-input
                        v-model="searchInput2"
                        class=""
                        outlined
                        placeholder="게시판명"
                      />
                    </div> -->
                    <div class="wrap_counsel_form">
                      <div class="wrap_textarea">
                        <q-input
                          class="basic text-phara1 medium"
                          outlined
                          v-model="dataTextArea"
                          placeholder="게시판 설명을 입력하세요."
                          type="textarea"
                        >
                          <template v-slot:label>메시지 내용</template>
                        </q-input>
                        <div class="check_val">
                          <span>0</span>/<span>1,000</span>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시판 타이틀</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="게시판명"
                        v-model="select1"
                        :options="select1Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        placeholder="게시판명"
                      >
                      </q-select>
                    </div>
                  </td>

                  <th><span class="required">타이틀 형태</span></th>
                  <td>게시판명</td>
                </tr>
                <tr>
                  <th>권한설정</th>
                  <td colspan="3">
                    <div class="row-4">
                      <div class="search_item type_large">
                        <q-input
                          v-model="searchInput3"
                          class=""
                          placeholder="입력하세요"
                          outlined
                        />
                      </div>
                      <q-btn
                        unelevated
                        color="grey-2"
                        class="size_sm"
                        label="권한설정"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시판 테이블</span></th>
                  <td colspan="3">
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="게시판 테이블"
                        v-model="select2"
                        :options="select2Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        placeholder="기본 게시판"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시물 카테고리</span></th>
                  <td colspan="3">
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="게시판 테이블"
                          v-model="select3"
                          :options="select3Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          placeholder="사용안함"
                        >
                        </q-select>
                      </div>
                      <q-btn
                        unelevated
                        color="grey-2"
                        class="size_sm"
                        label="카테고리 선택"
                      />
                      <div class="search_item type_large">
                        <q-input
                          v-model="searchInput2"
                          class=""
                          placeholder="입력하세요"
                          outlined
                        />
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시판 유형</span></th>
                  <td>목록형</td>
                  <th><span class="required">답변형 게시판 여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="답변형"
                        v-model="select4"
                        :options="select4Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        placeholder="답변형"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">담당자 지정</span></th>
                  <td colspan="3">
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="담당자 지정"
                        v-model="select5"
                        :options="select5Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        placeholder="기본 게시판"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">보관기한 설정여부</span></th>
                  <td>
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="보관기한 설정여부"
                          v-model="select6"
                          :options="select6Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          placeholder="영구보관"
                        >
                        </q-select>
                      </div>
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="보관기한 설정여부"
                          v-model="select7"
                          :options="select7Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          placeholder="영구보관"
                        >
                        </q-select>
                      </div>
                    </div>
                  </td>
                  <th><span class="required">신규 게시물 표시</span></th>
                  <td>
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="신규 게시물 표시"
                          v-model="select8"
                          :options="select8Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>

                      <div class="search_item type_small">
                        <q-input
                          v-model="searchInput5"
                          class=""
                          outlined
                          placeholder="0"
                        />
                      </div>
                      일 이내 표기
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">첨부사이즈 제한</span></th>
                  <td colspan="3">
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-input
                          v-model="searchInput4"
                          class=""
                          outlined
                          placeholder="첨부사이즈 제한"
                        />
                      </div>
                      Byte
                      <q-btn
                        unelevated
                        color="grey-2"
                        class="size_sm"
                        label="초기값 설정"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required"
                      >첨부 확장자 제한 <br />
                      (blacklist)</span
                    >
                  </th>
                  <td colspan="3">
                    <div class="row-4">
                      <div class="search_item type_large">
                        <q-input
                          v-model="searchInput6"
                          class=""
                          outlined
                          placeholder="bat, exe, cat"
                        />
                      </div>
                      <div class="row">
                        <q-icon
                          name="icon-info-grey"
                          class="icon_svg filter-grey-3"
                        ></q-icon>

                        <span class="ml4">
                          허용된 확장자 | xlsx, pptx, hwpx, png, jpg
                        </span>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">금칙어 여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="금칙어 여부"
                        v-model="select9"
                        :options="select9Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <th><span class="required">이전/다음</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="이전/다음"
                        v-model="select10"
                        :options="select10Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">말머리 사용</span></th>
                  <td>
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="말머리 사용"
                          v-model="select11"
                          :options="select11Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                      <q-checkbox
                        class="mr10"
                        v-model="dataCheck1"
                        label="제목"
                        color="black"
                      />
                    </div>
                    <div class="row-4 mt10">
                      <div class="search_item type_medium">
                        <q-input
                          v-model="searchInput7"
                          class=""
                          placeholder="입력하세요"
                          outlined
                        />
                      </div>
                      <q-btn
                        unelevated
                        color="grey-2"
                        class="size_sm"
                        label="선택"
                      />
                    </div>
                  </td>
                  <th><span class="required">붐업여부</span></th>
                  <td>
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="붐업여부"
                          v-model="select12"
                          :options="select12Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </div>
                    <div class="row-4 mt10">
                      추천수
                      <div class="search_item type_small">
                        <q-input
                          v-model="searchInput8"
                          class=""
                          placeholder="0"
                          outlined
                        />
                      </div>
                      조회수
                      <div class="search_item type_small">
                        <q-input
                          v-model="searchInput9"
                          class=""
                          placeholder="입력하세요"
                          outlined
                        />
                      </div>
                      (두 조건 만족)
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">덧글 사용</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="덧글 사용"
                        v-model="select13"
                        :options="select13Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <th><span class="required">찬반여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="찬반여부"
                        v-model="select14"
                        :options="select14Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">목록 게시물수</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-input
                        v-model="searchInput10"
                        class=""
                        outlined
                        placeholder="20"
                      />
                    </div>
                  </td>
                  <th><span class="required">신고기능여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="신고기능여부"
                        v-model="select15"
                        :options="select15Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">목록 검색기간</span></th>
                  <td>
                    <div class="row-4">
                      <div class="search_item type_medium">
                        <q-input
                          v-model="searchInput11"
                          class=""
                          outlined
                          placeholder="5"
                        />
                      </div>
                      일
                    </div>
                  </td>
                  <th><span class="required">태그기능</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="태그기능"
                        v-model="select16"
                        :options="select16Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">내 게시물만 보기</span></th>
                  <td>
                    <q-checkbox
                      class="mr10"
                      v-model="dataCheck2"
                      dense
                      color="black"
                    />
                  </td>
                  <th><span class="required">조직선택 사용여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="태그기능"
                        v-model="select16"
                        :options="select16Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">게시판 팝업 사용여부</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="태그기능"
                        v-model="select16"
                        :options="select16Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <th><span class="required">PUSH 알림 파일첨부 설정</span></th>
                  <td>
                    <div class="search_item type_medium">
                      <q-select
                        class="hide_label"
                        label="태그기능"
                        v-model="select16"
                        :options="select16Opt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">일반 파일첨부 그룹설정</span></th>
                  <td colspan="3">
                    <div class="row">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="사용안함"
                          v-model="select16"
                          :options="select16Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th><span class="required">일반 파일첨부 그룹설정</span></th>
                  <td colspan="3">
                    <div class="row">
                      <div class="search_item type_medium">
                        <q-select
                          class="hide_label"
                          label="태그기능"
                          v-model="select17"
                          :options="select17Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </div>
                    <ul class="form_list">
                      <li class="gap10 align_center mt10">
                        <span>1번 그룹명</span>
                        <q-input
                          v-model="searchInput10"
                          class="w400"
                          outlined
                          placeholder="그룹명 입력"
                        />
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            label="태그기능"
                            v-model="select16"
                            :options="select16Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="삭제"
                        />
                      </li>
                      <li class="gap10 align_center mt10">
                        <span>2번 그룹명</span>
                        <q-input
                          v-model="searchInput10"
                          class="w400"
                          outlined
                          placeholder="그룹명 입력"
                        />
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            label="태그기능"
                            v-model="select16"
                            :options="select16Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="삭제"
                        />
                      </li>
                      <li class="gap10 align_center mt10">
                        <span>3번 그룹명</span>
                        <q-input
                          v-model="searchInput10"
                          class="w400"
                          outlined
                          placeholder="그룹명 입력"
                        />
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            label="태그기능"
                            v-model="select16"
                            :options="select16Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="삭제"
                        />
                      </li>
                      <li class="gap10 align_center mt10">
                        <span>4번 그룹명</span>
                        <q-input
                          v-model="searchInput10"
                          class="w400"
                          outlined
                          placeholder="그룹명 입력"
                        />
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            label="태그기능"
                            v-model="select16"
                            :options="select16Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="삭제"
                        />
                      </li>
                    </ul>
                    <div class="row mt10">
                      <q-btn
                        unelevated
                        color="grey-3"
                        class="size_sm"
                        label="그룹추가"
                      />
                      <q-icon
                        name="icon-info-grey"
                        class="icon_svg ml10 mr4"
                      ></q-icon>
                      그룹추가는 5개까지만 가능
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <div class="btn_area response">
              <q-btn unelevated outline class="size_lg wide" label="취소" />
              <q-btn
                unelevated
                color="black"
                class="size_lg wide"
                label="저장"
              />
              <q-btn
                unelevated
                color="grey-3"
                class="size_lg btn_position_end"
                label="목록"
              />
            </div>
          </div>
        </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->
      </q-tab-panels>
    </div>
  </div>
</template>
<style lang="scss" scoped>
td + th {
  border-left: 1px solid #ddd;
}
.row-4 {
  flex-wrap: wrap;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');
const select1 = ref(['']);
const select1Opt = ref([
  {
    id: 's21',
    desc: '게시판명1',
  },
  {
    id: 's22',
    desc: '게시판명2',
  },
]);
const select2 = ref(['']);
const select2Opt = ref([
  {
    id: 's21',
    desc: '게시판 테이블1',
  },
  {
    id: 's22',
    desc: '게시판 테이블2',
  },
]);
const select3 = ref(['']);
const select3Opt = ref([
  {
    id: 's20',
    desc: '사용 안함',
  },
  {
    id: 's21',
    desc: '게시물 카테고리1',
  },
  {
    id: 's22',
    desc: '게시물 카테고리2',
  },
]);
const select4 = ref(['']);
const select4Opt = ref([
  {
    id: 's20',
    desc: '답변형',
  },
  {
    id: 's21',
    desc: '답변형1',
  },
  {
    id: 's22',
    desc: '답변형2',
  },
]);
const select5 = ref('s20');
const select5Opt = ref([
  {
    id: 's20',
    desc: '지정안함',
  },
  {
    id: 's21',
    desc: '담당자1',
  },
  {
    id: 's22',
    desc: '담당자2',
  },
]);
const select6 = ref('s20');
const select6Opt = ref([
  {
    id: 's20',
    desc: '영구보관',
  },
  {
    id: 's21',
    desc: '보관기간v1',
  },
  {
    id: 's22',
    desc: '보관기간v2',
  },
]);
const select7 = ref('s20');
const select7Opt = ref([
  {
    id: 's20',
    desc: '1개월',
  },
  {
    id: 's21',
    desc: '2개월',
  },
  {
    id: 's22',
    desc: '3개월',
  },
]);
const select8 = ref('s20');
const select8Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '신규게시물 2',
  },
  {
    id: 's22',
    desc: '신규게시물 3',
  },
]);
const select9 = ref('s20');
const select9Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '금칙어 2',
  },
  {
    id: 's22',
    desc: '금칙어 3',
  },
]);
const select10 = ref('s20');
const select10Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '이전/다음 2',
  },
  {
    id: 's22',
    desc: '이전/다음 3',
  },
]);

const select11 = ref('s20');
const select11Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '말머리 2',
  },
  {
    id: 's22',
    desc: '말머리 3',
  },
]);
const select12 = ref('s20');
const select12Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '붐업 2',
  },
  {
    id: 's22',
    desc: '붐업 3',
  },
]);
const select13 = ref('s20');
const select13Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '덧글 2',
  },
  {
    id: 's22',
    desc: '덧글 3',
  },
]);
const select14 = ref('s20');
const select14Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '찬반 2',
  },
  {
    id: 's22',
    desc: '찬반 3',
  },
]);
const select15 = ref('s20');
const select15Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '신고기능여부 2',
  },
  {
    id: 's22',
    desc: '신고기능여부 3',
  },
]);
const select16 = ref('s20');
const select16Opt = ref([
  {
    id: 's20',
    desc: '사용안함',
  },
  {
    id: 's21',
    desc: '태그기능 2',
  },
  {
    id: 's22',
    desc: '태그기능 3',
  },
]);

const select17 = ref('s20');
const select17Opt = ref([
  {
    id: 's20',
    desc: '4개',
  },
  {
    id: 's21',
    desc: '3개',
  },
  {
    id: 's22',
    desc: '2개',
  },
]);

const dataCheck1 = ref(true);
const dataCheck2 = ref(false);
const searchInput1 = ref(['']);
const searchInput2 = ref(['']);
const searchInput3 = ref(['']);
const searchInput4 = ref(['']);
const searchInput5 = ref(['']);
const searchInput6 = ref(['']);
const searchInput7 = ref(['']);
const searchInput8 = ref(['']);
const searchInput9 = ref(['']);
const searchInput10 = ref(['']);
const searchInput11 = ref(['']);
</script>
