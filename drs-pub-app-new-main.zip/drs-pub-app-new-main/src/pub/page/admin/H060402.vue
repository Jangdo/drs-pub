<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">붐업관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <div class="row-calendar">
              <q-input
                outlined
                v-model="searchDate.from"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <span class="text-body2">~</span>
              <!-- 달력 인풋 -->
              <q-input
                outlined
                v-model="searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyTo"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.to"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyTo.hide()
                        "
                      />
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_m"
              outlined
              v-model="boardName"
              placeholder="제목"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_m"
              outlined
              v-model="writer"
              placeholder="등록자"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-checkbox
              v-model="dataCheck"
              label="등록일자 조회 제외"
              color="black"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab mt20">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="붐업 설정" :ripple="false" />
        <q-tab name="tab2" label="붐업 목록" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 -->
        <q-tab-panel name="tab1">
          <q-card class="wrap_table_box">
            <div class="table_dk">
              <div class="table_top">
                <div class="btn_wrap col-12 gap10">
                  <q-btn class="size_sm" outline label="붐업설정" />
                </div>
              </div>

              <q-table
                :rows="tableRows"
                :columns="tableColumns"
                row-key="idx"
                v-model:selected="table_selected"
                selection="multiple"
                v-model:pagination="dataPagination"
                hide-bottom
                hide-pagination
                separator="cell"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th class="w60"
                      ><q-checkbox v-model="props.selected" color="black"
                    /></q-th>
                    <q-th class="">게시판명</q-th>
                    <q-th class="">제목</q-th>
                    <q-th class="">첨부</q-th>
                    <q-th class="">추천</q-th>
                    <q-th class="">조회</q-th>
                    <q-th class="">등록자</q-th>
                    <q-th class="">등록일</q-th>
                  </q-tr>
                </template>
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td class="select"
                      ><q-checkbox v-model="props.selected" color="black"
                    /></q-td>
                    <q-td key="boardTitle" class="w180 text-center">
                      {{ props.row.boardTitle }}
                    </q-td>
                    <q-td key="tableName">
                      {{ props.row.tableName }}
                    </q-td>
                    <q-td key="file" class="w100 text-center">
                      <template v-if="props.row.file == 'Y'">
                        <q-icon name="icon-document" class="icon_svg"></q-icon>
                      </template>
                      <template v-else> </template>
                    </q-td>
                    <q-td key="recommend" class="w100 text-center">
                      {{ props.row.recommend }}
                    </q-td>
                    <q-td key="inquire" class="w100 text-center">
                      {{ props.row.inquire }}
                    </q-td>
                    <q-td key="author" class="w150 text-center">
                      {{ props.row.author }}
                    </q-td>
                    <q-td key="date" class="w150 text-center">
                      {{ props.row.date }}
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!-- 페이지네이션 -->
            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
            <!-- // 페이지네이션 -->
          </q-card>
        </q-tab-panel>
        <!--// tab1 -->

        <!-- tab2 -->
        <q-tab-panel name="tab2">
          <q-card class="wrap_table_box">
            <div class="table_dk">
              <div class="table_top">
                <div class="btn_wrap col-12 gap10">
                  <q-btn class="size_sm" outline label="붐업해제" />
                </div>
              </div>

              <q-table
                :rows="tableRows2"
                :columns="tableColumns2"
                row-key="idx"
                v-model:selected="table_selected2"
                selection="multiple"
                v-model:pagination="dataPagination"
                hide-bottom
                hide-pagination
                separator="cell"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th class="select"
                      ><q-checkbox v-model="props.selected" color="black"
                    /></q-th>
                    <q-th class="">게시판명</q-th>
                    <q-th class="">제목</q-th>
                    <q-th class="">첨부</q-th>
                    <q-th class="">추천</q-th>
                    <q-th class="">조회</q-th>
                    <q-th class="">등록자</q-th>
                    <q-th class="">등록일</q-th>
                  </q-tr>
                </template>
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td class="select"
                      ><q-checkbox v-model="props.selected" color="black"
                    /></q-td>
                    <q-td key="boardTitle2" class="w180 text-center">
                      {{ props.row.boardTitle2 }}
                    </q-td>
                    <q-td key="tableName2">
                      {{ props.row.tableName2 }}
                    </q-td>
                    <q-td key="file2" class="w100 text-center">
                      <template v-if="props.row.file2 == 'Y'">
                        <q-icon name="icon-document" class="icon_svg"></q-icon>
                      </template>
                      <template v-else> </template>
                    </q-td>
                    <q-td key="recommend2" class="w100 text-center">
                      {{ props.row.recommend2 }}
                    </q-td>
                    <q-td key="inquire2" class="w100 text-center">
                      {{ props.row.inquire2 }}
                    </q-td>
                    <q-td key="author2" class="w150 text-center">
                      {{ props.row.author2 }}
                    </q-td>
                    <q-td key="date2" class="w150 text-center">
                      {{ props.row.date2 }}
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!-- 페이지네이션 -->
            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
            <!-- // 페이지네이션 -->
          </q-card>
        </q-tab-panel>
        <!--// tab2 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const dataCheck = ref(true);

// tab
const tab = ref('tab2');

// table_search_area
const boardName = ref(['']);
const writer = ref(['']);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

// table데이터
const table_selected = ref([]);
const tableColumns = ref([
  {
    name: 'boardTitle',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.boardTitle,
  },
  {
    name: 'tableName',
    label: '제목',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName,
  },
  {
    name: 'file',
    label: '첨부',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.file,
  },
  {
    name: 'recommend',
    label: '추천',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.recommend,
  },
  {
    name: 'inquire',
    label: '조회',
  },
  {
    name: 'author',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'date',
    label: '등록일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
]);
const tableRows = ref([
  {
    idx: '1',
    boardTitle: '공지사항',
    tableName: '휴가 기간 연장안',
    file: 'Y',
    recommend: '999',
    inquire: '999',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '2',
    boardTitle: '게시판명',
    tableName: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file: '',
    recommend: '9,999',
    inquire: '9,999',
    author: '홍홍길동',
    date: '2022.11.01',
  },
  {
    idx: '3',
    boardTitle: '공지사항',
    tableName: '휴가 기간 연장안',
    file: 'Y',
    recommend: '999',
    inquire: '999',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '4',
    boardTitle: '게시판명',
    tableName: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file: '',
    recommend: '9,999',
    inquire: '9,999',
    author: '홍홍길동',
    date: '2022.11.01',
  },
  {
    idx: '5',
    boardTitle: '공지사항',
    tableName: '휴가 기간 연장안',
    file: 'Y',
    recommend: '999',
    inquire: '999',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '6',
    boardTitle: '게시판명',
    tableName: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file: '',
    recommend: '9,999',
    inquire: '9,999',
    author: '홍홍길동',
    date: '2022.11.01',
  },
  {
    idx: '7',
    boardTitle: '공지사항',
    tableName: '휴가 기간 연장안',
    file: 'Y',
    recommend: '999',
    inquire: '999',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '8',
    boardTitle: '게시판명',
    tableName: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file: '',
    recommend: '9,999',
    inquire: '9,999',
    author: '홍홍길동',
    date: '2022.11.01',
  },
  {
    idx: '9',
    boardTitle: '공지사항',
    tableName: '휴가 기간 연장안',
    file: 'Y',
    recommend: '999',
    inquire: '999',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '10',
    boardTitle: '게시판명',
    tableName: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file: '',
    recommend: '9,999',
    inquire: '9,999',
    author: '홍홍길동',
    date: '2022.11.01',
  },
]);

// pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
// table데이터 tab2
const table_selected2 = ref([]);
const tableColumns2 = ref([
  {
    name: 'boardTitle2',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.boardTitle2,
  },
  {
    name: 'tableName2',
    label: '제목',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName2,
  },
  {
    name: 'file2',
    label: '첨부',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.file2,
  },
  {
    name: 'recommend2',
    label: '추천',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.recommend2,
  },
  {
    name: 'inquire2',
    label: '조회',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.inquire2,
  },
  {
    name: 'author2',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author2,
  },
  {
    name: 'date2',
    label: '등록일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date2,
  },
]);
const tableRows2 = ref([
  {
    idx: '1',
    boardTitle2: '공지사항',
    tableName2: '휴가 기간 연장안',
    file2: 'Y',
    recommend2: '999',
    inquire2: '999',
    author2: '홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '2',
    boardTitle2: '게시판명',
    tableName2: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file2: '',
    recommend2: '9,999',
    inquire2: '9,999',
    author2: '홍홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '3',
    boardTitle2: '공지사항',
    tableName2: '휴가 기간 연장안',
    file2: 'Y',
    recommend2: '999',
    inquire2: '999',
    author2: '홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '4',
    boardTitle2: '게시판명',
    tableName2: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file2: '',
    recommend2: '9,999',
    inquire2: '9,999',
    author2: '홍홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '5',
    boardTitle2: '공지사항',
    tableName2: '휴가 기간 연장안',
    file2: 'Y',
    recommend2: '999',
    inquire2: '999',
    author2: '홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '6',
    boardTitle2: '게시판명',
    tableName2: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file2: '',
    recommend2: '9,999',
    inquire2: '9,999',
    author2: '홍홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '7',
    boardTitle2: '공지사항',
    tableName2: '휴가 기간 연장안',
    file2: 'Y',
    recommend2: '999',
    inquire2: '999',
    author2: '홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '8',
    boardTitle2: '게시판명',
    tableName2: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file2: '',
    recommend2: '9,999',
    inquire2: '9,999',
    author2: '홍홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '9',
    boardTitle2: '공지사항',
    tableName2: '휴가 기간 연장안',
    file2: 'Y',
    recommend2: '999',
    inquire2: '999',
    author2: '홍길동',
    date2: '2022.11.01',
  },
  {
    idx: '10',
    boardTitle2: '게시판명',
    tableName2: '한반도 긴장고조가 우려된다는 지적이 제기된다.',
    file2: '',
    recommend2: '9,999',
    inquire2: '9,999',
    author2: '홍홍길동',
    date2: '2022.11.01',
  },
]);
</script>
