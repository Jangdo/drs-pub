<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card inner_form" style="max-width: 1180px">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메뉴 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="dialog_search"></div>

          <!-- table_search_area type_02 -->
          <div class="table_search_area type_02">
            <div class="inline">
              <div class="wrap_item_input">
                <!-- <h3>사번 or 성명</h3> -->
                <q-select
                  class="box_m"
                  v-model="userNumberSelect"
                  :options="userNumberSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                  :class="[userNumberSelect == 0 ? 'placehoder' : '']"
                >
                </q-select>
              </div>
              <div class="wrap_item_input">
                <!-- <h3>사번 or 성명</h3> -->
                <q-input
                  class="box_l"
                  for=""
                  outlined
                  dense
                  v-model="userSearch"
                  placeholder="사번 or 성명을 입력하세요"
                />
              </div>
              <div class="btn_area">
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
          </div>
          <!--// table_search_area type_02 -->
          <div class="dialog_row">
            <!-- sm_area 트리 영역 -->
            <div class="sm_area">
              <q-tree
                :nodes="tree_data"
                node-key="id"
                selected-color="primary"
                class="category"
                v-model:selected="tree_selected"
                default-expand-all
                @update:selected="temp(tree_selected)"
              />
            </div>
            <!--// sm_area 트리 영역 -->
            <!-- main_area 테이블 영역 -->
            <div class="main_area">
              <!-- selectable_table type_row -->
              <div class="selectable_table type_row">
                <q-table
                  style="height: 411px; overflow: auto"
                  :rows="settingMenuRows"
                  :columns="settingMenuColumns"
                  row-key="code"
                  v-model:selected="settingMenuSelected"
                  selection="multiple"
                  hide-bottom
                  hide-pagination
                  v-model:pagination="settingMenu_pagination"
                  separator="cell"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td class="select"
                        ><q-checkbox v-model="props.selected"
                      /></q-td>
                      <q-td key="path" class="path">{{ props.row.path }}</q-td>
                      <q-td key="code" class=""> {{ props.row.code }}</q-td>
                      <q-td key="name" class="name"> {{ props.row.name }}</q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <div class="row">
                <h3>권한범위</h3>
                <q-option-group
                  class="wrap_check"
                  :options="authorityRangeoptions"
                  type="checkbox"
                  v-model="authorityRange"
                />
                <div class="btn_area">
                  <q-btn
                    class="btn_txt"
                    icon="ion-ios-add"
                    dense
                    outline
                    label="추가"
                  />
                  <q-btn
                    class="btn_txt"
                    icon="ion-ios-remove"
                    dense
                    outline
                    label="삭제"
                  />
                </div>
              </div>
              <div class="wrap_select_list">
                <ul class="select_list">
                  <li
                    :class="item.state"
                    v-for="(item, index) in selectedData"
                    :key="index"
                  >
                    <p>{{ item.code }}-{{ item.name }}({{ item.head }})</p>
                    <p class="authority_tag">
                      <span class="tag" v-if="item.authority.add">등록</span>
                      <span class="tag" v-if="item.authority.edit">수정</span>
                      <span class="tag" v-if="item.authority.del">삭제</span>
                      <span class="tag" v-if="item.authority.search">조회</span>
                    </p>
                  </li>
                </ul>
              </div>
              <!--// selectable_table type_row-->
            </div>
            <!--// main_area 테이블 영역 -->
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// menu
const userNumberSelect = ref('');
const userNumberSelectOption = ref([
  {
    id: '',
    desc: '사번을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '22021133',
  },
  {
    id: 'G',
    desc: '22021133',
  },
  {
    id: 'C',
    desc: '22021133 ',
  },
  {
    desc: '2202113',
  },
]);
const userSearch = ref('');
// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: 'home',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

//settingMenu_table데이터
//authority_table데이터
const settingMenuSelected = ref([]);

const settingMenuColumns = ref([
  {
    name: 'path',
    label: '메뉴경로',
    sortable: false,
    align: 'center',
    field: (row) => row.head,
  },

  {
    name: 'code',
    label: '메뉴코드',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },

  {
    name: 'name',
    label: '메뉴명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
]);
const settingMenuRows = ref([
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
  {
    path: '학습상담 > 내교실 > 학습콘텐츠',
    code: 'MA0001',
    name: '홍길동',
  },
]);

const authorityRange = ref([]);
const authorityRangeoptions = ref([
  { label: '등록', value: 'test1', color: 'black' },
  { label: '수정', value: 'test2', color: 'black' },
  { label: '삭제', value: 'test3', color: 'black' },
  { label: '조회', value: 'test4', color: 'black' },
]);

// selectedData
const selectedData = ref([
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: 'add',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
  {
    head: '서울강서본부',
    code: '20021134',
    name: '홍길동',
    state: '',
    authority: {
      add: true,
      edit: true,
      del: true,
      search: true,
    },
  },
]);

const settingMenu_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});
</script>

<style lang="scss">
.dialog_row {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.dialog_content {
  max-height: calc(100vh - 260px);
  overflow: auto;
}
.q-dialog {
  display: block;
  .wrap_check {
    display: flex;
    flex-direction: row;
    float: left;
    align-items: center;
    justify-content: flex-start;
  }
  .wrap_select_list {
    opacity: 1;
    .select_list {
      font-size: 16px;
      border-top: 1px solid;
      margin-top: 50px;
      height: 394px;
      overflow: auto;
      & > li {
        box-sizing: border-box;
        height: 60px;
        display: flex;
        align-items: flex-start;
        flex-direction: column;
        justify-content: center;
        padding: 0 0 0 28px;
        border-bottom: 1px solid rgba(0, 0, 0, 0.2);
        &.add {
          background: rgb(232 221 204 / 20%);
        }
      }
    }
  }
}
</style>
