<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">겸직 로그인 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="keyword"
              placeholder="위임 ID"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="inp_search"
              for=""
              outlined
              dense
              v-model="keyword2"
              placeholder="위임할 지점"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <!-- general_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" color="" outline label="선택삭제" />
            <q-btn
              class="size_sm"
              color="black"
              fill
              unelevated
              label="신규등록"
            />
          </div>
        </div>

        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          v-model:selected="selected"
          row-key="idx"
          v-model:pagination="dataPagination"
          selection="multiple"
          hide-bottom
          hide-pagination
          separator="cell"
          color="black"
        >
        </q-table>
      </div>
      <!-- pagination -->
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!-- // pagination -->
      <!-- // general_table -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const keyword = ref('');
const keyword2 = ref('');

//data테이블
const selected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '위임지점',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '지점',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '위임받을 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '이름',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '권한이름',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '위임팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '위임시작일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '위임종료일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '위임차단일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '비고',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 9,
    tdata1: 'J0145',
    tdata2: '차이홍 북수원 교육국 교육국',
    tdata3: '2200431113',
    tdata4: '홍홍길동',
    tdata5: '사업 팀장',
    tdata6: '0001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무 처리',
  },
  {
    idx: 8,
    tdata1: 'J45',
    tdata2: '차이홍 교육국',
    tdata3: '220043',
    tdata4: '홍동',
    tdata5: '팀장',
    tdata6: '1팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무',
  },
  {
    idx: 7,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 6,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 5,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 4,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 3,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 2,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
  {
    idx: 1,
    tdata1: 'J045',
    tdata2: '차이홍 북수원 교육국',
    tdata3: '22004313',
    tdata4: '홍길동',
    tdata5: '사업팀장',
    tdata6: '001팀',
    tdata7: '2023.03.01',
    tdata8: '2023.03.31',
    tdata9: '2023.04.01',
    tdata10: '업무처리',
  },
]);
</script>
