<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메뉴 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">메뉴 ID</span>
                  <q-input
                    class="as_dd hide_label"
                    label="메뉴 ID"
                    outlined
                    placeholder="메뉴 ID를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>메뉴 ID</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">메뉴명</span>
                  <q-input
                    class="as_dd hide_label"
                    label="메뉴명"
                    outlined
                    placeholder="메뉴명을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>메뉴명</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">순번</span>
                  <q-input
                    class="as_dd hide_label"
                    label="순번"
                    outlined
                    placeholder="순번을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>순번</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">컴포넌트</span>
                  <q-input
                    class="as_dd hide_label"
                    label="컴포넌트"
                    outlined
                    placeholder="컴포넌트를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>컴포넌트</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">탭여부</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="사용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="사용안함"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">출력구분</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="전체"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="웹"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="모바일"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">사용여부</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="사용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="사용안함"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">즐겨찾기 여부</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="사용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="사용안함"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">권한목록</span>
                  <div class="as_dd scroll mt15 mb15" style="height: 300px">
                    <ul class="full-width">
                      <li v-for="i in 20" :key="i">
                        <span>NC [국장]</span>
                        <span>등록|수정|삭제|다운|조회</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">PATH</span>
                  <q-input
                    v-model="dataFrom.url"
                    class="as_dd hide_label"
                    label="PATH"
                    outlined
                    placeholder="PATH를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>PATH</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="hastextarea">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">메뉴설명</span>
                  <div class="mt15 mb15 full-width">
                    <q-input
                      class="as_dd hide_label"
                      outlined
                      placeholder="메뉴설명을 입력하세요"
                      type="textarea"
                      v-model="dataFrom.txt"
                    >
                      <template v-slot:label>메뉴설명</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
    .as_dd {
      display: flex;
      gap: 0 10px;
    }
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  url: '',
});
</script>

<style lang="scss"></style>
