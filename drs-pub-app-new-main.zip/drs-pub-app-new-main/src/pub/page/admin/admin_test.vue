<template>
  <div class="q-pa-lg bg-grey-2">
    <q-breadcrumbs active-color="grey-8" class="mb50">
      <template v-slot:separator>
        <q-icon size="1.5em" name="chevron_right" />
      </template>
      <q-breadcrumbs-el label="HOME" to="/pub" />
      <q-breadcrumbs-el label="공통관리" to="/pub/admin" />
      <q-breadcrumbs-el :label="$route.name" />
    </q-breadcrumbs>
    <div class="admin_tit_area">
      <h2 class="text24b title">공통코드관리</h2>
    </div>
    <div class="admin_con_area">
      <div class="tab_admin">
        <q-tabs
          v-model="tab"
          color="white"
          active-color="brown-4"
          indicator-color="transparent"
          align="justify"
          class="tab_basic bg-white"
        >
          <q-tab name="upper" label="상위코드" />
          <q-tab name="downer" label="하위코드" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- 탭내용1 -->
          <q-tab-panel name="upper">
            <!-- table_serch_area type_01 -->
            <div class="table_serch_area type_01 row q-gutter-x-md">
              <div class="input_area col">
                <q-select
                  class="box_m"
                  v-model="dataSelect"
                  :options="dataSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                  :class="[dataSelect == 0 ? 'placehoder' : '']"
                >
                </q-select>
                <q-input
                  class="box_l col"
                  outlined
                  v-model="keyword"
                  placeholder="코드 or 코드명을 입력하세요"
                />
              </div>
              <div class="btn_area">
                <q-btn class="size_md" fill color="grey-9" label="조회" />
                <q-btn
                  class="btn_txt"
                  icon="ion-ios-refresh"
                  dense
                  outline color="grey-9"
                  label="초기화"
                />
              </div>
            </div>
            <!--// table_serch_area type_01 -->
            <!-- add_code_table -->
            <div class="add_code_table">
              <div class="btn_area mb14">
                <q-btn
                  class="size_sm row_add"
                  color="grey-9"
                  icon="ion-ios-add"
                  dense
                  outline
                  label="행추가"
                />
              </div>
              <q-table
                :rows="add_rows"
                :columns="add_columns"
                row-key="code"
                v-model:pagination="pagination"
                hide-pagination
                separator="cell"
              >
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td class="close">
                      <!-- 닫기 -->
                      <q-btn icon="ion-ios-close" dense flat label="" size="36px" />
                    </q-td>
                    <q-td key="code" class="code">
                      <div class="row flex q-gutter-sm">
                        <q-select
                          class="box_m"
                          v-model="props.row.code.select"
                          :options="dataSelectOption"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          :class="[dataSelect == 0 ? 'placehoder' : '']"
                        >
                        </q-select>

                        <q-input
                          outlined
                          v-model="props.row.code.input"
                          placeholder="입력하세요"
                          dense
                        >
                          <!-- <template v-slot:error>
                            동일한 이름이 있습니다.
                          </template> -->
                        </q-input>
                      </div>
                    </q-td>
                    <q-td key="name" class="code_name">
                      <q-input
                        outlined
                        v-model="props.row.name"
                        placeholder="입력하세요"
                        dense
                      />
                    </q-td>
                    <q-td key="state" class="state">
                      {{ tdState(props.row.state) }}</q-td
                    >
                    <q-td key="allow" :props="props" class="allow">
                      <q-toggle v-model="props.row.allow" color="negative" />
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!--// add_code_table -->
            <!-- edite_table -->
            <div class="edite_table type_01">
              <div class="row flex justify-between mb14">
                <q-btn outline color="grey-9" label="행삭제" class="size_sm row_remove" icon="ion-ios-remove" dense />
                <q-space />
                <q-btn fill color="black" label="저장" class="size_sm btn-save" icon="ion-ios-save" dense />
              </div>
              <q-table
                :rows="rows"
                :columns="columns"
                row-key="code"
                v-model:selected="selected"
                selection="multiple"
                hide-pagination
                separator="cell"
              >
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td class="select">
                      <q-checkbox v-model="props.selected" />
                    </q-td>
                    <q-td key="code" class="code">
                      {{ props.row.code }}
                      <q-popup-edit
                        v-model="props.row.code"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" autofocus />
                      </q-popup-edit>
                    </q-td>
                    <q-td key="name" class="code_name">
                      {{ props.row.name }}
                      <q-popup-edit
                        v-model="props.row.name"
                        buttons
                        label-set="확인"
                        label-cancel="취소"
                        v-slot="scope"
                      >
                        <q-input v-model="scope.value" autofocus />
                      </q-popup-edit>
                    </q-td>
                    <q-td key="state" class="state">
                      {{ tdState(props.row.state) }}
                    </q-td>
                    <q-td key="allow" :props="props" class="allow">
                      <q-toggle v-model="props.row.allow" color="negative" />
                    </q-td>
                  </q-tr>
                </template>
              </q-table>

              <!-- <div class="q-pa-lg flex flex-center">
                <q-pagination
                  v-model="pagination.page"
                  :max="pagesNumber"
                  :max-pages="11"
                  :ellipses="false"
                  :boundary-numbers="true"
                  color="grey-8"
                  active-color="black"
                  direction-links
                  boundary-links
                  icon-first="keyboard_double_arrow_left"
                  icon-last="keyboard_double_arrow_right"
                  icon-prev="keyboard_arrow_left"
                  icon-next="keyboard_arrow_right"
                />
              </div> -->
            </div>
            <!-- //edite_table -->
          </q-tab-panel>
          <!-- //탭내용1 -->
          <!-- 탭내용2 -->
          <q-tab-panel name="downer">
            222
          </q-tab-panel>
          <!-- //탭내용2 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

// tab
const tab = ref('upper');
// dropdown
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: '',
    desc: '코드를 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
// serchbox input
const keyword = ref('');

//edit_ table
const selected = ref([]);
const columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: true,
    field: (row) => row.code,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: true,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: true,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: true,
    field: (row) => row.allow,
  },
]);
const rows = ref([
  {
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: true,
  },
  {
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'edit',
    allow: true,
  },
  {
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: false,
  },
  {
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: false,
  },
]);

// add_code_table 데이터

const add_columns = ref([
  {
    name: 'btn',
    label: '',
    sortable: false,
    // field: (row) => row.code,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: true,
    field: (row) => row.code,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: true,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    class: 'state',
    sortable: true,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: true,
    field: (row) => row.allow,
  },
]);

const add_rows = ref([
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001', sample_err: true },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
  {
    btn: true,
    code: { select: 'SALE_01', input: 'name_SALE_001' },
    name: 'name_SALE_001',
    state: 'add',
    allow: true,
  },
]);

// pagination
const pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

function tdState(priority) {
  switch (priority) {
    case 'add':
      return '신규';
    case 'edit':
      return '수정';
    default:
      return '';
  }
}
</script>
