<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판 환경설정</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_box">
      <table class="table_row_sales">
        <colgroup>
          <col style="width: 235px" />
          <col />
        </colgroup>
        <tbody>
          <tr>
            <th><b class="essential">직명</b></th>
            <td>
              <div class="row items-center">
                <span class="text-body2 flex_no">TBBS1_</span>
                <div class="search_item ml10 flex_auto">
                  <q-input
                    class="inp_search"
                    outlined
                    placeholder="테이블명(물리)를 입력하세요"
                  ></q-input>
                </div>
              </div>
            </td>
          </tr>
          <tr>
            <th><b class="essential">성명</b></th>
            <td>
              <div class="search_item type_full">
                <q-input
                  class="inp_search"
                  outlined
                  placeholder="테이블명(논리)를 입력하세요."
                ></q-input>
              </div>
            </td>
          </tr>
          <tr>
            <th><b class="essential">출신학교</b></th>
            <td>
              <div class="search_item type_medium">
                <q-select
                  class=""
                  v-model="sysSelect"
                  :options="sysSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                  :class="[sysSelect == 0 ? 'placehoder' : '']"
                >
                </q-select>
              </div>
            </td>
          </tr>
          <tr>
            <th><b class="essential">첨부 확장자 제한(Blacklist)</b></th>
            <td>
              <div class="search_item type_full">
                <q-input
                  class="inp_search"
                  outlined
                  placeholder="확장자 명을 입력하세요. (확장자 구분은 ,를 입력하세요.)."
                ></q-input>
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- 버튼 -->
      <div class="btn_area btn_bottom_type01">
        <q-btn unelevated outline color="grey-4" class="size_lg" label="취소" />
        <q-btn unelevated color="black" class="size_lg" label="저장" />
      </div>
      <!-- // 버튼 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const sysSelect = ref('선택하세요');
const sysSelectOption = ref([
  {
    id: 'aaa1',
    desc: '선택하세요1',
  },
  {
    id: 'aaa2',
    desc: '선택하세요2',
  },
]);
</script>
