<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판 관리</h2>
      <Breadcrumbs />
    </div>

    <!-- 탭 영역 -->
    <div class="wrapper_tab">
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb24"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
      </q-tabs>
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <table class="table_row_view">
              <tbody>
                <tr>
                  <th><span class="">게시판명</span></th>
                  <td colspan="3">
                    {{ inpBoardName }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">게시판 설명</span></th>
                  <td colspan="3">
                    {{ inpBoardDetail }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">게시판 타이틀</span></th>
                  <td>
                    {{ inpBoardTitle }}
                  </td>
                  <th class="line_l">타이틀 형태</th>
                  <td>
                    {{ inpBoardTitleType }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">권한설정</span></th>
                  <td colspan="3">
                    {{ inpAuthority }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">게시판 테이블</span></th>
                  <td colspan="3">
                    {{ inpBoardTable }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">게시물 카테고리</span></th>
                  <td colspan="3">
                    {{ inpBoardCategory }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">게시판 유형</span></th>
                  <td>
                    {{ boardType }}
                  </td>
                  <th class="line_l">답변형 게시판 여부</th>
                  <td>
                    {{ boardReple }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">담당자 지정</span></th>
                  <td colspan="3" class="py20">
                    {{ inpManager }}<br />
                    {{ inpManager }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">보관기한 설정여부</span></th>
                  <td>
                    {{ SaveTermSet }}
                  </td>
                  <th class="line_l">신규게시물 표시</th>
                  <td>
                    {{ newPost }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">첨부사이즈 제한</span></th>
                  <td colspan="3">
                    {{ limitFileSize }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">첨부 확장자 제한(blacklist)</span></th>
                  <td colspan="3">
                    {{ limitFileType }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">금칙어 여부</span></th>
                  <td>
                    {{ forbiddenWord }}
                  </td>
                  <th class="line_l">이전/다음</th>
                  <td>
                    {{ prevNext }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">말머리 사용</span></th>
                  <td>
                    {{ bulletPoint }}
                  </td>
                  <th class="line_l">붐업여부</th>
                  <td>
                    {{ boomUp }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">덧글 사용</span></th>
                  <td>
                    {{ useReple }}
                  </td>
                  <th class="line_l">찬반여부</th>
                  <td>
                    {{ yesOrNo }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">목록 게시물수</span></th>
                  <td>
                    {{ boardListNum }}
                  </td>
                  <th class="line_l">신고기능여부</th>
                  <td>
                    {{ reportFunction }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">목록 검색기간</span></th>
                  <td>
                    {{ listSearchPeriod }}
                  </td>
                  <th class="line_l">태그기능</th>
                  <td>
                    {{ tagFunction }}
                  </td>
                </tr>
                <tr>
                  <th><span class="">내 게시물만 보기</span></th>
                  <td colspan="3">
                    <q-checkbox
                      v-model="dataCheck"
                      color="black"
                      disable
                      class=""
                    />
                  </td>
                </tr>
              </tbody>
            </table>

            <!-- 버튼 -->
            <div class="btn_area response">
              <q-space />
              <q-btn unelevated color="grey-2" class="size_md" label="목록" />
            </div>
            <!-- // 버튼 -->
          </div>
        </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->
      </q-tab-panels>
    </div>
    <!-- // 탭 영역 -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');
const inpBoardName = ref('공지사항');
const inpBoardDetail = ref('공지사항 게시판입니다.');
const inpBoardTitle = ref('제목');
const inpBoardTitleType = ref('타입');
const inpAuthority = ref('COMMON | RW');
const inpBoardTable = ref('기본게시판');
const inpBoardCategory = ref('공지 카테고리');
const boardType = ref('목록형');
const boardReple = ref('비답변형');
const inpManager = ref('김대교 | 강서교육국');
const SaveTermSet = ref('영구보관 1개월');
const newPost = ref('사용안함');
const limitFileSize = ref('00mb');
const limitFileType = ref('exe, bat, cat');
const forbiddenWord = ref('사용');
const prevNext = ref('사용안함');
const bulletPoint = ref('사용안함');
const boomUp = ref('사용안함');
const useReple = ref('사용안함');
const yesOrNo = ref('사용안함');
const boardListNum = ref('20');
const reportFunction = ref('사용안함');
const listSearchPeriod = ref('5 (일)');
const tagFunction = ref('사용안함');
const dataCheck = ref(false);
</script>
