<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">권한관리 (사용자/조직별)</h2>
      <Breadcrumbs />
    </div>

    <!-- 탭 영역 -->
    <div class="wrapper_tab">
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="사용자" :ripple="false" />
        <q-tab name="tab2" label="조직" :ripple="false" />
      </q-tabs>
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1"> tab1 내용 </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="팀, 교육국"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <q-card class="wrap_table_divide wrap_table_box">
            <!-- sm_area 트리 영역 -->
            <div class="sm_area">
              <div class="h56">
                <q-input
                  class="inp_search w100p"
                  outlined
                  dense
                  v-model="keyword2"
                  placeholder="조직명을 검색하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="tree_container">
                <q-tree
                  :nodes="tree_data"
                  node-key="id"
                  selected-color="primary"
                  class="category"
                  v-model:selected="tree_selected"
                  default-expand-all
                  @update:selected="temp(tree_selected)"
                  style="max-height: 580px; min-height: 580px"
                />
              </div>
            </div>
            <!--// sm_area 트리 영역 -->

            <!-- main_area 테이블 영역 -->
            <div class="main_area">
              <!-- selectable_table type_01 -->
              <div class="table_dk">
                <div class="table_top mb0">
                  <div class="info_wrap col-12 col-md-4">
                    <div class="h56 pt10 text-body2">
                      <span class="text-primary">총 <span>67</span>건</span>이
                      조회되었습니다.
                    </div>
                  </div>
                </div>
                <q-table
                  class="scrollable sticky_table_header"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                  :rows-per-page-options="[0]"
                  style="max-height: 580px"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="idx" class="select text-center">
                        {{ props.row.idx }}
                      </q-td>
                      <q-td key="tdata1" class="text-left">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="change" class="text-center w150">
                        <q-btn
                          outline
                          class="size_xxs btn_inner_table"
                          label="변경"
                        />
                      </q-td>
                      <q-td key="view" class="text-center w150">
                        <q-btn
                          outline
                          class="size_xxs btn_inner_table"
                          label="보기"
                        />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
            </div>
            <!--// main_area 테이블 영역 -->
          </q-card>
        </q-tab-panel>
        <!--// tab2 컨텐츠 -->
      </q-tab-panels>
    </div>
    <!-- // 탭 영역 -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const tab = ref('tab2');
const keyword = ref('');
const keyword2 = ref('');

// tree
const tree_data = [
  {
    label: '대교드림스',
    id: 'treeAll',
    icon: '',
    children: [
      {
        id: 'treeSub1',
        label: '서울서북본부',
        children: [
          {
            id: 'treeSub1_1',
            label: '서울서북지원팀',
            children: [
              {
                id: 'treeSub1_1_1',
                label: '하위1_1',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'treeSub1_1_2',
                label: '하위1_2',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'treeSub1_2',
            label: '강서교육국',
            img: '/icons/icon-tree-folder.svg',
          },
          {
            id: 'treeSub1_3',
            label: '동작교육국',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '서울강북본부',
        id: 'treeSub2',
        children: [
          {
            label: '하위1',
            id: 'treeSub2_1',
            children: [
              { id: 'treeSub2_1_1', label: '하위1-1' },
              { id: 'treeSub2_1_2', label: '하위1-1' },
            ],
          },
          { id: 'treeSub2_2', label: '하위2' },
        ],
      },
      {
        label: '서울강남본부',
        id: 'treeSub3',
        children: [
          { id: 'treeSub3_1', label: '하위1' },
          { id: 'treeSub3_2', label: '하위2' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('대교드림스');

const dataColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'change',
    label: '권한변경',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'view',
    label: '권한이력',
    sortable: false,
    align: 'center',
    field: (row) => row.delete,
  },
]);
const dataRows = ref([
  {
    idx: 100,
    tdata1: '서울서북본부',
    change: '',
    view: '',
  },
  {
    idx: 99,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 98,
    tdata1: '서울서북본부 > 서울서북 지원팀',
    change: '',
    view: '',
  },
  {
    idx: 97,
    tdata1: '서울 서북 본부 > 서울 서북 지원팀',
    change: '',
    view: '',
  },
  {
    idx: 96,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 95,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 94,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 93,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 92,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
  {
    idx: 91,
    tdata1: '서울서북본부 > 서울서북지원팀',
    change: '',
    view: '',
  },
]);
</script>
