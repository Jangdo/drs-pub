<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">회원 데이터출력 조회 및 폐기</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="본부명 전체"
              v-model="searchHead"
              :options="searchHeadOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="지점명 전체"
              v-model="searchBranch"
              :options="searchBranchOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="사업팀 전체"
              v-model="searchTeam"
              :options="searchTeamOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="구분 전체"
              v-model="searchCategory"
              :options="searchCategoryOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <div class="wrap_table_box">
      <!-- general_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="info_wrap col-12 col-md-4">
            <p class="row align-center text-body-2">
              총 <span>00</span>건의 검색결과가 있습니다
            </p>
          </div>
          <div class="btn_wrap col-12 col-md-8 gap10">
            <q-btn class="size_sm" color="" outline label="폐기" />
          </div>
        </div>
        <q-table
          class=""
          :rows="dataRows"
          :columns="dataColumns"
          v-model:selected="tblRowSelected"
          row-key="idx"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          selection="single"
          separator="cell"
          color="black"
          ><template v-slot:header="props">
            <q-tr :props="props">
              <q-th>선택</q-th>
              <q-th>대상메뉴명</q-th>
              <q-th>동의</q-th>
              <q-th>성명</q-th>
              <q-th>조회자 사번</q-th>
              <q-th>조회일시</q-th>
              <q-th>처리건수</q-th>
              <q-th>구분</q-th>
              <q-th>조회일시</q-th>
              <q-th>폐기자 사번</q-th>
              <q-th>폐기자 성명</q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="check" class="select text-center">
                <q-checkbox
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  class="check_to_radio"
                  v-model="props.selected"
                  color="black"
                />
              </q-td>
              <q-td key="tdata2" class="text-center">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="text-left">
                {{ props.row.tdata3 }}
              </q-td>
              <q-td key="tdata4" class="text-center">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="tdata5" class="text-center">
                {{ props.row.tdata5 }}
              </q-td>

              <q-td key="tdata6" class="text-center">
                {{ props.row.tdata6 }}
              </q-td>
              <q-td key="tdata7" class="text-center">
                {{ props.row.tdata7 }}
              </q-td>

              <q-td key="tdata8" class="text-center">
                {{ props.row.tdata8 }}
              </q-td>
              <q-td key="tdata9" class="text-center">
                {{ props.row.tdata9 }}
              </q-td>
              <q-td key="tdata10" class="text-center">
                {{ props.row.tdata10 }}
              </q-td>
              <q-td key="tdata11" class="text-center">
                {{ props.row.tdata11 }}
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <!-- pagination -->
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!-- // pagination -->
      <!--// general_table -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchHead = ref(['']);
const searchHeadOption = ref([
  {
    id: 'a',
    desc: '본부1',
  },
  {
    id: 'b',
    desc: '본부2',
  },
]);
const searchBranch = ref(['']);
const searchBranchOption = ref([
  {
    id: 'a',
    desc: '지점1',
  },
  {
    id: 'b',
    desc: '지점2',
  },
]);
const searchTeam = ref(['']);
const searchTeamOption = ref([
  {
    id: 'a',
    desc: '팀1',
  },
  {
    id: 'b',
    desc: '팀2',
  },
]);
const searchCategory = ref(['']);
const searchCategoryOption = ref([
  {
    id: 'a',
    desc: '구분1',
  },
  {
    id: 'b',
    desc: '구분2',
  },
]);

//data테이블
const tblRowSelected = ref([
  {
    idx: 1,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '게시물 제목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '팝업명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '기간',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata6',
    label: '사용여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '미리보기',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
]);
const dataRows = ref([
  {
    // tdata1: true,
    idx: 1,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 2,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 3,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 4,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 5,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 6,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 7,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 8,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 9,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
  {
    // tdata1: true,
    idx: 10,
    tdata2: 10,
    tdata2: '회비입금내역',
    tdata3: 'O',
    tdata4: '홍길동',
    tdata5: '1234567890',
    tdata6: '2022.11.01 12:34:22',
    tdata7: '10',
    tdata8: '진행중',
    tdata9: '2022.11.01 12:34:22',
    tdata10: '1234567890',
    tdata11: '홍길동',
  },
]);
</script>
<style lang="scss" scoped>
.align-center {
  align-items: center;
}
</style>
