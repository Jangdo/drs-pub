<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">게시판 폴더</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            outline
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="input_scoped">
            <div class="wrap_input">
              <div class="as_dt text-body2">폴더명</div>
              <div class="as_dd">
                <q-input
                  class="box_l"
                  for=""
                  outlined
                  dense
                  v-model="keyword"
                  placeholder="폴더명을 입력하세요"
                />
              </div>
            </div>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
</script>
<style lang="scss" scoped>
.input_scoped {
  .wrap_input {
    display: flex;
    flex-direction: row;
    width: 100%;
    border-top: 1px solid rgba(0, 0, 0, 0.2);
    border-bottom: 1px solid rgba(0, 0, 0, 0.2);
    min-height: 58px;
    align-items: center;
    .as_dt {
      padding: 0 24px;
      min-width: 58px;
      margin-right: 10px;
    }
    .as_dd {
      width: 100%;
      padding: 0 10px;
    }
  }
}
</style>
