<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">권한변경 - 서울서북본부 > 광명 교육국</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="권한명"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="wrap_table_divide wrap_table_box p0 mt20">
            <!-- sm_area 트리 영역 -->
            <div class="sm_area">
              <div class="h56">
                <q-input
                  class="inp_search w100p"
                  outlined
                  dense
                  v-model="keyword2"
                  placeholder="조직명을 검색하세요"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="tree_container">
                <q-tree
                  :nodes="tree_data"
                  node-key="id"
                  selected-color="primary"
                  class="category"
                  v-model:selected="tree_selected"
                  default-expand-all
                  @update:selected="temp(tree_selected)"
                  style="max-height: 842px; min-height: 842px"
                />
              </div>
            </div>
            <!--// sm_area 트리 영역 -->

            <!-- main_area 테이블 영역 -->
            <div class="main_area">
              <!-- selectable_table type_01 -->
              <div class="table_dk">
                <div class="table_top mb0">
                  <div class="info_wrap col-12 col-md-4">
                    <div class="h56 pt10 text-body2">
                      <span class="text-primary">총 <span>67</span>건</span>이
                      조회되었습니다.
                    </div>
                  </div>
                </div>
                <q-table
                  class="scrollable sticky_table_header"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  v-model:selected="selected"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                  selection="multiple"
                  color="black"
                  :rows-per-page-options="[0]"
                  style="max-height: 452px"
                >
                </q-table>
              </div>

              <div class="btn_area row justify-end mt40 mb16">
                <q-btn outline class="size_sm" label="추가" />
                <q-btn outline class="size_sm" label="삭제" />
              </div>

              <div class="scrollable_table_row_sales" style="max-height: 296px">
                <table class="table_row_sales no_title">
                  <tbody>
                    <tr>
                      <td>시스템관리자 > 인사회계_개발자</td>
                    </tr>
                    <tr>
                      <td>시스템관리자 > 제작매체_개발자</td>
                    </tr>
                    <tr>
                      <td>시스템관리자 > 일반 사용자</td>
                    </tr>
                    <tr>
                      <td>인사 > 인사담당자</td>
                    </tr>
                    <tr>
                      <td>회계 > 회계담당자</td>
                    </tr>
                    <tr>
                      <td>회계 > 회계담당자</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!--// main_area 테이블 영역 -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            outline
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const keyword = ref('');

// tree
const tree_data = [
  {
    label: '대교드림스',
    id: 'treeAll',
    icon: '',
    children: [
      {
        id: 'treeSub1',
        label: '시스템관리자',
        children: [
          {
            id: 'treeSub1_1',
            label: '인사회계_개발자',
            children: [
              {
                id: 'treeSub1_1_1',
                label: '하위1_1',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'treeSub1_1_2',
                label: '하위1_2',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'treeSub1_2',
            label: '제작매체_개발자',
            img: '/icons/icon-tree-folder.svg',
          },
          {
            id: 'treeSub1_3',
            label: '일반 사용자',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '인사',
        id: 'treeSub2',
        children: [
          {
            label: '인사담당자',
            id: 'treeSub2_1',
            children: [
              { id: 'treeSub2_1_1', label: '하위1-1' },
              { id: 'treeSub2_1_2', label: '하위1-1' },
            ],
          },
          { id: 'treeSub2_2', label: '하위2' },
        ],
      },
      {
        label: '회계',
        id: 'treeSub3',
        children: [
          { id: 'treeSub3_1', label: '회계담당자' },
          { id: 'treeSub3_2', label: '하위2' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('대교드림스');

//data테이블
const selected = ref([]);

const dataColumns = ref([
  {
    name: 'tdata1',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '권한명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
  },
  {
    idx: 10,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
  },
  {
    idx: 9,
    tdata1: '시스템관리자',
    tdata2: '제작매체_개발자',
  },
  {
    idx: 8,
    tdata1: '시스템관리자',
    tdata2: '일반 사용자',
  },
  {
    idx: 7,
    tdata1: '인사',
    tdata2: '인사담당자',
  },
  {
    idx: 6,
    tdata1: '회계',
    tdata2: '회계담당자',
  },
  {
    idx: 5,
    tdata1: '제작',
    tdata2: '제작담당자',
  },
  {
    idx: 4,
    tdata1: '매체',
    tdata2: '매체담당자',
  },
  {
    idx: 3,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
  },
  {
    idx: 2,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
  },
  {
    idx: 1,
    tdata1: '시스템관리자',
    tdata2: '인사회계_개발자',
  },
]);
</script>
