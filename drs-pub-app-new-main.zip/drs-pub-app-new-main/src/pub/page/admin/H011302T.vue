<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">메시지(탬플릿)관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb24"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="upper" label="문자패턴관리" :ripple="false" />
        <q-tab name="downer" label="방문시간 안내 멘트" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 문자패턴관리 tab 컨텐츠 -->
        <q-tab-panel name="upper"> 문자패턴 관리 : H011301T </q-tab-panel>
        <!--// 문자패턴관리 tab 컨텐츠 -->
        <!-- 방문시간 안내 멘트 tab 컨텐츠 -->
        <q-tab-panel name="downer">
          <div class="wrap_table_box">
            <!-- editable_table -->
            <div class="editable_table type_01">
              <div class="btn_area">
                <q-space />
                <q-btn
                  class="size_sm btn_save"
                  color="black"
                  unelevated
                  label="저장"
                />
              </div>
            </div>
            <!--// editable_table -->

            <!-- markup-table body rowspan -->
            <q-markup-table
              separator="cell"
              class="combine_table mt20"
              wrap-cells
            >
              <colgroup>
                <col style="width: 80px" />
                <col />
                <col style="width: 80px" />
              </colgroup>
              <thead>
                <tr>
                  <th>주차</th>
                  <th>멘트</th>
                  <th>Byte</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td class="pa10">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea.week1"
                      placeholder="##NAME##의 일주일 학습은 잘 진행되었나요? 내일 ##TIME## 에 방문할게요. 학습준비해서 기다려 주세요."
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </td>
                  <td>65</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td class="pa10">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea.week2"
                      placeholder="##NAME##의 일주일 학습은 잘 진행되었나요? 내일 ##TIME## 에 방문할게요. 학습준비해서 기다려 주세요."
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </td>
                  <td>65</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td class="pa10">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea.week3"
                      placeholder="##NAME##의 일주일 학습은 잘 진행되었나요? 내일 ##TIME## 에 방문할게요. 학습준비해서 기다려 주세요."
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </td>
                  <td>65</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td class="pa10">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea.week4"
                      placeholder="##NAME##의 일주일 학습은 잘 진행되었나요? 내일 ##TIME## 에 방문할게요. 학습준비해서 기다려 주세요."
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </td>
                  <td>65</td>
                </tr>
                <tr>
                  <td>5</td>
                  <td class="pa10">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea.week5"
                      placeholder="##NAME##의 일주일 학습은 잘 진행되었나요? 내일 ##TIME## 에 방문할게요. 학습준비해서 기다려 주세요."
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </td>
                  <td>65</td>
                </tr>
              </tbody>
            </q-markup-table>
            <!-- //markup-table body rowspan -->
          </div>
        </q-tab-panel>
        <!--// 방문시간 안내 멘트 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('downer');

// 멘트
const dataTextArea = ref({
  week1: '', //1주차
  week2: '', //2주차
  week3: '', //3주차
  week4: '', //4주차
  week5: '', //5주차
});
</script>
