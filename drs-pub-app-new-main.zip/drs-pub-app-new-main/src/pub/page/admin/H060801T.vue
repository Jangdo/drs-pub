<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">컬럼 속성관리</h2>
      <Breadcrumbs />
    </div>

    <!-- 탭 영역 -->
    <div class="wrapper_tab">
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="게시판 신고유형" :ripple="false" />
        <q-tab name="tab2" label="게시판 단일 코드" :ripple="false" />
        <q-tab name="tab3" label="게시판 멀티 코드" :ripple="false" />
      </q-tabs>
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <!-- 버튼 -->
            <div class="row-2">
              <div class="row-4">
                <q-input
                  class="w380"
                  outlined
                  placeholder="검색어를 입력하세요"
                >
                </q-input>
                <q-btn
                  class="size_sm btn_reset"
                  icon=""
                  outline
                  label="초기화"
                />
                <q-btn
                  fill
                  unelevated
                  class="size_sm btn_search"
                  label="조회"
                />
              </div>
              <div class="row-6">
                <q-btn class="size_sm" outline label="폴더삭제" />
                <q-btn class="size_sm" outline label="폴더수정" />
                <q-btn
                  class="size_sm"
                  color="black"
                  unelevated
                  label="폴더등록"
                />
              </div>
            </div>
            <!-- // 버튼 -->

            <!-- tree -->
            <div class="tree_container bg_white mt15">
              <q-tree
                :nodes="tree_data"
                node-key="id"
                selected-color="primary"
                class="tree type_01 height600"
                v-model:selected="tree_selected"
                default-expand-all
                @update:selected="temp(tree_selected)"
              />
            </div>
            <!-- // tree -->
          </div>
        </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->

        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3"> tab3 </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
    </div>
    <!-- // 탭 영역 -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');
// tree
const tree_data = [
  {
    label: '게시판 멀티코드(BBS_COLUMN_CODE_M)',
    id: 'treeAll',
    icon: '',
    // avatar: '/icons/icon-tree-home.svg',
    children: [
      {
        id: 'a_1',
        label: '노드1',
        children: [
          {
            id: 'a_1_1',
            label: '하위1',
            children: [
              {
                id: 'a_1_1_2',
                label: '하위1_하위1',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_1_1_3',
                label: '하위1_하위2',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          { id: 'a_1_2', label: '하위2', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '노드2',
        id: 'a_2',
        children: [
          {
            label: '하위1',
            id: 'a_2_1',
            children: [
              { id: 'a_2_1_1', label: '하위1_하위1' },
              { id: 'a_2_1_2', label: '하위1_하위2' },
            ],
          },
          { id: 'a_2_2', label: '하위2' },
        ],
      },
      {
        label: '노드3',
        id: 'a_3',
        children: [
          { id: 'a_3_1', label: '하위1' },
          { id: 'a_3_2', label: '하위2' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('게시판 멀티코드');
</script>
