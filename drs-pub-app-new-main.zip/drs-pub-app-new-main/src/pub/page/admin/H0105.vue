<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">시스템메시지 관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class=""
              outlined
              v-model="msgName"
              placeholder="메시지명"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              outlined
              v-model="msgId"
              placeholder="메시지 ID"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="시스템유형 전체"
              v-model="searchSys"
              :options="searchSysOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="inp_search"
              outlined
              v-model="msgCategory"
              placeholder="카테고리"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
        </div>
        <div class="mt10" v-if="stateHandle">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="메시지구분 전체"
                v-model="searchMsgType"
                :options="searchMsgTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="사용여부 전체"
                v-model="searchUseSelected"
                :options="searchSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>
    <q-btn
      class="btn_search_handle"
      fill
      color="grey-5"
      unelevated
      @click="actionHandle"
    >
      <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
      <q-icon color="white" name="ion-ios-arrow-down" v-else />
    </q-btn>

    <q-card class="wrap_table_box">
      <!-- selectable_table type_01 -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm btn_delete" outline label="선택삭제" />
            <q-btn
              class="size_sm btn_save"
              color="black"
              unelevated
              label="신규등록"
            />
          </div>
        </div>
        <q-table
          :rows="msgRows"
          :columns="msgColumns"
          row-key="idx"
          v-model:selected="msg_selected"
          selection="multiple"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-th>
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :class="props.row.state" :props="props">
              <q-td class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-td>
              <q-td key="idx" class="idx">{{ props.row.idx }}</q-td>
              <q-td key="sys" class="text-center"> {{ props.row.sys }}</q-td>
              <q-td key="category" class="text-center">{{
                props.row.category
              }}</q-td>
              <q-td key="id" class="text-center"> {{ props.row.id }}</q-td>
              <q-td key="name" class="msg_name"> {{ props.row.name }}</q-td>
              <q-td key="type" class="text-center">
                <template v-if="props.row.type == '확인'">
                  <span class="text-grey-3">{{ props.row.type }}</span>
                </template>
                <template v-else>
                  <span class="text-orange">{{ props.row.type }}</span>
                </template>
                <!-- <span class="text-grey-3">확인</span> -->
                <!-- <span class="text-orange">알림</span> -->
              </q-td>
              <q-td key="allow" :props="props" class="allow">
                <q-toggle
                  v-model="props.row.allow"
                  class="custom_tgl"
                  color="black"
                />
              </q-td>
              <q-td key="btn" :props="props" class="hasbtn detail">
                <q-btn
                  outline
                  class="size_xxs btn_detail_view"
                  label="보기"
                  @click="tableEvt(props.row.idx)"
                >
                </q-btn>
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!--// selectable_table type_01-->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchSys = ref(['']);
const msgName = ref(['']);
const msgId = ref(['']);
const msgCategory = ref('');
const searchSysOption = ref([
  {
    id: 'a',
    desc: '유형 유형',
  },
  {
    id: 'b',
    desc: '시스템유형 ',
  },
]);
const searchUseSelected = ref(['']);
const searchSelectOption = ref([
  {
    id: 'Y',
    desc: '사용',
  },
  {
    id: 'N',
    desc: '사용안함 ',
  },
]);
const searchMsgType = ref(['']);
const searchMsgTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

// msg_dialog
const msg_dialog = ref({
  open: false,
  id: 0,
});

//msg_table데이터
const msg_selected = ref([]);

const msgColumns = ref([
  {
    name: 'idx',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'sys',
    label: '시스템유형',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'category',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'id',
    label: '메시지 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },
  {
    name: 'name',
    label: '메시지 명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'type',
    label: '구분',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    category: '권한정보',
    id: 'MSG_C0000',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '확인',
    allow: false,
  },
  {
    idx: '2',
    category: '결제관련',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '3',
    category: '결제관련',
    id: 'MSG_C0002',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '확인',
    allow: false,
  },
  {
    idx: '4',
    category: '권한정보',
    id: 'MSG_C0003',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    type: '확인',
    sys: '눈높이',
    allow: false,
  },
  {
    idx: '5',
    category: '권한정보',
    id: 'MSG_C0004',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    type: '확인',
    sys: '눈높이',
    allow: false,
  },
  {
    idx: '6',
    category: '권한정보',
    id: 'MSG_C0005',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    type: '확인',
    sys: '눈높이',
    allow: true,
  },
  {
    idx: '7',
    category: '권한정보',
    id: 'MSG_C0006',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '8',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '9',
    category: '권한정보',
    id: 'MSG_C0007',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '10',
    category: '권한정보',
    id: 'MSG_C0008',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '11',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
  {
    idx: '12',
    category: '권한정보',
    id: 'MSG_C0009',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    sys: '눈높이',
    type: '알림',
    allow: false,
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

//tableEvt 테이블 상세보기 버튼 클릭
function tableEvt(id) {
  console.log('테이블  id :' + id + '상세보기');
  msg_dialog.value.idx = id;
  msg_dialog.value.open = true;
}
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
