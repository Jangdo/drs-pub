<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <!-- 팝업 제목 영역 -->
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">팝업게시물 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 영역 -->
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-input
                    outlined
                    :model-value="searchDate"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate"
                            @update:model-value="
                              searchDate, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    label="게시판 전체"
                    v-model="search1"
                    :options="search1Option"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input class="" for="" outlined dense placeholder="제목">
                  </q-input>
                </div>
                <div class="col-12 col-md-3">
                  <q-input class="" for="" outlined dense placeholder="등록자">
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!-- selectable_table type_01 -->
          <div class="table_dk">
            <q-table
              :rows="authorityRows"
              row-key="idx"
              v-model:selected="authoritySelected"
              selection="single"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header="props">
                <q-tr :props="props">
                  <q-th class="select">선택</q-th>
                  <q-th class="">게시판명</q-th>
                  <q-th class="w400">제목</q-th>
                  <q-th class="">등록자</q-th>
                  <q-th class="">등록일</q-th>
                </q-tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td class="select">
                    <q-checkbox
                      v-model="props.selected"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                      color="black"
                    />
                  </q-td>
                  <q-td class="text-center">{{ props.row.nameBoard }}</q-td>
                  <q-td class="text-left">{{ props.row.name }}</q-td>
                  <q-td class="text-center">{{ props.row.author }}</q-td>
                  <q-td class="text-center">{{ props.row.date }}</q-td>
                </q-tr>
              </template>
            </q-table>

            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
          <!--// selectable_table type_01-->
        </q-card-section>

        <!-- 버튼 -->
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const search1 = ref(['게시판 전체']);
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const searchDate = ref('2019.02.01');
//table데이터
const authoritySelected = ref([
  {
    idx: '2',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
]);

const authorityRows = ref([
  {
    idx: '1',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '2',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '3',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '4',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '5',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '6',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },

  {
    idx: '6',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '7',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '8',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '9',
    nameBoard: '공지사항',
    name: '휴가 기간 연장안',
    author: '홍길동',
    date: '2022.11.01',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
