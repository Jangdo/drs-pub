<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">테이블 관리</h2>
      <Breadcrumbs />
    </div>

    <q-card class="wrap_table_box">
      <table class="table_row_sales">
        <tbody>
          <tr>
            <th><b class="essential">테이블명(물리)</b></th>
            <td>TBBS1_WKNDPARKINGAPPLY</td>
          </tr>
          <tr>
            <th><b class="essential">테이블명(논리)</b></th>
            <td>주말주차신청</td>
          </tr>
        </tbody>
      </table>

      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" color="" outline label="추가" />
          </div>
        </div>
        <q-table
          class="scrollable sticky_table_header"
          :rows="dataRows"
          :columns="dataColumns"
          row-key="idx"
          v-model:selected="dataSlected"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th key="tdata1"
                >테이블 컬럼명 <span class="text-orange">*</span></q-th
              >
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="tdata1" class="text-left">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="text-left">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="text-right">
                {{ props.row.tdata3 }}
              </q-td>
              <q-td key="tdata4" class="text-left">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="tdata5" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c1" label="" color="black" />
              </q-td>
              <q-td key="tdata6" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c2" label="" color="black" />
              </q-td>
              <q-td key="tdata7" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c3" label="" color="black" />
              </q-td>
              <q-td key="tdata8" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c4" label="" color="black" />
              </q-td>
              <q-td key="tdata9" class="w60 text-center">
                <q-checkbox v-model="dataCheck.c5" label="" color="black" />
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>

      <!-- 버튼 -->
      <div class="btn_area response mt50 justify-end">
        <q-btn unelevated color="grey-2" class="size_lg" label="목록" />
      </div>
      <!-- // 버튼 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

//data테이블
const dataSlected = ref([]);
const dataCheck = ref({
  c1: true,
  c2: false,
  c3: false,
  c4: true,
  c5: false,
});
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const dataColumns = ref([
  {
    name: 'tdata2',
    label: '항목명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '컬럼길이',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '컬럼속성',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '필수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '목록',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '등록',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '수정',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '조회',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
]);
const dataRows = ref([
  {
    idx: 12,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 11,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '1',
    tdata4: '텍스트 텍스트',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 10,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 9,
    tdata1: 'STATUS111',
    tdata2: '항목명',
    tdata3: '132',
    tdata4: '텍스트 텍스트 텍스트 텍스트 텍스트 텍스트 텍스트 텍스트',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 8,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '2',
    tdata4: '텍스트',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 7,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 6,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 5,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 4,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 3,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 2,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
  {
    idx: 1,
    tdata1: 'STATUS',
    tdata2: '상태',
    tdata3: '32',
    tdata4: '텍스트 텍스트 (한줄 한줄)',
    tdata5: '',
    tdata6: '',
    tdata7: '',
    tdata8: '',
    tdata9: '',
  },
]);
</script>
<style lang="scss" scoped>
.justify-end {
  justify-content: flex-end !important;
}
</style>
