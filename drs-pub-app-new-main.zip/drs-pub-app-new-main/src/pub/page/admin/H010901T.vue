<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">일정관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
        keep-alive="true"
        animated
      >
        <q-tab name="calendar" label="캘린더" :ripple="false" />
        <q-tab name="schedule" label="반복일정" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 캘린더 tab 컨텐츠 -->
        <q-tab-panel name="calendar" keep-alive="true">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-select
                    label="모듈유형 선택"
                    v-model="moduleSelect"
                    :options="moduleSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    label="일정구분 선택"
                    v-model="scheduleSelect"
                    :options="scheduleSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    for=""
                    outlined
                    dense
                    v-model="nameSearch"
                    placeholder="제목"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!-- wrap_divide_schedule_table -->
          <div class="wrap_divide_schedule_table wrap_table_box">
            <div class="schedule_table">
              <div class="btn_area">
                <q-btn
                  flat
                  @click="fullCalandar.getApi().prev()"
                  icon="ion-ios-arrow-back"
                  class="prev"
                  ><span class="a11y">이전</span>
                </q-btn>
                <q-btn
                  flat
                  icon-right="ion-ios-arrow-down"
                  :label="date.year"
                  class="year"
                ></q-btn>
                <q-btn
                  flat
                  icon-right="ion-ios-arrow-down"
                  :label="date.month"
                  class="month"
                ></q-btn>
                <q-btn
                  flat
                  @click="fullCalandar.getApi().next()"
                  icon="ion-ios-arrow-forward"
                  class="next"
                  ><span class="a11y">다음</span></q-btn
                >
              </div>
              <FullCalendar ref="fullCalandar" :options="calendarOptions" />
            </div>

            <div class="table_dk" style="width: 50%; margin-top: 6px">
              <div class="table_top">
                <div class="btn_wrap col-12 gap10">
                  <q-btn class="size_sm" outline label="일정등록" />
                </div>
              </div>
              <q-table
                dense
                hide-pagination
                :rows="rows"
                :columns="columns"
                row-key="rowIndex"
                separator="cell"
              />
            </div>
            <!--// wrap_divide_schedule_table -->
          </div>
        </q-tab-panel>
        <!--// 캘린더 tab 컨텐츠 -->

        <!-- 반복일정 tab 컨텐츠 -->
        <q-tab-panel name="schedule">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m"
                    label="년도를 선택하세요"
                    v-model="searchYearSelect"
                    :options="searchYearSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[searchYearSelectOption == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m"
                    label="모듈을 선택하세요"
                    v-model="moduleSelect2"
                    :options="moduleSelect2Option"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[moduleSelect2 == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m"
                    v-model="scheduleSelect2"
                    :options="scheduleSelect2Option"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    label="일정구분을 선택하세요"
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[scheduleSelect2 == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    v-model="searchWord2"
                    placeholder="검색어를 입력하세요."
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="wrap_table_box">
            <div class="table_dk">
              <q-table
                :rows="scheduleRows"
                :columns="scheduleColumns"
                row-key="startDate"
                v-model:pagination="dataPagination"
                hide-bottom
                hide-pagination
                separator="cell"
              >
              </q-table>
            </div>
            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
        </q-tab-panel>
        <!--// 반복일정 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import FullCalendar from '@fullcalendar/vue3';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('calendar');
// tab
// setTimeout(() => {
//   tab.value = 'calendar';
// }, 100);
// const tab = ref('schedule');
// tab calendar
//캘린더 데이터
// table_search_area
const moduleSelect = ref('');
const moduleSelectOption = ref([
  // {
  //   id: '',
  //   desc: '모듈 유형을 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: 'N',
    desc: '모듈 유형 눈높이(N)',
  },
  {
    id: 'G',
    desc: '모듈 유형 학원(G)',
  },
  {
    id: 'C',
    desc: '모듈 유형 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '모듈 유형(M)',
  },
]);
const scheduleSelect = ref('');
const scheduleSelectOption = ref([
  // {
  //   id: '',
  //   desc: '일정구분을 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: 'N',
    desc: '일정구분 눈높이(N)',
  },
  {
    id: 'G',
    desc: '일정구분 학원(G)',
  },
  {
    id: 'C',
    desc: '일정구분 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '일정구분 (M)',
  },
]);
const nameSearch = ref('');

// fullCalandar
const fullCalandar = ref(null);
const date = ref({
  year: '2023',
  month: '03',
  day: '02',
});
const calendarOptions = ref({
  initialDate: date.value.year + '-' + date.value.month,
  editable: false,
  selectable: true,
  plugins: [dayGridPlugin, interactionPlugin, timeGridPlugin],
  locale: 'ko',
  height: 'auto',

  dateClick: handleDateClick,
  eventClick: handleEvtClick,
  headerToolbar: {
    left: '',
    center: '',
    right: '',
  },
  buttonText: {
    today: '오늘',
    month: 'month',
    week: 'week',
    day: 'day',
    list: 'list',
  },
  select: handleSelect,
  weekends: true,
  dayMaxEventRows: 3,
  events: [
    {
      title: '샘플일정1',
      start: '2023-03-07',
    },
    {
      title: '샘플일정2',
      start: '2023-03-08',
    },
    {
      title: '샘플일정3',
      start: '2023-03-14',
    },
  ],
});

function handleDateClick(info) {
  alert('dateaad click! ' + info.startStr + ' to ' + info.endStr, 'aaaa');
}
function handleSelect(info) {
  alert('selected ' + info.startStr + ' to ' + info.endStr, 'aaaa');
}
function handleEvtClick(info) {
  var eventObj = info.event;
  alert('Clicked ' + eventObj.title);
}

const columns = ref([
  {
    field: 'date',
    label: '일자',
    sortable: false,
    align: 'center',
  },
  {
    field: 'time',
    label: '시간',
    sortable: false,
    align: 'center',
  },
  {
    field: 'module',
    label: '모듈/일정구분',
    sortable: false,
    align: 'center',
  },
  {
    field: 'name',
    align: 'center',
    label: '제목',
    sortable: false,
    align: 'center',
  },
]);
const rows = ref([
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
  {
    date: '2022.12.05',
    time: '오후 3:00',
    module: '공통/배치작업',
    name: '법정공휴일',
  },
]);

// tab downer

// table_search_area
const searchYearSelect = ref('');
const searchYearSelectOption = ref([
  // {
  //   id: '',
  //   desc: '년도를 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: '2023',
    desc: '2023',
  },
  {
    id: '2024',
    desc: '2024',
  },
  {
    id: '2025',
    desc: '2025',
  },
]);
const moduleSelect2 = ref('');
const moduleSelect2Option = ref([
  // {
  //   id: '',
  //   desc: '모듈을 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: 'N',
    desc: '모듈 눈높이(N)',
  },
  {
    id: 'G',
    desc: '모듈 학원(G)',
  },
  {
    id: 'C',
    desc: '모듈 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '모듈 MOS(M)',
  },
]);
const scheduleSelect2 = ref('');
const scheduleSelect2Option = ref([
  // {
  //   id: '',
  //   desc: '일정구분을 선택하세요',
  //   // disable 옵션 샘플
  //   inactive: true,
  // },
  {
    id: 'N',
    desc: '일정구분 눈높이(N)',
  },
  {
    id: 'G',
    desc: '일정구분 학원(G)',
  },
  {
    id: 'C',
    desc: '일정구분 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '일정구분 MOS(M)',
  },
]);
const searchWord2 = ref('');

//하위코드 edit_ table데이터

const scheduleColumns = ref([
  {
    field: 'startDate',
    label: '시작일자',
    sortable: false,
    align: 'center',
  },
  {
    field: 'endDate',
    label: '종료일자',
    sortable: false,
    align: 'center',
  },
  {
    field: 'time',
    label: '시간',
    field: 'name',
    sortable: false,
    align: 'center',
  },
  {
    field: 'repeat',
    label: '반복',
    sortable: false,
    align: 'center',
  },
  {
    field: 'module',
    label: '모듈',
    sortable: false,
    align: 'center',
  },
  {
    field: 'scheduleSection',
    label: '일정구분',
    align: 'center',
    sortable: false,
  },
  {
    field: 'name',
    label: '제목',
    align: 'center',
    sortable: false,
  },
]);
const scheduleRows = ref([
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '없음',
    time: '하루종일',
    repeat: '매일',
    module: '공휴일',
    scheduleSection: '-',
    name: '1월 시스템 배치작업',
  },
  {
    startDate: '2023.01.01',
    endDate: '2023.01.14',
    time: '오후 3:00',
    repeat: '매달',
    module: '공통',
    scheduleSection: '배치작업',
    name: '1월 시스템 배치작업',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
