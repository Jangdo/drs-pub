<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">공통코드관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="upper" label="상위코드" :ripple="false" />
        <q-tab name="downer" label="하위코드" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- 상위코드 tab 컨텐츠 -->
        <q-tab-panel name="upper">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m"
                    v-model="sysSelect"
                    :options="sysSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[sysSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[dataSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="코드 or 코드명을 입력하세요"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="wrap_table_box">
            <!-- editable_table -->
            <div class="editable_table type_01">
              <div class="btn_area">
                <q-space />
                <q-btn
                  class="size_sm btn_delete"
                  color="grey-7"
                  icon=""
                  outline
                  label="선택삭제"
                />
                <q-btn
                  class="size_sm btn_row_add"
                  icon=""
                  outline
                  label="행추가"
                />
                <!-- <q-btn class="size_sm btn_cancel" unelevated label="취소" /> -->
                <q-btn class="size_sm btn_save" unelevated label="저장" />
              </div>
              <q-table
                :rows="rows"
                :columns="columns"
                row-key="code"
                v-model:selected="selected"
                selection="multiple"
                v-model:pagination="pagination"
                hide-pagination
                separator="cell"
              >
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td class="select">
                      <template v-if="props.row.state == 'add'">
                        <q-btn
                          icon="ion-ios-close"
                          dense
                          flat
                          class="btn_close"
                          size="36px"
                        />
                      </template>
                      <template v-else>
                        <q-checkbox v-model="props.selected" color="black" />
                      </template>
                    </q-td>
                    <q-td key="systemSelect" class="type">
                      <template v-if="props.row.state == 'add'">
                        <q-select
                          class="box_m"
                          v-model="props.row.systemSelect"
                          :options="SystemSelectionOption"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          :class="[dataSelect == 0 ? 'placehoder' : '']"
                        >
                        </q-select>
                      </template>
                      <template v-else>
                        {{ props.row.systemSelect }}
                        <q-popup-edit
                          v-model="props.row.systemSelect"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-select
                            class="box_m"
                            v-model="scope.value"
                            autofocus
                            :options="SystemSelectionOption"
                            option-value="desc"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                            :class="[dataSelect == 0 ? 'placehoder' : '']"
                          >
                          </q-select>
                        </q-popup-edit>
                      </template>
                    </q-td>
                    <q-td key="upperCodeSelect" class="code_type">
                      <template v-if="props.row.state == 'add'">
                        <q-select
                          class="box_m"
                          v-model="props.row.upperCodeSelect"
                          :options="UppercodeSelectionOption"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          :class="[dataSelect == 0 ? 'placehoder' : '']"
                        >
                        </q-select>
                      </template>
                      <template v-else>
                        {{ props.row.upperCodeSelect }}
                        <!-- 0217 수정요청 <q-popup-edit
                          v-model="props.row.upperCodeSelect"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-select
                            class="box_m"
                            v-model="scope.value"
                            autofocus
                            :options="UppercodeSelectionOption"
                            option-value="desc"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                            :class="[dataSelect == 0 ? 'placehoder' : '']"
                          >
                          </q-select>
                        </q-popup-edit> -->
                      </template>
                    </q-td>
                    <q-td key="code" class="code">
                      <template v-if="props.row.state == 'add'">
                        <q-input
                          outlined
                          v-model="props.row.code"
                          :error="props.row.code.sample_err"
                          placeholder="코드 입력"
                          dense
                        >
                          <!-- <template v-slot:error>
                          동일한 이름이 있습니다.
                        </template> -->
                        </q-input>
                      </template>
                      <template v-else>
                        {{ props.row.code }}
                        <!-- 0217 수정요청 -->
                        <!-- <q-popup-edit
                          v-model="props.row.code"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-input v-model="scope.value" dense autofocus />
                        </q-popup-edit> -->
                      </template>
                    </q-td>
                    <q-td key="name" class="code_name">
                      <template v-if="props.row.state == 'add'">
                        <q-input
                          outlined
                          v-model="props.row.name"
                          :error="props.row.name.sample_err"
                          placeholder="코드명 입력"
                          dense
                        >
                          <!-- <template v-slot:error>
                          동일한 이름이 있습니다.
                        </template> -->
                        </q-input>
                      </template>
                      <template v-else>
                        {{ props.row.name }}
                        <q-popup-edit
                          v-model="props.row.name"
                          buttons
                          label-set="확인"
                          label-cancel="취소"
                          v-slot="scope"
                        >
                          <q-input v-model="scope.value" dense autofocus />
                        </q-popup-edit>
                      </template>
                    </q-td>
                    <q-td key="state" class="state">
                      <template v-if="props.row.state == 'edit'">
                        <q-icon name="done"></q-icon>
                        {{ tdState(props.row.state) }}
                      </template>
                      <template v-else>
                        {{ tdState(props.row.state) }}
                      </template>
                    </q-td>
                    <q-td key="allow" :props="props" class="allow">
                      <q-toggle
                        v-model="props.row.allow"
                        false-value="N"
                        true-value="Y"
                        color="black"
                      />
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <!--// editable_table -->
          </div>
        </q-tab-panel>
        <!--// 상위코드 tab 컨텐츠 -->
        <!-- 하위코드 tab 컨텐츠 -->
        <q-tab-panel name="downer">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m"
                    v-model="sysSelect"
                    :options="sysSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[sysSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-select
                    class="box_m"
                    v-model="dataSelect"
                    :options="dataSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[dataSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="코드 or 코드명을 입력하세요"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!-- wrap_table_divide -->
          <div class="wrap_table_divide wrap_table_box">
            <div class="col_left">
              <!-- 상위코드 선택 table -->
              <div class="error_msg">
                <p class="title">상위코드를 먼저 선택해 주세요</p>
              </div>
              <div class="downer_table_left">
                <q-table
                  :rows="upper_choice_rows"
                  :columns="upper_choice_columns"
                  row-key="code"
                  v-model:pagination="upper_choice_pagination"
                  hide-pagination
                  separator="cell"
                  class="scrollable"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="systemSelect" class="text-center">
                        {{ props.row.systemSelect }}
                      </q-td>
                      <q-td key="upperCodeSelect" class="text-center">
                        {{ props.row.upperCodeSelect }}
                      </q-td>
                      <q-td key="code" class="code">
                        {{ props.row.code }}
                      </q-td>
                      <q-td key="name" class="code_name">
                        {{ props.row.name }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 상위코드 선택 table -->
            </div>
            <div class="col_right">
              <!-- 하위코드 editable_table -->
              <div class="editable_table type_01 downer_table_right">
                <div class="btn_area">
                  <q-btn
                    class="size_sm btn_row_up"
                    icon="keyboard_arrow_up"
                    outline
                    label=""
                  />
                  <q-btn
                    class="size_sm btn_row_down"
                    color="grey-7"
                    icon="keyboard_arrow_down"
                    outline
                    label=""
                  />
                  <q-space />
                  <q-btn
                    class="size_sm btn_delete"
                    color="grey-7"
                    icon=""
                    outline
                    label="선택삭제"
                  />
                  <q-btn
                    class="size_sm btn_row_add"
                    icon=""
                    outline
                    label="행추가"
                  />
                  <!-- <q-btn class="size_sm btn_cancel" unelevated label="취소" /> -->
                  <q-btn class="size_sm btn_save" unelevated label="저장" />
                </div>
                <q-table
                  :rows="downer_rows"
                  :columns="downer_columns"
                  row-key="code"
                  v-model:selected="downer_selected"
                  selection="multiple"
                  v-model:pagination="downer_pagination"
                  hide-pagination
                  separator="cell"
                  class="scrollable"
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td class="select">
                        <template v-if="props.row.state == 'add'">
                          <q-btn
                            icon="ion-ios-close"
                            flat
                            label=""
                            size="36px"
                          />
                        </template>
                        <template v-else>
                          <q-checkbox v-model="props.selected" color="black" />
                        </template>
                      </q-td>
                      <q-td key="code" class="code">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.code"
                            :error="props.row.code.sample_err"
                            dense
                            placeholder="코드 입력"
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.code }}
                          <q-popup-edit
                            v-model="props.row.code"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" dense autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="name" class="code_name">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.name"
                            :error="props.row.name.sample_err"
                            dense
                            placeholder="코드명 입력"
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.name }}
                          <q-popup-edit
                            v-model="props.row.name"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" dense autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="idx" class="index">
                        <template v-if="props.row.state == 'add'">
                          <q-input
                            outlined
                            v-model="props.row.idx"
                            :error="props.row.idx.sample_err"
                            dense
                          >
                            <!-- <template v-slot:error>
                        동일한 이름이 있습니다.
                      </template> -->
                          </q-input>
                        </template>
                        <template v-else>
                          {{ props.row.idx }}
                          <q-popup-edit
                            v-model="props.row.idx"
                            buttons
                            label-set="확인"
                            label-cancel="취소"
                            v-slot="scope"
                          >
                            <q-input v-model="scope.value" dense autofocus />
                          </q-popup-edit>
                        </template>
                      </q-td>
                      <q-td key="state" class="state">
                        <template v-if="props.row.state == 'edit'">
                          <q-icon name="done"></q-icon>
                          {{ tdState(props.row.state) }}
                        </template>
                        <template v-else>
                          {{ tdState(props.row.state) }}
                        </template>
                      </q-td>
                      <q-td key="allow" :props="props" class="allow">
                        <q-toggle
                          v-model="props.row.allow"
                          false-value="N"
                          true-value="Y"
                          color="black"
                        />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// 하위코드 editable_table -->
            </div>
          </div>
        </q-tab-panel>
        <!--// 하위코드 tab 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('upper');
// const tab = ref('downer');
// tab upper
//상위코드 edit_table데이터
// table_search_area
const sysSelect = ref('');
const sysSelectOption = ref([
  {
    id: '',
    desc: '시스템 유형을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const dataSelect = ref('');
const dataSelectOption = ref([
  {
    id: '',
    desc: '코드 유형을 선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const keyword = ref('');
const selected = ref([]);
const columns = ref([
  {
    name: 'systemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const rows = ref([
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: 'edit',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },

  //
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_11',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_12',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_13',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_14',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_15',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_16',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
]);
const SystemSelectionOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '시스템 눈높이(N)',
  },
  {
    id: 'G',
    desc: '시스템 학원(G)',
  },
  {
    id: 'C',
    desc: '시스템 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '시스템 MOS(M)',
  },
]);
const UppercodeSelectionOption = ref([
  {
    id: '',
    desc: '선택하세요',
    // disable 옵션 샘플
    inactive: true,
  },
  {
    id: 'N',
    desc: '상위 눈높이(N)',
  },
  {
    id: 'G',
    desc: '상위 학원(G)',
  },
  {
    id: 'C',
    desc: '상위 공통코드(C) ',
  },
  {
    id: 'M',
    desc: '상위 MOS(M)',
  },
]);
const pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

// tab downer

//하위코드 edit_ table데이터

const downer_selected = ref([]);
const downer_columns = ref([
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'idx',
    label: '순서',
    field: 'idx',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'state',
    label: '상태',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
]);
const downer_rows = ref([
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_01',
    name: 'name_SALE_001',
    idx: '',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_02',
    name: 'name_SALE_001',
    idx: '',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_03',
    name: 'name_SALE_001',
    idx: '',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_04',
    name: 'name_SALE_001',
    idx: '',
    state: 'add',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_05',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_06',
    name: 'name_SALE_001',
    idx: '',
    state: 'edit',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_07',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_08',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_09',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_10',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_11',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_12',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_13',
    name: 'name_SALE_001',
    idx: '',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_14',
    name: 'name_SALE_001',
    idx: '14',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_15',
    name: 'name_SALE_001',
    idx: '15',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_16',
    name: 'name_SALE_001',
    idx: '16',
    state: '',
    allow: 'N',
  },
]);
const downer_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

//상위코드 선택 table 데이터
const upper_choice_columns = ref([
  {
    name: 'systemSelect',
    label: '시스템 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'upperCodeSelect',
    label: '상위코드 유형',
    sortable: false,
    align: 'center',
  },
  {
    name: 'code',
    label: '코드',
    sortable: false,
    align: 'center',
  },
  {
    name: 'name',
    align: 'center',
    label: '코드명',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.name,
  },
]);
const upper_choice_rows = ref([
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_01',
    name: 'name_SALE_001',
    state: '',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_02',
    name: 'name_SALE_001',
    state: '',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_03',
    name: 'name_SALE_001',
    state: '',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_04',
    name: 'name_SALE_001',
    state: 'edit',
    allow: 'Y',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_05',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_06',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_07',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_08',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_09',
    name: 'name_SALE_001',
    state: '',
    allow: 'N',
  },
  {
    systemSelect: '시스템 SALE_01',
    upperCodeSelect: '상위 SALE_01',
    code: 'SALE_10',
    name: 'name_SALE_001',
    state: 'add',
    allow: 'N',
  },
]);
const upper_choice_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});

// td 상태값
function tdState(priority) {
  switch (priority) {
    case 'add':
      return '신규';
    case 'edit':
      return '수정중';
    default:
      return '';
  }
}
</script>
