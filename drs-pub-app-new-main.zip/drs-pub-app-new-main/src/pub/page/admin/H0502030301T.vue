<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">{{ $route.name }}</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb40"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
        <q-tab name="tab3" label="화면구성" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">
          <div class="wrap_table_box">
            <table class="table_row_admin">
              <colgroup>
                <col width="168px" />
                <col width="auto" />
                <col width="168px" />
                <col width="auto" />
              </colgroup>
              <tbody>
                <tr>
                  <th>
                    <span class="required">게시판명</span>
                  </th>
                  <td colspan="3">
                    <div class="">
                      <q-input
                        class="inp_search"
                        outlined
                        placeholder="게시판명을 입력하세요"
                      >
                        <!-- <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template> -->
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">게시판 설명</span>
                  </th>
                  <td colspan="3">
                    <div class="">
                      <q-input
                        class="box_xl inp_search"
                        outlined
                        placeholder="게시판설명을 입력하세요"
                        type="textarea"
                      ></q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">게시판 타이틀</span>
                  </th>
                  <td>
                    <!-- 드롭다운 -->
                    <div class="">
                      <q-select
                        class="hide_label"
                        label="선택하세요"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <!-- // 드롭다운 -->
                  </td>
                  <th class="line_l">
                    <span class="required">타이틀 형태</span>
                  </th>
                  <td>
                    <!-- 드롭다운 -->
                    <div class="">
                      <q-select
                        class="hide_label"
                        label="선택하세요"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <!-- // 드롭다운 -->
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">게시판 테이블</span>
                  </th>
                  <td>
                    <div class="">
                      <q-select
                        class=""
                        v-model="searchOrzType"
                        :options="searchOrzTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">권한 지정</span>
                  </th>
                  <td>
                    <div class="">
                      <q-btn
                        class="size_sm"
                        label="권한설정"
                        color="grey-2"
                        fill
                        unelevated
                      ></q-btn>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">게시물카테고리</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">권한 지정</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">게시판 유형</span>
                  </th>
                  <td>
                    <div class="">
                      <q-select
                        class="hide_label"
                        label="선택하세요"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">단답형게시판여부</span>
                  </th>
                  <td>
                    <div class="">
                      <q-select
                        class="hide_label"
                        label="선택하세요"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">변경이력관리사용</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="관리안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="관리"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">비인증게시판지정</span>
                  </th>
                  <td>
                    <div class="">
                      <q-select
                        class="hide_label"
                        label="선택하세요"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">변경이력관리사용</span>
                  </th>
                  <td colspan="3">
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="지정안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="지정"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                    <div class="mt10">
                      <q-btn
                        class="size_sm"
                        label="권한설정"
                        color="grey-2"
                        fill
                        unelevated
                      ></q-btn>
                    </div>
                    <div class="mt20">
                      <div class="tree_container">
                        <q-tree
                          :nodes="tree_data"
                          node-key="id"
                          selected-color="beige-3"
                          class="category type_tbl"
                          v-model:selected="tree_selected"
                          default-expand-all
                          @update:selected="temp(tree_selected)"
                        />
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">보관기한설정여부</span>
                  </th>
                  <td>
                    <div class="row">
                      <q-select
                        class="w280 hide_label"
                        label="영구보관"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                      <q-select
                        class="hide_label"
                        label="1"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                        <template v-slot:after> 개월 </template>
                      </q-select>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">신규게시물표시</span>
                  </th>
                  <td>
                    <div class="row">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-input class="inp_w100" outlined placeholder="0">
                        <template v-slot:after> 일 이내 표기 </template>
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">첨부사이즈제한</span>
                  </th>
                  <td colspan="3">
                    <div class="row">
                      <q-select
                        class="w280 hide_label"
                        label="기본값 사용"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                      <q-input class="w280" dense outlined placeholder="1">
                        <template v-slot:after> byte </template>
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">첨부 확장자 제한 (blaklist)</span>
                  </th>
                  <td colspan="3">
                    <div class="row">
                      <q-select
                        class="w280 hide_label"
                        label="기본값 사용"
                        v-model="searchBrandType"
                        :options="searchBrandTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                      <q-input
                        class="w280"
                        dense
                        outlined
                        placeholder="bat, exe, cat"
                      >
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">금칙어여부</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">이전/다음</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">말머리사용</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                    <div class="row">
                      <q-checkbox
                        v-model="dataCheck.subject"
                        label="제목"
                        color="black"
                      />
                      <q-checkbox
                        v-model="dataCheck.comment"
                        label="덧글"
                        color="black"
                      />
                      <q-input class="w280" dense outlined placeholder="1">
                        <template v-slot:after>
                          <q-btn
                            class="size_sm"
                            label="선택"
                            color="grey-2"
                            fill
                            unelevated
                          ></q-btn>
                        </template>
                      </q-input>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">붐업여부</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                    <div class="row">
                      <span class="inp_label">추천수</span>
                      <q-input class="inp_w100" dense outlined placeholder="0">
                      </q-input>
                      <span class="inp_label">조회수</span>
                      <q-input class="inp_w100" dense outlined placeholder="0">
                        <template v-slot:after> (두 조건 만족) </template>
                      </q-input>
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">덧글사용</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">찬반여부</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">목록게시물수</span>
                  </th>
                  <td>
                    <div class="">
                      <q-input class="inp_w280" dense outlined placeholder="20">
                      </q-input>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">신고가능여부</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">목록검색기간</span>
                  </th>
                  <td>
                    <div class="row">
                      <q-input class="inp_w280" dense outlined placeholder="5">
                        <template v-slot:after> (일) </template>
                      </q-input>
                    </div>
                  </td>
                  <th class="line_l">
                    <span class="required">태그기능</span>
                  </th>
                  <td>
                    <div class="">
                      <q-radio
                        v-model="dataRadio"
                        val="N"
                        label="사용안함"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        val="Y"
                        label="사용"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </td>
                </tr>
                <tr>
                  <th>
                    <span class="required">내 게시물만 보기</span>
                  </th>
                  <td colspan="3">
                    <div class="row">
                      <q-checkbox
                        v-model="dataCheck.myonly"
                        label=""
                        color="black"
                      />
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            <div class="btn_area btn_bottom_type01">
              <q-btn
                unelevated
                outline
                color="grey-4"
                class="size_lg"
                label="취소"
              />
              <q-btn unelevated color="black" class="size_lg" label="저장" />
            </div>
          </div>
        </q-tab-panel>
        <!--// tab1 컨텐츠 -->
        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->
        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3"> tab3 </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab1');

const searchBrandType = ref(['']);
const searchBrandTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const searchOrzType = ref(['']);
const searchOrzTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const dataRadio = ref('N');

// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
  },
  {
    label: '메시지 카테고리',
    id: 'a_2',
  },
  {
    label: '메시지 카테고리',
    id: 'a_3',
  },
  {
    label: '메시지 카테고리',
    id: 'a_4',
  },
  {
    label: '메시지 카테고리',
    id: 'a_1',
  },
  {
    label: '메시지 카테고리',
    id: 'a_2',
  },
  {
    label: '메시지 카테고리',
    id: 'a_3',
  },
  {
    label: '메시지 카테고리',
    id: 'a_4',
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('메시지 카테고리');

const dataCheck = ref({
  subject: true,
  comment: false,
  myonly: false,
});
</script>
