<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자 정보</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">로그인 ID</span>
                  <q-input
                    class="as_dd hide_label"
                    label="로그인 ID"
                    outlined
                    placeholder="로그인 ID를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>로그인 ID</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt required">이름</span>
                  <q-input
                    class="as_dd hide_label"
                    label="이름"
                    outlined
                    placeholder="이름을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>이름</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">권한그룹</span>
                  <q-select
                    class="as_dd hide_label"
                    label="선택하세요"
                    v-model="authorityGroupSelect"
                    :options="authorityGroupSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[authorityGroupSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
                <div class="form_item">
                  <span class="as_dt required">입금구분</span>
                  <q-select
                    class="as_dd hide_label"
                    label="선택하세요"
                    v-model="pathSelect"
                    :options="pathSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                    :class="[pathSelect == 0 ? 'placehoder' : '']"
                  >
                  </q-select>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">본부</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        /> </template
                    ></q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">조직</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">채널</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt required">팀</span>
                  <div class="as_dd search_item">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-search"
                          class="icon_svg"
                          flat
                          :ripple="false"
                          @click="test"
                        />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">52 시작시간</span>
                  <q-input
                    class="as_dd hide_label"
                    label="52 시작시간"
                    outlined
                    placeholder="52 시작시간를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>52 시작시간</template>
                  </q-input>
                </div>
                <div class="form_item">
                  <span class="as_dt">52 종료시간</span>
                  <q-input
                    class="as_dd hide_label"
                    label="52 종료시간"
                    outlined
                    placeholder="52 종료시간을 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>52 종료시간 *</template>
                  </q-input>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">사용여부</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="사용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="사용안함"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
                <div class="form_item">
                  <span class="as_dt">패스워드</span>
                  <q-btn
                    outline
                    color="grey-2"
                    class="size_xs btn_inner_table"
                    label="패스워드 초기화"
                  />
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">배포앱 버전</span>
                  <span class="as_dd">3.8.1</span>
                </div>
                <div class="form_item">
                  <span class="as_dt">콘텐츠 버전</span>
                  <span class="as_dd">3.8.1</span>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">단말고유키</span>
                  <div class="as_dd row al_center">
                    <span class="mr10">6123434dfa546g43645t1</span>
                    <q-btn
                      outline
                      color="grey-2"
                      class="size_xs btn_inner_table"
                      label="초기화"
                    />
                  </div>
                </div>
              </div>
            </li>

            <li class="hastextarea">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">비고</span>
                  <div class="as_dd wrap_counsel_form">
                    <div class="wrap_textarea mt15 mb15">
                      <q-input
                        class="basic text-phara1 medium"
                        outlined
                        v-model="dataTextArea"
                        placeholder="입력하세요"
                        type="textarea"
                      >
                        <template v-slot:label>메시지 내용</template>
                      </q-input>
                      <div class="check_val">
                        <span>0</span>/<span>1,000</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            class="size_lg"
            color="black"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 140px;
      flex-shrink: 0;
    }
    //
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const authorityGroupSelect = ref(['']);
const authorityGroupSelectOption = ref([
  {
    id: 'N',
    desc: '권한(N)',
  },
  {
    id: 'G',
    desc: '권한(G)',
  },
  {
    id: 'C',
    desc: '권한(C) ',
  },
  {
    id: 'M',
    desc: '권한(M)',
  },
]);
const pathSelect = ref(['']);
const pathSelectOption = ref([
  {
    id: 'N',
    desc: '사이트(N)',
  },
  {
    id: 'G',
    desc: '사이트(G)',
  },
  {
    id: 'C',
    desc: '사이트(C) ',
  },
  {
    id: 'M',
    desc: '사이트(M)',
  },
]);

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  customer: 'true',
  url: '',
});
function test() {
  console.log('btn_test');
}

const dataTextArea = ref('');
</script>
