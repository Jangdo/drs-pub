<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">팝업 4종 - 각 버튼 클릭 후 화면 확인하세요.</h2>
      <Breadcrumbs />
    </div>

    <div class="row-2 mt60">
      <q-btn
        unelevated
        label="일정 수정 전"
        color="positive"
        @click="dataDialog.alert1 = true"
      />

      <q-btn
        unelevated
        label="일정 수정 완료"
        color="positive"
        @click="dataDialog.alert2 = true"
      />

      <q-btn
        unelevated
        label="일정 삭제 전"
        color="orange"
        @click="dataDialog.alert3 = true"
      />

      <q-btn
        unelevated
        label="일정 삭제 완료"
        color="orange"
        @click="dataDialog.alert4 = true"
      />

      <!-- 일정 수정 전 -->
      <q-dialog v-model="dataDialog.alert1">
        <q-card class="dialog_card">
          <q-card-section class="dialog_title"> 일정 수정 </q-card-section>
          <q-card-section class="dialog_content">
            해당 일정을 수정하시겠습니까?<br />반복되는 일정입니다.
          </q-card-section>
          <q-card-actions class="dialog_actions type_column">
            <q-btn
              unelevated
              v-close-popup
              outline
              text-color="white"
              class="size_lg w100p"
              label="해당일정만 수정"
            />
            <q-btn
              unelevated
              v-close-popup
              outline
              text-color="white"
              class="size_lg w100p"
              label="이후 모든 일정 수정"
            />
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
          </q-card-actions>
        </q-card>
      </q-dialog>
      <!-- // 일정 수정 전 -->

      <!-- 일정 수정 완료 -->
      <q-dialog v-model="dataDialog.alert2">
        <q-card class="dialog_card">
          <q-card-section class="dialog_title"> 일정 수정 </q-card-section>
          <q-card-section class="dialog_content">
            저장이 완료되었습니다.
          </q-card-section>
          <q-card-actions class="dialog_actions">
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
          </q-card-actions>
        </q-card>
      </q-dialog>
      <!-- // 일정 수정 완료 -->

      <!-- 일정 삭제 전 -->
      <q-dialog v-model="dataDialog.alert3">
        <q-card class="dialog_card">
          <q-card-section class="dialog_title"> 일정 삭제 </q-card-section>
          <q-card-section class="dialog_content">
            해당 일정을 삭제하시겠습니까?<br />반복되는 일정입니다.
          </q-card-section>
          <q-card-actions class="dialog_actions type_column">
            <q-btn
              unelevated
              v-close-popup
              outline
              class="size_lg w100p"
              label="해당일정만 삭제"
            />
            <q-btn
              unelevated
              v-close-popup
              outline
              class="size_lg w100p"
              label="이후 모든 일정 삭제"
            />
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
          </q-card-actions>
        </q-card>
      </q-dialog>
      <!-- // 일정 삭제 전 -->

      <!-- 일정 삭제 완료 -->
      <q-dialog v-model="dataDialog.alert4">
        <q-card class="dialog_card">
          <q-card-section class="dialog_title"> 일정 삭제 </q-card-section>
          <q-card-section class="dialog_content">
            삭제 완료되었습니다.
          </q-card-section>
          <q-card-actions class="dialog_actions">
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
          </q-card-actions>
        </q-card>
      </q-dialog>
      <!-- // 일정 삭제 완료 -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataDialog = ref({
  alert1: false,
  alert2: false,
  alert3: false,
  alert4: false,
});
</script>
