<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">발송 URL 찾기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-3">
                  <div class="row-calendar">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            />
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </div>
                <div class="col-12 col-md-3">
                  <q-select
                    class="box_m hide_label"
                    label="대교_공지사항_행"
                    v-model="userNumberSelect"
                    :options="userNumberSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    placeholder="제목"
                  />
                </div>
                <div class="col-12 col-md-3">
                  <q-input
                    class="box_l"
                    for=""
                    outlined
                    dense
                    placeholder="등록자"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <!-- selectable_table type_01 -->
          <div class="table_dk mt10">
            <div class="table_top">
              <div class="btn_wrap col-12 gap10">
                <q-btn
                  class="size_sm"
                  outline
                  unelevated
                  color="black"
                  label="선택 초기화"
                />
              </div>
            </div>

            <q-table
              :rows="tableRows"
              :columns="tableColumns"
              row-key="idx"
              v-model:selected="tableSelected"
              selection="single"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header="props">
                <q-tr :props="props">
                  <q-th
                    v-for="col in props.cols"
                    :key="col.name"
                    :props="props"
                  >
                    {{ col.label }}
                  </q-th>
                </q-tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td class="select">
                    <q-checkbox v-model="props.selected" color="black" />
                    <!-- <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      color="orange"
                      checked-icon="trip_origin" unchecked-icon="radio_button_unchecked" class="check_to_radio"
                    /> -->
                  </q-td>
                  <q-td key="tdada1" class="text-left">{{
                    props.row.name
                  }}</q-td>
                  <q-td key="address" class="text-center">
                    {{ props.row.date }}<br />
                  </q-td>
                </q-tr>
              </template>
            </q-table>

            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
          <!--// selectable_table type_01-->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="적용"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
// menu
const userNumberSelect = ref('대교_공지사항_행');
const userNumberSelectOption = ref([
  {
    id: 'N',
    desc: '22021133',
  },
  {
    id: 'G',
    desc: '22021133',
  },
  {
    id: 'C',
    desc: '22021133 ',
  },
  {
    desc: '2202113',
  },
]);

const tableSelected = ref([
  {
    idx: '1',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
]);

const tableColumns = ref([
  {
    name: 'tdata1',
    label: '선택',
    sortable: false,
    align: 'center',
  },
  {
    name: 'tdata2',
    label: '제목',
    sortable: false,
    align: 'center',
  },
  {
    name: 'tdata3',
    label: '발송시간',
    sortable: false,
    align: 'center',
  },
]);
const tableRows = ref([
  {
    idx: '1',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '2',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '3',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '4',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '5',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '6',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '1',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '2',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '3',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '4',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '5',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
  {
    idx: '6',
    name: '[이벤트] 커피증정 <자기주도학습법> 영상 보고 댓글 작성',
    date: '2022.11.01',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
