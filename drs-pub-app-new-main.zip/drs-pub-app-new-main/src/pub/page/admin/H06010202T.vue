<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판 관리</h2>
      <Breadcrumbs />
    </div>

    <!-- 탭 영역 -->
    <div class="wrapper_tab">
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb24"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
      </q-tabs>
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1"> tab1 </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2">
          <div class="wrap_table_box">
            <!-- 테이블 세로 스크롤 scrollable tbl_row_11 클래스 추가 -->
            <q-table
              :rows="msgRows"
              :columns="msgColumns"
              row-key="idx"
              v-model:selected="msg_selected"
              selection="multiple"
              v-model:pagination="msg_pagination"
              hide-bottom
              hide-pagination
              separator="cell"
              color="black"
              class="mb50"
            >
              <template v-slot:header="props">
                <q-tr :props="props">
                  <q-th class="">테이블 컬럼명</q-th>
                  <q-th class=""
                    >표시명 <span class="text-orange">*</span></q-th
                  >
                  <q-th class="">크기</q-th>
                  <q-th class="">유형</q-th>
                  <q-th class="">사용</q-th>
                  <q-th class="">목록</q-th>
                  <q-th class="">등록</q-th>
                  <q-th class="">조회</q-th>
                  <q-th class="">넓이</q-th>
                </q-tr>
              </template>
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td class="text-center">
                    {{ props.row.tableColumn }}
                    <q-icon name="icon-diamond" class="icon_svg"></q-icon>
                  </q-td>
                  <q-td class="text-center">{{ props.row.name }}</q-td>
                  <q-td class="text-center">{{ props.row.size }}</q-td>
                  <q-td class="text-center">{{ props.row.type }}</q-td>
                  <q-td class="hasbtn"
                    ><q-checkbox
                      v-model="dataCheck"
                      color="black"
                      dense
                      disable
                  /></q-td>
                  <q-td class="hasbtn"
                    ><q-checkbox v-model="props.selected" color="black" dense
                  /></q-td>
                  <q-td class="hasbtn"
                    ><q-checkbox v-model="props.selected" color="black" dense
                  /></q-td>
                  <q-td class="hasbtn"
                    ><q-checkbox v-model="props.selected" color="black" dense
                  /></q-td>
                  <q-td class="text-center">
                    <q-input
                      outlined
                      v-model="inpWidth"
                      placeholder="입력하세요"
                    />
                  </q-td>
                </q-tr>
              </template>
            </q-table>

            <!-- 버튼 -->
            <div class="btn_area response">
              <q-space />
              <q-btn unelevated color="grey-2" class="size_md" label="목록" />
            </div>
            <!-- // 버튼 -->
          </div>
        </q-tab-panel>
        <!--// tab2 컨텐츠 -->
      </q-tab-panels>
    </div>
    <!-- // 탭 영역 -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab2');

//msg_table데이터
const msg_selected = ref([]);

const msgColumns = ref([
  {
    name: 'idx',
    label: '순번',
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tableColumn',
    label: '테이블 컬럼명',
    align: 'center',
    field: (row) => row.tableColumn,
  },
  {
    name: 'name',
    label: '표시명',
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'size',
    label: '크기',
    align: 'center',
    field: (row) => row.size,
  },
  {
    name: 'type',
    label: '유형',
    align: 'center',
    field: (row) => row.type,
  },
  {
    name: 'use',
    label: '사용',
    align: 'center',
    field: (row) => row.use,
  },
  {
    name: 'list',
    label: '목록',
    align: 'center',
    field: (row) => row.list,
  },
  {
    name: 'apply',
    label: '등록',
    align: 'center',
    field: (row) => row.apply,
  },
  {
    name: 'check',
    label: '조회',
    align: 'center',
    field: (row) => row.check,
  },
  {
    name: 'width',
    label: '넓이',
    align: 'center',
    field: (row) => row.width,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '2',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '3',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '4',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '5',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '6',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '7',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '8',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '9',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '10',
    tableColumn: 'POST_TITLE',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
  {
    idx: '11',
    tableColumn: 'POST_TITLE11',
    name: '제목',
    size: '330',
    type: 'TIMESTAMP',
  },
]);
const msg_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});

const dataCheck = ref(false);

const inpWidth = ref('');
</script>
