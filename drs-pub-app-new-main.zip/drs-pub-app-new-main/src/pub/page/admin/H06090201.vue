<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">테이블 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="keyword"
              placeholder="테이블명(물리)"
            >
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="keyword2"
              placeholder="테이블명(논리)"
            >
            </q-input>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <!-- general_table -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" outline label="선택삭제" />
            <q-btn class="size_sm" outline unelevated label="생성쿼리복사" />
            <q-btn class="size_sm" outline unelevated label="수정" />
            <q-btn
              class="size_sm"
              color="black"
              fill
              unelevated
              label="신규등록"
            />
          </div>
        </div>

        <q-table
          :rows="dataRows"
          :columns="dataColumns"
          v-model:selected="selected"
          row-key="idx"
          v-model:pagination="dataPagination"
          selection="multiple"
          hide-bottom
          hide-pagination
          separator="cell"
          color="black"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th>선택</q-th>
              <q-th v-for="col in props.cols" :key="col.name" :props="props">
                {{ col.label }}
              </q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :props="props">
              <q-td key="check" class="select text-center">
                <q-checkbox v-model="props.selected" color="black" />
              </q-td>
              <q-td key="tdata1" class="text-left">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="text-center">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="text-center">
                {{ props.row.tdata3 }}
              </q-td>
              <q-td key="tdata4" class="text-center">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="tdata5" class="text-center">
                {{ props.row.tdata5 }}
              </q-td>
              <q-td key="toggle" :props="props" class="text-center">
                <q-toggle
                  color="black"
                  v-model="props.row.toggle"
                  false-value="n"
                  true-value="y"
                />
              </q-td>
            </q-tr>
          </template>
        </q-table>
      </div>
      <!-- pagination -->
      <div class="pagination_container">
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          input
          class="justify-center"
        />
        <q-pagination
          v-model="dataPagination.current"
          v-if="$q.screen.name == 'lg'"
          :max="10"
          :max-pages="8"
          direction-links
          boundary-links
          rounded
          icon-first="keyboard_double_arrow_left"
          icon-last="keyboard_double_arrow_right"
          class="justify-center type_01"
        />
      </div>
      <!-- // pagination -->
      <!-- // general_table -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const keyword = ref('');
const keyword2 = ref('');

//data테이블
const selected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '테이블명(물리)',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '테이블명(논리)',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '등록일',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '확장여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'toggle',
    label: '사용여부',
    sortable: false,
    align: 'center',
    field: (row) => row.toggle,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '헬프데스크 FAQ',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'y',
  },
  {
    idx: 9,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ TBBS_HELPDESKFAQ',
    tdata2: '헬프데스크 헬프데스크 FAQ',
    tdata3: '2022.11.01',
    tdata4: '홍홍길동',
    tdata5: '확장형확장형',
    toggle: 'n',
  },
  {
    idx: 8,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 7,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 6,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 5,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 4,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 3,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 2,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
  {
    idx: 1,
    check: '',
    tdata1: 'TBBS_HELPDESKFAQ',
    tdata2: '테이블명',
    tdata3: '2022.11.01',
    tdata4: '홍길동',
    tdata5: '확장형',
    toggle: 'n',
  },
]);
</script>
