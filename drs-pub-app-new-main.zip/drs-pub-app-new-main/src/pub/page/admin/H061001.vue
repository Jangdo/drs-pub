<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <div class="row-4">
              <q-input
                outlined
                v-model="searchDate.from"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
              <span class="text-body2">~</span>
              <q-input
                outlined
                v-model="searchDate.to"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.to"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyTo.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
          <div class="col-12 col-md-3">
            <q-input class="" outlined v-model="keyword" placeholder="제목">
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-input class="" outlined v-model="keyword2" placeholder="등록자">
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-select
              class="hide_label"
              label="답변여부 전체"
              v-model="answerSelect"
              :options="answerSelectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
        </div>
        <div class="mt10" v-if="stateHandle">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="카테고리 전체"
                v-model="categorySelect"
                :options="categorySelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="말머리 전체"
                v-model="subjectSelect"
                :options="subjectSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-checkbox
                v-model="dataCheck"
                label="등록일자 조회 제외"
                color="black"
              />
            </div>
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>
    <q-btn
      class="btn_search_handle"
      fill
      color="grey-5"
      unelevated
      @click="actionHandle"
    >
      <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
      <q-icon color="white" name="ion-ios-arrow-down" v-else />
    </q-btn>

    <q-card class="wrap_table_divide wrap_table_box">
      <!-- sm_area 트리 영역 -->
      <div class="sm_area">
        <div class="tree_container mt50">
          <q-tree
            :nodes="tree_data"
            node-key="id"
            selected-color="primary"
            class="category type_tbl10"
            v-model:selected="tree_selected"
            default-expand-all
            @update:selected="temp(tree_selected)"
            style="max-height: 657px; min-height: 657px"
          />
        </div>
      </div>
      <!--// sm_area 트리 영역 -->

      <!-- main_area 테이블 영역 -->
      <div class="main_area">
        <!-- selectable_table type_01 -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm" outline label="선택삭제" />
              <q-btn class="size_sm" outline label="파일개시" />
              <q-btn fill unelevated outline class="size_sm" label="수정" />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_sm"
                label="신규등록"
              />
            </div>
          </div>

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:selected="selected"
            hide-bottom
            hide-pagination
            separator="cell"
            selection="multiple"
            color="black"
            class="scrollable sticky_table_header"
            :rows-per-page-options="[0]"
            style="max-height: 657px"
          >
          </q-table>
        </div>
      </div>
      <!--// main_area 테이블 영역 -->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
// table_search_area
const keyword = ref('');
const keyword2 = ref('');
const dataCheck = ref(true);
const searchDate = ref({
  from: '2023.02.01',
  to: '2023.02.20',
});
//
const answerSelect = ref(['']);
const answerSelectOption = ref([
  {
    id: 's11',
    desc: 'y',
  },
  {
    id: 's12',
    desc: 'n',
  },
]);
const categorySelect = ref(['']);
const categorySelectOption = ref([
  {
    id: 's21',
    desc: '카테고리1',
  },
  {
    id: 's22',
    desc: '카테고리1',
  },
]);
const subjectSelect = ref(['']);
const subjectSelectOption = ref([
  {
    id: 's31',
    desc: '말머리1',
  },
  {
    id: 's32',
    desc: '말머리2',
  },
]);

// tree
const tree_data = [
  {
    label: '게시판 메뉴관리',
    id: 'treeAll',
    icon: '',
    children: [
      {
        id: 'treeSub1',
        label: '솔루션엠한마당',
        children: [
          {
            id: '공지사항',
            label: '하위1',
            children: [
              {
                id: 'treeSub1_1_1',
                label: '하위1_1',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'treeSub1_1_2',
                label: '하위1_2',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          { id: '그 외', label: '하위2', img: '/icons/icon-tree-folder.svg' },
        ],
      },
      {
        label: '자료실',
        id: 'treeSub2',
        children: [
          {
            label: '하위1',
            id: 'treeSub2_1',
            children: [
              { id: 'treeSub2_1_1', label: '하위1-1' },
              { id: 'treeSub2_1_2', label: '하위1-1' },
            ],
          },
          { id: 'treeSub2_2', label: '하위2' },
        ],
      },
      {
        label: '게시판',
        id: 'treeSub3',
        children: [
          { id: 'treeSub3_1', label: '하위1' },
          { id: 'treeSub3_2', label: '하위2' },
        ],
      },
    ],
  },
];
//  트리 셀렉트 이벤트
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
const tree_selected = ref('게시판메뉴관리');

//data테이블
const selected = ref([]);

const dataColumns = ref([
  {
    name: 'tdata1',
    label: '제목',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '본문게시 카테고리',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '등록자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '등록일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '기본게시판 게시물 제목 제목 제목 제목입니다.',
    tdata2: '질문과답변',
    tdata3: '홍홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 9,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 10,
    tdata1: '기본게시판 게시물 제목 제목 제목 제목입니다.',
    tdata2: '질문과답변',
    tdata3: '홍홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 9,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 10,
    tdata1: '기본게시판 게시물 제목 제목 제목 제목입니다.',
    tdata2: '질문과답변',
    tdata3: '홍홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 9,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 10,
    tdata1: '기본게시판 게시물 제목 제목 제목 제목입니다.',
    tdata2: '질문과답변',
    tdata3: '홍홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 9,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 8,
    tdata1: '질문',
    tdata2: '이벤트',
    tdata3: '길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 7,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 6,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 5,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 4,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 3,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 2,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
  {
    idx: 1,
    tdata1: '기본게시판',
    tdata2: '공지사항',
    tdata3: '홍길동',
    tdata4: '2023.04.01',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
