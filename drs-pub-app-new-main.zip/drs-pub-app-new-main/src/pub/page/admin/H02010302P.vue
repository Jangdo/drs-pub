<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-4">
                  <q-select
                    class="hide_label"
                    label="본부 선택"
                    v-model="headquartersSelect"
                    :options="headquartersSelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <div class="col-12 col-md-4">
                  <q-input
                    class="box_l inp_search"
                    for=""
                    outlined
                    dense
                    placeholder="사번, 성명"
                  />
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="wrap_tree_table mt20 table_dk">
            <!-- sm_area 트리 영역 -->
            <!-- <div class="sm_area">
              <div class="tree_container">
                <q-tree
                  :nodes="treeData"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree hastbltit"
                  v-model:selected="treeSelected"
                  default-expand-all
                  @update:selected="temp1(treeSelected)"
                >
                </q-tree>
              </div>
            </div> -->
            <!--// sm_area 트리 영역 -->
            <div class="wrap_insert_table">
              <!-- search_user_table -->
              <q-table
                class="scrollable sticky_table_header"
                title="검색 사용자"
                :rows="before_rows"
                :columns="columns"
                row-key="workerNumber"
                :rows-per-page-options="[0]"
                selection="single"
                v-model:selected="before_selected"
                separator="cell"
                hide-pagination
                hide-bottom
                color="black"
                style="max-height: 491px"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th>선택</q-th>
                    <q-th>부서 정보</q-th>
                    <q-th>사번</q-th>
                    <q-th>이름</q-th>
                  </q-tr>
                </template>
                <!-- <template v-slot:body-selection="scope">
                  <q-checkbox
                    v-model="scope.selected"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                    color="black"
                  />
                </template> -->
              </q-table>
              <!--// search_user_table -->
              <!-- btn_area -->
              <div class="btn_area">
                <q-btn
                  class="size_sm btn_write"
                  dense
                  fill
                  unelevated
                  color="grey-3"
                  label="추가"
                />
                <q-btn
                  class="size_sm ml_0 btn_delete"
                  dense
                  fill
                  unelevated
                  color="grey-3"
                  label="삭제"
                />
              </div>
              <!--// btn_area -->
              <!-- set_user_table -->
              <q-table
                class="scrollable sticky_table_header"
                title="설정 사용자"
                :rows="after_rows"
                :columns="columns"
                row-key="workerNumber"
                :rows-per-page-options="[0]"
                selection="multiple"
                v-model:selected="after_selected"
                separator="cell"
                hide-pagination
                hide-bottom
                color="black"
                style="max-height: 491px"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th>선택</q-th>
                    <q-th>부서 정보</q-th>
                    <q-th>사번</q-th>
                    <q-th>이름</q-th>
                  </q-tr>
                </template>
              </q-table>
              <!--// set_user_table -->
            </div>
          </div>
          <!-- <q-separator class="popup_btm_line" /> -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const headquartersSelect = ref('');
const headquartersSelectOption = ref([
  {
    id: 'N',
    desc: '본부1',
  },
]);

//  table
const columns = ref([
  {
    name: 'infor',
    label: '부서 정보',
    align: 'center',
    sortable: false,
    field: 'infor',
  },
  {
    name: 'workerNumber',
    label: '사번',
    align: 'center',
    field: 'workerNumber',
    sortable: false,
  },
  {
    name: 'memberName',
    label: '이름',
    align: 'center',
    field: 'memberName',
    sortable: false,
  },
]);
// const initialPagination = ref({
//   sortBy: 'workerNumber',
//   descending: false,
//   page: 1,
//   rowsPerPage: 10,
//   // rowsNumber: xx if getting data from a server
// });

const before_rows = ref([
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123451',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123452',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123453',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123454',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
]);
const after_rows = ref([
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123451',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123452',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123453',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123454',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123451',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123452',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123453',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123454',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
  {
    infor: '서울 강서 본점 > 화곡 지점',
    workerNumber: 'a123455',
    memberName: '홍길동',
  },
]);
const before_selected = ref([
  { infor: '서울 강서 본점 > 화곡 지점', workerNumber: 'a123451' },
]);
const after_selected = ref([
  { infor: '서울 강서 본점 > 화곡 지점', workerNumber: 'a123451' },
]);
</script>
