<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">목록화면</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div>
            <h3 class="title1 mb20">목록화면</h3>
            <q-markup-table separator="cell" wrap-cells>
              <thead>
                <tr>
                  <th>
                    <div class="wrap_btn_area_arrow">
                      제목
                      <div class="btn_area_arrow">
                        <q-btn
                          class="size_xxs btn_row_up"
                          icon="keyboard_arrow_left"
                          disable
                          outline
                          label=""
                        />
                        <q-btn
                          class="size_xxs btn_row_down"
                          color="grey-7"
                          icon="keyboard_arrow_right"
                          outline
                          label=""
                        />
                      </div>
                    </div>
                  </th>
                  <th>
                    <div class="wrap_btn_area_arrow">
                      등록 패스워드
                      <div class="btn_area_arrow">
                        <q-btn
                          class="size_xxs btn_row_up"
                          icon="keyboard_arrow_left"
                          outline
                          label=""
                        />
                        <q-btn
                          class="size_xxs btn_row_down"
                          color="grey-7"
                          icon="keyboard_arrow_right"
                          outline
                          label=""
                        />
                      </div>
                    </div>
                  </th>
                  <th>
                    <div class="wrap_btn_area_arrow">
                      생성일
                      <div class="btn_area_arrow">
                        <q-btn
                          class="size_xxs btn_row_up"
                          icon="keyboard_arrow_left"
                          outline
                          label=""
                        />
                        <q-btn
                          disable
                          class="size_xxs btn_row_down"
                          color="grey-7"
                          icon="keyboard_arrow_right"
                          outline
                          label=""
                        />
                      </div>
                    </div>
                  </th>
                  <th>
                    <div class="wrap_btn_area_arrow">
                      생성일
                      <div class="btn_area_arrow">
                        <q-btn
                          class="size_xxs btn_row_up"
                          icon="keyboard_arrow_left"
                          outline
                          label=""
                        />
                        <q-btn
                          disable
                          class="size_xxs btn_row_down"
                          color="grey-7"
                          icon="keyboard_arrow_right"
                          outline
                          label=""
                        />
                      </div>
                    </div>
                  </th>
                  <th>
                    <div class="wrap_btn_area_arrow">
                      생성일
                      <div class="btn_area_arrow">
                        <q-btn
                          class="size_xxs btn_row_up"
                          icon="keyboard_arrow_left"
                          outline
                          label=""
                        />
                        <q-btn
                          disable
                          class="size_xxs btn_row_down"
                          color="grey-7"
                          icon="keyboard_arrow_right"
                          outline
                          label=""
                        />
                      </div>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="제목을 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="등록 패스워드를 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="생성일을 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="생성일을 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="생성일을 입력하세요"
                      />
                    </div>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>
          </div>

          <div class="mt60">
            <div class="row-2 mb20 items-end">
              <h3 class="title1">목록화면</h3>
              <div class="btn_area">
                <q-btn
                  class="size_sm"
                  color="grey-7"
                  outline
                  label="1칼럼 추가"
                />
                <q-btn
                  class="size_sm ml10"
                  color="grey-7"
                  outline
                  label="2칼럼 추가"
                />
              </div>
            </div>

            <div class="rounded-border-box">
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="titleSelect"
                    :options="titleSelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="ctSelect"
                    :options="ctSelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="categorySelect"
                    :options="categorySelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="categorySelect"
                    :options="categorySelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="targetSelect"
                    :options="targetSelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                  <q-select
                    v-model="optionSelect"
                    :options="optionSelectOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
              <div class="row justify-between">
                <div class="row gap10">
                  <q-select
                    v-model="revDate"
                    :options="revDateOpt"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <q-btn unelevated color="grey-3" class="size_sm" label="삭제" />
              </div>
            </div>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
.row.gap10 {
  flex-wrap: nowrap;
  flex-basis: calc(100% - 80px);
  .q-select {
    width: 100%;
  }
}
</style>
<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const titleSelect = ref(['제목']);
const titleSelectOpt = ref([
  {
    id: 'tt1',
    desc: '제목1',
  },
  {
    id: 'tt2',
    desc: '제목12',
  },
]);

const ctSelect = ref(['본문']);
const ctSelectOpt = ref([
  {
    id: 'ct1',
    desc: '본문1',
  },
  {
    id: 'ct2',
    desc: '본문2',
  },
]);

const categorySelect = ref(['카테고리']);
const categorySelectOpt = ref([
  {
    id: 'category1',
    desc: '카테고리1',
  },
  {
    id: 'category2',
    desc: '카테고리2',
  },
]);

const targetSelect = ref(['게시대상']);
const targetSelectOpt = ref([
  {
    id: 'target1',
    desc: '게시대상1',
  },
  {
    id: 'target2',
    desc: '게시대상2',
  },
]);

const optionSelect = ref(['게시옵션']);
const optionSelectOpt = ref([
  {
    id: 'option1',
    desc: '게시옵션1',
  },
  {
    id: 'option2',
    desc: '게시옵션2',
  },
]);
const revDate = ref(['게시 예약일']);
const revDateOpt = ref([
  {
    id: 'option1',
    desc: '게시 예약일1',
  },
  {
    id: 'option2',
    desc: '게시 예약일2',
  },
]);
</script>
