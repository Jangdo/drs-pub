<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판관리</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb40"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
        <q-tab name="tab3" label="화면구성" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1"> tab1 </q-tab-panel>
        <!--// tab1 컨텐츠 -->

        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2"> tab2 </q-tab-panel>
        <!--// tab2 컨텐츠 -->

        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3">
          <q-card class="wrap_table_box">
            <h3 class="title1 mb20">목록화면</h3>
            <q-markup-table separator="cell" wrap-cells>
              <thead>
                <tr>
                  <th class="">제목</th>
                  <th class="">등록 패스워드</th>
                  <th class="">생성일</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="제목을 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="등록 패스워드를 입력하세요"
                      />
                    </div>
                  </td>
                  <td>
                    <div class="search_item">
                      <q-input
                        class=""
                        outlined
                        placeholder="생성일을 입력하세요"
                      />
                    </div>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>

            <div class="row-2 mt60 mb20">
              <h3 class="title1">등록화면</h3>
              <div class="btn_area">
                <q-btn
                  class="size_sm"
                  color="grey-7"
                  outline
                  label="1칼럼 추가"
                />
                <q-btn
                  class="size_sm ml10"
                  color="grey-7"
                  outline
                  label="2칼럼 추가"
                />
              </div>
            </div>
            <p class="text-body2 add_column">칼럼을 추가해 주세요.</p>
          </q-card>
        </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab3');
</script>
