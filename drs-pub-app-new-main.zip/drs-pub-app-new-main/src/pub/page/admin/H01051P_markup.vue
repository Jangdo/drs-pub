<!-- <template>
  <div class="inner_list">
    <ul>
      <li>
        <span class="ad_label">* 메시지 ID</span>
        <q-input
          outlined
          v-model="msg_rows[msg_dialog.idx - 1].idx"
          placeholder="메시지 ID를 입력하세요"
          dense
        /><template
          ><q-dialog v-model="msg_dialog.open" class="positive">
            <q-card class="flex column justify-between">
              <q-card-section class="dialog_title">
                <div class="text20 bold" color="black" align="left">
                  메시지 등록
                </div>
              </q-card-section>
              <q-card-section class="q-pt-none text18 grey-8" align="center">
                <div class="inner_list">
                  <ul>
                    <li>
                      <span class="ad_label">* 메시지 ID</span>
                      <q-input
                        outlined
                        v-model="msg_rows[msg_dialog.idx - 1].idx"
                        placeholder="메시지 ID를 입력하세요"
                        dense
                      />
                    </li>

                    <li>
                      <span class="ad_label">* 메시지 명</span>
                      <q-input
                        outlined
                        v-model="msg_rows[msg_dialog.idx - 1].name"
                        placeholder="메시지 명을 입력하세요"
                        dense
                      />
                    </li>
                    <li>
                      <span class="ad_label">* 메시지 내용</span>
                      <q-input
                        outlined
                        v-model="msg_rows[msg_dialog.idx - 1].txt"
                        placeholder="메시지 내용을 입력하세요"
                        dense
                      />
                    </li>
                    <li>
                      <span class="ad_label">* 카테고리</span>
                      <q-input
                        outlined
                        v-model="dataInput2"
                        placeholder="메시지 ID를 입력하세요"
                        dense
                      />
                    </li>
                    <li>
                      <span class="ad_label">* 구분</span>
                      <q-input
                        outlined
                        v-model="dataInput2"
                        placeholder="메시지 ID를 입력하세요"
                        dense
                      />
                    </li>
                    <li>
                      <span class="ad_label">* 사용여부</span>
                      <q-input
                        outlined
                        v-model="dataInput2"
                        placeholder="메시지 ID를 입력하세요"
                        dense
                      />
                    </li>
                  </ul>
                </div>
              </q-card-section>
              <q-card-actions align="center" class="row item-end">
                <q-btn
                  unelevated
                  label="취소"
                  text-color="white"
                  class="col-6 cancel"
                  square
                  v-close-popup
                />
                <q-btn
                  unelevated
                  label="확인"
                  text-color="white"
                  class="col-6 confirm"
                  square
                  v-close-popup
                />
              </q-card-actions>
            </q-card> </q-dialog
        ></template>

        <script setup>
          import { ref } from 'vue';
        </script>
        <style lang="scss">
          .add_code_table {
            margin-bottom: 20px;
          }
          .sm_area {
            margin-right: 50px;
          }
          .row-2 {
            justify-content: flex-start;
          }
        </style>
      </li>

      <li>
        <span class="ad_label">* 메시지 명</span>
        <q-input
          outlined
          v-model="msg_rows[msg_dialog.idx - 1].name"
          placeholder="메시지 명을 입력하세요"
          dense
        />
      </li>
      <li>
        <span class="ad_label">* 메시지 내용</span>
        <q-input
          outlined
          v-model="msg_rows[msg_dialog.idx - 1].txt"
          placeholder="메시지 내용을 입력하세요"
          dense
        />
      </li>
      <li>
        <span class="ad_label">* 카테고리</span>
        <q-input
          outlined
          v-model="dataInput2"
          placeholder="메시지 ID를 입력하세요"
          dense
        />
      </li>
      <li>
        <span class="ad_label">* 구분</span>
        <q-input
          outlined
          v-model="dataInput2"
          placeholder="메시지 ID를 입력하세요"
          dense
        />
      </li>
      <li>
        <span class="ad_label">* 사용여부</span>
        <q-input
          outlined
          v-model="dataInput2"
          placeholder="메시지 ID를 입력하세요"
          dense
        />
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref } from 'vue';
// tree
const tree_data = [
  {
    label: '메시지 카테고리',
    id: 'a_1',
    icon: 'home',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              { id: 'a_4', label: '뎁스4' },
              { id: 'a_5', label: '뎁스4' },
            ],
          },
          { id: 'a_6', label: '뎁스3' },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const tree_selected = ref('메시지 카테고리');
// table_serch_area
const searchUseSelected = ref(['선택하세요']);
const searchSelectOption = ref([
  {
    id: 'Y',
    desc: '사용',
  },
  {
    id: 'N',
    desc: '미사용',
  },
]);
const searchSelectChoice = ref(['선택하세요']);
const searchSelectChoiceOption = ref([
  {
    id: 'A',
    desc: '전체',
    // disable 옵션 샘플
    // inactive: true,
  },
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const author = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

//
const msg_name = ref('');
// msg_dialog
const msg_dialog = ref({
  open: false,
  idx: 0,
});

//msg_table데이터
const msg_selected = ref([]);
const msg_columns = ref([
  {
    name: 'idx',
    label: '순서',
    align: 'right',
    sortable: false,
    align: 'right',
    field: (row) => row.idx,
  },
  {
    name: 'category',
    align: 'right',
    label: '카테고리',
    sortable: false,
    align: 'center',
    field: (row) => row.category,
  },
  {
    name: 'id',
    align: 'right',
    label: '메시지 ID',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },
  {
    name: 'name',
    align: 'center',
    label: '메시지 명',
    field: 'name',
    sortable: false,
    align: 'left',
    field: (row) => row.name,
  },
  {
    name: 'author',
    align: 'center',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'state',
    label: '구분',
    align: 'center',
    sortable: false,
    field: (row) => row.state,
  },
  {
    name: 'allow',
    label: '사용여부',
    align: 'center',
    sortable: false,
    field: (row) => row.allow,
  },
  {
    name: 'btn',
    label: '상세보기',
    align: 'center',
    sortable: false,
    field: (row) => row.btn,
  },
]);
const msg_rows = ref([
  {
    idx: '1',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '2',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '3',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '4',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '5',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '6',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },

  //
  {
    idx: '7',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '8',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '9',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '10',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '11',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
  {
    idx: '12',
    category: '권한정보',
    id: 'MSG_C0001',
    name: '[##A] 대상을 생성합니다. 계속하시겠습니까?',
    txt: 'txt',
    author: '상위 홍길동',
    state: 'confirm',
    allow: false,
  },
]);
const msg_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 20,
});
function temp(target) {
  console.log('셀렉트 이벤트 발생', target);
}
function tableEvt(id) {
  console.log('테이블  ' + id + '번째 행 클릭함');
  msg_dialog.value.idx = id;
  msg_dialog.value.open = true;
}
// td 상태값
function tdState(priority) {
  switch (priority) {
    case 'confirm':
      return '확인';
    case 'alert':
      return '알림';
    default:
      return '';
  }
}
</script>
<style lang="scss">
.add_code_table {
  margin-bottom: 20px;
}
.sm_area {
  margin-right: 50px;
}
.row-2 {
  justify-content: flex-start;
}
</style> -->
