<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">양식관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class="box_m"
              outlined
              v-model="boardName"
              placeholder="제목을 입력하세요"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="box_m"
              outlined
              v-model="writer"
              placeholder="등록자를 입력하세요"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-input
              outlined
              :model-value="searchDate.from + '~' + searchDate.to"
              class="inp_date normal"
              readonly
            >
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      mask="YYYY.MM.DD"
                      v-model="searchDate"
                      range
                      @update:model-value="
                        searchDate.from, $refs.qDateProxyFrom.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </div>
          <div class="col-12 col-md-3">
            <q-checkbox
              v-model="dataCheck"
              label="등록일자 조회 제외"
              color="black"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <!-- selectable_table type_01 -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" outline label="선택삭제" />
            <q-btn class="size_sm" outline label="수정" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_sm"
              label="신규등록"
            />
          </div>
        </div>

        <q-table
          :rows="tableRows"
          :columns="tableColumns"
          row-key="idx"
          v-model:selected="table_selected"
          selection="multiple"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-th>
              <q-th class="">제목</q-th>
              <q-th class="">등록자</q-th>
              <q-th class="">등록일</q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :class="props.row.state" :props="props">
              <q-td class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-td>
              <q-td key="tableName" class="cursor">
                {{ props.row.tableName }}
              </q-td>
              <q-td key="author" class="w150 text-center">
                {{ props.row.author }}
              </q-td>
              <q-td key="date" class="w150 text-center">
                {{ props.row.date }}
              </q-td>
            </q-tr>
          </template>
        </q-table>

        <!-- 페이지네이션 -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // 페이지네이션 -->
      </div>
      <!--// selectable_table type_01-->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const dataCheck = ref(true);

// table_search_area
const boardName = ref(['']);
const writer = ref(['']);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

//table데이터
const table_selected = ref([]);
const tableColumns = ref([
  {
    name: 'tableName',
    label: '제목',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName,
  },
  {
    name: 'author',
    label: '등록자',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'date',
    label: '등록일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
]);
const tableRows = ref([
  {
    idx: '1',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '2',
    tableName: '총무관리 양식',
    author: '황보홍길',
    date: '2022.11.01',
  },
  {
    idx: '3',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '4',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '5',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '6',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },

  {
    idx: '7',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '8',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '9',
    tableName:
      '특히 러시아가 우크라이나에 대한 군사적 지원 문제와 관련, 한반도 상황을 지렛대로 북한과의 밀착을 강화하며 우리 정부를 위협하는 흐름이어서 한반도 긴장고조가 우려된다는 지적이 제기된다.',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '10',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '11',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
  {
    idx: '12',
    tableName: '총무관리 양식',
    author: '홍길동',
    date: '2022.11.01',
  },
]);

//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
