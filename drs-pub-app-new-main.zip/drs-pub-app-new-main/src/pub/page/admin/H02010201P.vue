<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 inner_form medium">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자 정보 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">LC/YC 구분</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.type"
                      val="LC"
                      label="LC 채점교사"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.type"
                      val="YC"
                      label="YC 채점교사"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">이름</span>
                  <div class="as_dd">
                    <q-input
                      class="as_dd hide_label"
                      label="이름을 입력하세요"
                      outlined
                      placeholder="이름을 입력하세요"
                      stack-label
                      dense
                    >
                      <template v-slot:label>이름</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">사원번호(ID)</span>
                  <div class="as_dd">
                    <q-input
                      class="as_dd hide_label"
                      label="사원번호(ID)를 입력하세요"
                      outlined
                      placeholder="사원번호(ID)를 입력하세요"
                      stack-label
                      dense
                    >
                      <template v-slot:label>사원번호(ID)</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">폰번호</span>
                  <div class="as_dd">
                    <q-input
                      class="as_dd hide_label"
                      label="폰번호를 입력하세요"
                      outlined
                      placeholder="폰번호를 입력하세요"
                      stack-label
                      dense
                    >
                      <template v-slot:label>생년월일</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt">생년월일</span>
                  <div class="as_dd">
                    <q-input
                      class="as_dd hide_label"
                      label="생년월일을 입력하세요"
                      outlined
                      placeholder="생년월일을 입력하세요 (예 : 820101)"
                      stack-label
                      dense
                    >
                      <template v-slot:label>생년월일을 입력하세요</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">로그인 설정</span>
                  <div class="as_dd">
                    <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      label="허용"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                    <q-radio
                      v-model="dataFrom.allow"
                      val="false"
                      label="차단"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">근무기간</span>
                  <div class="as_dd input_row">
                    <!-- searchDate start.from -->
                    <q-input
                      outlined
                      v-model="dataFrom.searchDate.from"
                      class="inp_date"
                      style="width: 250px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="dataFrom.searchDate.from"
                              @update:model-value="
                                dataFrom.searchDate.from,
                                  $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!--// searchDate start.from -->
                    <div class="tilde">
                      <span>~</span>
                    </div>
                    <!-- searchDate start.to -->
                    <q-input
                      outlined
                      v-model="dataFrom.searchDate.to"
                      class="inp_date"
                      style="width: 250px"
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyto"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              v-model="dataFrom.searchDate.to"
                              mask="YYYY.MM.DD"
                              @update:model-value="
                                dataFrom.searchDate.to,
                                  $refs.qDateProxyto.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!--// searchDate start.to -->
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">이용 시간</span>
                  <div class="as_dd input_row">
                    <q-select
                      class="hide_label"
                      label="00"
                      v-model="hourSelect"
                      :options="hourSelectOption"
                      option-value="id"
                      option-label="hour"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
                    </q-select>
                    <div class="tilde">
                      <span>시</span>
                    </div>
                    <q-select
                      class="hide_label"
                      label="00"
                      v-model="minSelect"
                      :options="minSelectOption"
                      option-value="id"
                      option-label="min"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
                    </q-select>
                    <div class="tilde">
                      <span>분</span>
                    </div>
                    <div class="tilde">
                      <span>~</span>
                    </div>
                    <q-select
                      class="hide_label"
                      label="00"
                      v-model="hourSelect2"
                      :options="hourSelectOption"
                      option-value="id"
                      option-label="hour"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
                    </q-select>
                    <div class="tilde">
                      <span>시</span>
                    </div>
                    <q-select
                      class="hide_label"
                      label="00"
                      v-model="minSelect2"
                      :options="minSelectOption"
                      option-value="id"
                      option-label="min"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                <q-icon name="keyboard_arrow_down"></q-icon>
              </template> -->
                    </q-select>
                    <div class="tilde">
                      <span>분</span>
                    </div>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">MOS 이용 설정</span>
                  <div class="as_dd input_row">
                    <q-input
                      class="as_dd hide_label"
                      label="시간/분을 입력하세요. (예: 1305)"
                      outlined
                      placeholder="시간/분을 입력하세요. (예: 1305)"
                      stack-label
                      dense
                      style="width: 250px"
                    >
                      <template v-slot:label
                        >시간/분을 입력하세요. (예 : 1305)</template
                      >
                    </q-input>
                    <div class="tilde">
                      <span>~</span>
                    </div>
                    <q-input
                      class="as_dd hide_label"
                      label="시간/분을 입력하세요. (예: 1305)"
                      outlined
                      placeholder="시간/분을 입력하세요. (예: 1305)"
                      stack-label
                      dense
                      style="width: 250px"
                    >
                      <template v-slot:label
                        >시간/분을 입력하세요. (예 : 1305)</template
                      >
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
            <li class="divide_form">
              <div class="form_row">
                <div class="form_item">
                  <span class="as_dt required">비고</span>
                  <div class="mt15 mb15 full-width">
                    <q-input
                      class="as_dd hide_label"
                      outlined
                      placeholder="비고를 입력하세요"
                      type="textarea"
                      v-model="dataFrom.txt"
                    >
                      <template v-slot:label>비고</template>
                    </q-input>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
#pcOnly.screen--lg,
#manager .screen--lg,
#teacher .screen--lg {
  .hastextarea,
  .form_item {
    padding: 0;
    min-height: 68px;
    display: flex;
    margin-right: 15px;

    .as_dt {
      width: initial !important;
      margin-right: 20px;
      min-height: inherit;
      height: 100%;
      background: #f7f7f7;
      padding: {
        left: 20px;
        top: 25px;
      }
      flex-basis: 160px;
      flex-shrink: 0;
    }
    //
    .as_dd {
      display: flex;
      gap: 0 10px;
    }
  }
}
.form_row {
  width: 100%;
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const dataFrom = ref({
  type: 'LC',
  allow: 'true',
  searchDate: { from: '2023.01.25', to: '2023.01.25' },
});
const hourSelect = ref(['']);
const minSelect = ref(['']);
const hourSelect2 = ref(['']);
const minSelect2 = ref(['']);
const hourSelectOption = ref([
  {
    id: '00',
    hour: '00',
  },
  {
    id: '00',
    hour: '01',
  },
  {
    id: '00',
    hour: '02',
  },
  {
    id: '00',
    hour: '03',
  },
  {
    id: '00',
    hour: '04',
  },
]);
const minSelectOption = ref([
  {
    id: '00',
    min: '00',
  },
  {
    id: '00',
    min: '01',
  },
  {
    id: '00',
    min: '02',
  },
  {
    id: '00',
    min: '03',
  },
  {
    id: '00',
    min: '04',
  },
]);
// const searchDate = ref({
//   from: '2023.01.25',
//   to: '2023.01.25',
// });
</script>

<style lang="scss"></style>
