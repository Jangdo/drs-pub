<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 huge">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <!-- 탭 영역 -->
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              dense
              class="tab_basic mb24"
              color="white"
              active-color="white"
              active-bg-color="primary"
              indicator-color="transparent"
              align="justify"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="tab1" label="사용자" :ripple="false" />
              <q-tab name="tab2" label="조직" :ripple="false" />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="tab1">
                <div class="search_wrap">
                  <div class="search_cnt">
                    <div class="row q-col-gutter-sm">
                      <div class="col-12 col-md-3">
                        <q-input
                          class="box_l inp_search"
                          for=""
                          outlined
                          dense
                          v-model="inpName"
                          placeholder="사번, 성명"
                        />
                      </div>
                    </div>
                  </div>
                  <div class="btn_area">
                    <q-btn outline class="size_sm btn_reset" icon="" label="">
                      <span class="a11y">초기화</span>
                    </q-btn>
                    <q-btn
                      class="size_sm btn_search"
                      fill
                      unelevated
                      label="조회"
                    />
                  </div>
                </div>

                <div class="wrap_tree_table mt20">
                  <!-- sm_area 트리 영역 -->
                  <div class="sm_area" style="width: 260px">
                    <div class="mb16">
                      <q-input
                        class="box_m"
                        outlined
                        dense
                        placeholder="조직명을 검색하세요"
                        v-model="inpOrgan"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="tree_container">
                      <q-tree
                        :nodes="treeData"
                        node-key="id"
                        selected-color="primary"
                        class="popup_tree hastbltit"
                        v-model:selected="treeSelected"
                        default-expand-all
                        @update:selected="temp1(treeSelected)"
                        style="height: 452px"
                      >
                      </q-tree>
                    </div>
                  </div>
                  <!--// sm_area 트리 영역 -->

                  <!-- 테이블 영역 -->
                  <div class="wrap_insert_table mt56 table_dk">
                    <!-- table1 -->
                    <q-table
                      class="search_user_table sticky_table_header scrollable"
                      :rows="before_rows"
                      :columns="columns"
                      row-key="idx"
                      selection="multiple"
                      v-model:selected="before_selected"
                      separator="cell"
                      hide-pagination
                      hide-bottom
                      color="black"
                      :rows-per-page-options="[0]"
                    >
                      <!-- <template v-slot:header="props">
                      <q-tr :props="props">
                        <q-th class="select"><q-checkbox v-model="props.selected" color=black" /></q-th>
                        <q-th v-for="col in props.cols" :key="col.name" :props="props">
                          {{ col.label }}
                        </q-th>
                      </q-tr>
                    </template>
                    <template v-slot:body="props">
                      <q-tr :class="props.row.state" :props="props">
                        <q-td class="select"><q-checkbox v-model="props.selected" color="black" /></q-td>
                        <q-td class="text-center">{{ props.row.organ }}</q-td>
                        <q-td class="text-center">{{ props.row.name }}</q-td>
                      </q-tr>
                    </template> -->
                    </q-table>
                    <!--// table1 -->
                    <!-- btn_area -->
                    <div class="btn_area pt0">
                      <q-btn
                        class="size_sm"
                        color="grey-3"
                        dense
                        fill
                        unelevated
                        label="추가"
                      />
                      <q-btn
                        class="size_sm ml_0 mt10"
                        color="grey-3"
                        dense
                        fill
                        unelevated
                        label="삭제"
                      />
                    </div>
                    <!--// btn_area -->
                    <!-- table2 -->
                    <q-table
                      class="set_user_table sticky_table_header scrollable"
                      :rows="after_rows"
                      :columns="columns2"
                      row-key="idx"
                      selection="multiple"
                      v-model:selected="after_selected"
                      separator="cell"
                      hide-pagination
                      hide-bottom
                      color="black"
                      :rows-per-page-options="[0]"
                    >
                    </q-table>
                    <!--// table2 -->
                  </div>
                </div>

                <div class="row mt16">
                  <q-space />
                  <q-select
                    class="w280 hide_label"
                    label="권한을 선택하세요"
                    v-model="authoritySelect"
                    :options="authoritySelectOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
              </q-tab-panel>
              <!--// tab1 컨텐츠 -->

              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="tab2"> tab2 </q-tab-panel>
              <!--// tab2 컨텐츠 -->
            </q-tab-panels>
          </div>
          <!-- // 탭 영역 -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            class="size_lg"
            color="black"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const tab = ref('tab1');

const inpOrgan = ref('');
const inpName = ref('');

// tree
const treeData = [
  {
    label: '대교드림스',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '눈높이 서비스 부문',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp1(target) {
  console.log('셀렉트 이벤트 발생', target);
}

// table1
const columns = ref([
  {
    name: 'organ',
    label: '조직',
    align: 'center',
    field: 'organ',
  },
  {
    name: 'name',
    label: '성명',
    align: 'center',
    field: 'name',
  },
]);
// const initialPagination = ref({
//   sortBy: 'workerNumber',
//   descending: false,
//   // page: 1,
//   // rowsPerPage: 10,
//   // rowsNumber: xx if getting data from a server
// });
const before_rows = ref([
  {
    idx: '1',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '2',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '3',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
  },
]);

// table2
const columns2 = ref([
  {
    name: 'organ',
    label: '조직',
    align: 'center',
    field: 'organ',
  },
  {
    name: 'name',
    label: '성명',
    align: 'center',
    field: 'name',
  },
  {
    name: 'authority',
    label: '권한',
    align: 'center',
    field: 'authority',
  },
]);
const after_rows = ref([
  {
    idx: '1',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '2',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '3',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
  {
    idx: '4',
    organ: '강서교육국',
    name: '홍길동[22212222]',
    authority: '행정선생님',
  },
]);
const before_selected = ref([]);
const after_selected = ref([]);

// 권한선택
const authoritySelect = ref('');
const authoritySelectOption = ref([
  {
    id: 'N',
    desc: '권한(N)',
  },
  {
    id: 'G',
    desc: '권한(G)',
  },
  {
    id: 'C',
    desc: '권한(C) ',
  },
  {
    desc: '권한(M)',
  },
]);
</script>
