<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">사용자 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
          >
            <b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="mb10">
            <q-radio
              v-model="dataFrom.customer"
              val="true"
              label="칭찬"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              class="check_to_radio"
            />
            <q-radio
              v-model="dataFrom.customer"
              val="false"
              label="건의사항"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              class="check_to_radio"
            />
            <q-radio
              v-model="dataFrom.customer"
              val="true"
              label="연차신청"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              class="check_to_radio"
            />
            <q-radio
              v-model="dataFrom.customer"
              val="false"
              label="팁"
              color="black"
              checked-icon="trip_origin"
              unchecked-icon="radio_button_unchecked"
              class="check_to_radio"
            />
          </div>
          <q-separator />
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const dataFrom = ref({
  img: '',
  path: '',
  allow: 'true',
  customer: 'true',
  url: '',
});
// function test() {
//   console.log('btn_test');
// }
</script>
