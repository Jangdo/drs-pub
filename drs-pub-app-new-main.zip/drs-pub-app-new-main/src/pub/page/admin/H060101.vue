<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">게시판관리</h2>
      <Breadcrumbs />
    </div>
    <!-- //admin_tit_area -->
    <div class="search_wrap">
      <div class="search_cnt">
        <div class="row q-col-gutter-sm">
          <div class="col-12 col-md-3">
            <q-input
              class="inp_msg_name"
              outlined
              v-model="boardName"
              placeholder="게시판명"
            />
          </div>
          <div class="col-12 col-md-3">
            <q-input
              class="inp_msg_name"
              outlined
              v-model="writer"
              placeholder="테이블명(논리)"
            />
          </div>
        </div>
      </div>
      <div class="btn_area">
        <q-btn outline class="size_sm btn_reset" icon="" label="">
          <span class="a11y">초기화</span>
        </q-btn>
        <q-btn class="size_sm btn_search" fill unelevated label="조회" />
      </div>
    </div>

    <q-card class="wrap_table_box">
      <!-- selectable_table type_01 -->
      <div class="table_dk">
        <div class="table_top">
          <div class="btn_wrap col-12 gap10">
            <q-btn class="size_sm" outline label="선택삭제" />
            <q-btn class="size_sm" outline label="양식지정" />
            <q-btn class="size_sm" outline label="화면구성" />
            <q-btn fill unelevated outline class="size_sm" label="수정" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_sm"
              label="신규등록"
            />
          </div>
        </div>

        <q-table
          :rows="tableRows"
          :columns="tableColumns"
          row-key="idx"
          v-model:selected="table_selected"
          selection="multiple"
          v-model:pagination="dataPagination"
          hide-bottom
          hide-pagination
          separator="cell"
        >
          <template v-slot:header="props">
            <q-tr :props="props">
              <q-th class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-th>
              <q-th class="">게시판명</q-th>
              <q-th class="">게시판 종류</q-th>
              <q-th class="">테이블명</q-th>
              <q-th class="">등록자</q-th>
              <q-th class="">등록일자</q-th>
              <q-th class="">바로가기</q-th>
            </q-tr>
          </template>
          <template v-slot:body="props">
            <q-tr :class="props.row.state" :props="props">
              <q-td class="select"
                ><q-checkbox v-model="props.selected" color="black"
              /></q-td>
              <q-td key="tdata1" class="cursor">
                {{ props.row.tdata1 }}
              </q-td>
              <q-td key="tdata2" class="w150 text-center">
                {{ props.row.tdata2 }}
              </q-td>
              <q-td key="tdata3" class="">
                {{ props.row.tdata3 }}
              </q-td>
              <q-td key="tdata4" class="w150 text-center">
                {{ props.row.tdata4 }}
              </q-td>
              <q-td key="tdata5" class="w150 text-center">
                {{ props.row.tdata5 }}
              </q-td>
              <q-td key="btn" :props="props.btn" class="w150 hasbtn detail">
                <q-btn
                  outline
                  class="size_xxs btn_detail_view"
                  label="열기"
                  @click="tableEvt(props.row.idx)"
                >
                </q-btn>
              </q-td>
            </q-tr>
          </template>
        </q-table>

        <!-- 페이지네이션 -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // 페이지네이션 -->
      </div>
      <!--// selectable_table type_01-->
    </q-card>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const boardName = ref(['']);
const writer = ref(['']);

//table데이터
const table_selected = ref([]);
const tableColumns = ref([
  {
    name: 'tdata1',
    label: '게시판명',
    sortable: false,
    align: 'center',
    field: (row) => row.tableName,
  },
  {
    name: 'tdata2',
    label: '게시판 종류',
    field: 'name',
    sortable: false,
    align: 'center',
    field: (row) => row.author,
  },
  {
    name: 'tdata3',
    label: '테이블명',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
  {
    name: 'tdata4',
    label: '등록자',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
  {
    name: 'tdata5',
    label: '등록일자',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
  {
    name: 'tdata6',
    label: '등록일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
  {
    name: 'tdata7',
    label: '바로가기',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.date,
  },
]);
const tableRows = ref([
  {
    idx: '1',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '2',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '3',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '4',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '5',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '6',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },

  {
    idx: '7',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '8',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '9',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '10',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '11',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
  {
    idx: '12',
    tdata1: '대교게시판',
    tdata2: '목록형 / 영구',
    tdata3: 'TBBS_HELPDESKFAQ',
    tdata4: '홍길동',
    tdata5: '2023.04.17',
    btn: false,
  },
]);

//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
