<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 large">
        <!-- 팝업 제목 영역 -->
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">우편번호 조회</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 영역 -->
        <q-card-section class="dialog_content">
          <!-- table_search_area type_03 -->
          <div class="table_search_area type_03">
            <!-- <h3>검색어를 입력하세요</h3> -->
            <q-input
              class="inp_search"
              for=""
              outlined
              dense
              v-model="dataFrom.search"
              placeholder="검색어를 입력하세요 예시 : 도로명(반포대로 58), 건물명(독립기념관), 지번(삼성동 25)"
            />
            <div class="btn_area">
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <!--// table_search_area type_03 -->
          <!-- selectable_table type_01 -->
          <div class="selectable_table type_01">
            <q-table
              :rows="authorityRows"
              :columns="authorityColumns"
              row-key="idx"
              v-model:selected="authoritySelected"
              selection="single"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header="props">
                <q-tr :props="props">
                  <q-th class="select">선택</q-th>
                  <q-th class="">우편번호</q-th>
                  <q-th class="">주소</q-th>
                </q-tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td class="select">
                    <q-checkbox v-model="props.selected" color="black" />
                    <!-- <q-radio
                      v-model="dataFrom.allow"
                      val="true"
                      color="orange"
                      checked-icon="trip_origin" unchecked-icon="radio_button_unchecked" class="check_to_radio"
                    /> -->
                  </q-td>
                  <q-td key="tdada1" class="text-center">{{
                    props.row.code
                  }}</q-td>
                  <q-td key="address" class="text-left">
                    {{ props.row.address }}<br />
                    {{ props.row.address2 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>

            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
          </div>
          <!--// selectable_table type_01-->
        </q-card-section>

        <!-- 버튼 -->
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const dataFrom = ref({
  id: '',
  name: '',
  search: '',
  allow: '',
  category: '',
  forbidden: '',
});

//table데이터
const authoritySelected = ref([]);

const authorityColumns = ref([
  {
    name: 'tdata1',
    label: '우편번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'address',
    label: '주소',
    sortable: false,
    align: 'center',
    field: (row) => row.address,
  },
]);
const authorityRows = ref([
  {
    idx: '1',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '2',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '3',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '4',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '5',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '6',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '1',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '2',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '3',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '4',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '5',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
  {
    idx: '6',
    category: '시스템관리자',
    code: '08708',
    address: '(도로명) 서울 관악구 보라매로 3길 1',
    address2: '(지번) 서울 관악구 봉천동 702-107 (행정동 : 보라매동)',
  },
]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
