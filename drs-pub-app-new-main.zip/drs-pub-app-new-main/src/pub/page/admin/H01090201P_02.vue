<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메시지 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li>
              <span class="as_dt required">시스템 유형</span>
              <q-select
                class="as_dd"
                outlined
                dense
                v-model="dataFrom.sys"
                :options="sysSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
              ></q-select>
            </li>
            <li>
              <span class="as_dt required">카테고리</span>
              <q-input
                v-model="dataFrom.category"
                class="as_dd hide_label inp_search"
                label="* 카테고리"
                outlined
                placeholder="카테고리를 검색하세요"
                stack-label
                dense
              >
                <!-- <template v-slot:label>메시지 ID</template> -->
                <template v-slot:append>
                  <q-icon
                    name="icon-search"
                    class="icon_svg"
                    flat
                    :ripple="false"
                  />
                </template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required">메시지구분</span>
              <q-select
                class="as_dd"
                outlined
                dense
                v-model="dataFrom.typeMsg"
                :options="typeMsgOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
              ></q-select>
            </li>
            <li>
              <span class="as_dt required">메시지 명</span>
              <q-input
                v-model="dataFrom.name"
                class="as_dd hide_label"
                label="* 메시지 명"
                outlined
                placeholder="메시지 명을 입력하세요"
                stack-label
                dense
              >
                <template v-slot:label>메시지 명</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required">메시지 내용</span>
              <q-input
                class="as_dd hide_label"
                outlined
                placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
                type="textarea"
                v-model="dataFrom.txt"
              >
                <template v-slot:label>메시지 내용</template>
              </q-input>
            </li>

            <li>
              <span class="as_dt required">사용여부</span>
              <div class="as_dd">
                <q-radio
                  v-model="dataFrom.allow"
                  val="true"
                  label="사용"
                  color="black"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  class="check_to_radio"
                />
                <q-radio
                  v-model="dataFrom.allow"
                  val="false"
                  label="사용안함"
                  color="black"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  class="check_to_radio"
                />
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  category: '카테고리를 선택하세요',
  sys: '선택하세요',
  typeMsg: '선택하세요',
  allow: 'true',
});
const sysSelectOption = ref([
  {
    id: 'type01',
    desc: '시스템1',
  },
  {
    id: 'type02',
    desc: '시스템2',
  },
]);
const typeMsgOption = ref([
  {
    id: 'type01',
    desc: '타입1',
  },
  {
    id: 'type02',
    desc: '타입2',
  },
]);
</script>
