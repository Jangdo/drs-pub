<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 double inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">신고게시물 상세</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="">
            <table class="table_row_admin mb0">
              <colgroup>
                <col style="width: 110px" />
                <col />
                <col style="width: 110px" />
                <col />
              </colgroup>
              <tbody>
                <tr>
                  <th>게시판</th>
                  <td class="posting" colspan="3">[기타] 신고</td>
                </tr>
                <tr>
                  <th>게시물 제목</th>
                  <td class="posting" colspan="3">신고테스트</td>
                </tr>
                <tr>
                  <th class="valign_middle">게시판 내용</th>
                  <td class="posting py20" colspan="3">
                    직원 XXX 에 대한 비방글..<br />
                    신고게시물 내용 테스트입니다.<br />
                    피츠패트릭은 17일(한국시각) 미국 사우스캐롤라이나주 힐턴
                    헤드의 하버타운 골프링크스(파71)에서 열린 미국프로골프(PGA)
                    투어 RBC 헤리티지 최종 라운드에서 버디 4개와 보기 1개로
                    3타를 줄였다. 1-4라운드 합계 17언더파 267타를 기록한
                    피츠패트릭은 스피스와 동타를 기록, 연장 승부에 돌입했다.
                    피츠패트릭과 스피스는 1, 2차 연장에서 나란히 파를 기록하며
                    승부를 가리지 못했다. 하지만 3차 연장에서 피츠패트릭이
                    버디를 성공시키며 우승 트로피의 주인이 됐다.
                  </td>
                </tr>
                <tr>
                  <th>신고자</th>
                  <td class="posting">홍길동</td>
                  <th class="line_l">신고일자</th>
                  <td class="posting">2023.02.01 08:23:45</td>
                </tr>
                <tr>
                  <th>등록자</th>
                  <td class="posting">홍길동</td>
                  <th class="line_l">등록일자</th>
                  <td class="posting">2023.02.01 08:23:45</td>
                </tr>
              </tbody>
            </table>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);
</script>
