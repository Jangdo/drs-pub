<template>
  <div class="inner_admin">
    <div class="cnt_top">
      <h2 class="title">{{ $route.name }}</h2>
      <Breadcrumbs />
    </div>

    <!-- wrapper_tab -->
    <div class="wrapper_tab">
      <!-- 탭 상단 선택 -->
      <q-tabs
        v-model="tab"
        dense
        class="tab_basic mb40"
        color="white"
        active-color="white"
        active-bg-color="primary"
        indicator-color="transparent"
        align="justify"
        narrow-indicator
        outside-arrows
      >
        <q-tab name="tab1" label="기본정보" :ripple="false" />
        <q-tab name="tab2" label="컬럼설정" :ripple="false" />
      </q-tabs>
      <!--// 탭 상단 선택 -->
      <!-- tab-panels -->
      <q-tab-panels v-model="tab" animated>
        <!-- tab1 컨텐츠 -->
        <q-tab-panel name="tab1">tab1</q-tab-panel>
        <!--// tab1 컨텐츠 -->
        <!-- tab2 컨텐츠 -->
        <q-tab-panel name="tab2">
          <div class="wrap_table_box">
            <!-- editable_table -->
            <div class="table_row_admin">
              <q-table
                :rows="tableRows"
                :columns="tableColumns"
                row-key="idx"
                selection="multiple"
                v-model:pagination="table_pagination"
                hide-bottom
                hide-pagination
                separator="cell"
              >
                <template v-slot:header="props">
                  <q-tr :props="props">
                    <q-th
                      v-for="col in props.cols"
                      :key="col.name"
                      :props="props"
                    >
                      <span :class="col.class">{{ col.label }}</span>
                    </q-th>
                  </q-tr>
                </template>
                <template v-slot:body="props">
                  <q-tr :class="props.row.state" :props="props">
                    <q-td key="columnName" class="">
                      {{ props.row.columnName }}
                      <span
                        v-if="props.row.columnNameImpact"
                        class="text-orange ml10"
                        >&#9670;</span
                      >
                    </q-td>
                    <q-td key="name">
                      <div class="search_item type_full">
                        <q-input
                          v-model="props.row.name"
                          class="inp_search"
                          outlined
                          placeholder="제목"
                        ></q-input>
                      </div>
                    </q-td>
                    <q-td key="size" class="text-right">
                      {{ props.row.size }}</q-td
                    >
                    <q-td key="period" class=""> {{ props.row.type }}</q-td>
                    <q-td class="select text-center">
                      <q-checkbox
                        :disable="props.row.allowDisable"
                        v-model="props.row.allow"
                        color="black"
                      />
                    </q-td>
                    <q-td class="text-center">
                      <q-checkbox
                        :disable="props.row.listDisable"
                        v-model="props.row.list"
                        color="black"
                      />
                    </q-td>
                    <q-td class="text-center">
                      <q-checkbox
                        :disable="props.row.registrationDisable"
                        v-model="props.row.registration"
                        color="black"
                      />
                    </q-td>
                    <q-td class="text-center">
                      <q-checkbox
                        :disable="props.row.searchDisable"
                        v-model="props.row.search"
                        color="black"
                      />
                    </q-td>
                    <q-td class="text-center">
                      <q-input
                        v-model="props.row.columnWidth"
                        class="inp_search"
                        outlined
                        placeholder="넓이"
                        input-class="text-right"
                      ></q-input>
                    </q-td>
                  </q-tr>
                </template>
              </q-table>
            </div>
            <div class="btn_area btn_bottom_type01">
              <q-btn
                unelevated
                outline
                color="grey-4"
                class="size_lg"
                label="취소"
              />
              <q-btn unelevated color="black" class="size_lg" label="저장" />
            </div>
            <!--// editable_table -->
          </div>
        </q-tab-panel>
        <!--// tab2 컨텐츠 -->
        <!-- tab3 컨텐츠 -->
        <q-tab-panel name="tab3"> tab3 </q-tab-panel>
        <!--// tab3 컨텐츠 -->
      </q-tab-panels>
      <!--// tab-panels -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab2');

//table데이터

const tableColumns = ref([
  {
    name: 'columnName',
    label: '테이블 컬럼명',
    sortable: false,
    align: 'center',
    field: (row) => row.columnName,
  },
  {
    name: 'name',
    label: '표시명',
    sortable: false,
    class: 'require',
    align: 'center',
    field: (row) => row.name,
  },
  {
    name: 'size',
    label: '크기',
    sortable: false,
    align: 'center',
    field: (row) => row.size,
  },
  {
    name: 'type',
    label: '유형',
    sortable: false,
    align: 'center',
    field: (row) => row.type,
  },
  {
    name: 'allow',
    label: '사용',
    sortable: false,
    align: 'center',
    field: (row) => row.allow,
  },
  {
    name: 'list',
    label: '목록',
    sortable: false,
    align: 'center',
    field: (row) => row.list,
  },
  {
    name: 'registration',
    label: '등록',
    sortable: false,
    align: 'center',
    field: (row) => row.registration,
  },
  {
    name: 'search',
    label: '검색',
    sortable: false,
    align: 'center',
    field: (row) => row.search,
  },
  {
    name: 'columnWidth',
    label: '넓이',
    sortable: false,
    align: 'center',
    field: (row) => row.columnWidth,
  },
]);

const tableRows = ref([
  {
    idx: '1',
    columnName: 'POST_TITLE',
    columnNameImpact: true,
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '100',
  },
  {
    idx: '2',
    columnName: 'POST_TITLE',
    columnNameImpact: false,
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '3',
    columnName: 'POST_TITLE',
    columnNameImpact: true,
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '4',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    allowDisable: true,
    list: true,
    listDisable: true,
    registration: false,
    registrationDisable: true,
    search: false,
    searchDisable: true,
    columnWidth: '',
  },
  {
    idx: '5',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: false,
    registration: true,
    search: false,
    columnWidth: '',
  },
  {
    idx: '6',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '7',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '8',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '9',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '10',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
  {
    idx: '11',
    columnName: 'POST_TITLE',
    name: '',
    size: '330',
    type: 'TIMESTAMP',
    allow: true,
    list: true,
    registration: true,
    search: true,
    columnWidth: '',
  },
]);

const table_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});
</script>
<style lang="scss">
@import '../../../css/mixin.scss';

.q-table {
  span.require:after {
    display: inline-block;
    content: '*';
    padding-left: 5px;
    color: $orange;
  }
}
</style>
