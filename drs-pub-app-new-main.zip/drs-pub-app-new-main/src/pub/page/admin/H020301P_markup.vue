<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">메시지 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <!-- inner_list -->
          <ul class="inner_list">
            <li>
              <span class="as_dt required">메시지 ID</span>
              <q-input
                v-model="dataFrom.id"
                class="as_dd hide_label"
                label="* 메시지 ID"
                outlined
                placeholder="메시지 명을 입력하세요"
                stack-label
                dense
              >
                <template v-slot:label>메시지 ID</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required">메시지 명</span>
              <q-input
                v-model="dataFrom.name"
                class="as_dd hide_label"
                label="* 메시지 명"
                outlined
                placeholder="메시지 명을 입력하세요"
                stack-label
                dense
              >
                <template v-slot:label>메시지 명</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required">메시지 내용</span>
              <q-input
                class="as_dd hide_label"
                outlined
                placeholder="메시지 내용을 입력하세요 [##파라미터명##]을 구분하여 입력하시기 바랍니다."
                type="textarea"
                v-model="dataFrom.txt"
              >
                <template v-slot:label>메시지 내용</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required">카테고리</span>
              <q-btn
                class="as_dd size_sm btn_category_select"
                icon="ion-ios-list"
                outline
                unelevated
                :label="dataFrom.category"
                @click="clickCategory()"
              />
            </li>
            <li>
              <span class="as_dt required">구분</span>
              <q-select
                class="as_dd"
                outlined
                dense
                v-model="dataFrom.state"
                :options="stateSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
              ></q-select>
            </li>
            <li>
              <span class="as_dt required">사용여부</span>
              <div class="as_dd">
                <q-radio
                  v-model="dataFrom.allow"
                  val="true"
                  label="사용"
                  color="orange"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  class="check_to_radio"
                />
                <q-radio
                  v-model="dataFrom.allow"
                  val="false"
                  label="사용안함"
                  color="orange"
                  checked-icon="trip_origin"
                  unchecked-icon="radio_button_unchecked"
                  class="check_to_radio"
                />
              </div>
            </li>
          </ul>
          <!--// inner_list -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_save"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  category: '카테고리를 선택하세요',
  state: '선택하세요',
  allow: 'true',
});
//
const stateSelectOption = ref([
  {
    id: 'confirm',
    desc: '확인',
  },
  {
    id: 'alert',
    desc: '알림',
  },
]);

function clickCategory() {
  console.log('카테고리 팝업 호출');
}
</script>

<style lang="scss">
// .a11y {
//   @extend %a11y;
// }
// %a11y {
//   overflow: hidden;
//   position: absolute;
//   clip: rect(0, 0, 0, 0);
//   clip-path: circle(0);
//   width: 1px;
//   height: 1px;
//   margin: -1px;
//   border: 0;
//   padding: 0;
//   white-space: nowrap;
//   background: transparent;
// }

// body .q-input.hide_label {
//   .q-field__inner {
//     .q-field__label {
//       @extend %a11y;
//     }
//   }
// }
</style>
