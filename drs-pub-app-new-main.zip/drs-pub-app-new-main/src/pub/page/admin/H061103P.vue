<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 wide">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">조직 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row">
            <!-- 테이블 -->
            <div class="" style="max-width: 350px">
              <q-list dense bordered padding class="rounded-borders">
                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>

                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>

                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>
              </q-list>
            </div>
            <!-- // 테이블 -->

            <!-- 버튼 -->
            <div class="column mr20 ml20 justify-center">
              <div>
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="추가"
                />
              </div>
              <div class="mt10">
                <q-btn
                  fill
                  unelevated
                  class="size_xs btn_tbl_add"
                  color="grey-3"
                  label="삭제"
                />
              </div>
            </div>
            <!-- // 버튼 -->

            <!-- 테이블 -->
            <div class="" style="max-width: 350px">
              <q-list dense bordered padding class="rounded-borders">
                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>

                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>

                <q-item clickable v-ripple>
                  <q-item-section> Item </q-item-section>
                </q-item>
              </q-list>
            </div>
            <!-- // 테이블 -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="primary"
            class="size_sm"
            label="설정"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
</script>
