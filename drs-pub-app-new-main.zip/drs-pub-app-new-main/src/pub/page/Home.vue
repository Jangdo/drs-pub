<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <div class="card_profile">
      <!-- infor -->

      <div class="infor">
        <div class="pic_area">
          <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
        </div>
        <div class="txt_area">
          <div class="tit_area">
            <p class="text-h2">김윤찬</p>
            <span class="badge">신입</span>
          </div>
          <div class="more"><span>초등1</span><span>강남교육국 외2</span></div>
        </div>
      </div>
      <!--// infor -->
      <!-- main_btn_area -->
      <div class="main_btn_area">
        <q-btn flat>
          <q-icon name="icon-user_outline" class="icon_svg"></q-icon>
          <span class="txt">회원정보</span>
        </q-btn>
        <q-btn flat>
          <q-icon name="icon-user_outline" class="icon_svg"></q-icon>
          <span class="txt">학습관리</span>
        </q-btn>
        <q-btn flat>
          <q-icon name="icon-user_outline" class="icon_svg"></q-icon>
          <span class="txt">회비현황</span>
        </q-btn>
        <q-btn flat>
          <q-icon name="icon-user_outline" class="icon_svg"></q-icon>
          <span class="txt">이력관리</span>
        </q-btn>
      </div>
      <!--// main_btn_area -->
      <!-- parents_area -->
      <div class="parents_area">
        <p class="tit text18">김윤찬 어머님</p>
        <div class="btn_area">
          <q-btn round icon="map" />
           <q-btn round icon="mail" />
           <q-btn round icon="call" />
        </div>
      </div>
      <!--// parents_area -->
    </div>

    <!--
    <ul class="list_link">
      <li>
        <q-btn to="/" flat>
           <q-icon name="icon-computer" class="icon_svg"></q-icon>

        </q-btn>
      </li>
    </ul> -->
  </div>
</template>

<script setup>
// import { ref} from 'vue';
</script>
<style lang="scss">
.q-page-container {
  // margin-top: 75px;
}
</style>
