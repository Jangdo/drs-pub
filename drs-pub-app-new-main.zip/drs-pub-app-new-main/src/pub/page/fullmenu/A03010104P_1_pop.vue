<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form type_bg">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">주소검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="wrap_contents_box">
            <!-- 검색폼 -->
            <q-input
              class="inp_search"
              outlined
              dense
              placeholder="주소를 검색해 주세요"
              v-model="addrSearch"
            >
              <template v-slot:append>
                <q-icon name="icon-close" class="icon_svg" />
              </template>
            </q-input>
          </div>

          <!-- 검색결과 -->

          <div class="wrap_contents_box">
            <section class="search_addr_result">
              <!-- 
                검색결과 화면 : A03010104P_pop.vue 
              -->

              <!-- 검색결과 없음 -->
              <div>
                <p class="title4 text-center">검색결과가 없습니다.</p>
                <p class="text-phara2 text-grey-3 text-center mt10">
                  도로명 + 건물번호<br />
                  지역명(동/리) + 번지<br />
                  지역명(동/리) + 건물명(아파트명)
                </p>
              </div>
            </section>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

// 검색
const addrSearch = ref('보라매로3길');
</script>
