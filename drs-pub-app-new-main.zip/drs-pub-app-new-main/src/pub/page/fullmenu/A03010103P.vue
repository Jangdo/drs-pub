<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">주소검색</h1>
      <Breadcrumbs />
    </div>

    <div class="member_page">
      <section>
        <!-- 검색폼 -->
        <q-input
          class="inp_search"
          outlined
          dense
          placeholder="주소를 검색해 주세요"
          v-model="addrSearch"
        >
          <template v-slot:append>
            <q-icon name="icon-search" class="icon_svg" />
          </template>
        </q-input>
      </section>

      <section class="search_addr_result">
        <!-- 검색결과 -->
        <div>
          <p class="title4 text-center">주소를 검색해 주세요.</p>
          <p class="text-phara2 text-grey-3 text-center mt10">
            도로명 + 건물번호<br />
            지역명(동/리) + 번지<br />
            지역명(동/리) + 건물명(아파트명)
          </p>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const addrSearch = ref('');
</script>
