<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        등록확인 결과
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="result">
            <div class="pic_area">
              <img src="/img/result-man-check.svg" alt="" />
            </div>
            <div class="impact_txt">
              <p class="text-h3 text-grey-3">
                <span class="text-grey-1">김윤찬</span>님은 <br />
                <span class="text-grey-1">마카다미아</span>에서
                <span class="text-orange">입회회원</span>으로 <br />
                등록하셨습니다
              </p>
            </div>
            <div class="more_infor text-phara1">
              드림스 회원등록 버튼을 선택하시면 <br />
              바로 드림스 입회회원 등록이 가능합니다.<br />
              체험 또는 입회를 하실 수 있습니다.
            </div>
          </div>

          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                fill
                unelevated
                v-close-popup
                color="black"
                class="size_lg"
                label="드림스 회원등록"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
