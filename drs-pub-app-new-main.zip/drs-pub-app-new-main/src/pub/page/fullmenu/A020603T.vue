<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1>
      <Breadcrumbs />
    </div>
    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li class="border">
            <p class="title1 name">
              <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
              승인요청
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">5</strong>건</span
              >
            </div>
          </li>
        </ul>
      </section>
      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow row_4"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">영업지표</div>
              </div>
            </q-tab>
            <q-tab name="tab2" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">과목현황</div>
              </div>
            </q-tab>
            <q-tab name="tab3" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">조직현황</div>
              </div>
            </q-tab>
            <q-tab name="tab4" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">입금현황</div>
              </div>
            </q-tab>
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1"> </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2"></q-tab-panel>
            <!--// tab2 컨텐츠 -->
            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3">
              <div class="chart_area">
                <div class="chart_details type02 wrap_more_content">
                  <ul>
                    <li>
                      <div class="top">
                        <div class="title1">조직</div>
                      </div>
                      <div class="bottom">
                        <q-btn
                          unelevated
                          class="title1 text-primary mob_none"
                          label="125,343"
                        >
                          <q-icon
                            name="icon-arrow-right"
                            class="icon_svg ml8 filter-grey-3"
                          ></q-icon>
                        </q-btn>
                        <div class="title1 text-primary mob_block">125,343</div>
                      </div>
                    </li>
                    <li>
                      <div class="top">
                        <div class="title1">팀</div>
                      </div>
                      <div class="bottom">
                        <div class="title1 text-primary">125,343</div>
                      </div>
                    </li>
                    <li>
                      <div class="top">
                        <div class="title1">채널</div>
                      </div>
                      <div class="bottom">
                        <q-btn
                          unelevated
                          class="title1 text-primary mob_none"
                          label="38.00%"
                        >
                          <q-icon
                            name="icon-arrow-right"
                            class="icon_svg ml8 filter-grey-3"
                          ></q-icon>
                        </q-btn>
                        <div class="title1 text-primary mob_block">125,343</div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="wrap_more_content">
                  <dl class="a_list_cnt_01">
                    <dt>
                      <span class="title">구성원 관리</span>
                      <q-btn outline class="size_xxs no_line">
                        <q-icon
                          name="icon-arrow-right"
                          size="20px"
                          class="icon_svg filter-grey-3"
                        />
                      </q-btn>
                    </dt>
                    <dd>
                      <ul class="list_type_chart">
                        <li>
                          <div class="as_dt">국장</div>
                          <div class="as_dd">123</div>
                        </li>
                        <li>
                          <div class="as_dt">팀장</div>
                          <div class="as_dd">1</div>
                        </li>
                        <li>
                          <div class="as_dt">업무선생님</div>
                          <div class="as_dd">15</div>
                        </li>
                        <li>
                          <div class="as_dt">선생님</div>
                          <div class="as_dd">15</div>
                        </li>
                      </ul>
                    </dd>
                  </dl>
                  <!-- <q-expansion-item
                  class="expansion_custom type_a02"
                  group="somegroup"
                >
                  <template v-slot:header>
                    <q-item-section class="tit_area">
                      <span class="title">구성원 관리</span>
                    </q-item-section>
                  </template>
                  <q-card>
                    <q-card-section>
                      <ul class="list_type_chart">
                        <li>
                          <div class="as_dt">국장</div>
                          <div class="as_dd">123</div>
                        </li>
                        <li>
                          <div class="as_dt">팀장</div>
                          <div class="as_dd">1</div>
                        </li>
                        <li>
                          <div class="as_dt">업무선생님</div>
                          <div class="as_dd">15</div>
                        </li>
                        <li>
                          <div class="as_dt">선생님</div>
                          <div class="as_dd">15</div>
                        </li>
                      </ul>
                    </q-card-section>
                  </q-card>
                </q-expansion-item> -->
                </div>
              </div>
            </q-tab-panel>
            <!--// tab3 컨텐츠 -->
            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4"></q-tab-panel>
            <!--// tab4 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>

      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab3');
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';
</style>
