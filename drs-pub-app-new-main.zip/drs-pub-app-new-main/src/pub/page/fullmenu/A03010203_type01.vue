<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        등록확인 결과
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="result">
            <div class="pic_area">
              <img src="/img/result-man-check.svg" alt="" />
            </div>
            <div class="impact_txt">
              <p class="text-h3 text-grey-3">
                <span class="text-grey-1">김윤찬</span>님이
                <span class="text-orange">입회회원</span>으로 <br />
                등록신청 되었습니다
              </p>
            </div>
            <div class="more_infor text-phara1">
              휴대폰번호로 회원가입 url을 전송하였습니다 <br />
              고객 등록 완료 후 입회가 가능합니다
            </div>
          </div>

          <ul class="list_check_bullet mt40">
            <li><span>인증방법</span><strong>마카다미아</strong></li>
            <li><span>인증방법</span><strong>010-1234-5678</strong></li>
          </ul>

          <div class="list_bg_block mt20">
            <ul class="ul_custom">
              <li>평일 09시~18시까지 녹취업무가 진행됩니다.</li>
              <li>17시 이후 입력시, 다음날 09시부터 연락드릴 에정입니다.</li>
              <li>
                고객만족팀으로 회원정보 연동 후에는 수정 및 삭제가 불가합니다.
              </li>
            </ul>
          </div>

          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                unelevated
                outline
                color="black"
                class="size_lg"
                label="회원프로필 보기"
              />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="등록 내역 확인"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
