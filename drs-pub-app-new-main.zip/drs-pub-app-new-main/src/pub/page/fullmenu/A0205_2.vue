<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li>
            <p class="title1 name">
              <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
              승인요청
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">5</strong>건</span
              >
            </div>
          </li>
          <li>
            <p class="title1 name">
              <q-icon name="icon-user_add" class="icon_svg"></q-icon>
              입회상담
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">12</strong>건</span
              >
            </div>
          </li>
          <li>
            <p class="title1 name">
              <q-icon name="icon-message" class="icon_svg"></q-icon>
              일반상담
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">2</strong>건</span
              >
            </div>
          </li>
        </ul>
        <div class="gray_roundbox">
          <q-expansion-item
            default-opened
            class="border_type"
            label="수업현황/출결현황"
          >
            <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
            <!-- wrap_linear-progress -->
            <div class="wrap_linear-progress">
              <div class="tit_area">
                <span class="tit title3">1팀</span>
                <div class="balloon">
                  {{ progress }} <span class="unit">%</span>
                </div>
              </div>
              <div class="linear_progress">
                <div class="pointer" :style="{ width: progress + '%' }"></div>
              </div>
            </div>
            <!--// wrap_linear-progress -->
            <div class="wrap_linear-progress">
              <div class="tit_area">
                <span class="tit title3">2팀</span>
                <div class="balloon">
                  {{ progress }} <span class="unit">%</span>
                </div>
              </div>
              <div class="linear_progress green">
                <div class="pointer" :style="{ width: progress + '%' }"></div>
              </div>
            </div>
            <div class="wrap_linear-progress">
              <div class="tit_area">
                <span class="tit title3">신대방 LC</span>
                <div class="balloon">
                  {{ progress }} <span class="unit">%</span>
                </div>
              </div>
              <div class="linear_progress yellow">
                <div class="pointer" :style="{ width: progress + '%' }"></div>
              </div>
            </div>
            <div class="wrap_linear-progress">
              <div class="tit_area">
                <span class="tit title3">보라매 LC</span>
                <div class="balloon">
                  {{ progress }} <span class="unit">%</span>
                </div>
              </div>
              <div class="linear_progress orange">
                <div class="pointer" :style="{ width: progress + '%' }"></div>
              </div>
            </div>
          </q-expansion-item>
        </div>
      </section>
      <section>
        <q-list class="pay_list">
          <q-expansion-item class="expansion_custom type03" expand-icon-toggle>
            <template v-slot:header>
              <q-item-section class="tit_area">
                <div class="title">영업지표</div>
                <div class="process_area">
                  <span class="txt">순종수</span>
                  <span class="num">+234</span>
                </div>
              </q-item-section>
            </template>
            <q-card>
              <div class="date_area">
                <q-icon name="icon-check-grey" class="icon_svg"></q-icon>
                <span>2023.1</span>
                <span>월 기준</span>
              </div>
              <q-card-section class="max_295">
                <table class="sales_index">
                  <thead>
                    <tr>
                      <th>
                        <span class="txt">순증수</span>
                        <span class="num text-black">2714</span>
                      </th>
                      <th>
                        <span class="txt">순증지수</span>
                        <span class="num text-black">2714</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">입회</span>
                        <span class="num text-warning">23</span>
                      </td>
                      <td>
                        <span class="txt">입회지수</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">입회</span>
                        <span class="num text-orange">23</span>
                      </td>
                      <td>
                        <span class="txt">입회지수</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">입회</span>
                        <span class="num text-positive">23</span>
                      </td>
                      <td>
                        <span class="txt">입회지수</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td>
                        <span class="txt">총원</span>
                        <span class="num text-primary">634</span>
                      </td>
                      <td>
                        <span class="txt">총원지수</span>
                        <span class="num text-black">23,456</span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </q-card-section>
            </q-card>
            <div class="btm_action">
              <div class="btm_row">
                <div class="info_area">
                  <span class="txt">영업마감일</span>
                  <div class="day">
                    <span>D</span>
                    <span>-</span>
                    <span>8</span>
                  </div>
                </div>
                <q-btn
                  fill
                  unelevated
                  color="black"
                  class="size_sm"
                  label="내역보기"
                />
              </div>
            </div>
          </q-expansion-item>
        </q-list>
        <!-- 링크 -->
        <div class="member_main_link grid-3">
          <div class="link_item">
            <q-btn flat class="btn_link on">
              <p class="name">
                입회/체험 <br style="display: block" />회원등록
              </p>
              <q-icon name="icon-graduation" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">
                상품<br />
                검색
              </p>
              <q-icon name="icon-search-alt" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">
                즉시<br />
                결제
              </p>
              <q-icon name="icon-coin" class="icon_svg"></q-icon>
            </q-btn>
          </div>
        </div>
        <ul class="list_type_1 mt20">
          <li>
            <p class="title1 name">
              <q-icon name="icon-card" class="filter-grey-3 icon_svg"></q-icon>
              회비미납
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">12</strong>/153건</span
              >
            </div>
          </li>
          <li>
            <p class="title1 name">
              <q-icon
                name="icon-clipboard"
                class="filter-grey-3 icon_svg"
              ></q-icon>
              진도미결정
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">2</strong>/15건</span
              >
            </div>
          </li>
          <li>
            <p class="title1 name">
              <q-icon name="icon-book" class="filter-grey-3 icon_svg"></q-icon>
              긴급교재
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">2</strong>/15건</span
              >
            </div>
          </li>
        </ul>
      </section>

      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="new" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-write"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">입금현황</div>
              </div>
            </q-tab>
            <q-tab name="birth" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-cake"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">생일알림</div>
              </div></q-tab
            >
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="new">
              <div class="wrap_list_page_a">
                <ul class="list_page_a">
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                </ul>

                <div class="btn_area mt30">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
            </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="birth">
              <div class="wrap_list_page_a">
                <ul class="list_page_a">
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                </ul>

                <div class="btn_area mt30">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>

      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const tab = ref('new');
const progress = ref('26');
</script>
<style lang="scss" scoped>
#manager .member_main_link .btn_link.on {
  background: #2e9dd1;
}
.member_main_link.grid-3 {
  display: flex;
  justify-content: space-between;
  .btn_link {
    height: 130px;
  }
  .link_item {
    width: calc((100% - 30px) / 3);
  }
}
.wrap_linear-progress {
  margin-bottom: 0;
  & > .tit_area {
    & > .tit {
      display: flex;
      align-items: center;
      flex-direction: row;
    }
  }
  .linear_progress {
    margin: 0;
  }
}
.gray_roundbox {
  border-radius: 12px;
}

.wrapper_tab .q-tabs.tab_basic.no_shadow {
  box-shadow: none;
  .q-tab {
    &.q-tab--active .small_type_01.row {
      .q-tab__label {
        color: #fff;
      }
      .q-icon {
        filter: brightness(0) saturate(100%) invert(100%) sepia(100%)
          saturate(0%) hue-rotate(308deg) brightness(105%) contrast(101%);
      }
    }
    .q-tab__label {
      color: #767676;
    }
    .small_type_01.row {
      align-items: center;
    }
    .q-icon {
      font-size: 24px;
    }
  }
}
.wrap_list_page_a {
  .list_page_a {
    li {
      border-bottom: 1px solid #d7d7d7;
      height: 54px;
      display: flex;
      align-items: center;
      flex-direction: row;
      justify-content: space-between;
      .q-btn.date_area {
        width: 130px;
        &.flex-end {
          align-items: flex-end;
        }
      }
      .q-btn__content {
        justify-content: space-between;
      }
      span {
        font-size: 16px;
        line-height: 18px;

        margin-right: 10px;
        font-weight: 600;
      }
      .name {
        color: #000;
        font-size: 18px;
        line-height: 20px;
        margin-left: 10px;
      }
      .grade {
        color: #339f63;
      }
      .date {
        margin-right: 0;
        width: calc(100% - 24px);
        text-align: left;
      }
      .subject {
        color: #767676;
      }
      .add_txt {
        margin-left: 10px;
        margin-right: 0;
      }
      .q-btn {
        padding: 0;
        .q-icon {
          width: 24px;
          font-size: 24px;
          margin-left: 10px;
          filter: brightness(0) saturate(100%) invert(87%) sepia(0%)
            saturate(218%) hue-rotate(182deg) brightness(83%) contrast(104%);
        }
        &.on {
          .q-icon {
            filter: brightness(0) saturate(100%) invert(0%) sepia(9%)
              saturate(7500%) hue-rotate(133deg) brightness(109%) contrast(107%);
          }
        }
      }
    }
  }
  .wrap_right_btn {
    display: flex;
    flex-direction: row;
    justify-content: flex-end;
    color: #767676;
    .right_btn {
      padding: 0;
      .q-icon {
        margin-right: 6px;
        font-size: 18px;
      }
    }
  }
}
.wrap_list_page_a2 {
  .title1 {
    padding-bottom: 18px;
    border-bottom: 1px solid #d7d7d7;
  }

  .list_page_a2 {
    margin-bottom: 80px;
    li {
      height: 54px;
      display: flex;
      width: 100%;
      border-bottom: 1px solid #d7d7d7;
      & > .q-btn {
        padding: 0;
        font-size: 16px;
        line-height: 18px;
        color: #000;
        font-weight: 400;
        width: 100%;
        p {
          width: 100%;
          padding-left: 10px;
          display: flex;
          align-items: center;
          text-align: left;
          strong {
            color: #339f63;
            font-weight: 600;
            margin-right: 10px;
          }
          span {
            width: calc(100% - 37px);
            display: inline-block;
            max-width: calc(100% - 39px);
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
          }
        }
      }
    }
  }
}

body.screen--lg {
  .wrap_linear-progress {
    max-width: 780px;
    margin: 0 auto;
  }
  .q-card__section.q-card__section--vert.max_295 {
    max-width: 295px;
    margin: 0 0 0 auto;
  }
  .wrap_list_page_a {
    .list_page_a {
      li {
        border-bottom: 1px solid #d7d7d7;
        height: 54px;
        display: flex;
        align-items: center;
        flex-direction: row;

        justify-content: space-between;
        .q-btn.date_area {
          width: 200px;
        }
        span {
          font-size: 16px;
          line-height: 18px;

          margin-right: 10px;
          font-weight: 600;
        }
        .name {
          text-align: left;
          width: 90px;
        }
        .grade {
          width: 50px;
          text-align: left;
        }
        .date {
          width: 305px;
        }
        .subject {
          width: 305px;
          text-align: left;
        }
        .add_txt {
          margin: 0;
        }
      }
    }
  }
}
</style>
