<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        입회회원 등록
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <div class="cont_lg_center_400">
          <div class="block_certify">
            <p class="tit title1">인증방법을 선택해주세요</p>
            <div class="wrap_cerfiybtn">
              <q-btn class="btn_box_certify on" flat to="/">
                <div class="bg_img recording">
                  <span class="title3">녹취</span>
                </div>
              </q-btn>
              <q-btn class="btn_box_certify" flat to="/">
                <div class="bg_img macadamia">
                  <span class="title3">인증 알림톡 발송</span>
                </div>
              </q-btn>
            </div>
          </div>

          <div class="block_certify text-center">
            <p class="tit title1 title_underline">
              <q-icon name="icon-info" class="icon_svg"></q-icon>
              단체회원이신가요?
            </p>
            <p class="text-phara1 text-grey-3">
              단체회원으로 등록하려면 선택해주세요
            </p>
            <q-btn
              outline
              rounded
              color="grey-06"
              class="size_lg_rounded shadow mt20"
            >
              <div class="left">
                <span class="text-grey-3">단체회원 등록</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
              </div>
            </q-btn>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss">
// 인증방법 이미지
.q-btn__content .bg_img {
  &.recording:before {
    background-image: url(/img/member_recording-grey.svg);
  }
  &.macadamia:before {
    background-image: url(/img/member_macadamia-grey.svg);
  }

  .on & {
    &.recording:before {
      background-image: url(/img/member_recording-green.svg);
    }
    &.macadamia:before {
      background-image: url(/img/member_macadamia-green.svg);
    }
  }
}
body {
  &.screen--lg {
    .cont_lg_center_400 {
      max-width: 400px;
      margin: 0 auto;
    }
  }
}
</style>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
