<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li class="border">
            <p class="title1 name">
              <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
              승인요청
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">5</strong>건</span
              >
            </div>
          </li>
        </ul>
      </section>
      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow row_4"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">영업지표</div>
              </div>
            </q-tab>
            <q-tab name="tab2" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">과목현황</div>
              </div>
            </q-tab>
            <q-tab name="tab3" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">조직현황</div>
              </div>
            </q-tab>
            <q-tab name="tab4" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">입금현황</div>
              </div>
            </q-tab>
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1"></q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2">
              <div class="chart_area">
                <div class="wrap_chart height_2">
                  <vue-highcharts :options="chart_pie"></vue-highcharts>
                </div>

                <div class="wrap_more_content">
                  <q-table
                    class="w_all"
                    :rows="dataRows"
                    :columns="dataColumns"
                    :pagination="initialPagination"
                    row-key="idx"
                    rowsPerPage="6"
                    hide-bottom
                    separator="cell"
                  >
                    <template v-slot:bottom-row>
                      <q-tr class="tr_btm">
                        <q-td class="test-left">총계</q-td>
                        <q-td class="text-center"> 116 </q-td>
                        <q-td class="text-center"> 4.8 </q-td>
                        <q-td class="text-center"> 100 </q-td>
                      </q-tr>
                    </template>
                  </q-table>
                </div>
              </div>
              <div class="btn_area mt30 justify-center">
                <q-btn outline rounded color="grey-06" class="size_lg_rounded">
                  <div class="left">
                    <span class="text-grey-3">[전사] 조직별 영업현황</span>
                  </div>
                  <div class="right">
                    <q-icon
                      name="icon-arrow-down-grey"
                      class="icon_svg"
                    ></q-icon>
                  </div>
                </q-btn>
              </div>
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3"></q-tab-panel>
            <!--// tab3 컨텐츠 -->
            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4"></q-tab-panel>
            <!--// tab4 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>

      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab2');
const chart_pie = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
    type: 'pie',
    backgroundColor: '#F1F7FB',
  },
  colors: [
    '#BCD5F2',
    '#9747FF',
    '#44B87B',
    '#EFD26A',
    '#555d67',
    '#0964CE',
    '#BD0000',
    '#00B2BD',
    '#BD00AA',
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    width: '100%',
    verticalAlign: 'top',
    itemMarginTop: 0,
    padding: 1,
    symbolPadding: 1,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontSize: '12',
      lineHight: '16',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  title: false,
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },
  accessibility: {
    point: {
      valueSuffix: '%',
    },
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '{point.percentage:.2f}',
        style: {
          textOutline: false,
          color: '#fff',
          fontSize: 9,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
        distance: -20,
        filter: {
          property: 'percentage',
          operator: '>',
          value: 1,
        },
      },
      showInLegend: true,
    },
  },
  series: [
    {
      name: '과목',
      borderWidth: 0,

      data: [
        { name: '국어', y: 35.7 },
        { name: '영어', y: 38.0 },
        { name: '수학', y: 12.5 },
        { name: '사회과학', y: 7.1 },
        { name: '내신완공', y: 3.1 },
        { name: '한자일본어', y: 3.6 },
        { name: '유아', y: 3.6 },
        { name: '기타', y: 3.6 },
      ],
    },
  ],
};
const dataColumns = ref([
  {
    name: 'subject',
    label: '',
    sortable: false,
    align: 'left',
    field: (row) => row.subject,
  },
  {
    name: 'subjectCount',
    label: '과목수',
    sortable: false,
    align: 'center',
    field: (row) => row.subjectCount,
  },
  {
    name: 'goods',
    label: '제품지수',
    sortable: false,
    align: 'center',
    field: (row) => row.goods,
  },
  {
    name: 'point',
    label: '평가점수',
    sortable: false,
    align: 'center',
    field: (row) => row.point,
  },
]);
const dataRows = ref([
  {
    subject: '국어',
    subjectCount: '28',
    goods: '0.8',
    point: '15',
  },
  {
    subject: '영어',
    subjectCount: '32',
    goods: '0.8',
    point: '15',
  },
  {
    subject: '수학',
    subjectCount: '32',
    goods: '0.8',
    point: '15',
  },
  {
    subject: '사회과학',
    subjectCount: '32',
    goods: '0.8',
    point: '15',
  },
  {
    subject: '내신완공',
    subjectCount: '32',
    goods: '0.8',
    point: '15',
  },
  {
    subject: '한자일본어',
    subjectCount: '32',
    goods: '0.8',
    point: '15',
  },
]);
const initialPagination = ref({
  sortBy: 'desc',
  descending: false,
  page: 1,
  rowsPerPage: 6,
  // rowsNumber: xx if getting data from a server
});
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';
.member_page.main_page:deep() {
  .q-table {
    td,
    th {
      padding: 0;
      &:first-child {
        padding-left: 10px;
      }
    }
    tr.tr_btm {
      background: #f7f7f7;
    }
  }
}
.screen--lg {
  .member_page.main_page:deep() {
    .wrap_chart.height_2 {
      width: calc(50% - 10px);
      height: 464px;
    }
  }
}
</style>
