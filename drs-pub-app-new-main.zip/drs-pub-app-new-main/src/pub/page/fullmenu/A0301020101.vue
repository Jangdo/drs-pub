<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit">입회회원 등록</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage type01 stepper_form">
          <q-stepper
            v-model="step"
            ref="stepper"
            flat
            :active-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            inactive-color="black"
            header-class="step_type00"
            inactive-icon="none"
            done-icon="none"
            active-icon="none"
            animated
          >
            <q-step :name="1" title="STEP 1 기본정보" :done="step > 1">
              <p class="text_type_info mb20">단체회원으로 등록합니다</p>

              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt required_right">이름</span>
                  <q-input
                    v-model="dataForm.name"
                    class="as_dd hide_label"
                    label="* 이름"
                    outlined
                    placeholder="이름를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>이름</template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt required_right">생년월일</span>
                  <q-input
                    outlined
                    v-model="dataForm.birth"
                    class="as_dd hide_label inp_date"
                  >
                    <template v-slot:label>생년월일</template>
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date v-model="dataForm.date" minimal> </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt required_right">성별</span>
                  <div class="as_dd">
                    <q-btn-toggle
                      class="toggle_gender"
                      v-model="dataForm.gender"
                      spread
                      unelevated
                      :toggle-color="
                        $route.matched[1].props.default.userType === 'teacher'
                          ? 'positive'
                          : 'primary'
                      "
                      text-color="grey-3"
                      :options="[
                        { label: '남', value: '남' },
                        { label: '여', value: '여' },
                      ]"
                    />
                  </div>
                </li>
                <li>
                  <span class="as_dt required_right">학년</span>
                  <div class="as_dd">
                    <q-select
                      outlined
                      dense
                      v-model="degreeSelect"
                      :options="degreeSelectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                          <q-icon name="keyboard_arrow_down"></q-icon>
                        </template> -->
                    </q-select>
                  </div>
                </li>
                <li>
                  <span class="as_dt required_right">휴대폰번호</span>
                  <div class="wrap_as_dd">
                    <div class="as_dd col2_btn">
                      <q-input
                        v-model="dataForm.phone"
                        class="as_dd hide_label"
                        label="* 휴대폰번호"
                        outlined
                        placeholder="숫자만 입력 해주세요"
                        stack-label
                        dense
                      >
                        <template v-slot:label>휴대폰번호</template>
                      </q-input>
                    </div>
                  </div>
                </li>
                <li>
                  <span class="as_dt">주소</span>
                  <q-input
                    v-model="dataForm.address"
                    class="as_dd hide_label inp_search"
                    label="* 주소"
                    outlined
                    placeholder="주소를 검색하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>주소</template>
                    <template v-slot:append>
                      <q-btn flat :ripple="false">
                        <q-icon name="icon-search_m" class="icon_svg"></q-icon>
                      </q-btn>
                    </template>
                  </q-input>
                  <q-input
                    v-model="dataForm.address2"
                    class="as_dd hide_label inp_search2 bg_white"
                    disabled
                    label="상세주소"
                    outlined
                    placeholder="상세주소"
                    stack-label
                    dense
                  >
                    <template v-slot:label>상세주소</template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt">회원등록 경로</span>
                  <div class="as_dd">
                    <q-select
                      outlined
                      dense
                      v-model="dataSelect"
                      :options="dataSelectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                          <q-icon name="keyboard_arrow_down"></q-icon>
                        </template> -->
                    </q-select>
                  </div>
                </li>
                <li>
                  <span class="as_dt required_right">증빙자료</span>
                  <div class="as_dd">
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataForm.information"
                      placeholder="첨부파일을 선택해주세요"
                      label="증빙자료선택"
                      class="hide_label file_custom"
                    >
                      <template v-slot:after>
                        <q-btn
                          fill
                          unelevated
                          class="btn_file_select"
                          color="grey-2"
                          label="선택"
                        />
                      </template>
                      <template v-slot:append>
                        <q-btn
                          flat
                          dense
                          :ripple="false"
                          class="btn_input_slot"
                        >
                          <q-icon
                            v-if="dataForm.information === null"
                            name="icon-search_m"
                            class="icon_svg"
                          ></q-icon>
                        </q-btn>
                      </template>
                    </q-file>
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </q-step>

            <q-step :name="2" title="STEP 2 보호자정보" :done="step > 2">
              <!-- inner_list -->
              <ul class="inner_list">
                <li>
                  <span class="as_dt required_right">관계</span>
                  <div class="as_dd">
                    <q-select
                      outlined
                      dense
                      v-model="relationSelect"
                      :options="relationSelectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dropdown-icon="ion-ios-arrow-down"
                    >
                      <!-- <template v-slot:append>
                          <q-icon name="keyboard_arrow_down"></q-icon>
                        </template> -->
                    </q-select>
                  </div>
                </li>
                <li>
                  <span class="as_dt required_right">이름</span>
                  <q-input
                    v-model="dataForm2.name"
                    class="as_dd hide_label"
                    label="* 이름"
                    outlined
                    placeholder="이름를 입력하세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>이름</template>
                  </q-input>
                </li>
                <li>
                  <span class="as_dt required_right">휴대폰번호</span>
                  <div class="wrap_as_dd">
                    <div class="as_dd col2_btn">
                      <q-input
                        v-model="dataForm2.phone"
                        class="as_dd hide_label"
                        label="* 휴대폰번호"
                        outlined
                        placeholder="숫자만 입력 해주세요"
                        stack-label
                        dense
                      >
                        <template v-slot:label>휴대폰번호</template>
                      </q-input>
                    </div>
                  </div>
                </li>
                <li>
                  <span class="as_dt">인증방법<strong>녹취</strong></span>
                  <div class="list_bg_block as_dd_innerlist">
                    <ul class="ul_custom">
                      <li>
                        대표보호자를 통한 인증은 반드시 회원의 대표보호자를
                        통해야 합니다.
                      </li>
                      <li>
                        대리인증은 위법행위입니다. [개인정보보호법 제 22조 제
                        6항]
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
              <!--// inner_list -->
            </q-step>

            <template v-slot:navigation>
              <q-stepper-navigation>
                <div class="btn_area btn_bottom_type01">
                  <q-btn
                    v-if="step == 1"
                    outline
                    class="size_lg"
                    color="grey-4"
                    label="인증변경"
                  />
                  <q-btn
                    v-if="step > 1"
                    outline
                    @click="$refs.stepper.previous()"
                    class="size_lg"
                    color="grey-4"
                    label="이전"
                  />
                  <q-btn
                    fill
                    unelevated
                    color="black"
                    class="size_lg"
                    @click="$refs.stepper.next(), scrolTop()"
                    :label="step === 2 ? '등록신청' : '다음'"
                  />
                </div>
              </q-stepper-navigation>
            </template>
          </q-stepper>
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
// 스텝
const step = ref(1);
function scrolTop() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  });
}

const dataForm = ref({
  birth: ref('2019.02.01'),
  name: '',
  gender: '남',
  phone: '',
  address: '',
  address2: '',
  information: null,
});
const dataForm2 = ref({
  name: '',
  phone: '',
});

const degreeSelect = ref(['선택하세요']);
const degreeSelectOption = ref([
  {
    id: '1',
    desc: '초등1',
  },
]);
const relationSelect = ref(['선택하세요']);
const relationSelectOption = ref([
  {
    id: '1',
    desc: '부모',
  },
]);
const dataSelect = ref(['선택하세요']);
const dataSelectOption = ref([
  {
    id: '1',
    desc: '친구추천',
  },
]);
</script>
