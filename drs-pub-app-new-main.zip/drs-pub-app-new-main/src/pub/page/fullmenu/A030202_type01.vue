<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        등록확인 결과
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="result">
            <div class="pic_area">
              <img src="/img/result-man-check.svg" alt="" />
            </div>
            <div class="impact_txt">
              <p class="text-h3 text-grey-3">
                <span class="text-grey-1">김윤찬</span>님이 <br />
                <span class="text-orange">입회회원</span> 등록 결과입니다
              </p>
            </div>
          </div>

          <ul class="list_check_bullet">
            <li><span>인증방법</span><strong>마카다미아</strong></li>
            <li><span>휴대폰 번호</span><strong>010-1234-5678</strong></li>
            <li><span>등록상태</span><strong>실패</strong></li>
          </ul>

          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                unelevated
                outline
                color="black"
                class="size_lg"
                label="인증변경"
              />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="재신청"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
