<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">회원관리</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <!-- table_search_area type_flexable -->
      <div class="table_search_area type_flexable member_search_grid_column2">
        <div class="search_item">
          <!-- <h3>유형을 선택하세요</h3> -->
          <q-select
            class=""
            v-model="searchYear"
            :options="searchYearOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
        <div class="search_item">
          <!-- <h3>화면을 선택하세요</h3> -->
          <q-select
            class=""
            v-model="searchMonth"
            :options="searchMonthOption"
            option-value="id"
            option-label="desc"
            option-disable="inactive"
            emit-value
            map-options
            dense
            outlined
            dropdown-icon="ion-ios-arrow-down"
          >
          </q-select>
        </div>
      </div>
      <!--// table_search_area type_flexable -->

      <section class="mt30">
        <div class="member_tit_area">
          <div class="title">
            <span class="text-black">전체</span>
            <span class="text-positive num">5</span>
            <span class="text-positive">건</span>
          </div>

          <div class="options">
            <q-select
              class="opt_member"
              v-model="searchMonth"
              :options="searchMonthOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
        </div>

        <div class="list_member_area">
          <div class="student_card type02 on with_btn">
            <div class="date">
              <p class="body1">2023.03.12</p>
              <p class="body1">2023.03.20</p>
            </div>
            <div class="profile_box">
              <div class="cursor-pointer" @click="console.log('here')">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge color="green" class="small">단체</q-badge>
                  <q-space />
                </div>
                <div class="body2">
                  <span>본인인증</span>
                  <span>대기</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli"
                    >눈높이 수학, 솔루니 논술, 눈높이 국어, 눈높이 수학, 솔루니
                    논술</strong
                  >
                </div>
              </div>
              <q-btn
                fill
                unelevated
                class="size_xs btn_cancel"
                label="재신청"
              />
            </div>
          </div>

          <div class="student_card type02 with_btn">
            <div class="date">
              <p class="body1">2023.03.12</p>
              <p class="body1">2023.03.20</p>
            </div>
            <div class="profile_box">
              <div class="cursor-pointer" @click="console.log('here')">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">성인</span>
                  <q-space />
                </div>
                <div class="body2">
                  <span>완료</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli"
                    >눈높이 수학, 솔루니 논술, 눈높이 국어, 눈높이 수학, 솔루니
                    논술</strong
                  >
                </div>
              </div>
              <q-btn
                fill
                unelevated
                class="size_xs btn_cancel"
                label="재신청"
              />
            </div>
          </div>

          <div class="student_card type02 with_btn">
            <div class="date">
              <p class="body1">2023.03.12</p>
              <p class="body1">2023.03.20</p>
            </div>
            <div class="profile_box">
              <div class="cursor-pointer" @click="console.log('here')">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-space />
                </div>
                <div class="body2">
                  <span>녹취</span>
                  <span>대기</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli">-</strong>
                </div>
              </div>
              <q-btn
                fill
                unelevated
                class="size_xs btn_cancel"
                label="재신청"
              />
            </div>
          </div>

          <div class="student_card type02 with_btn">
            <div class="date">
              <p class="body1">2023.03.12</p>
              <p class="body1">2023.03.20</p>
            </div>
            <div class="profile_box">
              <div class="cursor-pointer" @click="console.log('here')">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-space />
                </div>
                <div class="body2">
                  <span>녹취</span>
                  <span>실패</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli">-</strong>
                </div>
              </div>
              <q-btn
                fill
                unelevated
                class="size_xs btn_cancel"
                label="재신청"
              />
            </div>
          </div>

          <div class="student_card type02 with_btn">
            <div class="date">
              <p class="body1">2023.03.12</p>
              <p class="body1">2023.03.20</p>
            </div>
            <div class="profile_box">
              <div class="cursor-pointer" @click="console.log('here')">
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-space />
                </div>
                <div class="body2">
                  <span>본인인증</span>
                  <span>대기</span>
                </div>
                <div class="bottom body2">
                  <span>학습과목</span>
                  <strong class="eli">-</strong>
                </div>
              </div>
              <q-btn
                fill
                unelevated
                class="size_xs btn_cancel"
                label="재신청"
              />
            </div>
          </div>
        </div>

        <div class="btn_area mt30">
          <q-btn class="size_lg btn_more" fill unelevated icon="" />
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchYear = ref(['2023']);
const searchYearOption = ref([
  {
    id: 'year2023',
    desc: '2023',
  },
  {
    id: 'year2022',
    desc: '2022',
  },
]);
const searchMonth = ref(['1월']);
const searchMonthOption = ref([
  {
    id: 'month01',
    desc: '1월',
  },
  {
    id: 'month02',
    desc: '2월',
  },
]);
</script>
<style lang="scss"></style>
