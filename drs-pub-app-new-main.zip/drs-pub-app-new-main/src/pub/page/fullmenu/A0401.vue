<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">####</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="loading_area">
            <img src="/img/img_loading.svg" alt="" />
            <p class="txt title4">화면 로딩이 지연되고 있습니다</p>
          </div>
          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="다시 시도"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>

<style lang="scss" scoped>
.loading_area {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: calc(100vh - 304px);
  img {
    animation: rotate infinite 2s;
  }
  .txt {
    margin-top: 20px;
    color: #767676;
  }
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(720deg);
  }
}

.h-full {
  min-height: calc(100vh - 172px);
}
</style>
