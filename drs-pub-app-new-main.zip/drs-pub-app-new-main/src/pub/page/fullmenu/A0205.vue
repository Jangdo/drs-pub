<template>
  <div>
    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1> -->
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
                승인요청
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">5</strong>건</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-user_add" class="icon_svg"></q-icon>
                입회상담
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">12</strong>건</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-message" class="icon_svg"></q-icon>
                일반상담
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">2</strong>건</span
                >
              </div>
            </q-btn>
          </li>
        </ul>
        <div class="gray_roundbox mt30 pb0">
          <div class="tit_area with_link">
            <p class="title3">
              <span class="text-primary">서울서북교육국</span>
              출결현황
            </p>
          </div>
          <div class="title-date text-body3 text-grey-3">2023.2.5.월</div>
          <div class="wrap_linear-progress mb0" v-if="lecture">
            <div class="tit_area">
              <span class="tit title3"
                ><strong class="text-h2 text-primary">22</strong
                ><b class="title4 text-gray-3">/</b>97명</span
              >
              <div class="balloon">
                {{ progress }} <span class="unit">%</span>
              </div>
            </div>
            <div class="linear_progress">
              <div class="pointer" :style="{ width: progress + '%' }"></div>
            </div>
            <div class="roundbox mt30" v-show="searchExpand">
              <div class="wrap_row">
                <div class="row flex justify-between">
                  <span class="as_dt text-body1">1팀</span>
                  <span class="as_dd title1 text-primary">56%</span>
                </div>
                <div class="row flex justify-between">
                  <span class="as_dt text-body1">2팀</span>
                  <span class="as_dd title1 text-primary">86%</span>
                </div>
                <div class="row flex justify-between">
                  <span class="as_dt text-body1">3팀</span>
                  <span class="as_dd title1 text-primary">23%</span>
                </div>
                <div class="row flex justify-between">
                  <span class="as_dt text-body1">4팀</span>
                  <span class="as_dd title1 text-primary">5%</span>
                </div>
                <div class="row flex justify-between">
                  <span class="as_dt text-body1">5팀</span>
                  <span class="as_dd title1 text-primary">57%</span>
                </div>
              </div>
            </div>
            <div class="search_expand flex flex-center py10">
              <q-btn
                class="size_sm btn_contract icon_svg"
                v-if="searchExpand"
                fill
                unelevated
                icon="icon-arrow_up"
                label="닫기"
                @click="searchExpand = false"
              />
              <q-btn
                class="size_sm btn_expand icon_svg"
                v-else
                fill
                unelevated
                icon="icon-arrow_down"
                label="자세히 보기"
                @click="searchExpand = true"
              />
            </div>
          </div>
          <div class="txt_exclamation4" v-else>
            <p class="title4 text-grey-3">오늘은 수업이 없는 날입니다</p>
          </div>
        </div>
      </section>
      <section>
        <q-list class="pay_list">
          <q-expansion-item class="expansion_custom type03" expand-icon-toggle>
            <template v-slot:header>
              <q-item-section class="tit_area">
                <div class="title">영업지표</div>
                <div class="process_area">
                  <span class="txt">순종수</span>
                  <span class="num">+234</span>
                </div>
              </q-item-section>
            </template>
            <q-card>
              <q-card-section class="max_295">
                <div class="row-2">
                  <div class="row info_area body2">
                    <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                    <span class="txt ml6 text-grey-3">전일기준</span>
                  </div>
                  <div class="row info_area body2">
                    <span class="txt text-grey-3">영업마감일</span>
                    <div class="day ml8 body1 text-primary">
                      <span>D</span>
                      <span>-</span>
                      <span>8</span>
                    </div>
                  </div>
                </div>
                <table class="sales_index">
                  <thead>
                    <tr>
                      <th>
                        <span class="txt">순증수</span>
                        <span class="num text-black">271</span>
                      </th>
                      <th class="text-right">
                        <span class="txt">순증지수</span>
                        <span class="num text-black">2,714</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">입회</span>
                      </td>
                      <td class="text-right">
                        <span class="num text-warning">23</span>
                        <span class="txt text-grey-3 ml8">/</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">퇴회</span>
                      </td>
                      <td class="text-right">
                        <span class="num text-orange">23</span>
                        <span class="txt text-grey-3 ml8">/</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <q-icon
                          name="icon-smile-grey"
                          class="icon_svg"
                        ></q-icon>
                        <span class="txt">순증</span>
                      </td>
                      <td class="text-right">
                        <span class="num text-positive">23</span>
                        <span class="txt text-grey-3 ml8">/</span>
                        <span class="num">1,356</span>
                      </td>
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td>
                        <span class="txt">총원</span>
                      </td>
                      <td class="text-right">
                        <span class="num text-primary">634</span>
                        <span class="txt text-grey-3 ml8">/</span>
                        <span class="num text-black">23,456</span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </q-card-section>
            </q-card>
            <div class="btm_action">
              <div class="btm_row">
                <q-space />
                <q-btn
                  fill
                  unelevated
                  color="black"
                  class="size_sm"
                  label="자세히 보기"
                />
              </div>
            </div>
          </q-expansion-item>
        </q-list>
        <!-- 링크 -->
        <div class="member_main_link grid-3">
          <div class="link_item">
            <q-btn flat class="btn_link on">
              <p class="name">
                입회/체험 <br style="display: block" />회원등록
              </p>
              <q-icon name="icon-graduation" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">
                상품<br />
                검색
              </p>
              <q-icon name="icon-search-alt" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">
                즉시<br />
                결제
              </p>
              <q-icon name="icon-coin" class="icon_svg"></q-icon>
            </q-btn>
          </div>
        </div>
        <ul class="list_type_1 mt20">
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon
                  name="icon-card"
                  class="filter-grey-3 icon_svg"
                ></q-icon>
                회비미납
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">12</strong>/153건</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon
                  name="icon-clipboard"
                  class="filter-grey-3 icon_svg"
                ></q-icon>
                진도미결정
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">2</strong>/15건</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon
                  name="icon-book"
                  class="filter-grey-3 icon_svg"
                ></q-icon>
                긴급교재
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-primary title1">2</strong>/15건</span
                >
              </div>
            </q-btn>
          </li>
        </ul>
      </section>
      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="new" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-write"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">진도미결정</div>
              </div>
            </q-tab>
            <q-tab name="birth" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-coin"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">입금률</div>
              </div>
            </q-tab>
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="new">
              <div class="wrap_list_page_a">
                <ul class="list_page_a">
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <div class="on flex-end">
                      <span class="text_end_type title1 text-primary">18</span>
                      <span class="text_end_type title4 text-grey-3">/</span>
                      <span class="text_end_type title4 text-black">24</span>
                      <span class="text_end_type title4 text-black">과목</span>
                    </div>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <div class="on flex-end">
                      <span class="text_end_type title1 text-primary">18</span>
                      <span class="text_end_type title4 text-grey-3">/</span>
                      <span class="text_end_type title4 text-black">24</span>
                      <span class="text_end_type title4 text-black">과목</span>
                    </div>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <div class="on flex-end">
                      <span class="text_end_type title1 text-primary">18</span>
                      <span class="text_end_type title4 text-grey-3">/</span>
                      <span class="text_end_type title4 text-black">24</span>
                      <span class="text_end_type title4 text-black">과목</span>
                    </div>
                  </li>
                </ul>
                <div class="btn_area mt30">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
            </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="birth">
              <div class="wrap_list_page_a">
                <ul class="list_page_a">
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                  <li>
                    <q-btn flat class="txt_area" :ripple="false">
                      <q-icon name="icon-user" class="icon_svg"></q-icon>
                      <span class="name">김윤찬</span>
                      <span class="subject">선생님</span>
                    </q-btn>
                    <q-btn flat class="on date_area flex-end" :ripple="false">
                      <span class="text_end_type title3 text-primary"
                        >86 <b class="text-body1 text-grey-3">%</b></span
                      >
                    </q-btn>
                  </li>
                </ul>
                <div class="btn_area mt30">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>
      <section>
        <div class="wrap_list_page_a">
          <div class="title_area underline">
            <q-icon
              name="icon-cake"
              class="icon_svg filter-black mr10"
              size="24px"
            ></q-icon>
            <p class="title1">생일알림</p>
          </div>
          <ul class="list_page_a cus01" v-if="teacherBirth">
            <li>
              <div class="info">
                <strong class="name title3">
                  한선영
                  <span class="subject">선생님</span>
                  <q-badge color="orange" rounded class="q-ml-xs">
                    생일
                  </q-badge>
                </strong>
                <div class="desc">
                  <span class="date">00/00(월)</span>
                </div>
              </div>
              <div class="ico">
                <q-btn flat class="on" :ripple="false">
                  <q-icon name="icon-mail" class="icon_svg"></q-icon>
                </q-btn>
              </div>
            </li>
            <li>
              <div class="info">
                <strong class="name title3">
                  한선영
                  <span class="subject">선생님</span>
                  <q-badge color="orange" rounded class="q-ml-xs">
                    생일
                  </q-badge>
                </strong>
                <div class="desc">
                  <span class="date">00/00(월)</span>
                </div>
              </div>
              <div class="ico">
                <q-btn flat class="on" :ripple="false">
                  <q-icon name="icon-mail" class="icon_svg"></q-icon>
                </q-btn>
              </div>
            </li>
          </ul>
          <div class="list_page_a">
            <div class="txt_exclamation4">
              <p class="title4 text-grey-3">생일인 선생님이 없습니다</p>
            </div>
          </div>
          <div class="btn_area">
            <q-btn class="size_lg btn_more" fill unelevated icon="" />
          </div>
        </div>
      </section>
      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>

      <q-scroll-observer @scroll="onScroll" debounce="100" />
    </div>
    <!-- 퀵메뉴 배경 -->
    <div
      class="quick_dimed"
      @click="quickOpen = false"
      v-show="quickOpen == true"
    ></div>
    <!-- 퀵메뉴 열고 닫힘 -->
    <div
      class="wrap_quick_menu"
      :style="bottomOfWindow == true ? 'bottom:172px' : 'bottom:102px'"
    >
      <q-btn
        class="size_big btn_quick_open"
        @click="quickOpen = true"
        v-show="quickOpen == false"
        stack
        fill
        unelevated
        icon=""
        :color="
          $route.matched[1].props.default.userType === 'teacher'
            ? 'positive'
            : 'primary'
        "
        label="바로가기"
      />
      <q-btn
        class="size_big btn_quick_close"
        @click="quickOpen = false"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        :color="
          $route.matched[1].props.default.userType === 'teacher'
            ? 'positive'
            : 'primary'
        "
        label="닫기"
      />
      <q-btn
        class="size_big btn_quick_edit"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="편집"
      />
      <q-btn
        class="size_big btn_quick_lms"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="lms"
      />
      <q-btn
        class="size_big btn_quick_attendance"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="출결"
      />
      <q-btn
        class="size_big btn_quick_content"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="콘텐츠"
      />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
const tab = ref('new');
const progress = ref('26');
const quickOpen = ref(false);
const lecture = ref(false); // 수업이 있을때
const teacherBirth = ref(true); // 선생님 생일이 있을때
const searchExpand = ref(true);

const bottomOfWindow = ref(false);

function onScroll() {
  bottomOfWindow.value =
    Math.max(
      window.pageYOffset,
      document.documentElement.scrollTop,
      document.body.scrollTop
    ) +
      window.innerHeight ===
    document.documentElement.offsetHeight;
}
// console.log(bottomOfWindow);
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';
</style>
