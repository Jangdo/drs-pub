<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form type_bg">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">주소검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="wrap_contents_box">
            <!-- 검색폼 -->
            <q-input
              class="inp_search"
              outlined
              dense
              placeholder="주소를 검색해 주세요"
              v-model="addrSearch"
            >
              <template v-slot:append>
                <q-icon name="icon-close" class="icon_svg" />
              </template>
            </q-input>
          </div>

          <!-- 검색결과 -->

          <div class="wrap_contents_box">
            <section class="search_addr_result">
              <!-- 
                검색결과 없는 경우 화면 : A03010104P_1_pop.vue 
              -->

              <!-- 검색결과 리스트 -->
              <div class="addr_result_list">
                <div class="addr_info on">
                  <p class="text-body1 text-orange zipcode">08708</p>
                  <p class="text-body2 text-grey-1 addr1">
                    서울 관악구 보라매로3길 1
                  </p>
                  <p class="text-body1 text-grey-2 addr2">
                    서울 관악구 봉천동 702-107
                  </p>
                </div>
                <div class="addr_info">
                  <p class="text-body1 text-orange zipcode">08708</p>
                  <p class="text-body2 text-grey-1 addr1">
                    서울 관악구 보라매로3길 1
                  </p>
                  <p class="text-body1 text-grey-2 addr2">
                    서울 관악구 봉천동 702-107
                  </p>
                </div>
                <div class="addr_info">
                  <p class="text-body1 text-orange zipcode">08708</p>
                  <p class="text-body2 text-grey-1 addr1">
                    서울 관악구 보라매로3길 1
                  </p>
                  <p class="text-body1 text-grey-2 addr2">
                    서울 관악구 봉천동 702-107
                  </p>
                </div>
              </div>
            </section>
            <!-- pagination -->
            <div class="pagination_container">
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                input
                class="justify-center"
              />
              <q-pagination
                v-model="dataPagination.current"
                v-if="$q.screen.name == 'lg'"
                :max="10"
                :max-pages="8"
                direction-links
                boundary-links
                rounded
                icon-first="keyboard_double_arrow_left"
                icon-last="keyboard_double_arrow_right"
                class="justify-center type_01"
              />
            </div>
            <!-- // pagination -->
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

// 검색
const addrSearch = ref('보라매로3길');

const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
<style lang="scss" scoped>
// :deep(.pagination_container) {
//   margin: 20px 0;

//   .q-pagination__content,
//   .q-pagination__middle {
//     // border: 2px solid red;
//     gap: 10px;
//     & > .q-btn,
//     & > .q-input {
//       color: #767676 !important;
//       font-size: 16px;
//       border-radius: 20px;
//       min-width: 40px !important;
//       height: 40px;
//       padding: {
//         left: 10px !important;
//         right: 10px !important;
//       }
//     }
//     .bg-primary {
//       background-color: #000 !important;
//     }
//     .text-white {
//       color: #fff !important;
//     }

//     & > .q-btn {
//       &.q-btn-item {
//         &:first-child,
//         &:last-child,
//         &:nth-child(2),
//         &:nth-last-child(2) {
//           border: 1px solid #cecece;
//         }
//       }
//     }
//     .q-pagination__middle {
//       & > .q-btn {
//         &.q-btn-item {
//           border: none;
//         }
//       }
//     }
//   }
// }
</style>
