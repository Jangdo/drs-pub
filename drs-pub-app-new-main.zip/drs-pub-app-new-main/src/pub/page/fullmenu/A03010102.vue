<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">개인정보 수집 및 이용 동의</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <section class="dialog_terms">
            <ul class="list">
              <li>
                <h3 class="tit title3">개인정보 수집 이용하는 자</h3>
                <p class="txt text-phara2">(주)대교</p>
              </li>
              <li>
                <h3 class="tit title3">개인정보 수집 이용 항목</h3>
                <ul class="list_middot text-grey-3">
                  <li>필수정보 : 이름, 전화번호, 학년, 성별, 관심제품</li>
                  <li>선택정보 : 주소</li>
                </ul>
              </li>
              <li>
                <h3 class="tit title3">수집 목적</h3>
                <p class="txt text-phara2">
                  교육 상품 상담 안내(전화, SMS 등)를 위한 마케팅 자료로 사용
                </p>
              </li>
              <li>
                <h3 class="tit title3">보유/이용 기간</h3>
                <p class="txt text-phara2">수집일로부터 3개월</p>
              </li>
              <li>
                <p class="txt text-phara2">
                  개인정보 주체는 상기 개인정보 수집에 동의하지 않을 권리가
                  있으며, 이 경우 교육 상담 안내 마케팅에는 사용되지 않습니다.
                  또한 언제든 동의를 철회할 수 있으며, 이 경우 수집된 개인정보는
                  즉시 파기됩니다.
                </p>
              </li>
            </ul>
          </section>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            v-close-popup
            class="size_lg btn_cancel"
            color="black"
            label="미동의"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg btn_save"
            label="동의"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
</script>
<style lang="scss"></style>
