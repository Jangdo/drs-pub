<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_form">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">인증 알림톡 발송</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <p class="text_type_info">
            마카다미아와 드림스를 동시에 입회회원 등록 가능합니다.
          </p>

          <div class="form_send_url mt30">
            <div class="as_row type02">
              <div class="as_cell">
                <span class="as_dt required_right">이름</span>
                <strong class="as_dd">김윤찬</strong>
              </div>
              <div class="as_cell">
                <span class="as_dt required_right">생년월일</span>
                <strong class="as_dd">2012.01.01</strong>
              </div>
            </div>
            <div class="as_row">
              <div>
                <span class="as_dt required_right">휴대폰번호</span>
                <div class="as_dd">
                  <q-input
                    class="inp_search"
                    outlined
                    dense
                    placeholder="입력하세요"
                    v-model="phoneNum"
                  >
                    <template v-slot:append v-if="phoneNum !== ''">
                      <q-btn flat dense :ripple="false" class="btn_input_slot">
                        <q-icon name="icon-close" class="icon_svg" />
                      </q-btn>
                    </template>
                  </q-input>
                </div>
              </div>
            </div>
            <div class="as_row">
              <div class="as_dd">
                <q-input
                  class="basic"
                  outlined
                  v-model="dataTextArea"
                  placeholder="메시지 내용을 입력하세요"
                  type="textarea"
                >
                  <template v-slot:label>메시지 내용</template>
                </q-input>
              </div>
            </div>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="보내기"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const dataTextArea = ref(
  '대교 학습의 시작, 마카다미아와 함께 해요 [마카다미아] https://www.macadamia.kr/user/join'
);
const phoneNum = ref('010-1234-5678');
</script>
<style lang="scss"></style>
