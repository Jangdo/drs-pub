<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-computer" class="icon_svg"></q-icon>
                수업완료현황
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-green title1">43</strong>/60과목</span
                >
                <span class="data_item"
                  ><strong class="text-green title1">2</strong>/20명</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-card" class="icon_svg"></q-icon>
                회비미납
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-green title1">12</strong>/153건</span
                >
              </div>
            </q-btn>
          </li>
          <li class="uppper_btn">
            <q-btn flat class="flat_btn">
              <p class="title1 name">
                <q-icon name="icon-clipboard" class="icon_svg"></q-icon>
                진도미결정
              </p>
              <div class="data">
                <span class="data_item"
                  ><strong class="text-green title1">2</strong>/15과목</span
                >
              </div>
            </q-btn>
          </li>
        </ul>
      </section>

      <!-- 입금현황 & 링크 -->
      <section class="mt40">
        <q-expansion-item
          class="expansion_custom type02 a02"
          expand-icon-toggle
        >
          <template v-slot:header>
            <q-item-section class="tit_area">
              <span class="title">입금현황</span>
              <span class="process_area">
                <span class="txt">입금률</span>
                <span class="num">54</span>
                <span class="sign">%</span>
              </span>
            </q-item-section>
          </template>
          <q-card>
            <q-card-section class="right pt0">
              <div class="w100p">
                <!-- tooltip_down type_question -->
                <div class="tooltip_area type_02">
                  <q-fab
                    direction="up"
                    hide-icon
                    class="tooltip_down"
                    v-model="tooltip1"
                    flat
                  >
                    <q-fab-action
                      square
                      label=""
                      label-position="left"
                      color="black"
                      style="width: 200px"
                    >
                      <span class="btn_close"></span>
                      <p class="txt text-body2">
                        '현재 입금된 금액으로 산정하며,마감 후 변동될 수
                        있습니다.'
                      </p>
                    </q-fab-action>
                  </q-fab>
                  <q-btn
                    flat
                    :ripple="false"
                    class="_defatul_style"
                    @click="tooltip1 = !tooltip1"
                  >
                    <p class="pl5">전일 기준</p>
                  </q-btn>
                </div>
                <!--// tooltip_down type_question -->
                <div class="price_area">
                  <q-icon name="icon-pay" class="icon_svg"></q-icon>
                  <div class="price">
                    <span>3,980,000</span>
                    <span>원</span>
                  </div>
                </div>
              </div>
            </q-card-section>
          </q-card>
          <div class="btm_action">
            <div class="flex justify-end">
              <q-btn
                fill
                unelevated
                color="black"
                class="size_sm"
                label="자세히 보기"
              />
            </div>
          </div>
        </q-expansion-item>

        <!-- 링크 -->
        <div class="member_main_link grid-4">
          <div class="link_item">
            <q-btn flat class="btn_link on">
              <p class="name">
                입회/체험 <br style="display: block" />회원등록
              </p>
              <q-icon name="icon-graduation" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">회원검색</p>
              <q-icon name="icon-search-alt" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">상품검색</p>
              <!-- <q-icon name="icon-coin" class="icon_svg"></q-icon> -->
              <q-icon name="icon-search-alt" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <div class="link_item">
            <q-btn flat class="btn_link">
              <p class="name">영업실적</p>
              <q-icon name="icon-graph" class="icon_svg"></q-icon>
            </q-btn>
          </div>
        </div>
      </section>

      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="new" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-id"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">신규회원</div>
              </div>
            </q-tab>
            <q-tab name="birth" :ripple="false">
              <div class="small_type_01 row">
                <q-icon
                  name="icon-cake"
                  class="icon_svg filter-grey-3 mr10"
                ></q-icon>
                <div class="q-tab__label title1">생일알림</div>
              </div>
            </q-tab>
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="new">
              <div class="wrap_list_page_a">
                <ul class="list_page_a cus01">
                  <li>
                    <div class="info">
                      <strong class="name title3">
                        김윤찬
                        <q-badge color="orange" rounded class="q-ml-xs">
                          신입
                        </q-badge>
                      </strong>
                      <div class="desc">
                        <span class="grade body1">초등2</span>
                        <span class="date">00/00(월)</span>
                        <span class="txt">눈높이수학</span>
                      </div>
                    </div>
                    <div class="ico">
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      </q-btn>
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-map" class="icon_svg"></q-icon>
                      </q-btn>
                    </div>
                  </li>
                  <li>
                    <div class="info">
                      <strong class="name title3">
                        일이삼사오육칠팔구십일이삼일이삼사오육칠팔구십일이삼일이
                        일이삼사오육칠팔구십일이삼일이삼사오육칠팔구십일이삼일이
                        <q-badge color="orange" rounded class="q-ml-xs">
                          신입
                        </q-badge>
                      </strong>
                      <div class="desc">
                        <span class="grade body1">초등2</span>
                        <span class="date">00/00(월)</span>
                        <span class="txt"
                          >일이삼사오육칠팔 일이삼사오육칠팔</span
                        >
                      </div>
                    </div>
                    <div class="ico">
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      </q-btn>
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-map" class="icon_svg"></q-icon>
                      </q-btn>
                    </div>
                  </li>
                  <li>
                    <div class="info">
                      <strong class="name title3">
                        일이삼사
                        <q-badge color="primary" rounded class="q-ml-xs">
                          전입
                        </q-badge>
                      </strong>
                      <div class="desc">
                        <span class="grade body1">초등2</span>
                        <span class="date">00/00(월)</span>
                        <span class="txt"
                          >일이삼사오육칠팔 일이삼사오육칠팔 일이삼사오육칠팔
                          일이삼사오육칠팔 일이삼사오육칠팔
                        </span>
                      </div>
                    </div>
                    <div class="ico">
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      </q-btn>
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-map" class="icon_svg"></q-icon>
                      </q-btn>
                    </div>
                  </li>
                </ul>

                <div class="btn_area">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
              <div class="list_page_a cus01">
                <div class="txt_exclamation4">
                  <p class="title4 text-grey-3">생일인 선생님이 없습니다</p>
                </div>
              </div>
            </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="birth">
              <div class="wrap_list_page_a">
                <ul class="list_page_a cus01">
                  <li>
                    <div class="info">
                      <strong class="name title3">
                        김윤찬
                        <q-badge color="orange" rounded class="q-ml-xs">
                          생일
                        </q-badge>
                      </strong>
                      <div class="desc">
                        <span class="grade body1">초등2</span>
                        <span class="date">00/00(월)</span>
                        <!-- <span class="txt">눈높이수학</span> -->
                      </div>
                    </div>
                    <div class="ico">
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      </q-btn>
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-mail" class="icon_svg"></q-icon>
                      </q-btn>
                    </div>
                    <!-- <div class="txt_area">
                    <span class="name title3">김윤찬</span>
                    <span class="grade body1">초등2</span>
                  </div>
                  <div class="on">
                    <span class="subject">생일</span>
                    <span class="date body1">2.6(월)</span>
                  </div>
                  <q-btn flat class="on" :ripple="false">
                    <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                  </q-btn>
                  <q-btn flat class="on" :ripple="false">
                    <q-icon name="icon-mail" class="icon_svg"></q-icon>
                  </q-btn> -->
                  </li>
                  <li>
                    <div class="info">
                      <strong class="name title3">
                        아브디라쉬토바엘레오노라아브디라라쉬토바엘레오노라아브디라
                        <q-badge color="orange" rounded class="q-ml-xs">
                          생일
                        </q-badge>
                      </strong>
                      <div class="desc">
                        <span class="grade body1">초등2</span>
                        <span class="date">00/00(월)</span>
                        <!-- <span class="txt">눈높이수학</span> -->
                      </div>
                    </div>
                    <div class="ico">
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                      </q-btn>
                      <q-btn flat class="on" :ripple="false">
                        <q-icon name="icon-mail" class="icon_svg"></q-icon>
                      </q-btn>
                    </div>
                    <!-- <div class="txt_area">
                    <span class="name title3">김윤찬</span>
                    <span class="grade body1">초등2</span>
                  </div>
                  <div class="">
                    <span class="subject">생일</span>
                    <span class="date body1">2.6(월)</span>
                  </div>
                  <q-btn flat class="" :ripple="false">
                    <q-icon name="icon-user-info" class="icon_svg"></q-icon>
                  </q-btn>
                  <q-btn flat class="" :ripple="false">
                    <q-icon name="icon-mail" class="icon_svg"></q-icon>
                  </q-btn> -->
                  </li>
                </ul>
                <div class="btn_area mt30">
                  <q-btn class="size_lg btn_more" fill unelevated icon="" />
                </div>
              </div>
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>

      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong>본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong>강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>
      <q-scroll-observer @scroll="onScroll" debounce="100" />
    </div>
    <!-- 퀵메뉴 배경 -->
    <div
      class="quick_dimed"
      @click="quickOpen = false"
      v-show="quickOpen == true"
    ></div>

    <!-- 퀵메뉴 열고 닫힘 -->
    <div
      class="wrap_quick_menu"
      :style="bottomOfWindow == true ? 'bottom:172px' : 'bottom:102px'"
    >
      <q-btn
        class="size_big btn_quick_open"
        @click="quickOpen = true"
        v-show="quickOpen == false"
        stack
        fill
        unelevated
        icon=""
        :color="
          $route.matched[1].props.default.userType === 'teacher'
            ? 'positive'
            : 'primary'
        "
        label="바로가기"
      />
      <q-btn
        class="size_big btn_quick_close"
        @click="quickOpen = false"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        :color="
          $route.matched[1].props.default.userType === 'teacher'
            ? 'positive'
            : 'primary'
        "
        label="닫기"
      />
      <q-btn
        class="size_big btn_quick_edit"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="편집"
      />
      <q-btn
        class="size_big btn_quick_lms"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="lms"
      />
      <q-btn
        class="size_big btn_quick_attendance"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="출결"
      />
      <q-btn
        class="size_big btn_quick_content"
        v-show="quickOpen == true"
        stack
        fill
        unelevated
        icon=""
        color="black"
        label="콘텐츠"
      />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('new');
const quickOpen = ref(false);
const tooltip1 = ref(false);
const bottomOfWindow = ref(false);

function onScroll() {
  bottomOfWindow.value =
    Math.max(
      window.pageYOffset,
      document.documentElement.scrollTop,
      document.body.scrollTop
    ) +
      window.innerHeight ===
    document.documentElement.offsetHeight;
}
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';

._defatul_style {
  padding: 0;
  min-height: 0;
}

body.screen--lg {
  .q-expansion-item.expansion_custom.type02
    .q-expansion-item__content
    .price_area {
    justify-content: flex-end;
  }
}
</style>
