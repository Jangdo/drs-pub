<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="bottom_sheet">
        <div class="carousel_wrap">
          <q-carousel
            animated
            v-model="slide"
            arrows
            infinite
            class="pop_slider"
            ref="carousel"
          >
            <q-carousel-slide
              v-for="slide in slides"
              :key="slide.id"
              :name="slide.id"
              class="pop_slide pt0"
            >
              <q-card-section class="pop_title_wrap pa0">
                <h3 class="tit ellipsis text-left">
                  {{ slide.id }}타이틀이 길경우는 말줄임 표시해주..
                </h3>
                <q-btn
                  icon="close"
                  class="btn_close"
                  v-close-popup
                  flat
                  @click="popForm = false"
                  unelevated
                  dense
                  style="right: 0; top: 10px"
                  ><b class="a11y">닫기</b></q-btn
                >
                <!-- <div class="inner">
                </div> -->
                <q-card-section class="wrap_lms pd0 pt10">
                  <div class="row gap10">
                    <span class="body1 text-grey-3">김대교{{ slide.id }}</span>
                    <span class="body1">2023-08-02 00:00</span>
                    <span class="body1 text-grey-3">조회수 000</span>
                  </div>
                  <q-separator class="mt10 mb20" style="display: block" />
                </q-card-section>
              </q-card-section>
              <div class="cont_area">
                컨텐츠 {{ slide.id }}
              </div></q-carousel-slide
            >
          </q-carousel>
          <div class="row justify-center mt10">
            {{ slide }} / {{ slides.length }}
          </div>
        </div>

        <div class="not_today">
          <q-checkbox
            v-model="dataCheck"
            color="black"
            label="오늘 다시 보지 않기"
            dense
          />
        </div>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const dataCheck = ref(true);
const slide = ref(1);
const slides = [
  {
    id: 1,
  },
  {
    id: 2,
  },
  {
    id: 3,
  },
  {
    id: 4,
  },
];
</script>
<style lang="scss" scoped>
.bottom_sheet {
  position: relative;
  width: 100%;
  max-height: 80vh;
  box-shadow: none !important;
  padding-top: 30px;
  background-color: transparent;
  // .tit_area {
  //   position: relative;
  //   padding: 30px 20px 0 20px !important;
  //   border-bottom: none !important;
  //   margin: 0 !important;
  //   .inner {
  //     position: relative;
  //     padding-bottom: 16px;
  //     height: 36px;
  //     border-bottom: 1px solid rgba(0, 0, 0, 0.12);
  //     .tit {
  //       font-size: 20px;
  //       font-weight: 600;
  //       line-height: 1;
  //     }
  //     .btn_close {
  //       position: absolute;
  //       right: 0;
  //       top: -3px !important;
  //       padding: 0;
  //       font-size: 26px;
  //     }
  //   }
  // }

  .carousel_wrap {
    border-top-left-radius: 12px !important;
    border-top-right-radius: 12px !important;
    position: relative;
    background-color: #fff;
    padding-bottom: 10px;
    overflow: hidden;
    .tit_area {
      padding: 0 !important;
    }
    .q-carousel__slide {
      padding: 30px 16px 0 16px;
    }
  }
  .not_today {
    position: absolute;
    left: 16px;
    top: 0;
    z-index: 2;
  }
  :global(.not_today .q-checkbox .q-checkbox__label) {
    color: #fff !important;
  }
}

@import '../../../css/list_a.scss';
</style>
<style>
.pop_slider {
  height: inherit;
  .cont_area {
    height: 300px;
    background-color: #d7d7d7;
    overflow-y: auto;
  }
  .q-carousel__arrow {
    .q-btn {
      top: 50px;
      width: 32px;
      height: 32px;
      border: 2px solid #fff;
      border-radius: 50%;

      &.q-btn--dense {
        padding: 0;
      }

      .q-icon {
        font-size: 22px;
      }
    }
  }
}
</style>
