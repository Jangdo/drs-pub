<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm">
      <q-card class="respons_card">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit ellipsis text-left pdr20 w100p">
            타이틀이 길경우는 말줄임 표시해주..
          </h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
          <!-- <div class="inner">
          </div> -->
        </q-card-section>
        <q-card-section class="wrap_lms">
          <div class="row gap10">
            <span class="body1 text-grey-3">김대교</span>
            <span class="body1">2023-08-02 00:00</span>
            <span class="body1 text-grey-3">조회수 000</span>
          </div>
          <q-separator class="mt10 mb20" />
          <div class="content_area" style="background-color: #d7d7d7">
            컨텐츠1
          </div>
          <div class="mt10">
            <q-checkbox
              v-model="dataCheck"
              label="오늘 다시 보지 않기"
              dense
              color="black"
            />
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!-- 타이틀 없는 CASE no_title class 추가 -->
    <q-dialog
      :modelValue="popForm2"
      class="dialog_btm"
      :style="{ 'z-index': zIndex }"
    >
      <q-card
        class="respons_card"
        style="left: 30px; top: 30px"
        @click="++zIndex"
      >
        <q-card-section class="pop_title_wrap">
          <!-- <div class="inner">
          </div> -->
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm2 = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="wrap_lms pt0">
          <div class="content_area" style="background-color: #d7d7d7">
            컨텐츠1
          </div>
          <div class="mt10">
            <q-checkbox
              v-model="dataCheck"
              label="오늘 다시 보지 않기"
              dense
              color="black"
            />
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!-- // 타이틀 없는 CASE -->

    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const popForm2 = ref(true);

const dataCheck = ref(false);
const zIndex = ref(6000);
</script>

<style lang="scss" scoped>
:global(.q-dialog__backdrop) {
  display: none;
}
.tit_area {
  position: relative;
  padding: 30px 20px 0 20px;
  .inner {
    &.no_line {
      border-bottom: none;
    }
    position: relative;
    padding-bottom: 16px;
    height: 36px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.12);
    .tit {
      font-size: 20px;
      font-weight: 600;
      line-height: 1;
    }
    .btn_close {
      position: absolute;
      right: 0;
      top: -3px !important;
      padding: 0;
      font-size: 26px;
    }
  }
  &.no_title {
    .inner {
      border-bottom: none;
    }
    & + .wrap_lms {
      padding-top: 0;
    }
  }
}
.content_area {
  height: 400px;
  padding: 16px;
  overflow-y: auto;
}
@import '../../../css/list_a.scss';
</style>
<style lang="scss" scoped></style>
