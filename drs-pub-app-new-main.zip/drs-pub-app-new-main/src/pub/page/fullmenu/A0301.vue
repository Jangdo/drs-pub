<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        회원등록 확인
      </h1>
      <Breadcrumbs />
    </div>
    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <h3 class="tit text-phara1">
            이름, 생년월일, 휴대폰번호를 입력하고 <br />
            등록확인을 해주세요
          </h3>
          <!-- inner_list -->
          <ul class="inner_list">
            <li>
              <span class="as_dt required_right">이름</span>
              <q-input
                v-model="dataForm.name"
                class="as_dd hide_label"
                label="* 이름"
                outlined
                placeholder="이름를 입력하세요"
                stack-label
                dense
              >
                <template v-slot:label>이름</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required_right">생년월일</span>
              <q-input
                outlined
                v-model="dataForm.date"
                class="as_dd hide_label inp_date"
              >
                <template v-slot:label>생년월일</template>
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date v-model="dataForm.date" minimal> </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required_right">휴대폰번호</span>
              <q-input
                v-model="dataForm.phone"
                class="as_dd hide_label"
                label="* 휴대폰번호"
                outlined
                placeholder="숫자만 입력 해주세요"
                stack-label
                dense
              >
                <template v-slot:label>휴대폰번호</template>
              </q-input>
            </li>
          </ul>
          <!--// inner_list -->
          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                outline
                v-close-popup
                class="size_lg"
                color="black"
                label="취소"
              />
              <q-btn
                fill
                unelevated
                v-close-popup
                color="black"
                class="size_lg"
                label="등록확인"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const dataForm = ref({
  date: ref('2019.02.01'),
  name: '',
  txt: '',
});
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
