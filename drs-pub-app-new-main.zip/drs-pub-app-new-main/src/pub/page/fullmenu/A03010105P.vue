<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change fit_contents">
      <q-card class="respons_card type_form">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">상세주소입력</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="form_addr_details">
            <div class="addr_info">
              <p class="text-body1 text-orange zipcode">08708</p>
              <p class="text-body2 text-grey-1 addr1">
                서울 관악구 보라매로3길 1
              </p>
              <p class="text-body1 text-grey-2 addr2">
                서울 관악구 봉천동 702-107
              </p>
            </div>
            <q-input
              class="inp_search mt15"
              outlined
              dense
              placeholder="상세주소 입력(동/호)"
              v-model="inpDetails"
            >
              <template v-slot:append v-if="inpDetails !== ''">
                <q-btn flat dense :ripple="false" class="btn_input_slot">
                  <q-icon name="icon-close" class="icon_svg" />
                </q-btn>
              </template>
            </q-input>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <!-- 23.05.11 버튼에 'fit_text' 클래스 추가 -->
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg w100p fit_text"
            label="상세주소 입력완료"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
const inpDetails = ref('');
</script>
