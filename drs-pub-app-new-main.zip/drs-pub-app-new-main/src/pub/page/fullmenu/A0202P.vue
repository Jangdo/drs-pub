<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">써밋 LMS</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            wght="100"
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="wrap_lms">
            <div class="tit_area">
              <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
              <h3 class="tit_lms text-body2">
                제품 LMS를 선택하시면 학습관리 사이트로 이동 가능합니다.
              </h3>
            </div>
            <div>
              <ul class="list_lms">
                <li>
                  <q-btn flat class="on">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/speed_math.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스피드 수학 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/score_math.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스코어 수학 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/score_korean.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스코어 국어 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/speaking.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스피킹 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/step_korean.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스텝국어 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/vocabulary.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 어휘력 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/step_english.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스텝영어 <br />LMS</p>
                  </q-btn>
                </li>
                <li>
                  <q-btn flat class="">
                    <div class="img_area">
                      <img
                        src="https://drs-imaged.daekyo.co.kr/images/main/lms/step_english.png"
                        alt=""
                      />
                    </div>
                    <p class="title3">써밋 스텝영어 중등 <br />LMS</p>
                  </q-btn>
                </li>
              </ul>
            </div>
          </div>
        </q-card-section>
        <!-- <q-card-actions class="dialog_actions">
          <q-btn
            outline
            v-close-popup
            class="size_lg btn_cancel"
            color="black"
            label="미동의"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg btn_save"
            label="동의"
          />
        </q-card-actions> -->
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
</script>
<style lang="scss">
@import '../../../css/list_a.scss';
</style>
