<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        등록확인 결과
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="result">
            <div class="pic_area">
              <img src="/img/result-man-check.svg" alt="" />
            </div>
            <div class="impact_txt">
              <p class="text-h3 text-grey-3">
                <span class="text-grey-1">김윤찬</span>님은 <br />
                <span class="text-orange">체험회원</span>으로 등록되었습니다
              </p>
            </div>
            <div class="more_infor text-phara1">
              바로 체험하기 신청이 가능합니다. <br />
              상품입회는 입회회원 등록 후 가능합니다.
            </div>
            <q-btn
              outline
              elevated
              rounded
              color="grey-06"
              class="size_lg_rounded shadow mt20"
            >
              <div class="left">
                <span class="text-grey-3">입회회원 등록</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
              </div>
            </q-btn>

            <q-btn
              outline
              elevated
              rounded
              color="grey-06"
              class="size_lg_rounded shadow mt20"
            >
              <div class="left">
                <span class="text-grey-3">회원 프로필보기</span>
              </div>
              <div class="right">
                <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
              </div>
            </q-btn>
          </div>

          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                unelevated
                outline
                color="black"
                class="size_lg"
                label="상담 등록"
              />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="체험하기"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>

<style lang="scss" scoped>
.q-btn.size_lg_rounded {
  & + & {
    margin-top: 10px;
  }
}

.h-full {
  min-height: calc(100vh - 172px);
}
</style>
