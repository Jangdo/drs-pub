<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        등록확인 결과
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage">
          <div class="result">
            <div class="pic_area">
              <img src="/img/result-man-check.svg" alt="" />
            </div>
            <div class="impact_txt">
              <p class="text-h3 text-grey-3">
                <span class="text-grey-1">김윤찬</span>님의 <br />
                등록된 회원정보가 없습니다
              </p>
            </div>
            <div class="more_infor text-phara1">
              체험을 하시려면 <br />
              <span class="text-grey-1">체험회원 가입</span>을 선택해주세요.<br />
              입회를 하시려면 <span class="text-grey-1">입회회원 가입</span>을
              해주세요.<br />
            </div>
          </div>

          <!-- wrap_fixed_bottom -->
          <div class="wrap_fixed_bottom">
            <div class="btn_area" style="">
              <q-btn
                unelevated
                outline
                color="black"
                class="size_lg"
                label="체험회원 등록"
              />
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="입회회원 등록록"
              />
            </div>
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
// import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
