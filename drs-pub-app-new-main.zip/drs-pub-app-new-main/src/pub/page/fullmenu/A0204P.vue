<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">즐겨찾기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="wrap_favorites">
            <div class="edit_area">
              <div class="tit_box">
                <p class="name title1">김대교 선생님</p>
                <div class="btn_area mb0">
                  <q-btn
                    flat
                    v-if="editState == false"
                    @click="editState = !editState"
                    >편집</q-btn
                  >
                  <q-btn
                    flat
                    v-if="editState == true"
                    @click="editState = !editState"
                    >초기화</q-btn
                  >
                  <q-btn
                    flat
                    v-if="editState == true"
                    @click="editState = !editState"
                    >완료</q-btn
                  >
                </div>
              </div>
              <div class="view_box">
                <template v-if="editState == false">
                  <q-btn
                    class="size_big btn_quick_content"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="학습관"
                  />
                  <q-btn
                    class="size_big btn_quick_content"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="콘텐츠"
                  />
                  <q-btn
                    class="size_big btn_quick_content"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="출결"
                  />
                  <q-btn
                    class="size_big btn_quick_content"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="LMS"
                  />
                </template>
                <template v-if="editState == true">
                  <q-btn
                    class="size_big btn_quick_content tip_edit"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="콘텐츠"
                  />
                  <q-btn
                    class="size_big btn_quick_content tip_edit"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="콘텐츠"
                  />
                  <q-btn
                    class="size_big btn_quick_content tip_edit"
                    stack
                    fill
                    unelevated
                    icon=""
                    color="black"
                    label="콘텐츠"
                  />
                  <q-btn flat class="btn_quick_circle_plus">
                    <img src="/img/circle_plus.svg" alt="" />
                  </q-btn>
                </template>
                <!-- <img src="/img/circle_plus.svg" alt=""/> -->
              </div>
              <div class="infor">
                <q-icon
                  name="icon-info"
                  class="icon_svg filter-grey-3"
                ></q-icon>
                <p class="text-body2">
                  즐겨찾기는 최대 4개까지 설정하실 수 있습니다.
                </p>
              </div>
            </div>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">상담</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
              default-opened
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">수업</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
              default-opened
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">검색</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">커뮤니티</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">마이</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">외부링크</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item
              class="expansion_custom type_a01"
              expand-icon-toggle
            >
              <template v-slot:header>
                <q-item-section class="tit_area">
                  <span class="title">기타</span>
                  <strong>4</strong>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div
                    class="menu_toggle"
                    v-for="(item, index) in menuToggleList"
                    :key="index"
                  >
                    <div class="depth1">
                      <p class="title2">{{ item.depth1 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth1State = !item.depth1State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth1State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                    <div class="depth2">
                      <p class="title2">{{ item.depth2 }}</p>
                      <q-btn
                        flat
                        class=""
                        @click="item.depth2State = !item.depth2State"
                      >
                        <q-icon
                          name="icon-bookmark-fill"
                          class="icon_svg"
                          v-if="item.depth2State"
                        ></q-icon>
                        <q-icon
                          v-else
                          name="icon-bookmark"
                          class="icon_svg"
                        ></q-icon
                      ></q-btn>
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <!-- <q-btn
            outline
            v-close-popup
            class="size_lg btn_cancel"
            color="black"
            label="미동의"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg btn_save"
            label="동의"
          /> -->
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
const editState = ref(false);
const menuToggleList = ref([
  {
    depth1: '메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴',
    depth2: '메뉴 메뉴 메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴',
    depth1State: 'true',
    depth2State: 'false',
  },
  {
    depth1: '메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴',
    depth2: '메뉴 메뉴 메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴메뉴 메뉴 메뉴',
    depth1State: false,
    depth2State: false,
  },
]);
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';
</style>
