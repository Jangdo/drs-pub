<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">
        체험회원 등록
      </h1>
      <Breadcrumbs />
    </div>

    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page">
      <section class="h-full">
        <!-- form_onpage -->
        <div class="form_onpage type01" style="padding-bottom: 160px">
          <h3 class="tit impact">학습자 정보</h3>
          <!-- inner_list -->
          <ul class="inner_list">
            <li>
              <span class="as_dt required_right">이름</span>
              <q-input
                v-model="dataForm.name"
                class="as_dd hide_label"
                label="* 이름"
                outlined
                placeholder="이름를 입력하세요"
                stack-label
                dense
              >
                <template v-slot:label>이름</template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required_right">생년월일</span>
              <q-input
                outlined
                v-model="dataForm.date"
                class="as_dd hide_label inp_date"
              >
                <template v-slot:label>생년월일</template>
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date v-model="dataForm.date" minimal> </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </li>
            <li>
              <span class="as_dt required_right">휴대폰번호</span>
              <div class="wrap_as_dd">
                <div class="as_dd col2_btn">
                  <q-input
                    v-model="dataForm.phone"
                    class="as_dd hide_label"
                    label="* 휴대폰번호"
                    outlined
                    placeholder="숫자만 입력 해주세요"
                    stack-label
                    dense
                  >
                    <template v-slot:label>휴대폰번호</template>
                  </q-input>
                  <q-btn
                    fill
                    unelevated
                    class="size_sm btn_certi_num full-width"
                    color="grey-5"
                    label="인증번호 발송"
                  />
                </div>
                <div class="infor_txt">
                  <q-icon name="icon-info" class="icon_svg"></q-icon>
                  <p class="text-body2">
                    인증에 실패하였습니다 재인증 하시려면 [인증번호 재발송]을
                    선택 해주세요
                  </p>
                </div>
                <div class="as_dd col2_btn">
                  <q-input
                    v-model="dataForm.certi"
                    class="as_dd hide_label inp_certi"
                    label="* 인증번호"
                    outlined
                    placeholder="인증번호 4자리 숫자를 입력"
                    stack-label
                    dense
                  >
                    <template v-slot:append>
                      <span class="time_count text-orange">05:00</span>
                    </template>
                  </q-input>
                  <q-btn
                    fill
                    unelevated
                    class="size_sm btn_certi_num full-width"
                    color="grey-5"
                    label="인증번호 확인"
                  />
                </div>
              </div>
            </li>
            <li>
              <span class="as_dt required_right">주소</span>
              <q-input
                v-model="dataForm.address"
                class="as_dd hide_label inp_search"
                label="* 주소"
                outlined
                placeholder="주소를 검색하세요"
                stack-label
                dense
              >
                <template v-slot:label>주소</template>
                <template v-slot:append>
                  <q-btn flat :ripple="false">
                    <q-icon name="icon-search_m" class="icon_svg"></q-icon>
                  </q-btn>
                </template>
              </q-input>
              <q-input
                v-model="dataForm.address2"
                class="as_dd hide_label inp_search2 bg_white"
                disabled
                label="상세주소"
                outlined
                placeholder=""
                stack-label
                dense
              >
                <template v-slot:label>상세주소</template>
              </q-input>
            </li>
            <li>
              <div class="as_dt blank"></div>
              <div class="row_input">
                <q-checkbox
                  v-model="dataForm.check01"
                  dense
                  color="black"
                  class="inp_check"
                  label="개인정보 수집 및 이용 동의(필수)"
                />

                <q-checkbox
                  v-model="dataForm.check02"
                  dense
                  color="black"
                  class="inp_check"
                  label="마케팅 정보 수신 동의 (선택)"
                />
              </div>
            </li>
            <li>
              <span class="as_dt required_right">회원등록 경로</span>
              <div class="as_dd">
                <q-select
                  outlined
                  dense
                  v-model="dataSelect"
                  :options="dataSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dropdown-icon="ion-ios-arrow-down"
                >
                  <!-- <template v-slot:append>
                  <q-icon name="keyboard_arrow_down"></q-icon>
                </template> -->
                </q-select>
              </div>
            </li>
          </ul>
          <!--// inner_list -->
          <!-- wrap_fixed_bottom -->
          <div class="btn_area btn_bottom_type01">
            <q-btn
              unelevated
              outline
              color="grey-4"
              class="size_lg"
              label="취소"
            />
            <q-btn unelevated color="black" class="size_lg" label="등록하기" />
          </div>
          <!--// wrap_fixed_bottom -->
        </div>
        <!--// form_onpage -->
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataForm = ref({
  date: ref('2019.02.01'),
  name: '',
  txt: '',
  certi: '',
  check01: true,
  check02: false,
});
const dataSelect = ref(['선택하세요']);
const dataSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
</script>
<style lang="scss" scoped>
.h-full {
  min-height: calc(100vh - 172px);
}
</style>
