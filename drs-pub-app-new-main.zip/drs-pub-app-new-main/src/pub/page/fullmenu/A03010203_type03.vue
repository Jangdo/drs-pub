<template>
  <!-- 회원 페이지 member_page 분기-->
  <div class="member_page">
    <!-- section_card_profile -->
    <section class="section_card_profile">
      <q-card class="card_profile" flat>
        <!-- infor_area -->
        <div class="infor_area">
          <div class="pic_area">
            <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
          </div>
          <div class="txt_area">
            <div class="tit_area">
              <p class="tit text-h2">김윤찬</p>
              <span class="member_number">(P15907)</span>
              <span class="badge">신입</span>
            </div>
            <div class="more text-body2">
              <span>초등1</span>
              <span>강남교육국 외2</span>
            </div>
          </div>
        </div>
        <!--// infor_area -->
        <!-- main_btn_area -->
        <div class="main_btn_area">
          <q-btn
            flat
            stack
            dense
            icon=""
            class="btn_member_info"
            label="회원정보"
          >
          </q-btn>
          <hr class="h_separator" />
          <q-btn
            flat
            stack
            dense
            icon=""
            class="btn_lesson_manage"
            label="학습관리"
          >
          </q-btn>
          <hr class="h_separator" />
          <q-btn
            flat
            stack
            dense
            icon=""
            class="btn_pay_status"
            label="회비현황"
          >
          </q-btn>
          <hr class="h_separator" />
          <q-btn
            flat
            stack
            dense
            icon=""
            class="btn_history_manage"
            label="이력관리"
          >
          </q-btn>
        </div>
        <!--// main_btn_area -->
        <!-- parents_area -->
        <div class="parents_area">
          <p class="tit title3">김윤찬 어머님</p>
          <div class="btn_area">
            <q-btn
              round
              fill
              unelevated
              color="grey-4"
              icon=""
              class="btn_map"
            />
            <q-btn
              round
              fill
              unelevated
              color="grey-4"
              icon=""
              class="btn_mail"
            />
            <q-btn
              round
              fill
              unelevated
              color="grey-4"
              icon=""
              class="btn_call"
            />
          </div>
        </div>
        <!--// parents_area -->
      </q-card>
    </section>
    <!--// section_card_profile -->
    <hr class="separator" />
    <!-- wrap_list_type_0 -->
    <section class="wrap_list_type_0">
      <!-- section_tit -->
      <div class="section_tit">
        <h3 class="icon_txt">
          <div class="txt">
            <q-icon name="icon-class-calendar" class="icon_svg"></q-icon>
            학습중
          </div>
          <span class="impact">43</span>
          <span> 과목 </span>
        </h3>
        <q-btn to="" flat>
          <q-icon name="icon-arrow-right" class="icon_svg"></q-icon>
          <div class="a11y">바로가기</div>
        </q-btn>
      </div>
      <!-- section_tit -->
      <!--// list_type_0 -->
      <ul class="list_type_0">
        <li>
          <q-btn to="" flat>
            <p class="txt title3">눈높이 수학</p>
            <p class="count impact_color text-body1">주3회</p>
            <p class="time text-body2">23.03.05까지</p>
          </q-btn>
        </li>
        <li>
          <q-btn to="" flat>
            <p class="txt title3">솔루니 점프마스솔루니 점프마스</p>
            <p class="count impact_color text-body1">3회</p>
            <p class="time text-body2">23.03.05까지</p>
          </q-btn>
        </li>
        <li class="on">
          <q-btn :ripple="false" to="" flat>
            <p class="txt title3">써밋 중등 수학</p>
            <p class="count text-body1">체험</p>
            <p class="time text-body2">23.03.05까지</p>
          </q-btn>
        </li>
        <li class="on">
          <q-btn :ripple="false" to="" flat>
            <p class="txt title3">써밋 어휘력</p>
            <p class="count text-body1">체험</p>
            <p class="time text-body2">23.03.05까지</p>
          </q-btn>
        </li>
      </ul>
      <!-- list_type_0 -->

      <div class="btn_area shop_basket">
        <q-btn
          align="between"
          fill
          unelevated
          color="positive"
          class="size_lg btn_shop_basket full-width"
        >
          <div class="left">
            <q-icon left name="" />
            <span>학습바구니</span>
          </div>
          <div class="right">
            <span>2개 제품이 있어요</span>
            <q-icon right name="" />
          </div>
        </q-btn>
      </div>
    </section>
    <!-- //wrap_list_type_0 -->
    <hr class="separator" />
    <!-- section_pay -->
    <section class="section_pay">
      <!-- section_tit -->
      <div class="section_tit no_border">
        <h3 class="icon_txt">
          <div class="txt">
            <q-icon name="icon-card" class="icon_svg"></q-icon>
            결제현황
          </div>
        </h3>
      </div>
      <!-- section_tit -->
      <!-- pay_list -->
      <q-list class="pay_list">
        <q-expansion-item class="pay_status" expand-icon-toggle color="black">
          <template v-slot:header>
            <q-item-section class="date">
              <span class="year">2023</span>
              <span class="dot">.</span>
              <span class="month">01</span>
            </q-item-section>
            <q-item-section class="price">
              <div class="btn_area">
                <q-btn
                  fill
                  unelevated
                  icon=""
                  class="btn_exclamation"
                  @click="tooltip1 = true"
                ></q-btn>
                <div v-show="tooltip1" class="pay_alert">
                  <div class="tooltip_area">
                    <div class="text">
                      이번달
                      <span class="text-orange">미납 <span>1</span>건</span>이
                      있어요
                    </div>
                    <q-btn
                      fill
                      dense
                      class="btn_close"
                      @click="tooltip1 = false"
                    ></q-btn>
                  </div>
                </div>
              </div>
              <div class="pre">총</div>
              <div class="num">135,000</div>
              <div class="won">원</div>
            </q-item-section>
          </template>
          <q-card>
            <q-card-section>
              <div class="title">
                <span class="regular">정기</span>
                <span class="num">2</span>
                <span class="case">건</span>
              </div>
              <table class="pay_tbl">
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    <!-- 결제완료 -->
                    <q-badge color="orange" class="normal">미납</q-badge>
                    <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                  </td>
                </tr>
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    결제완료
                    <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                    <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                  </td>
                </tr>
              </table>
            </q-card-section>
            <q-separator class=""></q-separator>
            <q-card-section>
              <div class="title">
                <span class="regular">비정기</span>
                <span class="num"></span>
                <span class="case">건</span>
              </div>
              <table class="pay_tbl">
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    <!-- 결제완료 -->
                    <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                    <q-badge color="grey-4" class="normal">결제대기</q-badge>
                  </td>
                </tr>
              </table>
            </q-card-section>
          </q-card>
        </q-expansion-item>
        <q-expansion-item class="pay_status" expand-icon-toggle>
          <template v-slot:header>
            <q-item-section class="date">
              <span class="year">2023</span>
              <span class="dot">.</span>
              <span class="month">01</span>
            </q-item-section>
            <q-item-section class="price">
              <div class="btn_area">
                <q-btn
                  fill
                  unelevated
                  icon=""
                  class="btn_exclamation"
                  @click="tooltip2 = true"
                ></q-btn>
                <div v-show="tooltip2" class="pay_alert">
                  <div class="tooltip_area">
                    <div class="text">
                      이번달
                      <span class="text-orange">미납 <span>1</span>건</span>이
                      있어요
                    </div>
                    <q-btn
                      fill
                      dense
                      class="btn_close"
                      @click="tooltip2 = false"
                    ></q-btn>
                  </div>
                </div>
              </div>
              <div class="pre">총</div>
              <div class="num">135,000</div>
              <div class="won">원</div>
            </q-item-section>
          </template>
          <q-card>
            <q-card-section>
              <div class="title">
                <span class="regular">정기</span>
                <span class="num">2</span>
                <span class="case">건</span>
              </div>
              <table class="pay_tbl">
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    <!-- 결제완료 -->
                    <q-badge color="orange" class="normal">미납</q-badge>
                    <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                  </td>
                </tr>
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    결제완료
                    <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                    <!-- <q-badge color="grey-4" class="normal">결제대기</q-badge> -->
                  </td>
                </tr>
              </table>
            </q-card-section>
            <q-separator class=""></q-separator>
            <q-card-section>
              <div class="title">
                <span class="regular">비정기</span>
                <span class="num"></span>
                <span class="case">건</span>
              </div>
              <table class="pay_tbl">
                <tr>
                  <th>KB국민카드</th>
                  <td>1,1120,000원</td>
                  <td>
                    <!-- 결제완료 -->
                    <!-- <q-badge color="orange" class="normal">미납</q-badge> -->
                    <q-badge color="grey-4" class="normal">결제대기</q-badge>
                  </td>
                </tr>
              </table>
            </q-card-section>
          </q-card>
        </q-expansion-item>
      </q-list>
      <!-- //pay_list -->
      <div class="list_btm">
        <q-btn
          flat
          icon=""
          color="grey-3"
          label="전체보기"
          class="btn_all_view"
        ></q-btn>
      </div>
    </section>
    <!-- //section_pay -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
const tooltip1 = ref(false);
const tooltip2 = ref(false);
</script>
<style lang="scss"></style>
