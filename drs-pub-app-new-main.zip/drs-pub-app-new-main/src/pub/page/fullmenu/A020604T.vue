<template>
  <div class="fregment">
    <div class="cnt_top">
      <h1 class="text-h1 pc_tit" v-if="$q.screen.name == 'lg'">선생님</h1>
      <Breadcrumbs />
    </div>
    <!-- 회원 페이지 member_page 분기-->
    <div class="member_page main_page">
      <!-- 현황 -->
      <section>
        <ul class="list_type_1">
          <li class="border">
            <p class="title1 name">
              <q-icon name="icon-check_circle" class="icon_svg"></q-icon>
              승인요청
            </p>
            <div class="data">
              <span class="data_item"
                ><strong class="text-primary title1">5</strong>건</span
              >
            </div>
          </li>
        </ul>
      </section>
      <section>
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            dense
            class="tab_basic no_shadow row_4"
            :active-bg-color="
              $route.matched[1].props.default.userType === 'teacher'
                ? 'positive'
                : 'primary'
            "
            active-color="white"
            indicator-color="transparent"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">영업지표</div>
              </div>
            </q-tab>
            <q-tab name="tab2" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">과목현황</div>
              </div>
            </q-tab>
            <q-tab name="tab3" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">조직현황</div>
              </div>
            </q-tab>
            <q-tab name="tab4" :ripple="false">
              <div class="small_type_01 row">
                <div class="q-tab__label title1">입금현황</div>
              </div>
            </q-tab>
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1"></q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2"></q-tab-panel>
            <!--// tab2 컨텐츠 -->
            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3"></q-tab-panel>
            <!--// tab3 컨텐츠 -->
            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4">
              <div class="chart_area type_block">
                <div class="chart_details">
                  <ul>
                    <li>
                      <div class="top">
                        <div class="title1">
                          <strong class="dot bg-primary"></strong>회원매출액
                          <q-fab
                            direction="down"
                            hide-icon
                            class="tooltip_down type_question"
                            flat
                          >
                            <q-fab-action
                              square
                              label=""
                              label-position="bottom"
                              color="primary"
                              style="width: 200px"
                            >
                              <span class="btn_close"></span>
                              <p class="txt text-body2">물음표 타입</p>
                            </q-fab-action>
                          </q-fab>
                        </div>
                      </div>
                      <div class="bottom">
                        <q-btn
                          unelevated
                          class="title1 text-primary mob_none"
                          label="125,343"
                        >
                          <q-icon
                            name="icon-arrow-right"
                            class="icon_svg ml8 filter-grey-3"
                          ></q-icon>
                        </q-btn>
                        <div class="title1 text-primary mob_block">125,343</div>
                      </div>
                    </li>
                    <li>
                      <div class="top">
                        <div class="title1">
                          <strong class="dot bg-green"></strong>회원당매출액
                        </div>
                      </div>
                      <div class="bottom">
                        <div class="title1 text-primary">125,343</div>
                      </div>
                    </li>
                    <li>
                      <div class="top">
                        <div class="title1">
                          <strong class="dot bg-warning"></strong>입금총액
                        </div>
                      </div>
                      <div class="bottom">
                        <q-btn
                          unelevated
                          class="title1 text-primary mob_none"
                          label="125,343"
                        >
                          <q-icon
                            name="icon-arrow-right"
                            class="icon_svg ml8 filter-grey-3"
                          ></q-icon>
                        </q-btn>
                        <div class="title1 text-primary mob_block">125,343</div>
                      </div>
                    </li>
                    <li>
                      <div class="top">
                        <div class="title1">
                          <strong class="dot bg-orange"></strong>입금률
                          <q-fab
                            direction="down"
                            hide-icon
                            class="tooltip_down type_question"
                            flat
                          >
                            <q-fab-action
                              square
                              label=""
                              label-position="bottom"
                              color="primary"
                              style="width: 200px"
                            >
                              <span class="btn_close"></span>
                              <p class="txt text-body2">물음표 타입</p>
                            </q-fab-action>
                          </q-fab>
                        </div>
                      </div>
                      <div class="bottom">
                        <div class="title1 text-red">38.00%</div>
                      </div>
                    </li>
                  </ul>
                </div>

                <div class="wrap_chart_type3">
                  <vue-highcharts :options="chart_line"></vue-highcharts>
                </div>
              </div>
            </q-tab-panel>
            <!--// tab4 컨텐츠 -->
          </q-tab-panels>
        </div>
      </section>

      <!-- 공지 -->
      <section class="mt40">
        <div class="wrap_list_page_a2">
          <p class="title1">공지</p>
          <ul class="list_page_a2">
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">본사</strong>
                  <span>대교, CCM(소비자중심경영) 7회 연속 인증</span>
                </p>
              </q-btn>
            </li>
            <li>
              <q-btn flat class="txt_area" :ripple="false">
                <p>
                  <strong class="text-primary">강남교육국</strong>
                  <span
                    >선생님 2023년 상반기 교육일정 Lorem ipsum dolor sit amet
                    consectetur adipisicing elit. Accusantium praesentium ullam
                    laudantium voluptatibus cumque nobis dolore? Excepturi vero
                    a, neque tenetur inventore, iste fuga quas quisquam, maxime
                    eius dolores consequatur.</span
                  >
                </p>
              </q-btn>
            </li>
          </ul>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab4');
const chart_line = {
  colors: ['#BCD5F2', '#9747FF', '#44b87b', '#FF6B23', '#555d67', '#c0c4cd'],
  chart: {
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,

  yAxis: {
    title: false,
    labels: {
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  xAxis: {
    lineColor: '#000',
    lineWidth: 2,
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },

  plotOptions: {
    line: {
      marker: false,
    },
    series: {
      label: {
        connectorAllowed: false,
      },
      // pointStart: 2010,
    },
  },

  series: [
    {
      name: '회원매출액',
      data: [74000, 80000, 100000, 125000, 150000, 160000],
    },
    {
      name: '회원당매출액',
      data: [50000, 60000, 70000, 67000, 24000, 50000],
    },
    {
      name: '입금총액',
      data: [54000, 74000, 78000, 69000, 80000, 82000],
    },
    {
      name: '입금률(%)',
      data: [82000, 72000, 62000, 54000, 12000, 72000],
    },
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 28,
    itemStyle: {
      color: '#000',
      fontWeight: 700,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  // responsive: {
  //   rules: [
  //     {
  //       condition: {
  //         maxWidth: 500,
  //       },
  //       chartOptions: {

  //       },
  //     },
  //   ],
  // },
};
</script>
<style lang="scss" scoped>
@import '../../../css/list_a.scss';
</style>
