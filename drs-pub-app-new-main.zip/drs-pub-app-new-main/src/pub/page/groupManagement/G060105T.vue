<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_contents_box">
        <!-- 상단정보 -->
        <div class="con_tab_head">
          <div class="con_tab_head-top">
            <p class="title1">2023년 11월</p>
          </div>
          <div class="con_tab_head-bottom">
            <div class="title4 text-grey-4 dept_info">
              <span>서울서북본부</span>
              <span>강서교육국</span>
              <span>001팀</span>
              <span class="title3 text-grey-1">YC1[바다꿈] 운영현황</span>
              <!-- 서울서북본부 > 강서교육국 > 001팀 > YC1[바다꿈] 운영현황 -->
            </div>
            <div class="body2 text-grey-3 manager_info" 담당자>
              <span>팀장 <strong class="text-black">홍길동</strong></span>
              <span>SC교사 <strong class="text-black">김대교</strong></span>
              <span class="text-orange">직영</span>
            </div>
          </div>
        </div>
        <!-- //상단정보 -->

        <!-- 콘텐츠박스 내 탭 픽스타입 -->
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            inline-label
            class="tab_line type02"
            active-bg-color="white"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" label="영업현황" :ripple="false" />
            <q-tab name="tab2" label="회원매출/입금" :ripple="false" />
            <q-tab name="tab3" label="관리지표" :ripple="false" />
            <q-tab name="tab4" label="서비스지표" :ripple="false" />
            <q-tab name="tab5" label="출결율" :ripple="false" />
            <q-tab name="tab6" label="과목/학습방법 현황" :ripple="false" />
          </q-tabs>
          <q-tab-panels v-model="tab" animated>
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1">상하단라인 좌측여백 fix 내용1</q-tab-panel>
            <!--// tab1 컨텐츠 -->

            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2"> 하단라인 좌측여백 fix 내용2 </q-tab-panel>
            <!--// tab2 컨텐츠 -->

            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3"> 하단라인 좌측여백 fix 내용3 </q-tab-panel>
            <!--// tab3 컨텐츠 -->

            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4">상하단라인 좌측여백 fix 내용4</q-tab-panel>
            <!--// tab4 컨텐츠 -->

            <!-- tab5 컨텐츠 -->
            <q-tab-panel name="tab5">
              <h3 class="title1 text-grey-1 mb20">출결현황</h3>
              <div class="wrap_flex_half_g30">
                <div class="wrap_highcharts" style="min-height: 230px">
                  <h4 class="title3 mb30">2022년 4월</h4>
                  <div class="row justify-around" style="background: #f1f7fb">
                    <q-knob
                      readonly
                      v-model="circle1"
                      show-value
                      :size="[$q.screen.name == 'lg' ? '10vw' : '100px']"
                      :thickness="0.3"
                      color="orange-10"
                      track-color="grey-6"
                    >
                      <div class="label_area">
                        <div class="text-body3 text-center">월누적</div>
                        <div class="text-h3 text-orange-10">{{ circle1 }}%</div>
                      </div>
                      <div class="knob-desc"><b>00</b>/000</div>
                    </q-knob>

                    <q-knob
                      readonly
                      v-model="circle2"
                      show-value
                      :size="[$q.screen.name == 'lg' ? '10vw' : '100px']"
                      :thickness="0.3"
                      color="blue-10"
                      track-color="grey-6"
                    >
                      <div class="label_area">
                        <div class="text-body3 text-center">2주차</div>
                        <div class="text-h3 text-blue-10">{{ circle2 }}%</div>
                      </div>
                      <div class="knob-desc"><b>00</b>/000</div>
                    </q-knob>
                  </div>
                </div>

                <div class="wrap_highcharts">
                  <h4 class="title3 mb30">2022년 4월</h4>
                  <vue-highcharts
                    :options="chart_column_shadow"
                  ></vue-highcharts>
                </div>
              </div>
              <div class="wrap_flex_g30">
                <div class="wrap_highcharts">
                  <!-- 데이터 없음 -->
                  <div
                    class="flex flex-center column"
                    style="min-height: 230px"
                  >
                    <q-icon
                      name="icon-info-grey filter-grey-6"
                      class="icon_svg"
                      size="32px"
                      color="grey-6"
                    ></q-icon>
                    <span class="text-grey-3 mt10"
                      >영업일 전일 기준으로 데이터가 없습니다</span
                    >
                  </div>
                </div>
              </div>
            </q-tab-panel>
            <!--// tab5 컨텐츠 -->

            <!-- tab6 컨텐츠 -->
            <q-tab-panel name="tab6">상하단라인 좌측여백 fix 내용6</q-tab-panel>
            <!--// tab6 컨텐츠 -->
          </q-tab-panels>
        </div>
        <!-- //콘텐츠박스 내 탭 픽스타입 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

import VueHighcharts from 'vue3-highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import accessibility from 'highcharts/modules/accessibility';
import Highcharts from 'highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

HighchartsMore(Highcharts);
accessibility(Highcharts);
// table_search_area
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');
// const searchExpand = ref(true);

const searchDate = ref({
  from: '2023.05.03',
});

// 탭
const tab = ref('tab5');

// 차트
const chart_column_shadow = {
  chart: {
    // 높이 수정
    height: 250,
    backgroundColor: '#F1F7FB',
    type: 'column',
  },
  title: false,
  xAxis: {
    lineColor: '#000000',
    lineWidth: 2,
    categories: ['월요일', '화요일', '수요일', '목요일', '금요일'],
    labels: {
      format: '{value}',
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: [
    {
      min: 0,
      max: 100,
      opposite: false,
      title: false,
      subtitle: false,
      // y축 라벨 삭제
      labels: { enabled: false, format: '{value}월' },
    },
  ],
  legend: false,
  tooltip: {
    shared: false,
  },
  plotOptions: {
    column: {
      grouping: false,
      shadow: false,
      borderWidth: 0,
      borderRadius: 2,
      pointWidth: 24,
    },
  },

  series: [
    {
      name: '목표',
      color: '#C0C4CD',
      data: [100, 100, 100, 100, 100],
      pointPadding: 0.3,
      pointPlacement: -0.2,
    },
    {
      name: '달성',
      color: '#555D67',
      data: [88, 90, 0, 0, 0],
      pointPadding: 0.3,
      pointPlacement: -0.2,
      dataLabels: [
        {
          // pointFormat:
          //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          format: '{point.y}%',
          enabled: true,
          inside: true,
          style: {
            textOutline: false,
            color: '#fff',
            fontSize: 12,
            fontWeight: '400',
            fontFamily: 'Pretendard',
          },
        },
      ],
    },
  ],
};

// q-knob circle
const circle1 = ref(80);
const circle2 = ref(70);
</script>
