<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->
        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="wrapper_tab">
                <q-tabs
                  v-model="tabintab"
                  inline-label
                  class="tab_line"
                  active-bg-color="white"
                  active-color="primary"
                  indicator-color="primary"
                  align="justify"
                  narrow-indicator
                  outside-arrows
                >
                  <q-tab name="tab41" label="원칙" :ripple="false" />
                  <q-tab name="tab42" label="직원명부" :ripple="false" />
                  <q-tab name="tab43" label="지도점검기록부" :ripple="false" />
                  <q-tab name="tab44" label="학원강사 게시표" :ripple="false" />
                  <q-tab name="tab45" label="교습비 게시표" :ripple="false" />
                  <q-tab
                    name="tab46"
                    label="교습비 반환 규정"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab47"
                    label="문서접수 및 발송대장"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab48"
                    label="교습비 게시표(옥외)"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab49"
                    label="학원 안전점검 체크리스트"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab410"
                    label="자체 실태 점검표 "
                    :ripple="false"
                  />
                </q-tabs>
                <q-tab-panels v-model="tabintab" animated>
                  <!-- tab41 컨텐츠 -->
                  <q-tab-panel name="tab41"> tab41 </q-tab-panel>
                  <!--// tab41 컨텐츠 -->

                  <!-- tab42 컨텐츠 -->
                  <q-tab-panel name="tab42"> tab42 </q-tab-panel>
                  <!--// tab42 컨텐츠 -->

                  <!-- tab43 컨텐츠 -->
                  <q-tab-panel name="tab43"> tab43 </q-tab-panel>
                  <!--// tab43 컨텐츠 -->

                  <!-- tab44 컨텐츠 -->
                  <q-tab-panel name="tab44"> tab44 </q-tab-panel>
                  <!--// tab44 컨텐츠 -->

                  <!-- tab45 컨텐츠 -->
                  <q-tab-panel name="tab45"> tab45 </q-tab-panel>
                  <!--// tab45 컨텐츠 -->

                  <!-- tab46 컨텐츠 -->
                  <q-tab-panel name="tab46"> tab46 </q-tab-panel>
                  <!--// tab46 컨텐츠 -->

                  <!-- tab47 컨텐츠 -->
                  <q-tab-panel name="tab47"> tab47 </q-tab-panel>
                  <!--// tab47 컨텐츠 -->

                  <!-- tab48 컨텐츠 -->
                  <q-tab-panel name="tab48"> tab48 </q-tab-panel>
                  <!--// tab48 컨텐츠 -->

                  <!-- tab49 컨텐츠 -->
                  <q-tab-panel name="tab49">
                    <!-- summary + button -->
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.04.07</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>
                    <!-- // summary + button -->

                    <!-- 라운드박스 -->
                    <div class="document_rule">
                      <div class="outline_box">
                        <h3 class="title1 text-grey-1">
                          학원 안전점검 체크리스트
                        </h3>
                        <div class="group">
                          <!-- 버튼 영역 -->
                          <div class="btn_area type_g1 center">
                            <span class="text-body2 mr10">학원(교습소)명</span>
                            <q-input
                              class="inp_basic mr20"
                              outlined
                              v-model="inp1"
                              placeholder="입력하세요"
                            />
                            <span class="text-body2 mr10">학원(교습소)명</span>
                            <q-input
                              class="inp_basic mr20"
                              outlined
                              v-model="inp2"
                              placeholder="입력하세요"
                            />
                            <span class="text-body2 mr10"
                              >점검일(월별작성)</span
                            >
                            <!-- searchDate start.to -->
                            <q-input
                              outlined
                              v-model="searchDate.to"
                              class="inp_date mr20 normal"
                              readonly
                            >
                              <template v-slot:append>
                                <q-icon
                                  name="icon-calendar"
                                  class="icon_svg cursor-pointer"
                                >
                                  <q-popup-proxy
                                    ref="qDateProxyto"
                                    cover
                                    transition-show="scale"
                                    transition-hide="scale"
                                  >
                                    <q-date
                                      minimal
                                      v-model="searchDate.to"
                                      mask="YYYY.MM.DD"
                                      @update:model-value="
                                        searchDate.to, $refs.qDateProxyto.hide()
                                      "
                                    >
                                    </q-date>
                                  </q-popup-proxy>
                                </q-icon>
                              </template>
                            </q-input>
                            <!--// searchDate start.to -->
                            <q-space />
                            <div class="btn_area">
                              <q-btn
                                class="size_sm"
                                fill
                                unelevated
                                color="black"
                                label="등록"
                              />
                            </div>
                          </div>
                          <!-- 버튼 영역 -->

                          <!-- table -->
                          <q-markup-table separator="cell" wrap-cells>
                            <colgroup>
                              <col />
                              <col style="width: 200px !important" />
                              <col
                                style="
                                  min-width: 300px !important;
                                  max-width: 640px !important;
                                "
                              />
                            </colgroup>
                            <thead>
                              <tr>
                                <th class="">세부점검 사항</th>
                                <th class="">점검결과</th>
                                <th class="">비고</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 안전관리 매뉴얼, 대피 안내 및 보험가입 철저
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 피난안내도 부착 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 각 실별 화재 발생 시 대피요령 안내문 비치
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 안전관리 매뉴얼 비치 및 관계자 내용 숙지
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 영업배상 책임보험 등 가입 및 갱신계약 이행
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 건물 등 시설물 안전 분야
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 비상대피로 확보 및 비상문 개방 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 계단, 복도 등 대피로 물건 적재 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 내부시설 무단 개조 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 승강기 등 내부설비 정기검사 실시
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 전기 안전 분야
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 전기설비 정기검사 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 전기 배선 불량 및 콘센트 분산 사용 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 누전차단기 작동 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 소방 안전 분야(소방설치 기준에 따라 점검)
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 소화기 비치 및 충약 상태 여부(1실당 1개)
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 소방시설 정기검사 여부(완강기 포함)
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 피난 유도등 상태 및 피난구 확보 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 자동화재감지기 및 경보기 작동 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 인화성 물질 방치 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 화재예방 실천 및 화재 발생 시 대피요령 숙지
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 가스시설 등 위험물 안전 분야(해당 시설의
                                  경우)
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 경보, 차단설비 작동 및 주변 환기 상태
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 가스공급 조절장치 이상 유무
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 가스배관 고정 및 도색불량 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 중간밸브 설치 및 위치 적정 여부
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 취사용가스, 도시가스시설, 보일러실 등
                                  관리실태
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td class="text-left pl24">
                                  - 가스 등 위험시설 안전교육 실시
                                </td>
                                <td>
                                  <q-select
                                    class="hide_label"
                                    label="선택하세요"
                                    v-model="select1"
                                    :options="select1Option"
                                    option-value="id"
                                    option-label="desc"
                                    option-disable="inactive"
                                    emit-value
                                    map-options
                                    dense
                                    outlined
                                    dropdown-icon="ion-ios-arrow-down"
                                  >
                                  </q-select>
                                </td>
                                <td>
                                  <div class="search_item">
                                    <q-input
                                      v-model="input"
                                      class="w100p"
                                      outlined
                                      placeholder=""
                                    />
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="3" class="bg_blue">
                                  ○ 가스시설 등 위험물 안전 분야(해당 시설의
                                  경우)
                                </td>
                              </tr>
                            </tbody>
                          </q-markup-table>
                          <!-- // table -->
                        </div>
                      </div>

                      <div class="info_caution mt20">
                        <strong class="info_caution_tit"
                          ><q-icon name="icon-info02" class="icon_svg"></q-icon>
                          주의사항</strong
                        >
                        <p>
                          위 안전점검 체크리스트는 다중이용업소 기준에 해당되지
                          않는 학원·교습소에서 작성하는 서식임( 시설 규모에 따라
                          적정 변경하여 사용 가능 ) 위 안전점검 체크리스트는
                          다중이용업소 기준에 해당되지 않는 학원·교습소에서
                          작성하는 서식임( 시설 규모에 따라 적정 변경하여 사용
                          가능 )
                        </p>
                        <p>
                          점검 결과 미흡한 사항은 개선 조치해야 함 ( 건물주와
                          협의 )
                        </p>
                      </div>
                    </div>
                    <!-- // 라운드박스 -->
                  </q-tab-panel>
                  <!--// tab49 컨텐츠 -->

                  <!-- tab410 컨텐츠 -->
                  <q-tab-panel name="tab410">410</q-tab-panel>
                  <!--// tab410 컨텐츠 -->
                </q-tab-panels>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab4');
const tabintab = ref('tab49');

// 인풋창
const input = ref();
const inp1 = ref();
const inp2 = ref();
const searchDate = ref({
  to: '2019.02.01',
});

const select1 = ref(['']);
const select1Option = ref([
  {
    id: 's1',
    desc: '세렉트1',
  },
  {
    id: 's2',
    desc: '세렉트2',
  },
]);
</script>
