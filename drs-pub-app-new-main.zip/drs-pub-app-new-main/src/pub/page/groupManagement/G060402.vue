<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">이체제외/수정</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- 탭 영역 -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="선생님별 교재청구점검표 " :ripple="false" />
          <q-tab name="tab2" label="진도미결정교사 조회" :ripple="false" />
          <q-tab name="tab3" label="진도그래프 점검/추천" :ripple="false" />
          <q-tab name="tab4" label="요일별 진도점검표" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> tab1 내용 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="box_xl normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                              self="top middle"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                :emit-immediately="true"
                                default-view="Months"
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <span class="text-body2">~</span>
                      <q-input
                        outlined
                        v-model="searchDate.to"
                        class="box_xl normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyTo"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                              self="top middle"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                :emit-immediately="true"
                                default-view="Months"
                                v-model="searchDate.to"
                                @update:model-value="
                                  searchDate.to, $refs.qDateProxyTo.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                </div>
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="section"
                  v-model:pagination="paginationSample"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                </q-table>
              </div>
              <!--// general_table -->

              <!-- 테이블 하단 인포 리스트 -->
              <div class="info_list_box mt30">
                <ul class="ul_custom disc">
                  <li>
                    데이터가 많아 조회하는데 무리가 갈 수 있으므로 범위는
                    1일(하루)로 해주십시오.
                  </li>
                  <li>
                    각 교실의 인원수 Coloum을 클릭하여 교실별 인원수를
                    확인하십시요.
                  </li>
                </ul>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 내용 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 내용 </q-tab-panel>
          <!--// tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
      <!-- // 탭 영역 -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// 현재탭 활성
const tab = ref('tab2');

// 날짜선택
const searchDate = ref({
  from: '2023.05',
  to: '2023.05',
});

//data테이블 페이징
const paginationSample = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 0,
});

// 테이블 헤더 칼럼명
const dataColumns = ref([
  {
    name: 'idx',
    label: 'No.',
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'endDay',
    label: '교재마감일',
    align: 'center',
    field: (row) => row.endDay,
  },
  {
    name: 'businessTeam',
    label: '사업팀',
    align: 'center',
    field: (row) => row.businessTeam,
  },
  {
    name: 'chanel',
    label: '채널명',
    align: 'center',
    field: (row) => row.chanel,
  },
  {
    name: 'teacher',
    label: '선생님명',
    align: 'center',
    field: (row) => row.teacher,
  },
  {
    name: 'tdata5',
    label: '결정현황',
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'monday',
    label: '월',
    align: 'center',
    field: (row) => row.monday,
  },
  {
    name: 'thuesday',
    label: '화',
    align: 'center',
    field: (row) => row.thuesday,
  },
  {
    name: 'wednesdsday',
    label: '수',
    align: 'center',
    field: (row) => row.wednesdsday,
  },
  {
    name: 'thursday',
    label: '목',
    align: 'center',
    field: (row) => row.thursday,
  },
  {
    name: 'friday',
    label: '금',
    align: 'center',
    field: (row) => row.friday,
  },
]);

// 테이블 row 데이터
const dataRows = ref([
  {
    idx: 10,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 9,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 8,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 7,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 6,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 5,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 4,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 3,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 2,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
  {
    idx: 1,
    endDay: '2023.05.04',
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    teacher: '김정숙[0031044761]',
    tdata5: '-',
    monday: '4/34',
    thuesday: '4/34',
    wednesdsday: '4/34',
    thursday: '4/34',
    friday: '4/34',
  },
]);
</script>
