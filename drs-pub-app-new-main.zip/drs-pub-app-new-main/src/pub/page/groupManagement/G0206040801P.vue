<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card type_02 small">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">교습비 상세</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>구분</th>
                <td class="text-left">수학</td>
              </tr>
              <tr>
                <th>과목</th>
                <td class="text-left">써밋 스피드 수학</td>
              </tr>
              <tr>
                <th>분당 초등 단가</th>
                <td>
                  <div class="search_item type_small">
                    <q-input
                      v-model="input1"
                      class=""
                      outlined
                      input-class="text-right"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>분당 중등 단가</th>
                <td>
                  <div class="search_item type_small">
                    <q-input
                      v-model="input2"
                      class=""
                      outlined
                      input-class="text-right"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>학습시간</th>
                <td>
                  <div class="search_item type_small">
                    <q-input
                      v-model="input3"
                      class=""
                      outlined
                      input-class="text-right"
                      readonly
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>가격</th>
                <td class="text-left">80,000</td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const input1 = ref('100');
const input2 = ref('100');
const input3 = ref('10');
</script>
