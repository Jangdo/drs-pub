<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">목표수립</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- table_search_area type_flexable -->
      <div class="table_search_area type_flexable">
        <div class="search_hide" v-if="searchExpand">
          <div class="search_item">
            <q-select
              class="box_l"
              v-model="searchYearType"
              :options="searchYearTypeOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="search_item">
            <q-select
              class="box_l"
              v-model="searchSubjectType"
              :options="searchSubjectTypeOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="search_item btn_area">
            <q-btn class="size_sm btn_reset" icon="" outline label="초기화" />
            <q-btn fill unelevated class="size_sm btn_search" label="조회" />
          </div>
        </div>
        <div class="search_expand">
          <q-btn
            class="size_sm btn_contract"
            v-if="searchExpand"
            fill
            unelevated
            icon=""
            label="검색 닫기"
            @click="searchExpand = false"
          />
          <q-btn
            class="size_sm btn_expand"
            v-else
            fill
            unelevated
            icon=""
            label="검색 펼치기"
            @click="searchExpand = true"
          />
        </div>
      </div>
      <!--// table_search_area type_flexable -->

      <div class="wrap_table_box">
        <!-- 참고하세요 + 더보기 -->
        <div class="wrap_info_box v_center">
          <div class="tit_area">
            <q-icon name="icon-info" class="icon_svg"></q-icon>
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>해당 테이블의 항목별 설명이 두줄 가량 노출됩니다.</p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
        <!-- // 참고하세요 + 더보기 -->

        <!-- general_table -->
        <div class="general_table type_total">
          <!-- 버튼영역 -->
          <div class="btn_area type_g2">
            <!-- item 추가 수정-->
            <div class="item">
              <q-btn class="size_sm" outline label="수정완료" />
              <q-btn
                fill
                unelevated
                v-close-popup
                color="primary"
                class="size_sm"
                label="최종완료"
              />
            </div>
          </div>
          <!-- // 버튼영역 -->

          <q-table
            class="multi_head scrollable tbl_row_13"
            :rows="dataRows"
            row-key="tdata1"
            hide-bottom
            v-model:pagination="dataPagination"
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="3">본부</th>
                <th colspan="6">조직규모</th>
                <th colspan="2">시장성 50%</th>
                <th rowspan="3">비중합계</th>
                <th rowspan="3">순증수</th>
                <th rowspan="3" style="width: 170px">순증지 수정</th>
                <th rowspan="3">매출목표수정</th>
              </tr>
              <tr>
                <th colspan="2" class="row_first">총원(과목) 10%</th>
                <th colspan="2">교사수 10%</th>
                <th colspan="2">러닝센터수 30%</th>
                <th colspan="2">전략대상고객</th>
              </tr>
              <tr>
                <th class="row_first">전년 12월</th>
                <th>비중</th>
                <th>전년 12월</th>
                <th>비중</th>
                <th>전년 12월</th>
                <th>비중</th>
                <th>목표 년</th>
                <th>비중</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="align_center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="align_center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="align_center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="align_center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="align_center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="align_center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="align_center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="align_right">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="align_center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="align_right">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="align_right">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="align_center">
                  <div class="search_item">
                    <q-input class="" for="" outlined placeholder="" />
                  </div>
                </q-td>
                <q-td key="tdata13" class="align_right">
                  {{ props.row.tdata13 }}
                </q-td>
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td class="align_center">합계</q-td>
                <q-td class="align_center">1,000,000,000</q-td>
                <q-td class="align_center">10.01%</q-td>
                <q-td class="align_center">99,000,000</q-td>
                <q-td class="align_center">5.0%</q-td>
                <q-td class="align_center">10,000</q-td>
                <q-td class="align_center">1.01%</q-td>
                <q-td class="align_right">100</q-td>
                <q-td class="align_center">1.00%</q-td>
                <q-td class="align_right">10.00%</q-td>
                <q-td class="align_right">500</q-td>
                <q-td class="align_right">5,000</q-td>
                <q-td class="align_right">9.00%</q-td>
              </q-tr>
              <q-tr class="tr_btm type_total">
                <q-td class="align_center">수정합계</q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_right"></q-td>
                <q-td class="align_center"></q-td>
                <q-td class="align_right"></q-td>
                <q-td class="align_right"></q-td>
                <q-td class="align_right"
                  ><span class="fc_primary">5,000</span></q-td
                >
                <q-td class="align_right">9.00%</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchYearType = ref(['년도를 선택하세요']);
const searchYearTypeOption = ref([
  {
    id: 'year1',
    desc: '2023',
  },
  {
    id: 'year1',
    desc: '2024',
  },
]);

const searchSubjectType = ref(['구분을 선택하세요']);
const searchSubjectTypeOption = ref([
  {
    id: 'subject1',
    desc: '구분1',
  },
  {
    id: 'subject2',
    desc: '구분2 ',
  },
]);
const searchExpand = ref(true);

//data테이블
const dataRows = ref([
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: false,
  page: 1,
  rowsPerPage: 9999,
});
</script>
