<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">목표수립</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="본부" :ripple="false" />
          <q-tab name="tab2" label="조직" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      for="id2"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            transition-show="scale"
                            transition-hide="scale"
                            self="top middle"
                          >
                            <q-date
                              minimal
                              mask="YYYY"
                              years-in-month-view
                              :emit-immediately="true"
                              default-view="Years"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                    <!-- <q-select
                    class="hide_label box_l"
                    label="년도를 선택하세요"
                    v-model="searchYearType"
                    :options="searchYearTypeOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select> -->
                  </div>
                  <div class="col-12 col-md-9">
                    <q-option-group
                      v-model="groupSelect"
                      :options="groupSelectOptions"
                      color="black"
                      inline
                    />
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="general_table type_total">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                  <div class="btn_wrap col-12 col-md-8 gap10">
                    <div class="item">
                      <q-btn class="size_sm" outline label="수정완료" />
                    </div>
                  </div>
                </div>

                <q-table
                  class="multi_head scrollable tbl_row_14"
                  :rows="dataRows"
                  row-key="idx"
                  hide-bottom
                  v-model:pagination="dataPagination"
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th rowspan="2">본부</th>
                      <th colspan="16">순증지수 목표</th>
                    </tr>
                    <tr>
                      <th class="row_first">1월</th>
                      <th>2월</th>
                      <th>3월</th>
                      <th>1Q</th>
                      <th>4월</th>
                      <th>5월</th>
                      <th>6월</th>
                      <th>2Q</th>
                      <th>7월</th>
                      <th>8월</th>
                      <th>9월</th>
                      <th>3Q</th>
                      <th>10월</th>
                      <th>11월</th>
                      <th>12월</th>
                      <th>4Q</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props" class="h116">
                      <q-td key="tdata1" class="align_center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="align_right pa0">
                        <div class="w100p">
                          <div class="text-orange">{{ props.row.tdata2 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata3" class="align_right pa0">
                        <div class="w100p">
                          <div class="text-primary">{{ props.row.tdata3 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata4" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata5" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata5 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata6" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata6 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata7" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata7 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata8" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata8 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata9" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata9 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata10" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata10 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata11" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata11 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata12" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata12 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata13" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata13 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata14" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata14 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata15" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata15 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata16" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata16 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                      <q-td key="tdata17" class="align_right pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata17 }}</div>
                          <div>
                            <q-input
                              class="w100"
                              for=""
                              outlined
                              dense
                              v-model="keyword"
                              placeholder="입력하세요"
                            />
                          </div>
                        </div>
                      </q-td>
                    </q-tr>
                  </template>
                  <template v-slot:bottom-row>
                    <q-tr class="tr_btm">
                      <q-td class="align_center">합계</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">80.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                    </q-tr>
                    <q-tr class="tr_btm type_total">
                      <q-td class="align_center">수정합계</q-td>
                      <q-td class="align_right text-orange">1,000.0</q-td>
                      <q-td class="align_right">11,180.0</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">100.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">111,111,000.0</q-td>
                      <q-td class="align_right">1,111,000.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">100.0</q-td>
                      <q-td class="align_right">10.0</q-td>
                      <q-td class="align_right">100.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                      <q-td class="align_right">1,111,000.0</q-td>
                    </q-tr>
                    <q-tr class="tr_btm type_total">
                      <q-td class="align_center">기준합계</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                      <q-td class="align_right">180.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">10.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,111,000.0</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">1,100.0</q-td>
                      <q-td class="align_right">100.0</q-td>
                      <q-td class="align_right">100.0</q-td>
                      <q-td class="align_right">1,000.0</q-td>
                      <q-td class="align_right">11,000.0</q-td>
                      <q-td class="align_right">111,000.0</q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table -->
              <!-- 참고하세요 + 더보기 -->
              <div class="wrap_info_box v_center">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>해당 테이블의 항목별 설명이 두줄 가량 노출됩니다.</p>
                </div>
                <div class="btn_area">
                  <q-btn
                    fill
                    unelevated
                    color="grey-4"
                    class="size_xs"
                    label="더보기"
                  />
                </div>
              </div>
              <!-- // 참고하세요 + 더보기 -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->
          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');
const searchDate = ref({
  from: '2019',
});
// // table_search_area
// const searchYearType = ref(['']);
// const searchYearTypeOption = ref([
//   {
//     id: 'year1',
//     desc: '2023',
//   },
//   {
//     id: 'year2',
//     desc: '2024',
//   },
// ]);
// radio group
const groupSelect = ref('op1');
const groupSelectOptions = ref([
  {
    label: '순증수',
    value: 'op1',
  },
  {
    label: '순증지수',
    value: 'op2',
  },
  {
    label: '매출',
    value: 'op3',
  },
]);

//data테이블
const keyword = ref([]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 10,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 9,
    tdata1: '서울 중앙',
    tdata2: '1,00.0',
    tdata3: '10.0',
    tdata4: '1,00.0',
    tdata5: '0.0',
    tdata6: '10.0',
    tdata7: '1,00.0',
    tdata8: '111,000.0',
    tdata9: '1,111,000.0',
    tdata10: '11,111,000.0',
    tdata11: '111,111,000.0',
    tdata12: '10,000.0',
    tdata13: '100,000.0',
    tdata14: '100.0',
    tdata15: '10.0',
    tdata16: '1.0',
    tdata17: '111,000.0',
  },
  {
    idx: 8,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 7,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 6,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 5,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 4,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 3,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 2,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
  {
    idx: 1,
    tdata1: '서울서북',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
  },
]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
</script>
