<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">진도점검관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="선생님별 교재청구점검표" :ripple="false" />
          <q-tab name="tab2" label="진도미결정교사조회" :ripple="false" />
          <q-tab name="tab3" label="진도그래프 점검/추천" :ripple="false" />
          <q-tab name="tab4" label="요일별 진도점검표" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="box_l normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                :emit-immediately="true"
                                default-view="Months"
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <q-input
                        class="inp_search"
                        outlined
                        dense
                        placeholder="제품"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>
            <q-space class="sp30" />
            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <q-table
                  :rows="data1Rows"
                  :columns="data1Columns"
                  row-key="idx"
                  v-model:pagination="data1Pagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                </q-table>

                <q-table
                  class="multi_head mt30"
                  :rows="data2Rows"
                  row-key="idx"
                  v-model:pagination="data2Pagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th rowspan="2">과목</th>
                      <th rowspan="2">교재</th>
                      <th>1</th>
                      <th>2</th>
                      <th>3</th>
                      <th>4</th>
                      <th>5</th>
                      <th>6</th>
                      <th>7</th>
                      <th>8</th>
                      <th>9</th>
                      <th>10</th>
                      <th>11</th>
                      <th>12</th>
                      <th>13</th>
                      <th>14</th>
                      <th>15</th>
                      <th>16</th>
                      <th>17</th>
                      <th>18</th>
                      <th>19</th>
                      <th>20</th>
                      <th>21</th>
                      <th>22</th>
                      <th>23</th>
                      <th>24</th>
                      <th>25</th>
                      <th>26</th>
                      <th>27</th>
                      <th>28</th>
                      <th>29</th>
                      <th>30</th>
                      <th>31</th>
                      <th>32</th>
                      <th>33</th>
                      <th>34</th>
                      <th>35</th>
                      <th>36</th>
                      <th>37</th>
                      <th>38</th>
                      <th>39</th>
                      <th>40</th>
                      <th rowspan="2">01</th>
                    </tr>
                    <tr>
                      <th class="row_first">41</th>
                      <th>42</th>
                      <th>43</th>
                      <th>44</th>
                      <th>45</th>
                      <th>46</th>
                      <th>47</th>
                      <th>48</th>
                      <th>49</th>
                      <th>50</th>
                      <th>51</th>
                      <th>52</th>
                      <th>53</th>
                      <th>54</th>
                      <th>55</th>
                      <th>56</th>
                      <th>57</th>
                      <th>58</th>
                      <th>59</th>
                      <th>60</th>
                      <th>61</th>
                      <th>62</th>
                      <th>63</th>
                      <th>64</th>
                      <th>65</th>
                      <th>66</th>
                      <th>67</th>
                      <th>68</th>
                      <th>69</th>
                      <th>70</th>
                      <th>71</th>
                      <th>72</th>
                      <th>73</th>
                      <th>74</th>
                      <th>75</th>
                      <th>76</th>
                      <th>77</th>
                      <th>78</th>
                      <th>79</th>
                      <th>80</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="tdata1" class="align_center" rowspan="3">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="align_center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata2_1" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_1 }}</div>
                          <div>{{ props.row.tdata2_41 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_2" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_2 }}</div>
                          <div>{{ props.row.tdata2_42 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_3" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_3 }}</div>
                          <div>{{ props.row.tdata2_43 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_4" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_4 }}</div>
                          <div>{{ props.row.tdata2_44 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_5" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_5 }}</div>
                          <div>{{ props.row.tdata2_45 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_6" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_6 }}</div>
                          <div>{{ props.row.tdata2_46 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_7" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_7 }}</div>
                          <div>{{ props.row.tdata2_47 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_8" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_8 }}</div>
                          <div>{{ props.row.tdata2_48 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_9" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_9 }}</div>
                          <div>{{ props.row.tdata2_49 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_10" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_10 }}</div>
                          <div>{{ props.row.tdata2_50 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_11" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_11 }}</div>
                          <div>{{ props.row.tdata2_51 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_12" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_12 }}</div>
                          <div>{{ props.row.tdata2_52 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_13" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_13 }}</div>
                          <div>{{ props.row.tdata2_53 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_14" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_14 }}</div>
                          <div>{{ props.row.tdata2_54 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_15" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_15 }}</div>
                          <div>{{ props.row.tdata2_55 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_16" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_16 }}</div>
                          <div>{{ props.row.tdata2_56 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_17" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_17 }}</div>
                          <div>{{ props.row.tdata2_57 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_18" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_18 }}</div>
                          <div>{{ props.row.tdata2_58 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_19" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_19 }}</div>
                          <div>{{ props.row.tdata2_59 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_20" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_20 }}</div>
                          <div>{{ props.row.tdata2_60 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_21" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_21 }}</div>
                          <div>{{ props.row.tdata2_61 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_22" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_22 }}</div>
                          <div>{{ props.row.tdata2_62 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_23" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_23 }}</div>
                          <div>{{ props.row.tdata2_63 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_24" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_24 }}</div>
                          <div>{{ props.row.tdata2_64 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_25" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_25 }}</div>
                          <div>{{ props.row.tdata2_65 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_26" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_26 }}</div>
                          <div>{{ props.row.tdata2_66 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_27" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_27 }}</div>
                          <div>{{ props.row.tdata2_67 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_28" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_28 }}</div>
                          <div>{{ props.row.tdata2_68 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_29" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_29 }}</div>
                          <div>{{ props.row.tdata2_69 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_30" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_30 }}</div>
                          <div>{{ props.row.tdata2_70 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_31" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_31 }}</div>
                          <div>{{ props.row.tdata2_71 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_32" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_32 }}</div>
                          <div>{{ props.row.tdata2_72 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_33" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_33 }}</div>
                          <div>{{ props.row.tdata2_73 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_34" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_34 }}</div>
                          <div>{{ props.row.tdata2_74 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_35" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_35 }}</div>
                          <div>{{ props.row.tdata2_75 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_36" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_36 }}</div>
                          <div>{{ props.row.tdata2_76 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_37" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_37 }}</div>
                          <div>{{ props.row.tdata2_77 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_38" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_38 }}</div>
                          <div>{{ props.row.tdata2_78 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_39" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_39 }}</div>
                          <div>{{ props.row.tdata2_79 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_40" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata2_40 }}</div>
                          <div>{{ props.row.tdata2_80 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata2_total" class="align_center">
                        {{ props.row.tdata2_total }}
                      </q-td>
                    </q-tr>
                    <q-tr :props="props">
                      <q-td key="tdata3" class="align_center row_first">
                        {{ props.row.tdata3 }}
                      </q-td>
                      <q-td key="tdata3_1" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_1 }}</div>
                          <div>{{ props.row.tdata3_41 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_2" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_2 }}</div>
                          <div>{{ props.row.tdata3_42 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_3" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_3 }}</div>
                          <div>{{ props.row.tdata3_43 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_4" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_4 }}</div>
                          <div>{{ props.row.tdata3_44 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_5" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_5 }}</div>
                          <div>{{ props.row.tdata3_45 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_6" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_6 }}</div>
                          <div>{{ props.row.tdata3_46 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_7" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_7 }}</div>
                          <div>{{ props.row.tdata3_47 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_8" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_8 }}</div>
                          <div>{{ props.row.tdata3_48 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_9" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_9 }}</div>
                          <div>{{ props.row.tdata3_49 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_10" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_10 }}</div>
                          <div>{{ props.row.tdata3_50 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_11" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_11 }}</div>
                          <div>{{ props.row.tdata3_51 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_12" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_12 }}</div>
                          <div>{{ props.row.tdata3_52 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_13" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_13 }}</div>
                          <div>{{ props.row.tdata3_53 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_14" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_14 }}</div>
                          <div>{{ props.row.tdata3_54 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_15" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_15 }}</div>
                          <div>{{ props.row.tdata3_55 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_16" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_16 }}</div>
                          <div>{{ props.row.tdata3_56 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_17" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_17 }}</div>
                          <div>{{ props.row.tdata3_57 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_18" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_18 }}</div>
                          <div>{{ props.row.tdata3_58 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_19" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_19 }}</div>
                          <div>{{ props.row.tdata3_59 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_20" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_20 }}</div>
                          <div>{{ props.row.tdata3_60 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_21" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_21 }}</div>
                          <div>{{ props.row.tdata3_61 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_22" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_22 }}</div>
                          <div>{{ props.row.tdata3_62 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_23" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_23 }}</div>
                          <div>{{ props.row.tdata3_63 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_24" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_24 }}</div>
                          <div>{{ props.row.tdata3_64 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_25" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_25 }}</div>
                          <div>{{ props.row.tdata3_65 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_26" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_26 }}</div>
                          <div>{{ props.row.tdata3_66 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_27" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_27 }}</div>
                          <div>{{ props.row.tdata3_67 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_28" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_28 }}</div>
                          <div>{{ props.row.tdata3_68 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_29" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_29 }}</div>
                          <div>{{ props.row.tdata3_69 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_30" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_30 }}</div>
                          <div>{{ props.row.tdata3_70 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_31" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_31 }}</div>
                          <div>{{ props.row.tdata3_71 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_32" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_32 }}</div>
                          <div>{{ props.row.tdata3_72 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_33" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_33 }}</div>
                          <div>{{ props.row.tdata3_73 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_34" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_34 }}</div>
                          <div>{{ props.row.tdata3_74 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_35" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_35 }}</div>
                          <div>{{ props.row.tdata3_75 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_36" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_36 }}</div>
                          <div>{{ props.row.tdata3_76 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_37" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_37 }}</div>
                          <div>{{ props.row.tdata3_77 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_38" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_38 }}</div>
                          <div>{{ props.row.tdata3_78 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_39" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_39 }}</div>
                          <div>{{ props.row.tdata3_79 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_40" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata3_40 }}</div>
                          <div>{{ props.row.tdata3_80 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata3_total" class="align_center">
                        {{ props.row.tdata3_total }}
                      </q-td>
                    </q-tr>
                    <q-tr :props="props" class="bg-blue-3">
                      <q-td key="tdata4" class="align_center row_first">
                        {{ props.row.tdata4 }}
                      </q-td>
                      <q-td key="tdata4_1" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_1 }}</div>
                          <div>{{ props.row.tdata4_41 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_2" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_2 }}</div>
                          <div>{{ props.row.tdata4_42 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_3" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_3 }}</div>
                          <div>{{ props.row.tdata4_43 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_4" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_4 }}</div>
                          <div>{{ props.row.tdata4_44 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_5" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_5 }}</div>
                          <div>{{ props.row.tdata4_45 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_6" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_6 }}</div>
                          <div>{{ props.row.tdata4_46 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_7" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_7 }}</div>
                          <div>{{ props.row.tdata4_47 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_8" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_8 }}</div>
                          <div>{{ props.row.tdata4_48 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_9" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_9 }}</div>
                          <div>{{ props.row.tdata4_49 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_10" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_10 }}</div>
                          <div>{{ props.row.tdata4_50 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_11" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_11 }}</div>
                          <div>{{ props.row.tdata4_51 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_12" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_12 }}</div>
                          <div>{{ props.row.tdata4_52 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_13" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_13 }}</div>
                          <div>{{ props.row.tdata4_53 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_14" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_14 }}</div>
                          <div>{{ props.row.tdata4_54 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_15" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_15 }}</div>
                          <div>{{ props.row.tdata4_55 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_16" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_16 }}</div>
                          <div>{{ props.row.tdata4_56 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_17" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_17 }}</div>
                          <div>{{ props.row.tdata4_57 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_18" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_18 }}</div>
                          <div>{{ props.row.tdata4_58 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_19" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_19 }}</div>
                          <div>{{ props.row.tdata4_59 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_20" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_20 }}</div>
                          <div>{{ props.row.tdata4_60 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_21" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_21 }}</div>
                          <div>{{ props.row.tdata4_61 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_22" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_22 }}</div>
                          <div>{{ props.row.tdata4_62 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_23" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_23 }}</div>
                          <div>{{ props.row.tdata4_63 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_24" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_24 }}</div>
                          <div>{{ props.row.tdata4_64 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_25" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_25 }}</div>
                          <div>{{ props.row.tdata4_65 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_26" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_26 }}</div>
                          <div>{{ props.row.tdata4_66 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_27" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_27 }}</div>
                          <div>{{ props.row.tdata4_67 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_28" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_28 }}</div>
                          <div>{{ props.row.tdata4_68 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_29" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_29 }}</div>
                          <div>{{ props.row.tdata4_69 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_30" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_30 }}</div>
                          <div>{{ props.row.tdata4_70 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_31" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_31 }}</div>
                          <div>{{ props.row.tdata4_71 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_32" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_32 }}</div>
                          <div>{{ props.row.tdata4_72 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_33" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_33 }}</div>
                          <div>{{ props.row.tdata4_73 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_34" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_34 }}</div>
                          <div>{{ props.row.tdata4_74 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_35" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_35 }}</div>
                          <div>{{ props.row.tdata4_75 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_36" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_36 }}</div>
                          <div>{{ props.row.tdata4_76 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_37" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_37 }}</div>
                          <div>{{ props.row.tdata4_77 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_38" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_38 }}</div>
                          <div>{{ props.row.tdata4_78 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_39" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_39 }}</div>
                          <div>{{ props.row.tdata4_79 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_40" class="align_center pa0">
                        <div class="w100p">
                          <div>{{ props.row.tdata4_40 }}</div>
                          <div>{{ props.row.tdata4_80 }}</div>
                        </div>
                      </q-td>
                      <q-td key="tdata4_total" class="align_center">
                        {{ props.row.tdata4_total }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- // general_table -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 </q-tab-panel>
          <!--// tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');

const searchDate = ref({
  from: '2019.02',
  to: '2019.02',
});

//data테이블
const data1Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 1,
});
const data1Columns = ref([
  {
    name: 'tdata1',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '팀',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '채널',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '선생님',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '과목',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '교재수급일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
]);
const data1Rows = ref([
  {
    idx: 1,
    tdata1: '강서교육국',
    tdata2: '001팀',
    tdata3: 'YC1[바다꿈]',
    tdata4: '김정숙 [0031044761]',
    tdata5: '전과목',
    tdata6: '2022. 01. 11 ~ 2023. 02. 23',
  },
]);

const data2Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const data2Rows = ref([
  {
    idx: 11,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 10,
    tdata1: '눈높이 영어',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '999',
    tdata2_2: '999',
    tdata2_3: '999',
    tdata2_4: '999',
    tdata2_5: '999',
    tdata2_6: '999',
    tdata2_7: '999',
    tdata2_8: '999',
    tdata2_9: '999',
    tdata2_10: '999',
    tdata2_11: '999',
    tdata2_12: '999',
    tdata2_13: '999',
    tdata2_14: '999',
    tdata2_15: '999',
    tdata2_16: '999',
    tdata2_17: '999',
    tdata2_18: '999',
    tdata2_19: '999',
    tdata2_20: '999',
    tdata2_21: '999',
    tdata2_22: '999',
    tdata2_23: '999',
    tdata2_24: '999',
    tdata2_25: '999',
    tdata2_26: '999',
    tdata2_27: '999',
    tdata2_28: '999',
    tdata2_29: '999',
    tdata2_30: '999',
    tdata2_31: '999',
    tdata2_32: '999',
    tdata2_33: '999',
    tdata2_34: '999',
    tdata2_35: '999',
    tdata2_36: '999',
    tdata2_37: '999',
    tdata2_38: '999',
    tdata2_39: '999',
    tdata2_40: '999',
    tdata2_41: '999',
    tdata2_42: '999',
    tdata2_43: '999',
    tdata2_44: '999',
    tdata2_45: '999',
    tdata2_46: '999',
    tdata2_47: '999',
    tdata2_48: '999',
    tdata2_49: '999',
    tdata2_50: '999',
    tdata2_51: '999',
    tdata2_52: '999',
    tdata2_53: '999',
    tdata2_54: '999',
    tdata2_55: '999',
    tdata2_56: '999',
    tdata2_57: '999',
    tdata2_58: '999',
    tdata2_59: '999',
    tdata2_60: '999',
    tdata2_61: '999',
    tdata2_62: '999',
    tdata2_63: '999',
    tdata2_64: '999',
    tdata2_65: '999',
    tdata2_66: '999',
    tdata2_67: '999',
    tdata2_68: '999',
    tdata2_69: '999',
    tdata2_70: '999',
    tdata2_71: '999',
    tdata2_72: '999',
    tdata2_73: '999',
    tdata2_74: '999',
    tdata2_75: '999',
    tdata2_76: '999',
    tdata2_77: '999',
    tdata2_78: '999',
    tdata2_79: '999',
    tdata2_80: '999',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '999',
    tdata3_2: '999',
    tdata3_3: '999',
    tdata3_4: '999',
    tdata3_5: '999',
    tdata3_6: '999',
    tdata3_7: '999',
    tdata3_8: '999',
    tdata3_9: '999',
    tdata3_10: '999',
    tdata3_11: '999',
    tdata3_12: '999',
    tdata3_13: '999',
    tdata3_14: '999',
    tdata3_15: '999',
    tdata3_16: '999',
    tdata3_17: '999',
    tdata3_18: '999',
    tdata3_19: '999',
    tdata3_20: '999',
    tdata3_21: '999',
    tdata3_22: '999',
    tdata3_23: '999',
    tdata3_24: '999',
    tdata3_25: '999',
    tdata3_26: '999',
    tdata3_27: '999',
    tdata3_28: '999',
    tdata3_29: '999',
    tdata3_30: '999',
    tdata3_31: '999',
    tdata3_32: '999',
    tdata3_33: '999',
    tdata3_34: '999',
    tdata3_35: '999',
    tdata3_36: '999',
    tdata3_37: '999',
    tdata3_38: '999',
    tdata3_39: '999',
    tdata3_40: '999',
    tdata3_41: '999',
    tdata3_42: '999',
    tdata3_43: '999',
    tdata3_44: '999',
    tdata3_45: '999',
    tdata3_46: '999',
    tdata3_47: '999',
    tdata3_48: '999',
    tdata3_49: '999',
    tdata3_50: '999',
    tdata3_51: '999',
    tdata3_52: '999',
    tdata3_53: '999',
    tdata3_54: '999',
    tdata3_55: '999',
    tdata3_56: '999',
    tdata3_57: '999',
    tdata3_58: '999',
    tdata3_59: '999',
    tdata3_60: '999',
    tdata3_61: '999',
    tdata3_62: '999',
    tdata3_63: '999',
    tdata3_64: '999',
    tdata3_65: '999',
    tdata3_66: '999',
    tdata3_67: '999',
    tdata3_68: '999',
    tdata3_69: '999',
    tdata3_70: '999',
    tdata3_71: '999',
    tdata3_72: '999',
    tdata3_73: '999',
    tdata3_74: '999',
    tdata3_75: '999',
    tdata3_76: '999',
    tdata3_77: '999',
    tdata3_78: '999',
    tdata3_79: '999',
    tdata3_80: '999',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '999',
    tdata4_2: '999',
    tdata4_3: '999',
    tdata4_4: '999',
    tdata4_5: '999',
    tdata4_6: '999',
    tdata4_7: '999',
    tdata4_8: '999',
    tdata4_9: '999',
    tdata4_10: '999',
    tdata4_11: '999',
    tdata4_12: '999',
    tdata4_13: '999',
    tdata4_14: '999',
    tdata4_15: '999',
    tdata4_16: '999',
    tdata4_17: '999',
    tdata4_18: '999',
    tdata4_19: '999',
    tdata4_20: '999',
    tdata4_21: '999',
    tdata4_22: '999',
    tdata4_23: '999',
    tdata4_24: '999',
    tdata4_25: '999',
    tdata4_26: '999',
    tdata4_27: '999',
    tdata4_28: '999',
    tdata4_29: '999',
    tdata4_30: '999',
    tdata4_31: '999',
    tdata4_32: '999',
    tdata4_33: '999',
    tdata4_34: '999',
    tdata4_35: '999',
    tdata4_36: '999',
    tdata4_37: '999',
    tdata4_38: '999',
    tdata4_39: '999',
    tdata4_40: '999',
    tdata4_41: '999',
    tdata4_42: '999',
    tdata4_43: '999',
    tdata4_44: '999',
    tdata4_45: '999',
    tdata4_46: '999',
    tdata4_47: '999',
    tdata4_48: '999',
    tdata4_49: '999',
    tdata4_50: '999',
    tdata4_51: '999',
    tdata4_52: '999',
    tdata4_53: '999',
    tdata4_54: '999',
    tdata4_55: '999',
    tdata4_56: '999',
    tdata4_57: '999',
    tdata4_58: '999',
    tdata4_59: '999',
    tdata4_60: '999',
    tdata4_61: '999',
    tdata4_62: '999',
    tdata4_63: '999',
    tdata4_64: '999',
    tdata4_65: '999',
    tdata4_66: '999',
    tdata4_67: '999',
    tdata4_68: '999',
    tdata4_69: '999',
    tdata4_70: '999',
    tdata4_71: '999',
    tdata4_72: '999',
    tdata4_73: '999',
    tdata4_74: '999',
    tdata4_75: '999',
    tdata4_76: '999',
    tdata4_77: '999',
    tdata4_78: '999',
    tdata4_79: '999',
    tdata4_80: '999',
  },
  {
    idx: 9,
    tdata1: '눈높이 국어',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 8,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 7,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 6,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 5,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 4,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 3,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 2,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
  {
    idx: 1,
    tdata1: '눈높이 수학',
    tdata2: '5A',
    tdata2_total: '1,000',
    tdata2_1: '0',
    tdata2_2: '0',
    tdata2_3: '0',
    tdata2_4: '0',
    tdata2_5: '0',
    tdata2_6: '0',
    tdata2_7: '0',
    tdata2_8: '0',
    tdata2_9: '0',
    tdata2_10: '0',
    tdata2_11: '0',
    tdata2_12: '0',
    tdata2_13: '0',
    tdata2_14: '0',
    tdata2_15: '0',
    tdata2_16: '0',
    tdata2_17: '0',
    tdata2_18: '0',
    tdata2_19: '0',
    tdata2_20: '0',
    tdata2_21: '0',
    tdata2_22: '0',
    tdata2_23: '0',
    tdata2_24: '0',
    tdata2_25: '0',
    tdata2_26: '0',
    tdata2_27: '0',
    tdata2_28: '0',
    tdata2_29: '0',
    tdata2_30: '0',
    tdata2_31: '0',
    tdata2_32: '0',
    tdata2_33: '0',
    tdata2_34: '0',
    tdata2_35: '0',
    tdata2_36: '0',
    tdata2_37: '0',
    tdata2_38: '0',
    tdata2_39: '0',
    tdata2_40: '0',
    tdata2_41: '0',
    tdata2_42: '0',
    tdata2_43: '0',
    tdata2_44: '0',
    tdata2_45: '0',
    tdata2_46: '0',
    tdata2_47: '0',
    tdata2_48: '0',
    tdata2_49: '0',
    tdata2_50: '0',
    tdata2_51: '0',
    tdata2_52: '0',
    tdata2_53: '0',
    tdata2_54: '0',
    tdata2_55: '0',
    tdata2_56: '0',
    tdata2_57: '0',
    tdata2_58: '0',
    tdata2_59: '0',
    tdata2_60: '0',
    tdata2_61: '0',
    tdata2_62: '0',
    tdata2_63: '0',
    tdata2_64: '0',
    tdata2_65: '0',
    tdata2_66: '0',
    tdata2_67: '0',
    tdata2_68: '0',
    tdata2_69: '0',
    tdata2_70: '0',
    tdata2_71: '0',
    tdata2_72: '0',
    tdata2_73: '0',
    tdata2_74: '0',
    tdata2_75: '0',
    tdata2_76: '0',
    tdata2_77: '0',
    tdata2_78: '0',
    tdata2_79: '0',
    tdata2_80: '0',
    tdata3: '6A',
    tdata3_total: '1,000',
    tdata3_1: '0',
    tdata3_2: '0',
    tdata3_3: '0',
    tdata3_4: '0',
    tdata3_5: '0',
    tdata3_6: '0',
    tdata3_7: '0',
    tdata3_8: '0',
    tdata3_9: '0',
    tdata3_10: '0',
    tdata3_11: '0',
    tdata3_12: '0',
    tdata3_13: '0',
    tdata3_14: '0',
    tdata3_15: '0',
    tdata3_16: '0',
    tdata3_17: '0',
    tdata3_18: '0',
    tdata3_19: '0',
    tdata3_20: '0',
    tdata3_21: '0',
    tdata3_22: '0',
    tdata3_23: '0',
    tdata3_24: '0',
    tdata3_25: '0',
    tdata3_26: '0',
    tdata3_27: '0',
    tdata3_28: '0',
    tdata3_29: '0',
    tdata3_30: '0',
    tdata3_31: '0',
    tdata3_32: '0',
    tdata3_33: '0',
    tdata3_34: '0',
    tdata3_35: '0',
    tdata3_36: '0',
    tdata3_37: '0',
    tdata3_38: '0',
    tdata3_39: '0',
    tdata3_40: '0',
    tdata3_41: '0',
    tdata3_42: '0',
    tdata3_43: '0',
    tdata3_44: '0',
    tdata3_45: '0',
    tdata3_46: '0',
    tdata3_47: '0',
    tdata3_48: '0',
    tdata3_49: '0',
    tdata3_50: '0',
    tdata3_51: '0',
    tdata3_52: '0',
    tdata3_53: '0',
    tdata3_54: '0',
    tdata3_55: '0',
    tdata3_56: '0',
    tdata3_57: '0',
    tdata3_58: '0',
    tdata3_59: '0',
    tdata3_60: '0',
    tdata3_61: '0',
    tdata3_62: '0',
    tdata3_63: '0',
    tdata3_64: '0',
    tdata3_65: '0',
    tdata3_66: '0',
    tdata3_67: '0',
    tdata3_68: '0',
    tdata3_69: '0',
    tdata3_70: '0',
    tdata3_71: '0',
    tdata3_72: '0',
    tdata3_73: '0',
    tdata3_74: '0',
    tdata3_75: '0',
    tdata3_76: '0',
    tdata3_77: '0',
    tdata3_78: '0',
    tdata3_79: '0',
    tdata3_80: '0',
    tdata4: '계',
    tdata4_total: '1,000',
    tdata4_1: '0',
    tdata4_2: '0',
    tdata4_3: '0',
    tdata4_4: '0',
    tdata4_5: '0',
    tdata4_6: '0',
    tdata4_7: '0',
    tdata4_8: '0',
    tdata4_9: '0',
    tdata4_10: '0',
    tdata4_11: '0',
    tdata4_12: '0',
    tdata4_13: '0',
    tdata4_14: '0',
    tdata4_15: '0',
    tdata4_16: '0',
    tdata4_17: '0',
    tdata4_18: '0',
    tdata4_19: '0',
    tdata4_20: '0',
    tdata4_21: '0',
    tdata4_22: '0',
    tdata4_23: '0',
    tdata4_24: '0',
    tdata4_25: '0',
    tdata4_26: '0',
    tdata4_27: '0',
    tdata4_28: '0',
    tdata4_29: '0',
    tdata4_30: '0',
    tdata4_31: '0',
    tdata4_32: '0',
    tdata4_33: '0',
    tdata4_34: '0',
    tdata4_35: '0',
    tdata4_36: '0',
    tdata4_37: '0',
    tdata4_38: '0',
    tdata4_39: '0',
    tdata4_40: '0',
    tdata4_41: '0',
    tdata4_42: '0',
    tdata4_43: '0',
    tdata4_44: '0',
    tdata4_45: '0',
    tdata4_46: '0',
    tdata4_47: '0',
    tdata4_48: '0',
    tdata4_49: '0',
    tdata4_50: '0',
    tdata4_51: '0',
    tdata4_52: '0',
    tdata4_53: '0',
    tdata4_54: '0',
    tdata4_55: '0',
    tdata4_56: '0',
    tdata4_57: '0',
    tdata4_58: '0',
    tdata4_59: '0',
    tdata4_60: '0',
    tdata4_61: '0',
    tdata4_62: '0',
    tdata4_63: '0',
    tdata4_64: '0',
    tdata4_65: '0',
    tdata4_66: '0',
    tdata4_67: '0',
    tdata4_68: '0',
    tdata4_69: '0',
    tdata4_70: '0',
    tdata4_71: '0',
    tdata4_72: '0',
    tdata4_73: '0',
    tdata4_74: '0',
    tdata4_75: '0',
    tdata4_76: '0',
    tdata4_77: '0',
    tdata4_78: '0',
    tdata4_79: '0',
    tdata4_80: '0',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
