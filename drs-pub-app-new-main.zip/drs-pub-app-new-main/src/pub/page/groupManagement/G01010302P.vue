<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 medium">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">계좌번호조회</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-12">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="계좌번호를 입력하세요"
                  >
                  </q-input>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>

          <div class="table_dk">
            <q-table
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="resultPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td class="select" key="checkRadio">
                    <q-radio
                      v-model="dataRadio"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </q-td>
                  <q-td key="tdata1" class="text-center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="text-center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="text-center">
                    {{ props.row.tdata3 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            fill
            color="black"
            v-close-popup
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// table데이터
const dataColumns = ref([
  {
    name: 'checkRadio',
    label: '선택',
    sortable: false,
    align: 'center',
    field: (row) => row.checkRadio,
  },
  {
    name: 'tdata1',
    label: '계좌번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '은행명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '예금주',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 9,
    checkRadio: '',
    tdata1: '111-1111-111-1111',
    tdata2: '카카오뱅크',
    tdata3: '홍홍길동',
    allow: false,
  },
  {
    idx: 8,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 7,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 6,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 5,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 4,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 3,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 2,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
  {
    idx: 1,
    checkRadio: '',
    tdata1: '00111100012',
    tdata2: '국민은행',
    tdata3: '홍길동',
    allow: false,
  },
]);

const resultPagination = ref({
  sortBy: 'idx',
  descending: false,
  page: 1,
  rowsPerPage: 10,
});

const popForm = ref(true);
</script>
