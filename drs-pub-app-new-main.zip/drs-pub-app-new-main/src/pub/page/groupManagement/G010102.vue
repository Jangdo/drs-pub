<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">[성장사업] 제품지수현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- table_search_area type_flexable -->
      <div class="table_search_area type_flexable">
        <div class="search_hide" v-if="searchExpand">
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check1"
              class="checkbox_custom type01"
              label="부문"
              color="black"
            />
          </div>
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check2"
              class="checkbox_custom type01"
              label="본부"
              color="black"
            />
          </div>
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check3"
              class="checkbox_custom type01"
              label="조직"
              color="black"
            />
          </div>
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check4"
              class="checkbox_custom type01"
              label="팀"
              color="black"
            />
          </div>
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check5"
              class="checkbox_custom type01"
              label="채널"
              color="black"
            />
          </div>
          <div class="search_item">
            <q-checkbox
              dense
              v-model="check6"
              class="checkbox_custom type01"
              label="선생님"
              color="black"
            />
          </div>
          <div class="search_item btn_area">
            <q-btn
              fill
              unelevated
              color="grey-2"
              class="size_sm btn_search_m"
              icon=""
              label="검색"
            />
          </div>
          <div class="search_item">
            <!-- <h3>채널조회 조건을 등록하세요</h3> -->
            <q-input
              class="box_xl inp_search"
              outlined
              placeholder="채널조회 조건을 등록하세요"
            >
              <template v-slot:append>
                <q-icon
                  name="icon-search"
                  class="icon_svg"
                  flat
                  :ripple="false"
                /> </template
            ></q-input>
          </div>
          <div class="search_item">
            <!-- <h3>학습유형</h3> -->
            <q-select
              class="box_l"
              v-model="searchstudyType"
              :options="searchstudyTypeOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="search_item">
            <!-- <h3>시스템 유형을 선택하세요</h3> -->
            <q-select
              class="box_l"
              v-model="searchSys"
              :options="searchSysOption"
              option-value="sysytemCategory"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="search_item">
            <!-- <h3>계층/랭킹별 보기를 선택하세요</h3> -->
            <q-select
              class="box_m"
              v-model="searchTreeSelected"
              :options="searchtreeselectedOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <!-- 모바일 + 태블릿에서만 보임 -->
          <div
            class="search_item"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          >
            <div class="wrap_opt_group">
              <q-option-group
                class="opt_group_custom type01"
                :options="dayOptionm1"
                type="checkbox"
                v-model="daym1"
                color="blue-3"
              />
            </div>
          </div>
          <!-- 모바일 + 태블릿에서만 보임 -->
          <div
            class="search_item"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          >
            <div class="wrap_opt_group">
              <q-option-group
                class="opt_group_custom type01"
                :options="dayOptionm2"
                type="checkbox"
                v-model="daym2"
                color="blue-3"
              />
            </div>
          </div>
          <!-- pc에서만 보임 -->
          <div class="search_item" v-if="$q.screen.name == 'lg'">
            <div class="wrap_opt_group">
              <q-option-group
                class="opt_group_custom type01"
                :options="dayOption"
                type="checkbox"
                v-model="day"
                color="blue-3"
              />
            </div>
          </div>
          <div class="search_item">
            <!-- searchDate start.from -->
            <q-input
              outlined
              v-model="searchDate.from"
              class="inp_date normal"
              readonly
            >
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      mask="YYYY.MM.DD"
                      v-model="searchDate.from"
                      @update:model-value="
                        searchDate.from, $refs.qDateProxyFrom.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
            <!--// searchDate start.from -->
          </div>
          <div class="search_item">
            <q-checkbox
              v-model="dataCheck"
              label="교육지원비 적용"
              class="check_in_search"
              color="black"
            />
          </div>
          <div class="search_item btn_area">
            <q-btn class="size_sm btn_reset" icon="" outline label="초기화" />
            <q-btn fill unelevated class="size_sm btn_search" label="조회" />
          </div>
        </div>
        <div class="search_expand">
          <q-btn
            class="size_sm btn_contract"
            v-if="searchExpand"
            fill
            unelevated
            icon=""
            label="검색 닫기"
            @click="searchExpand = false"
          />
          <q-btn
            class="size_sm btn_expand"
            v-else
            fill
            unelevated
            icon=""
            label="검색 펼치기"
            @click="searchExpand = true"
          />
        </div>
      </div>
      <!--// table_search_area type_flexable -->

      <div class="wrap_table_box">
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="icon-info" class="icon_svg"></q-icon>
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>소개입회지수 - 눈높이 교육국 간 소개입회를제외한 소개입회실적</p>
            <p>
              ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
              소개입회지수, 소개퇴회지수 실적임
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
        <!-- general_table type_tree -->
        <div class="general_table type_tree">
          <div class="btn_area">
            <q-space />
            <q-btn class="size_sm btn_excel" outline label="">
              <q-icon class="svg_icon filter-positive" />
            </q-btn>
          </div>
          <q-table
            class="stickty_left_table"
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td
                  key="section"
                  class="section hastree"
                  :class="props.row.depth"
                >
                  <q-btn
                    outline
                    v-show="props.row.flat == false"
                    class="btn_tree_expand_tbl"
                    :icon="
                      props.row.state == true
                        ? 'ion-arrow-dropup'
                        : 'ion-arrow-dropdown'
                    "
                  >
                  </q-btn>
                  <p :class="props.row.flat == true ? 'flat_txt' : ''">
                    {{ props.row.section }}
                  </p>
                  <q-img
                    v-show="props.row.img"
                    :src="
                      props.row.img +
                      '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                    "
                    spinner-color="white"
                    class="user_thumb"
                  />
                </q-td>
                <q-td key="countDayIn" class="join_per_day">
                  {{ props.row.countDayIn }}</q-td
                >
                <q-td key="countDayIn2" class="change_per_day">
                  {{ props.row.countDayIn2 }}</q-td
                >
                <q-td key="countDayOut" class="leave_per_day">
                  {{ props.row.countDayOut }}</q-td
                >
                <q-td
                  key="countDayOut2"
                  class="leave_change_per_day align_right"
                >
                  {{ props.row.countDayOut2 }}</q-td
                >
                <q-td key="countMonthIn" class="join_per_month align_right">
                  {{ props.row.countMonthIn }}</q-td
                >
                <q-td key="countMonthIn2" class="change_per_month align_right">
                  {{ props.row.countMonthIn2 }}</q-td
                >
                <q-td key="countAllIn" class="join_all align_right">
                  {{ props.row.countAllIn }}</q-td
                >
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td>합계</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table type_tree -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchSys = ref(['시스템유형을 선택하세요']);
const searchSysOption = ref([
  {
    id: 'a',
    desc: '유형 유형',
  },
  {
    id: 'b',
    desc: '시스템유형 ',
  },
]);
const searchTreeSelected = ref(['계층/랭킹별 보기를 선택하세요']);
const searchtreeselectedOption = ref([
  {
    id: 'tree',
    desc: '계층',
  },
  {
    id: 'lanking',
    desc: '랭킹 ',
  },
]);
const searchstudyType = ref(['학습유형을 선택하세요']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
});
const dataCheck = ref(true);
// 검색영역 추가
const daym1 = ref(['all']);
const dayOptionm1 = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
]);
const daym2 = ref(['wed']);
const dayOptionm2 = ref([
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
const check1 = ref(false);
const check2 = ref(false);
const check3 = ref(false);
const check4 = ref(false);
const check5 = ref(false);
const check6 = ref(false);
const searchExpand = ref(true);

//data테이블

const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'countDayIn',
    label: '일입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn,
  },
  {
    name: 'countDayIn2',
    label: '일전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn2,
  },
  {
    name: 'countDayOut',
    label: '일퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut,
  },
  {
    name: 'countDayOut2',
    label: '일전환퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut2,
  },
  {
    name: 'countMonthIn',
    label: '월입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countMonthIn,
  },
  {
    name: 'countMonthIn2',
    label: '월전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countMonthIn2,
  },
  {
    name: 'countAllIn',
    label: '전체입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countAllIn,
  },
]);
const dataRows = ref([
  {
    section: 'depth1성장사업본부',
    depth: 'depth1',
    state: true,
    flat: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth2 드림멘토사업팀 [김대교]',
    depth: 'depth2',
    state: true,
    flat: false,
    img: 'https://d2wwpgb2oxedpp.cloudfront.net/images/avatar.png',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth3 [에듀테크멘토링]',
    depth: 'depth3',
    state: true,
    flat: false,
    img: 'https://d2wwpgb2oxedpp.cloudfront.net/images/avatar.png',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth4 강정현 [11123456]',
    depth: 'depth4',
    state: true,
    flat: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },

  {
    section: 'depth5 강정현 [11123456]',
    depth: 'depth5',
    state: true,
    flat: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 강정현 [11123456]',
    depth: 'depth6',
    flat: false,

    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});
</script>
