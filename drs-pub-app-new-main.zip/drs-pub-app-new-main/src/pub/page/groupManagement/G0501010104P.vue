<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree fit_content sales_popup_560">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit w100p text-left">요일선택</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="weekday_group_btn">
            <div class="wrap_opt_group">
              <q-option-group
                class="opt_group_custom type02"
                :options="dayOption"
                type="checkbox"
                v-model="day"
                color="black"
              />
            </div>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            class="size_sm btn_reset"
            icon=""
            label="초기화"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="선택"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

// 요일선택
const day = ref(['tues']);
const dayOption = ref([
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
</script>
<style lang="scss"></style>
