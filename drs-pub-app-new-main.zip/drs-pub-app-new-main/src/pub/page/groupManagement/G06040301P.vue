<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">진도점검</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="student">
            <div class="text-h1 mb13">김윤찬</div>
            <div class="row mb20">
              <div>
                <span class="body2 text-grey-3">학년</span>
                <span class="body2 text-grey-6 ml6 mr6">|</span>
                <span class="body2 text-grey-1">초등2</span>
              </div>
              <div class="ml20">
                <span class="body2 text-grey-3">회원번호</span>
                <span class="body2 text-grey-6 ml6 mr6">|</span>
                <span class="body2 text-grey-1">P159072349</span>
              </div>
            </div>
            <q-separator />
            <div class="mb30"></div>
            <div class="mo_column">
              <div class="pc_w50p mo_mb10">
                <q-select
                  class="box_xl hide_label"
                  label="선택하세요"
                  v-model="week"
                  :options="weekOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="pc_w50p">
                <div class="row-2">
                  <div>
                    <div class="row mb8">
                      <span class="body2 text-grey-3">진도결정마감</span>
                      <span class="body2 text-grey-6 ml6 mr6">|</span>
                      <span class="body2 text-grey-1">2023.04.20 (목)</span>
                    </div>
                    <div class="row">
                      <span class="body2 text-grey-3">교재수급</span>
                      <span class="body2 text-grey-6 ml6 mr6">|</span>
                      <span class="body2 text-grey-1">2023.04.28 (금)</span>
                    </div>
                  </div>
                  <div>
                    <q-btn color="grey-5" fill unelevated class="btn_circle">
                      <q-icon
                        class="icon_svg"
                        name="icon-class-calendar filter-white"
                        size="22px"
                      ></q-icon>
                    </q-btn>
                  </div>
                </div>
              </div>
            </div>
            <div class="mb30"></div>
          </div>
          <div class="wrap_arrow_table">
            <q-markup-table
              separator="cell"
              wrap-cells
              class="arrow_table scrollable mb30"
            >
              <thead>
                <tr>
                  <th colspan="7">선긋기</th>
                  <th colspan="5">1~5까지의 수 쓰기</th>
                </tr>
                <tr>
                  <th>1</th>
                  <th>2</th>
                  <th>3</th>
                  <th>4</th>
                  <th>5</th>
                  <th>6</th>
                  <th>7</th>
                  <th>8</th>
                  <th>9</th>
                  <th>10</th>
                  <th>11</th>
                  <th>12</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="bg-blue-3">
                    <!-- 첫번째 타입 아이콘 종류
                    - arrow 화살표 있는 선
                    - line 일자 선
                    
                    두번째 타입 선 종류
                    - solid 실선
                    - dashed 점선

                    세번째 타입 색상
                    - warning 노란색
                    - grey-4 회색
                    - positive 그린
                    - orange
                    - primary -->
                    <div class="arrow solid warning"></div>
                  </td>
                  <td>
                    <div class="line solid warning"></div>
                  </td>
                  <td>
                    <div class="arrow solid warning"></div>
                  </td>
                  <td>
                    <div class="line solid warning"></div>
                  </td>
                  <td>
                    <div class="arrow solid warning"></div>
                  </td>
                  <td>
                    <div class="line solid warning"></div>
                  </td>
                  <td>
                    <div class="arrow solid warning"></div>
                  </td>
                  <td>
                    <div class="line solid grey-4"></div>
                  </td>
                  <td>
                    <div class="arrow solid grey-4"></div>
                  </td>
                  <td>
                    <div class="line dashed grey-4"></div>
                  </td>
                  <td>
                    <div class="line dashed grey-4"></div>
                  </td>
                  <td>
                    <div class="arrow dashed grey-4"></div>
                  </td>
                </tr>
                <tr>
                  <td class="bg-blue-3">
                    <div class="arrow solid positive"></div>
                  </td>
                  <td>
                    <div class="line solid positive"></div>
                  </td>
                  <td>
                    <div class="arrow solid positive"></div>
                  </td>
                  <td>
                    <div class="line solid positive"></div>
                  </td>
                  <td>
                    <div class="arrow solid positive"></div>
                  </td>
                  <td>
                    <div class="line solid positive"></div>
                  </td>
                  <td>
                    <div class="arrow solid positive"></div>
                  </td>
                  <td>
                    <div class="line dashed positive"></div>
                  </td>
                  <td>
                    <div class="line dashed positive"></div>
                  </td>
                  <td>
                    <div class="arrow dashed positive"></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                </tr>
                <tr>
                  <td class="bg-blue-3">
                    <div class="arrow solid orange"></div>
                  </td>
                  <td>
                    <div class="line solid orange"></div>
                  </td>
                  <td>
                    <div class="arrow solid orange"></div>
                  </td>
                  <td>
                    <div class="line solid orange"></div>
                  </td>
                  <td>
                    <div class="arrow solid orange"></div>
                  </td>
                  <td>
                    <div class="line solid orange"></div>
                  </td>
                  <td>
                    <div class="arrow solid orange"></div>
                  </td>
                  <td>
                    <div class="line dashed orange"></div>
                  </td>
                  <td>
                    <div class="line dashed orange"></div>
                  </td>
                  <td>
                    <div class="arrow dashed orange"></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                </tr>
                <tr>
                  <td class="bg-blue-3">
                    <div class="arrow solid primary"></div>
                  </td>
                  <td>
                    <div class="line solid primary"></div>
                  </td>
                  <td>
                    <div class="arrow solid primary"></div>
                  </td>
                  <td>
                    <div class="line solid primary"></div>
                  </td>
                  <td>
                    <div class="arrow solid primary"></div>
                  </td>
                  <td>
                    <div class="line solid primary"></div>
                  </td>
                  <td>
                    <div class="arrow solid primary"></div>
                  </td>
                  <td>
                    <div class="line dashed primary"></div>
                  </td>
                  <td>
                    <div class="line dashed primary"></div>
                  </td>
                  <td>
                    <div class="arrow dashed primary"></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                  <td>
                    <div class=""></div>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>
            <div>
              <ul class="inner_list dense">
                <li>
                  <span class="as_dt text-black">진도점검 피드백</span>
                  <q-input
                    v-model="dataFrom.feedback"
                    class="as_dd hide_label"
                    outlined
                    placeholder="입력해주세요"
                    stack-label
                    dense
                  >
                  </q-input>
                </li>
              </ul>
            </div>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const week = ref(['']);
const weekOption = ref([
  {
    id: 'week1',
    desc: '월요일',
  },
  {
    id: 'week2',
    desc: '화요일',
  },
  {
    id: 'week3',
    desc: '수요일',
  },
  {
    id: 'week4',
    desc: '목요일',
  },
  {
    id: 'week5',
    desc: '금요일',
  },
]);

const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  information: '',
  feedback: '',
  state: '',
  allow: '',
});
</script>
