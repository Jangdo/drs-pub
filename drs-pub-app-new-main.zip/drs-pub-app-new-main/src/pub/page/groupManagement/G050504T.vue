<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">성과관리 현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="[눈높이] 성과관리 현황" :ripple="false" />
          <q-tab name="tab2" label="[솔루니] 성과관리 현황" :ripple="false" />
          <q-tab name="tab3" label="[눈높이] 총원성장/매출" :ripple="false" />
          <q-tab name="tab4" label="[솔루니] 총원성장 /매출" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> 탭1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> 탭2 </q-tab-panel>
          <!-- // tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> 탭3 </q-tab-panel>
          <!-- // tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="box_l normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="row q-col-gutter-sm" v-if="stateHandle">
                  <div class="col-12 col-md-3">
                    <q-option-group
                      v-model="select"
                      :options="selectOpt"
                      color="black"
                      inline
                    />
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <div class="table_dk type_tree">
                <div class="table_top">
                  <div class="btn_wrap col-12 gap10">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>

                <q-table
                  class="tbl_row_14 sticky_table_header sticky_table_footer stickty_left_table multi_head stickty_left_table"
                  :rows="dataRows"
                  row-key="idx"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th rowspan="3" class="tbl_left_fix_1">구분</th>
                      <th colspan="48">연 목표 성과관리현황</th>
                    </tr>
                    <tr>
                      <th colspan="3" class="row_first">1월</th>
                      <th colspan="3">2월</th>
                      <th colspan="3">3월</th>
                      <th colspan="3">1Q</th>
                      <th colspan="3">4월</th>
                      <th colspan="3">5월</th>
                      <th colspan="3">6월</th>
                      <th colspan="3">2Q</th>
                      <th colspan="3">7월</th>
                      <th colspan="3">8월</th>
                      <th colspan="3">9월</th>
                      <th colspan="3">3Q</th>
                      <th colspan="3">10월</th>
                      <th colspan="3">11월</th>
                      <th colspan="3">12월</th>
                      <th colspan="3">4Q</th>
                    </tr>
                    <tr>
                      <th class="row_first">목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td
                        key="section"
                        class="section hastree"
                        :class="props.row.depth"
                      >
                        <q-btn
                          outline
                          v-show="props.row.flat == false"
                          class="btn_tree_expand_tbl"
                          :icon="
                            props.row.state == true
                              ? 'ion-arrow-dropup'
                              : 'ion-arrow-dropdown'
                          "
                        >
                        </q-btn>
                        <p :class="props.row.flat == true ? 'flat_txt' : ''">
                          {{ props.row.section }}
                        </p>
                        <q-img
                          v-show="props.row.img"
                          :src="
                            props.row.img +
                            '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                          "
                          spinner-color="white"
                          class="user_thumb"
                        />
                      </q-td>
                      <q-td key="goal1" class="goal text-right">
                        {{ props.row.goal1 }}
                      </q-td>
                      <q-td key="result1" class="results text-right">
                        {{ props.row.result1 }}
                      </q-td>
                      <q-td key="rate1" class="rate text-right">
                        {{ props.row.rate1 }}
                      </q-td>
                      <q-td key="goal2" class="goal text-right">
                        {{ props.row.goal2 }}
                      </q-td>
                      <q-td key="result2" class="results text-right">
                        {{ props.row.result2 }}
                      </q-td>
                      <q-td key="rate2" class="rate text-right">
                        {{ props.row.rate2 }}
                      </q-td>
                      <q-td key="goal3" class="goal text-right">
                        {{ props.row.goal3 }}
                      </q-td>
                      <q-td key="result3" class="results text-right">
                        {{ props.row.result3 }}
                      </q-td>
                      <q-td key="rate3" class="rate text-right">
                        {{ props.row.rate3 }}
                      </q-td>
                      <q-td key="goalQ1" class="goal text-right">
                        {{ props.row.goalQ1 }}
                      </q-td>
                      <q-td key="resultQ1" class="results text-right">
                        {{ props.row.resultQ1 }}
                      </q-td>
                      <q-td key="rateQ1" class="rate text-right">
                        {{ props.row.rateQ1 }}
                      </q-td>
                      <q-td key="goal4" class="goal text-right">
                        {{ props.row.goal4 }}
                      </q-td>
                      <q-td key="result4" class="results text-right">
                        {{ props.row.result4 }}
                      </q-td>
                      <q-td key="rate4" class="rate text-right">
                        {{ props.row.rate4 }}
                      </q-td>
                      <q-td key="goal5" class="goal text-right">
                        {{ props.row.goal5 }}
                      </q-td>
                      <q-td key="result5" class="results text-right">
                        {{ props.row.result5 }}
                      </q-td>
                      <q-td key="rate5" class="rate text-right">
                        {{ props.row.rate5 }}
                      </q-td>
                      <q-td key="goal6" class="goal text-right">
                        {{ props.row.goal6 }}
                      </q-td>
                      <q-td key="result6" class="results text-right">
                        {{ props.row.result6 }}
                      </q-td>
                      <q-td key="rate6" class="rate text-right">
                        {{ props.row.rate6 }}
                      </q-td>
                      <q-td key="goalQ2" class="goal text-right">
                        {{ props.row.goalQ2 }}
                      </q-td>
                      <q-td key="resultQ2" class="results text-right">
                        {{ props.row.resultQ2 }}
                      </q-td>
                      <q-td key="rateQ2" class="rate text-right">
                        {{ props.row.rateQ2 }}
                      </q-td>
                      <q-td key="goal7" class="goal text-right">
                        {{ props.row.goal7 }}
                      </q-td>
                      <q-td key="result7" class="results text-right">
                        {{ props.row.result7 }}
                      </q-td>
                      <q-td key="rate7" class="rate text-right">
                        {{ props.row.rate7 }}
                      </q-td>
                      <q-td key="goal8" class="goal text-right">
                        {{ props.row.goal8 }}
                      </q-td>
                      <q-td key="result8" class="results text-right">
                        {{ props.row.result8 }}
                      </q-td>
                      <q-td key="rate8" class="rate text-right">
                        {{ props.row.rate8 }}
                      </q-td>
                      <q-td key="goal9" class="goal text-right">
                        {{ props.row.goal9 }}
                      </q-td>
                      <q-td key="result9" class="results text-right">
                        {{ props.row.result9 }}
                      </q-td>
                      <q-td key="rate9" class="rate text-right">
                        {{ props.row.rate9 }}
                      </q-td>
                      <q-td key="goalQ3" class="goal text-right">
                        {{ props.row.goalQ3 }}
                      </q-td>
                      <q-td key="resultQ3" class="results text-right">
                        {{ props.row.resultQ3 }}
                      </q-td>
                      <q-td key="rateQ3" class="rate text-right">
                        {{ props.row.rateQ3 }}
                      </q-td>
                      <q-td key="goal10" class="goal text-right">
                        {{ props.row.goal10 }}
                      </q-td>
                      <q-td key="result10" class="results text-right">
                        {{ props.row.result10 }}
                      </q-td>
                      <q-td key="rate10" class="rate text-right">
                        {{ props.row.rate10 }}
                      </q-td>
                      <q-td key="goal11" class="goal text-right">
                        {{ props.row.goal11 }}
                      </q-td>
                      <q-td key="result11" class="results text-right">
                        {{ props.row.result11 }}
                      </q-td>
                      <q-td key="rate11" class="rate text-right">
                        {{ props.row.rate11 }}
                      </q-td>
                      <q-td key="goal12" class="goal text-right">
                        {{ props.row.goal12 }}
                      </q-td>
                      <q-td key="result12" class="results text-right">
                        {{ props.row.result12 }}
                      </q-td>
                      <q-td key="rate12" class="rate text-right">
                        {{ props.row.rate12 }}
                      </q-td>
                      <q-td key="goalQ4" class="goal text-right">
                        {{ props.row.goalQ4 }}
                      </q-td>
                      <q-td key="resultQ4" class="results text-right">
                        {{ props.row.resultQ4 }}
                      </q-td>
                      <q-td key="rateQ4" class="rate text-right">
                        {{ props.row.rateQ4 }}
                      </q-td>
                    </q-tr>
                  </template>
                  <template v-slot:bottom-row>
                    <q-tr class="tr_btm">
                      <q-td>합계</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- 참고하세요 + 버튼 -->
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>해당 테이블의 항목별 설명이 두줄 가량 노출됩니다.</p>
                </div>
                <div class="btn_area">
                  <q-btn
                    fill
                    unelevated
                    color="grey-4"
                    class="size_xs"
                    label="더보기"
                  />
                </div>
              </div>
              <!-- // 참고하세요 + 버튼 -->
            </div>
          </q-tab-panel>
          <!-- // tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab4');
const searchDate = ref({
  from: '2023.06.01',
});
const select = ref('op1');
const selectOpt = ref([
  {
    label: '평가점수',
    value: 'op1',
  },
  {
    label: '총원지수',
    value: 'op2',
  },
  {
    label: '매출',
    value: 'op3',
  },
]);

// data테이블
const dataRows = ref([
  {
    idx: 11,
    section: '서울서북',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
    goalQ1: '0',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 10,
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: false,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 9,
    section: '강서교육국 [김대교]',
    depth: 'depth3',
    state: true,
    flat: false,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 8,
    section: '강서교육국 [강정현]',
    depth: 'depth4',
    state: true,
    flat: true,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 7,
    section: '강서교육국 [강정현]',
    depth: 'depth3',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 6,
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 5,
    section: '서울강북',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 4,
    section: '서울남동',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 3,
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 2,
    section: '울산',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '0',
    rateQ1: '0',
    goal4: '0',
    result4: '0',
    rate4: '0',
    goal5: '0',
    result5: '0',
    rate5: '0',
    goal6: '0',
    result6: '0',
    rate6: '0',
    goalQ2: '0',
    resultQ2: '0',
    rateQ2: '0',
    goal7: '0',
    result7: '0',
    rate7: '0',
    goal8: '0',
    result8: '0',
    rate8: '0',
    goal9: '0',
    result9: '0',
    rate9: '0',
    goalQ3: '0',
    resultQ3: '0',
    rateQ3: '0',
    goal10: '0',
    result10: '0',
    rate10: '0',
    goal11: '0',
    result11: '0',
    rate11: '0',
    goal12: '0',
    result12: '0',
    rate12: '0',
    goalQ4: '0',
    resultQ4: '0',
    rateQ4: '0',
  },
  {
    idx: 1,
    section: '경북',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '999,999',
    result1: '999,999',
    rate1: '9,999,999',
    goal2: '99,999,999',
    result2: '99,999,999',
    rate2: '99,999,999',
    goal3: '999,999,9993',
    result3: '999,999,999',
    rate3: '999,999,999',
    resultQ1: '999,999,999',
    rateQ1: '999,999,999',
    goal4: '999,999,999',
    result4: '99,999,999',
    rate4: '9,999,999',
    goal5: '99,999,999',
    result5: '999,999,999',
    rate5: '99,999,999',
    goal6: '999,999,999',
    result6: '9,999,999',
    rate6: '999,999,999',
    goalQ2: '99,999,999',
    resultQ2: '9,999,999',
    rateQ2: '999,999',
    goal7: '99,999',
    result7: '9,999',
    rate7: '999',
    goal8: '99',
    result8: '999,999,999',
    rate8: '999,999,999',
    goal9: '999,999,999',
    result9: '999,999,999',
    rate9: '999,999,999',
    goalQ3: '999,999,999',
    resultQ3: '999,999,999',
    rateQ3: '999,999,999',
    goal10: '999,999,999',
    result10: '999,999,999',
    rate10: '0999,999,999',
    goal11: '999,999,999',
    result11: '999,999,999',
    rate11: '999,999,999',
    goal12: '999,999,999',
    result12: '999,999,999',
    rate12: '999,999,999',
    goalQ4: '999,999,999',
    resultQ4: '999,999,999',
    rateQ4: '999,999,999',
  },
]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 99999,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
