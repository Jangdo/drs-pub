<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회비조정</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date box_l normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyto"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyto.hide()
                          "
                          mask="YYYY.MM"
                          years-in-month-view
                          :emit-immediately="true"
                          default-view="Months"
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>조직</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-select
                  class="hide_label box_l"
                  label="회비조정항목 전체"
                  v-model="select1Type"
                  :options="select1TypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="hide_label box_l"
                  label="처리현황 전체"
                  v-model="select2Type"
                  :options="select2TypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-input outlined dense v-model="keyword" placeholder="회원">
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <!-- 검색결과, 정렬 -->
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8 gap10">
              <q-btn class="size_sm" outline label="수수료공제 첨부 양식서" />
              <q-btn
                class="size_sm"
                fill
                unelevated
                color="black"
                label="신청"
              />
            </div>
          </div>
          <!-- // 검색결과, 정렬 -->

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
          </q-table>
        </div>
        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // pagination -->

        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <ul class="ul_custom disc text-grey-3">
              <li>
                신청번호를 누르시면(클릭) 회비조정 신청내역을 상세하게 보실 수
                있습니다.
              </li>
              <li>
                영업마감 시 국장, 그룹장(임원) 미승인건은 '기간만료' 처리됩니다.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  to: '2019.02',
});
const select1Type = ref(['회비조정항목 전체']);
const select1TypeOption = ref([
  {
    id: 'select11',
    desc: '회비조정항목1',
  },
  {
    id: 'select12',
    desc: '회비조정항목2 ',
  },
]);
const select2Type = ref(['처리현황 전체']);
const select2TypeOption = ref([
  {
    id: 'select21',
    desc: '처리현황1',
  },
  {
    id: 'select22',
    desc: '처리현황2 ',
  },
]);

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '신청일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '신청번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '회비조정항목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '처리현황',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  // {
  //   name: 'tdata5',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata5,
  // },
  {
    name: 'tdata6',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '신청자명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata11',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '회비조정액',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata13,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 9,
    tdata1: '2022.04.03',
    tdata2: '2023110331_C1_001',
    tdata3: '회비 조정',
    tdata4: '임원 승인',
    // tdata5: '눈높이 사업2 부분',
    tdata6: '서울 서북본부',
    tdata7: '서울 강서 교육국',
    tdata8: '0001',
    tdata9: '[LC]달빛 드림',
    tdata10: '홍홍길동[12341567890]',
    tdata11: '홍홍길동',
    tdata12: '123456789012',
    tdata13: '100,000',
  },
  {
    idx: 8,
    tdata1: '2022.04.03',
    tdata2: '202301_C1_001',
    tdata3: '회비',
    tdata4: '승인',
    // tdata5: '눈높이부분',
    tdata6: '서북본부',
    tdata7: '강서교육국',
    tdata8: '01',
    tdata9: '[LC]달빛',
    tdata10: '홍동[123456790]',
    tdata11: '길동',
    tdata12: '123456',
    tdata13: '10,000',
  },
  {
    idx: 7,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 6,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 5,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 4,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 3,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 2,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
  {
    idx: 1,
    tdata1: '2022.04.03',
    tdata2: '20230331_C1_001',
    tdata3: '회비조정',
    tdata4: '임원승인',
    // tdata5: '눈높이사업부분',
    tdata6: '서울서북본부',
    tdata7: '서울강서교육국',
    tdata8: '001',
    tdata9: '[LC]달빛드림',
    tdata10: '홍길동[1234567890]',
    tdata11: '홍길동',
    tdata12: '1234567890',
    tdata13: '2,000',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
