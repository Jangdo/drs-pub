<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree row5" v-if="$q.screen.name == 'lg'">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="single_form">
            <h3 class="title3">부문</h3>
            <q-select
              class="box_xl hide_label"
              v-model="searchstudyType"
              :options="searchstudyTypeOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              label="선택하세요"
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="row_tree_group">
            <div class="item_tree">
              <p class="tree_group_tit mb10">본부</p>
              <!-- pc -->
              <div class="tree_container">
                <q-tree
                  :nodes="treeData1"
                  node-key="id"
                  selected-color="tree_selected"
                  class="tree_dgroup"
                  v-model:selected="treeSelected1"
                  default-expand-all
                  @update:selected="temp('트리1', treeSelected1)"
                >
                  <!-- 230503 멀티 셀렉트 수정 -->
                  <template v-slot:default-header="prop">
                    <div
                      class="tree_item"
                      :class="prop.node.selected ? 'tree_selected' : ''"
                    >
                      {{ prop.node.label }}
                    </div>
                  </template>
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit mb10">조직</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData2"
                  node-key="id"
                  selected-color="tree_selected"
                  class="tree_dgroup"
                  v-model:selected="treeSelected2"
                  default-expand-all
                  @update:selected="temp('트리2', treeSelected2)"
                >
                  <!-- 230503 멀티 셀렉트 수정 -->
                  <template v-slot:default-header="prop">
                    <div
                      class="tree_item"
                      :class="prop.node.selected ? 'tree_selected' : ''"
                    >
                      {{ prop.node.label }}
                    </div>
                  </template>
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit mb10">팀</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData3"
                  node-key="id"
                  selected-color="tree_selected"
                  class="tree_dgroup"
                  v-model:selected="treeSelected3"
                  default-expand-all
                  @update:selected="temp('트리3', treeSelected3)"
                >
                  <!-- 230503 멀티 셀렉트 수정 -->
                  <template v-slot:default-header="prop">
                    <div
                      class="tree_item"
                      :class="prop.node.selected ? 'tree_selected' : ''"
                    >
                      {{ prop.node.label }}
                    </div>
                  </template>
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit mb10">채널</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData4"
                  node-key="id"
                  selected-color="tree_selected"
                  class="tree_dgroup"
                  v-model:selected="treeSelected4"
                  default-expand-all
                  @update:selected="temp('트리4', treeSelected4)"
                >
                  <!-- 230503 멀티 셀렉트 수정 -->
                  <template v-slot:default-header="prop">
                    <div
                      class="tree_item"
                      :class="prop.node.selected ? 'tree_selected' : ''"
                    >
                      {{ prop.node.label }}
                    </div>
                  </template>
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit mb10">선생님</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData5"
                  node-key="id"
                  selected-color="tree_selected"
                  class="tree_dgroup"
                  v-model:selected="treeSelected5"
                  default-expand-all
                  @update:selected="temp('트리5', treeSelected5)"
                >
                  <!-- 230503 멀티 셀렉트 수정 -->
                  <template v-slot:default-header="prop">
                    <div
                      class="user_tree tree_item"
                      :class="prop.node.selected ? 'tree_selected' : ''"
                    >
                      {{ prop.node.label }}
                    </div>
                  </template>
                </q-tree>
              </div>
            </div>
          </div>
          <!-- <div class="tree_btm">
          </div> -->
          <!-- <q-separator class="popup_btm_line" /> -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <div class="btn_area response">
            <q-btn
              unelevated
              outline
              v-close-popup
              class="size_lg"
              label="취소"
            />
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
            <q-btn
              class="size_md btn_reset btn_position_end"
              unelevated
              icon=""
              dense
              outline
              label="초기화"
            />
          </div>
        </q-card-actions>
      </q-card>

      <q-card
        class="respons_card type_tree"
        v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
      >
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <q-list class="list_custom type01">
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">부문</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected1.length > 0"
                    >
                      <span>{{ treeSelected1 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData1"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected1"
                    default-expand-all
                    @update:selected="temp('트리1', treeSelected1)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">본부</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected2.length > 0"
                    >
                      <span>{{ treeSelected2 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData2"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected2"
                    default-expand-all
                    @update:selected="temp('트리2', treeSelected2)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">조직</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected3.length > 0"
                    >
                      <span>{{ treeSelected3 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData3"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected3"
                    default-expand-all
                    @update:selected="temp('트리3', treeSelected3)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        <!-- <img
                          class="q-tree__img q-mr-sm"
                          src="/icons/icon-tree-folder.svg"
                        /> -->
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">팀</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected4.length > 0"
                    >
                      <span>{{ treeSelected4 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData4"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected4"
                    default-expand-all
                    @update:selected="temp('트리4', treeSelected4)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">채널</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected5.length > 0"
                    >
                      <span>{{ treeSelected5 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData5"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected5"
                    default-expand-all
                    @update:selected="temp('트리5', treeSelected5)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <!-- <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">선생님</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected6.length > 0"
                    >
                      <span>{{ treeSelected6 }}</span>

                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData6"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type02"
                    v-model:selected="treeSelected6"
                    default-expand-all
                    @update:selected="temp('트리6', treeSelected6)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item user_tree"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item> -->
          </q-list>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            icon=""
            class="size_sm btn_reset"
            label="초기화"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="검색"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>
<style lang="scss" scoped>
:deep(.tree_dgroup.q-tree) {
  height: 348px;
  padding: 5px 8px;
  .q-tree__node-header {
    // node 전체
    display: inline-flex;
    align-items: flex-start;
    width: min-content;
    line-height: 1.3;
    padding: 0;
    body.screen--sm & {
      width: 100%;
    }
    &.q-tree__node--selected {
      background: none !important;
    }
  }
  .q-tree__node--parent {
    & > div:first-child {
      margin-bottom: 5px;
      .q-tree__node-header-content {
        cursor: default;
        padding-right: 0;
        & > div {
          width: auto;
          flex-basis: inherit;
          font-weight: 600;
          word-break: keep-all;
          white-space: break-spaces;
          font-size: 16px;
        }
      }
    }
  }
  .q-tree__node--child {
    .q-tree__node-header {
      padding: 0 !important;
      &.q-tree__node--selected {
        padding: 0 !important;
        .q-tree__node-header-content {
          width: min-content;
          background: #eeeae4;
          padding: 0;
          border-radius: 4px;
          .tree_item {
            padding: 4px 8px;
          }
        }
      }
    }
    .tree_item {
      padding: 4px 8px;
      color: #555;
      &.tree_selected {
        padding: 4px 8px;
      }
    }
    .user_tree {
      white-space: nowrap;
      word-break: keep-all;
    }
  }
  .q-tree__node:after {
    top: 0;
  }
}
</style>
<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// tree
const treeData1 = ref([
  {
    label: '교육서비스부문',
    id: 'a_0',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'a_1',
        label: '눈높이서비스부문',
        selected: true,
      },
      {
        label: '성장서비스부문',
        selected: false,
        id: 'a_2',
      },
      {
        label: '디지털서비스부문',
        id: 'a_3',
        selected: false,
      },
    ],
  },
]);
const treeSelected1 = ref('');

const treeData2 = [
  {
    label: '교육서비스부문 > 서울서북본부',
    id: 'b_0',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'b_1',
        label: '서울서북마케팅1팀 교육국 교육국',
        selected: true,
      },
      {
        label: '경인본부2',
        selected: false,
        id: 'b_2',
      },
      {
        label: '경인본부3',
        id: 'b_3',
        selected: false,
      },
    ],
  },
];
const treeSelected2 = ref('');

const treeData3 = [
  {
    label: '서울강북본부 > 서울강북마케팅1팀 > 교육국',
    id: 'c_0',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'c_1',
        label: '경인본부1',
        selected: true,
      },
      {
        label: '경인본부2',
        selected: true,
        id: 'c_2',
      },
      {
        label: '경인본부3',
        id: 'c_3',
        selected: true,
      },
    ],
  },
];
const treeSelected3 = ref('');
const treeData4 = [
  {
    label: '서울강북본부 > 서울강북마케팅1팀 교육국 > 001',
    id: 'd_0',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'd_1',
        label: '경인본부1',
        selected: true,
      },
      {
        label: '경인본부2',
        selected: false,
        id: 'd_2',
      },
      {
        label: ' 경인본부3경인본부3 경인본부3',
        id: 'd_3',
        selected: false,
      },
    ],
  },
];
const treeSelected4 = ref('');
const treeData5 = [
  {
    label: '서울강북본부 > 서울강북마케팅1팀 교육국 > 001 > 채널없음',
    id: 'e_0',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'e_1',
        label: '유정민[22000731]',
        selected: true,
      },
      {
        label: '유정민[22000731]',
        selected: false,
        id: 'e_2',
      },
      {
        label: '유정민[22000731]',
        id: 'e_3',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_4',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_5',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_6',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_7',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_8',
        selected: false,
      },
      {
        label: '유정민[22000731]',
        id: 'e_9',
        selected: false,
      },
    ],
  },
];
const treeSelected5 = ref('');
// const treeData6 = [
//   {
//     label: '본부1',
//     id: 'b_1',
//     selected: false,
//   },
//   {
//     label: '본부2',
//     id: 'b_2',
//     selected: true,
//   },
//   {
//     label: '본부3',
//     id: 'b_3',
//     selected: false,
//   },
// ];
// const treeSelected6 = ref('');
// 트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}

const searchstudyType = ref(['']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
</script>
