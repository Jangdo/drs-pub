<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->

        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                                :emit-immediately="true"
                                default-view="Months"
                              />
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <div class="wrap_opt_group">
                        <q-option-group
                          class="opt_group_custom week_type"
                          type="checkbox"
                          color="blue-3"
                          v-model="day"
                          :options="dayOption"
                        />
                      </div>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-select
                        class="box_l"
                        v-model="selectSelected"
                        :options="selectOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="btn_wrap col-12">
                    <q-btn class="size_sm btn_print" outline icon="" label="" />
                  </div>
                </div>
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  v-model:pagination="dataPagination"
                  row-key=""
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="tdata1" class="text-center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="text-center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata3" class="text-left">
                        {{ props.row.tdata3 }}
                      </q-td>
                      <q-td key="tdata4" class="text-center">
                        {{ props.row.tdata4 }}
                      </q-td>
                      <q-td key="tdata5" class="text-center">
                        {{ props.row.tdata5 }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab1');
const searchDate = ref({
  from: '2019.02',
});

// table_search_area
// const daym1 = ref(['all']);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);

const selectSelected = ref(['수강생대장']);
const selectOption = ref([
  {
    id: '111',
    desc: '111',
  },
  {
    id: '222',
    desc: '222 ',
  },
]);

//data테이블
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '이름',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원번호',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '주소',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '전화번호',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '입원월일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
]);
const dataRows = ref([
  {
    tdata1: '김정숙',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '홍길동',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 2호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '나대굥',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '김정숙',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '홍길동',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '나대굥',
    tdata2: '111',
    tdata3: '경기 화성시 진안동 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '김정숙',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '홍길동',
    tdata2: '1',
    tdata3: '경기 화성시 진안동 월드메르디앙 2호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '나대굥',
    tdata2: '111',
    tdata3: '경기 화성시 진안동 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '김정숙',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
  {
    tdata1: '김정숙',
    tdata2: '0055568198',
    tdata3: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata4: '01012345000',
    tdata5: '2020.12.29',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 9999,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
