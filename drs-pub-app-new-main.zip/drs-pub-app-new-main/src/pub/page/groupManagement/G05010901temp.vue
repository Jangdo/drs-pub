<template>
  <div class="inner_admin">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="dialog_card type_02 venti">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="row_tree_group">
            <div class="item_tree">
              <h3 class="inner_tit">본부</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData1"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree"
                  v-model:selected="treeSelected1"
                  default-expand-all
                  @update:selected="temp('트리1', treeSelected1)"
                >
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="inner_tit">조직</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData2"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree"
                  v-model:selected="treeSelected2"
                  default-expand-all
                  @update:selected="temp('트리2', treeSelected2)"
                >
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="inner_tit">팀</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData3"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree"
                  v-model:selected="treeSelected3"
                  default-expand-all
                  @update:selected="temp('트리3', treeSelected3)"
                >
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="inner_tit">채널</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData4"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree"
                  v-model:selected="treeSelected4"
                  default-expand-all
                  @update:selected="temp('트리4', treeSelected4)"
                >
                </q-tree>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="inner_tit">선생님</h3>
              <div class="tree_container">
                <q-tree
                  :nodes="treeData5"
                  node-key="id"
                  selected-color="primary"
                  class="popup_tree"
                  v-model:selected="treeSelected5"
                  default-expand-all
                  @update:selected="temp('트리5', treeSelected5)"
                >
                </q-tree>
              </div>
            </div>
          </div>
          <div class="tree_btm">
            <div class="btn_area">
              <q-btn
                class="size_sm btn_reset"
                icon="ion-ios-refresh"
                dense
                outline
                label="선택 초기화"
              />
            </div>
          </div>
          <q-separator class="popup_btm_line" />
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_cancel"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_submit"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// tree
const treeData1 = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected1 = ref('메시지 카테고리');

const treeData2 = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected2 = ref('메시지 카테고리');

const treeData3 = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected3 = ref('메시지 카테고리');
const treeData4 = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected4 = ref('메시지 카테고리');
const treeData5 = [
  {
    label: '사용자 카테고리',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected5 = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}
</script>
