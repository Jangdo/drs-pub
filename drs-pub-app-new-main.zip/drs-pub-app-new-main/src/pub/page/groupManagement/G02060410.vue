<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <!-- 2023.06.21 : 탭색상 변경 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!-- //2023.06.21 : 탭색상 변경 -->
        <!--// 탭 상단 선택 -->
        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="wrapper_tab">
                <q-tabs
                  v-model="tabintab"
                  inline-label
                  class="tab_line"
                  active-bg-color="white"
                  active-color="primary"
                  indicator-color="primary"
                  align="justify"
                  narrow-indicator
                  outside-arrows
                >
                  <q-tab name="tab41" label="원칙" :ripple="false" />
                  <q-tab name="tab42" label="직원명부" :ripple="false" />
                  <q-tab name="tab43" label="지도점검기록부" :ripple="false" />
                  <q-tab name="tab44" label="학원강사 게시표" :ripple="false" />
                  <q-tab name="tab45" label="교습비 게시표" :ripple="false" />
                  <q-tab
                    name="tab46"
                    label="교습비 반환 규정"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab47"
                    label="문서접수 및 발송대장"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab48"
                    label="교습비 게시표(옥외)"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab49"
                    label="학원 안전점검 체크리스트"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab410"
                    label="자체 실태 점검표 "
                    :ripple="false"
                  />
                </q-tabs>
                <q-tab-panels v-model="tabintab" animated>
                  <!-- tab41 컨텐츠 -->
                  <q-tab-panel name="tab41">41</q-tab-panel>
                  <!--// tab41 컨텐츠 -->
                  <!-- tab42 컨텐츠 -->
                  <q-tab-panel name="tab42">42</q-tab-panel>
                  <!--// tab42 컨텐츠 -->
                  <!-- tab43 컨텐츠 -->
                  <q-tab-panel name="tab43">43</q-tab-panel>
                  <!--// tab43 컨텐츠 -->
                  <!-- tab44 컨텐츠 -->
                  <q-tab-panel name="tab44">44</q-tab-panel>
                  <!--// tab44 컨텐츠 -->
                  <!-- tab45 컨텐츠 -->
                  <q-tab-panel name="tab45">45</q-tab-panel>
                  <!--// tab45 컨텐츠 -->
                  <!-- tab46 컨텐츠 -->
                  <q-tab-panel name="tab46">46</q-tab-panel>
                  <!--// tab46 컨텐츠 -->
                  <!-- tab47 컨텐츠 -->
                  <q-tab-panel name="tab47">47</q-tab-panel>
                  <!--// tab47 컨텐츠 -->
                  <!-- tab48 컨텐츠 -->
                  <q-tab-panel name="tab48">48</q-tab-panel>
                  <!--// tab48 컨텐츠 -->
                  <!-- tab49 컨텐츠 -->
                  <q-tab-panel name="tab49">49</q-tab-panel>
                  <!--// tab49 컨텐츠 -->
                  <!-- tab410 컨텐츠 -->
                  <q-tab-panel name="tab410">
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.03.04</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>

                    <div class="document_rule">
                      <div class="outline_box">
                        <!-- 타이틀 -->
                        <div class="title1">
                          <span>자체 실태 점검표</span>
                          <q-space />
                          <q-btn
                            class="size_sm"
                            unelevated
                            fill
                            color="black"
                            label="등록"
                          />
                        </div>
                        <!-- // 타이틀 -->

                        <!-- 점검표 타이틀 입력 -->
                        <div class="row justify-center items-baseline mb24">
                          <q-input
                            class="inp_basic box_m"
                            outlined
                            v-model="inp1"
                            placeholder=""
                          />
                          <span class="title1 pl5"
                            >눈높이러닝센터 자체 실태 점검표 2-1</span
                          >
                        </div>
                        <!-- // 점검표 타이틀 입력 -->

                        <!-- 날짜 입력 -->
                        <div class="input_date">
                          <span class="txt">자체 점검일</span>
                          <div class="write">
                            <q-input
                              class="inp_basic"
                              outlined
                              v-model="inpYear"
                              placeholder=""
                            />
                            <span>년</span>
                            <q-input
                              class="inp_basic"
                              outlined
                              v-model="inpMonth"
                              placeholder=""
                            />
                            <span>월</span>
                            <q-input
                              class="inp_basic"
                              outlined
                              v-model="inpDay"
                              placeholder=""
                            />
                            <span>일</span>
                          </div>
                        </div>
                        <!-- // 날짜 입력-->

                        <!-- 점검자 입력 -->
                        <div class="input_date">
                          <span class="txt">점검자</span>
                          <q-input
                            class="inp_basic"
                            outlined
                            v-model="inpChecker"
                            점검자
                            placeholder=""
                          />
                          <span class="txt">(확인)</span>
                        </div>
                        <!-- // 점검자 입력 -->

                        <div class="group">
                          <div class="body1">1. 학원(독서실, 교습소) 현황</div>
                          <div class="content">
                            <!-- general_table -->
                            <div class="general_table pt20">
                              <q-table
                                :columns="data1Columns"
                                :rows="data1Rows"
                                row-key=""
                                hide-bottom
                                hide-pagination
                                separator="cell"
                              >
                                <template v-slot:body="props">
                                  <q-tr :props="props">
                                    <q-td key="tdata1_1" class="text-center">
                                      <!-- 2023.06.21 : input 추가 -->
                                      <q-input
                                        class="inp_basic"
                                        outlined
                                        v-model="props.row.tdata1_1"
                                        placeholder=""
                                      />
                                      <!-- //2023.06.21 : input 추가 -->
                                    </q-td>
                                    <q-td key="tdata1_2" class="text-center">
                                      <!-- 2023.06.21 : input 추가 -->
                                      <q-input
                                        class="inp_basic"
                                        outlined
                                        v-model="props.row.tdata1_2"
                                        placeholder=""
                                      />
                                      <!-- //2023.06.21 : input 추가 -->
                                    </q-td>
                                    <q-td
                                      key="tdata1_input1"
                                      class="text-center"
                                    >
                                      <q-input
                                        class="inp_basic"
                                        outlined
                                        v-model="props.row.tdata1_input1"
                                        placeholder=""
                                      />
                                    </q-td>
                                    <q-td
                                      key="tdata1_input2"
                                      class="text-center"
                                    >
                                      <q-input
                                        class="inp_basic"
                                        outlined
                                        v-model="props.row.tdata1_input2"
                                        placeholder=""
                                      />
                                    </q-td>
                                    <q-td
                                      key="tdata1_input3"
                                      class="text-center"
                                    >
                                      <q-input
                                        class="inp_basic"
                                        outlined
                                        v-model="props.row.tdata1_input3"
                                        placeholder=""
                                      />
                                    </q-td>
                                  </q-tr>
                                </template>
                              </q-table>
                            </div>
                            <!--// general_table -->
                          </div>
                        </div>

                        <div class="group mt60">
                          <div class="body1">
                            2. 자체 실태조사 내용(해당 항목에 시정
                            결과(예정)내용 기재)
                          </div>
                          <div class="content">
                            <!-- markup-table body rowspan -->
                            <q-markup-table
                              separator="cell"
                              class="combine_table mt20"
                              wrap-cells
                            >
                              <thead>
                                <tr>
                                  <th class="" style="width: 120px">구분</th>
                                  <th class="" colspan="2">
                                    점검 사항 (교육청에 통보된 내용)
                                  </th>
                                  <th class="" colspan="2">
                                    점검 실태(현재 운영 형태)
                                  </th>
                                  <th class="" style="width: 280px">
                                    시정 결과
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="text-left">1. 학원 명칭</td>
                                  <td class="text-left" colspan="2">
                                    무단 명칭 변경 사용 여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData1_1"
                                      placeholder="무, 유(명칭)을 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData1_2"
                                      placeholder="예시) 교육청 등록예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left">2. 설립자</td>
                                  <td class="text-left" colspan="2">
                                    무단 운영자(신고자) 변경 여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData2_1"
                                      placeholder="무, 유(변경자명)을 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic flexable"
                                      outlined
                                      v-model="inpData2_2"
                                      placeholder="예시) 교육청 등록예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left">3. 위치</td>
                                  <td class="text-left" colspan="2">
                                    무단 등록(신고) 위치 변동 여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData3_1"
                                      placeholder="무, 유(주소)을 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData3_2"
                                      placeholder="예시) 교육청 등록예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left" rowspan="5">
                                    4. 게시(표시)
                                  </td>
                                  <td class="text-left" colspan="2">
                                    학원등록증 비치
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_1"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_2"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first" colspan="2">
                                    교습비 게시표 게시여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_3"
                                      placeholder="게시 / 미게시 / 허위게시 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_4"
                                      placeholder="예시) 게시함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first" colspan="2">
                                    교습비 반환 규정 게시여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_5"
                                      placeholder="게시 / 미게시 / 허위게시 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_6"
                                      placeholder="예시) 게시함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    광고(홍보)실시 등
                                  </td>
                                  <td class="text-left">교습비 표시유무</td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_7"
                                      placeholder="표시 / 미표시 / 허위표시 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_8"
                                      placeholder="예시) 표시함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    강사 인적사항 게시
                                  </td>
                                  <td class="text-left">게시유무</td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_9"
                                      placeholder="게시 / 미게시 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData4_10"
                                      placeholder="예시) 게시함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left">5. 교습과정</td>
                                  <td class="text-left" colspan="2">
                                    등록(신고)교습과정[과목] 변동 여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData5_1"
                                      placeholder="무, 유(교습과정, 과목)을 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData5_2"
                                      placeholder="예시) 변경통보 예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left" rowspan="3">
                                    6. 교습비
                                  </td>
                                  <td class="text-left" colspan="2">
                                    교습비 변경 등록 여부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData6_1"
                                      placeholder="유 / 무 중 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <td rowspan="3">
                                    <div style="height: 100%">
                                      <q-input
                                        class="basic"
                                        outlined
                                        v-model="inpData6_2"
                                        placeholder="예시) 교습비 변경 등록 예정"
                                        type="textarea"
                                      >
                                        <template v-slot:label
                                          >메시지 내용</template
                                        >
                                      </q-input>
                                    </div>
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first" rowspan="2">
                                    교습과목
                                  </td>
                                  <td class="text-left" rowspan="2">
                                    교육청의 교습비 기준액에<br />준한 등록 신고
                                    교습비
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td colspan="2">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData6_3"
                                      placeholder="실제징수내역을 입력해주세요"
                                      auto-grow
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td class="row_first">
                                    <div class="row items-center mb5">
                                      <p class="text-left mr6">월 교습시간</p>

                                      <!-- tooltip_down -->
                                      <q-fab
                                        direction="up"
                                        hide-icon
                                        class="tooltip_down type_black grey-3"
                                        flat
                                      >
                                        <q-fab-action
                                          square
                                          label=""
                                          label-position="left"
                                          style="width: 260px"
                                        >
                                          <span class="btn_close"></span>
                                          <p class="txt text-body2">
                                            (한타임분수*주횟수*4,2주)(분)
                                          </p>
                                        </q-fab-action>
                                      </q-fab>
                                      <!--// tooltip_down -->
                                    </div>

                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData6_4"
                                      placeholder=""
                                      auto-grow
                                    />
                                  </td>
                                  <td>
                                    <p class="text-left mb5">징수액</p>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inpData6_5"
                                      placeholder=""
                                      auto-grow
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left">7. 수강생</td>

                                  <!-- 2023.06.21 : 수정 -->
                                  <td class="text-left" colspan="2">
                                    정원 00명 및 일시 수용인원 00명<br /><br />
                                    * 정원산정 * <br />
                                    ① 교실만의 면적:교실 가로X세로(㎡)<br />
                                    ② 1인 최소 면적 : 1.2(㎡)<br />
                                    ③ 일일 학습 운영시간 : AM12~PM9, 8H<br />
                                    ④ 일시 수용인원 : ①÷②<br />
                                    ⑤ 정원 : ①÷②X③ ⑥ 예시 : ①76(㎡)÷②1.2(㎡)X③8H
                                    = 506명
                                  </td>
                                  <td class="text-left" colspan="2">
                                    <div class="text-center row-4">
                                      <span>현원</span>
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData7_1"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td>
                                    <div style="height: 100%">
                                      <q-input
                                        class="basic"
                                        outlined
                                        v-model="inpData7_2"
                                        placeholder="예시) 좌동"
                                        type="textarea"
                                      >
                                        <template v-slot:label
                                          >메시지 내용</template
                                        >
                                      </q-input>
                                    </div>
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                              </tbody>
                            </q-markup-table>
                            <!-- //markup-table body rowspan -->
                          </div>
                        </div>

                        <!-- 점검표 타이틀 입력 -->
                        <div
                          class="row justify-center items-baseline mt120 mb60"
                        >
                          <q-input
                            class="inp_basic box_m"
                            outlined
                            v-model="inp2"
                            placeholder=""
                          />
                          <span class="title1 pl5"
                            >눈높이러닝센터 자체 실태 점검표 2-2</span
                          >
                        </div>
                        <!-- // 점검표 타이틀 입력 -->

                        <div class="group">
                          <div class="content">
                            <!-- markup-table body rowspan -->
                            <q-markup-table
                              separator="cell"
                              class="combine_table"
                              wrap-cells
                            >
                              <thead>
                                <tr>
                                  <th class="" style="width: 120px">구분</th>
                                  <th class="">
                                    점검 사항 (교육청에 통보된 내용)
                                  </th>
                                  <th class="">점검 실태(현재 운영 형태)</th>
                                  <th class="" style="width: 280px">
                                    시정 결과
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="text-left" rowspan="3">
                                    8. 강사현황
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td class="text-left">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >강사 등록 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_1"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td class="text-left">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >강사 미등록 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_2"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData8_3"
                                      placeholder="예시) 미등록 강사 등록 예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td class="text-left row_first">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >1. 성범죄경력조회서 검증 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_4"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td class="text-left">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >1. 경력조회서 미 검증 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_5"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData8_6"
                                      placeholder="예시) 지체없이 검증 완료 통보 예정"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td class="text-left row_first">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >2. 졸업(학력)증명서 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_7"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td class="text-left">
                                    <div class="text-center row-4">
                                      <span class="text-no-wrap"
                                        >2. 졸업(학력)증명서 :</span
                                      >
                                      <q-space />
                                      <q-input
                                        class="type_medium"
                                        outlined
                                        v-model="inpData8_8"
                                        placeholder=""
                                      />
                                      <span>명</span>
                                    </div>
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData8_9"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left" rowspan="5">
                                    9. 장부 비치
                                  </td>
                                  <td class="text-left">- 학원운영원칙</td>

                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_1"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_2"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    - 현금출납부(간편장부)
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_3"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_4"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    - 수강생 대장
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_5"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_6"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">- 출석부</td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_7"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_8"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    - 교습비 영수증 원부
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_9"
                                      placeholder="비치 / 미비치 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData9_10"
                                      placeholder="예시) 비치함"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left" rowspan="2">
                                    10. 기타
                                  </td>
                                  <td class="text-left">
                                    학원책임배상보험 가입
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData10_1"
                                      placeholder="가입 / 미가입 중 입력해주세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData10_2"
                                      placeholder="예시) 가입 후 교육청에 팩스로 보냄"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left row_first">
                                    일일 마지막 강의 종료 시간
                                  </td>
                                  <!-- 2023.06.21 : 수정 -->
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData10_3"
                                      placeholder="입력하세요"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      outlined
                                      v-model="inpData10_4"
                                      placeholder="예시) 9시 50분"
                                    />
                                  </td>
                                  <!-- //2023.06.21 : 수정 -->
                                </tr>
                                <tr>
                                  <td class="text-left">※ 종합 검토</td>
                                  <td class="text-left" colspan="3">
                                    <!-- 2023.06.21 : 수정 -->
                                    <q-input
                                      class="basic"
                                      outlined
                                      v-model="examine"
                                      placeholder="이 부분은 국장이 총 점검 기록하여 확인함"
                                      type="textarea"
                                    >
                                      <template v-slot:label
                                        >메시지 내용</template
                                      >
                                    </q-input>
                                    <!-- //2023.06.21 : 수정 -->
                                  </td>
                                </tr>
                              </tbody>
                            </q-markup-table>
                            <!-- //markup-table body rowspan -->

                            <!-- 2023.06.21 : 위치이동 -->
                            <p class="mt50 mb20 text-center">
                              허위로 서면평가를 작성할 시에는 교육청의
                              지도점검에 따른 행정처분과<br />그에 따른 지점장,
                              센터장의 책임 소재에 따른 불이익이 있을 수 있음을
                              인지바랍니다.
                            </p>
                            <!-- //2023.06.21 : 위치이동 -->
                          </div>
                        </div>
                      </div>

                      <!-- 2023.06.21 : 버튼 추가 -->
                      <div class="btn_area btn_bottom_type01">
                        <q-btn
                          unelevated
                          color="black"
                          class="size_lg"
                          label="저장"
                        />
                      </div>
                      <!-- //2023.06.21 : 버튼 추가 -->
                    </div>
                  </q-tab-panel>
                  <!--// tab410 컨텐츠 -->
                </q-tab-panels>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab4');
const tabintab = ref('tab410');

const inp1 = ref(); //점검표 2-1
const inp2 = ref(); //점검표 2-2

const inpYear = ref(); //자체점검일 년
const inpMonth = ref(); //자체점검일 월
const inpDay = ref(); //자체점검일 일
const inpChecker = ref(); //점검자

//학원현황 테이블
const data1Rows = ref([
  {
    tdata1_1: '', //설립(신고)자
    tdata1_2: '', //학원(교습소)명
    tdata1_input1: '', //주소
    tdata1_input2: '', //전화번호(휴대폰)
    tdata1_input3: '', //이메일
  },
]);
const data1Columns = ref([
  {
    name: 'tdata1_1',
    label: '설립(신고)자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1_1,
  },
  {
    name: 'tdata1_2',
    label: '학원(교습소)명',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1_2,
  },
  {
    name: 'tdata1_input1',
    label: '위치',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1_input1,
  },
  {
    name: 'tdata1_input2',
    label: '전화번호(휴대폰)',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1_input2,
  },
  {
    name: 'tdata1_input3',
    label: '이메일',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1_input3,
  },
]);

const inpData1_1 = ref(); //학원명칭 - 점검실태
const inpData1_2 = ref(); //학원명칭 - 시정결과
const inpData2_1 = ref(); //설립자 - 점검실태
const inpData2_2 = ref(); //설립자 - 시정결과
const inpData3_1 = ref(); //위치 - 점검실태
const inpData3_2 = ref(); //위치 - 시정결과
const inpData4_1 = ref(); //게시 - 학원등록증 비치 - 점검실태
const inpData4_2 = ref(); //게시 - 학원등록증 비치 - 시정결과
const inpData4_3 = ref(); //게시 - 교습비 게시표 게시여부 - 점검실태
const inpData4_4 = ref(); //게시 - 교습비 게시표 게시여부 - 시정결과
const inpData4_5 = ref(); //게시 - 교습비 반환 규정 게시여부 - 점검실태
const inpData4_6 = ref(); //게시 - 교습비 반환 규정 게시여부 - 시정결과
const inpData4_7 = ref(); //게시 - 광고(홍보)실시 등 - 점검실태
const inpData4_8 = ref(); //게시 - 광고(홍보)실시 등 - 시정결과
const inpData4_9 = ref(); //게시 - 강사 인적사항 게시 - 점검실태
const inpData4_10 = ref(); //게시 - 강사 인적사항 게시 - 시정결과
const inpData5_1 = ref(); //교습과정 - 점검실태
const inpData5_2 = ref(); //교습과정 - 시정결과
const inpData6_1 = ref(); //교습비 - 교습비 변경 등록 여부 - 점검실태
const inpData6_2 = ref(); //교습비 - 시정결과
const inpData6_3 = ref(); //교습비 - 교습과목 - 점검실태
const inpData6_4 = ref(); //교습비 - 월교습시간
const inpData6_5 = ref(); //교습비 - 징수액
const inpData7_1 = ref(); //수강생 - 점검실태
const inpData7_2 = ref(); //수강생 - 시정결과
const inpData8_1 = ref(); //강사현황 - 강사등록
const inpData8_2 = ref(); //강사현황 - 강사미등록
const inpData8_3 = ref(); //강사현황 - 강사 시정결과
const inpData8_4 = ref(); //강사현황 - 성범죄경력조회서 검증
const inpData8_5 = ref(); //강사현황 - 경력조회서 미 검증
const inpData8_6 = ref(); //강사현황 - 경력조회 시정결과
const inpData8_7 = ref(); //강사현황 - 졸업(학력)증명서1
const inpData8_8 = ref(); //강사현황 - 졸업(학력)증명서2
const inpData8_9 = ref(); //강사현황 - 졸업(학력)증명서 시정결과
const inpData9_1 = ref(); //장부비치 - 학원운영원칙 - 점검실태
const inpData9_2 = ref(); //장부비치 - 학원운영원칙 - 시정결과
const inpData9_3 = ref(); //장부비치 - 현금출납부 - 점검실태
const inpData9_4 = ref(); //장부비치 - 현금출납부 - 시정결과
const inpData9_5 = ref(); //장부비치 - 수강생 대장 - 점검실태
const inpData9_6 = ref(); //장부비치 - 수강생 대장 - 시정결과
const inpData9_7 = ref(); //장부비치 - 출석부 - 점검실태
const inpData9_8 = ref(); //장부비치 - 출석부 - 시정결과
const inpData9_9 = ref(); //장부비치 - 교습비 영수증 원부 - 점검실태
const inpData9_10 = ref(); //장부비치 - 교습비 영수증 원부 - 시정결과
const inpData10_1 = ref(); //기타 - 학원책임배상보험 가입 - 점검실태
const inpData10_2 = ref(); //기타 - 학원책임배상보험 가입 - 시정결과
const inpData10_3 = ref(); //기타 - 일일 마지막 강의 종료 시간 - 점검실태
const inpData10_4 = ref(); //기타 - 일일 마지막 강의 종료 시간 - 시정결과
const examine = ref(); //종합검토
</script>
