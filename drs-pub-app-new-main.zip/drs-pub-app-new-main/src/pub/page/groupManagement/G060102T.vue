<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
                style="flex: 10000 1 0%"
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_contents_box">
        <!-- 상단정보 -->
        <div class="con_tab_head">
          <div class="con_tab_head-top">
            <p class="title1">2023년 11월</p>
          </div>
          <div class="con_tab_head-bottom">
            <div class="title4 text-grey-4 dept_info">
              <span>서울서북본부</span>
              <span>강서교육국</span>
              <span>001팀</span>
              <span class="title3 text-grey-1">YC1[바다꿈] 운영현황</span>
              <!-- 서울서북본부 > 강서교육국 > 001팀 > YC1[바다꿈] 운영현황 -->
            </div>
            <div class="body2 text-grey-3 manager_info" 담당자>
              <span>팀장 <strong class="text-black">홍길동</strong></span>
              <span>SC교사 <strong class="text-black">김대교</strong></span>
              <span class="text-orange">직영</span>
            </div>
          </div>
        </div>
        <!-- //상단정보 -->

        <!-- 콘텐츠박스 내 탭 픽스타입 -->
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            inline-label
            class="tab_line type02"
            active-bg-color="white"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" label="영업현황" :ripple="false" />
            <q-tab name="tab2" label="회원매출/입금" :ripple="false" />
            <q-tab name="tab3" label="관리지표" :ripple="false" />
            <q-tab name="tab4" label="서비스지표" :ripple="false" />
            <q-tab name="tab5" label="출결율" :ripple="false" />
            <q-tab name="tab6" label="과목/학습방법 현황" :ripple="false" />
          </q-tabs>
          <q-tab-panels v-model="tab" animated>
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1">상하단라인 좌측여백 fix 내용1</q-tab-panel>
            <!--// tab1 컨텐츠 -->

            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2">
              <div class="wrap_roundbox">
                <dl>
                  <dt class="title4">
                    회원매출액
                    <q-fab
                      direction="down"
                      hide-icon
                      class="tooltip_down type_question"
                      flat
                    >
                      <q-fab-action
                        square
                        label=""
                        label-position="left"
                        color="primary"
                        style="width: 200px"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">물음표 타입</p>
                      </q-fab-action>
                    </q-fab>
                  </dt>
                  <dd class="title1">125,343</dd>
                </dl>

                <dl>
                  <dt class="title4">회원당매출액</dt>
                  <dd class="title1">25,343</dd>
                </dl>

                <dl>
                  <dt class="title4">회원매출액</dt>
                  <dd class="title1">125,343</dd>
                </dl>

                <dl>
                  <dt class="title4">
                    입금률(%)
                    <q-fab
                      direction="down"
                      hide-icon
                      class="tooltip_down type_question"
                      flat
                    >
                      <q-fab-action
                        square
                        :ripple="false"
                        label=""
                        label-position="left"
                        color="primary"
                        style="width: 200px"
                      >
                        <span class="btn_close"></span>
                        <p class="txt text-body2">물음표 타입</p>
                      </q-fab-action>
                    </q-fab>
                  </dt>
                  <dd class="title1 text-orange">38.00%</dd>
                </dl>
              </div>

              <div class="wrap_highcharts">
                <vue-highcharts :options="chart_line"></vue-highcharts>
              </div>
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->

            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3">상하단라인 좌측여백 fix 내용3</q-tab-panel>
            <!--// tab3 컨텐츠 -->

            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4">상하단라인 좌측여백 fix 내용4</q-tab-panel>
            <!--// tab4 컨텐츠 -->

            <!-- tab5 컨텐츠 -->
            <q-tab-panel name="tab5">상하단라인 좌측여백 fix 내용5</q-tab-panel>
            <!--// tab5 컨텐츠 -->

            <!-- tab6 컨텐츠 -->
            <q-tab-panel name="tab6">상하단라인 좌측여백 fix 내용6</q-tab-panel>
            <!--// tab6 컨텐츠 -->
          </q-tab-panels>
        </div>
        <!-- //콘텐츠박스 내 탭 픽스타입 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import accessibility from 'highcharts/modules/accessibility';
import Highcharts from 'highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

HighchartsMore(Highcharts);
accessibility(Highcharts);

const searchDate = ref({
  from: '2023.05.03',
});

// 탭
const tab = ref('tab2');

// 차트
const chart_line = {
  colors: ['#85BDFF', '#9747FF', '#44B87B', '#FF6B23'],
  chart: {
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,

  yAxis: {
    title: false,
    labels: {
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'Pretendard',
      },
    },
  },

  xAxis: {
    lineColor: '#000',
    lineWidth: 2,
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'Pretendard',
      },
    },
  },

  plotOptions: {
    line: {
      marker: false,
    },
    series: {
      label: {
        connectorAllowed: false,
      },
      // pointStart: 2010,
    },
  },

  series: [
    {
      name: '회원매출액',
      data: [74000, 80000, 100000, 125000, 150000, 160000],
    },
    {
      name: '회원당매출액',
      data: [50000, 60000, 70000, 67000, 24000, 50000],
    },
    {
      name: '입금총액',
      data: [54000, 74000, 78000, 69000, 80000, 82000],
    },
    {
      name: '입금률(%)',
      data: [82000, 72000, 62000, 54000, 12000, 72000],
    },
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 28,
    itemStyle: {
      color: '#000',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
};
</script>
