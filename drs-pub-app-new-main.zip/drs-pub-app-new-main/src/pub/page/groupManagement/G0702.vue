<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">마감 외 진도 수정</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
                <span class="text-body2 text-grey-3">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              총 <span>00</span>건의 검색결과가 있습니다
            </div>
            <div class="btn_wrap col-12 col-md-8 gap10">
              <q-btn outline class="size_sm" label="신규작성" />
            </div>
          </div>
          <q-table
            class="multi_head"
            :rows="dataRows"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="2">No</th>
                <th rowspan="2">교재수급일</th>
                <th rowspan="2">사업팀</th>
                <th rowspan="2">선생님명</th>
                <th colspan="2">월</th>
                <th colspan="2">화</th>
                <th colspan="2">수</th>
                <th colspan="2">목</th>
                <th colspan="2">금</th>
              </tr>
              <tr>
                <th class="row_first">출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <q-td key="tdata1" class="text-center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="text-center">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="text-center">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="text-center">
                  {{ props.row.tdata13 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="mt20 mb10 title3 text-pink-5">
            아래는 데이터가 없을 경우 예시입니다. 개발하실 때에 이 div는
            삭제하세요.
          </div>
          <q-table
            class="multi_head"
            row-key="idx"
            separator="cell"
            :data="dataData"
            no-data-label="데이터가 없습니다."
          >
            <template v-slot:header>
              <tr>
                <th rowspan="2">No</th>
                <th rowspan="2">교재수급일</th>
                <th rowspan="2">사업팀</th>
                <th rowspan="2">선생님명</th>
                <th colspan="2">월</th>
                <th colspan="2">화</th>
                <th colspan="2">수</th>
                <th colspan="2">목</th>
                <th colspan="2">금</th>
              </tr>
              <tr>
                <th class="row_first">출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
                <th>출장일</th>
                <th>주분</th>
              </tr>
            </template>
          </q-table>
        </div>
        <!-- // general_table -->
        <div class="info_list_box mt20">
          <ul class="ul_custom disc">
            <li>기존 수정사항을 수정하시려면 먼저를 조회를 하십시오.</li>
            <li>
              신규는 신규작성 버튼을 클릭하여 새롭게 작성하여 변경하여 주십시오.
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

//data테이블
const dataData = ref([]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const dataRows = ref([
  {
    idx: 11,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 10,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '신김정숙[003101144761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 9,
    tdata1: '2022.04.03',
    tdata2: '01',
    tdata3: '정숙[0031111044761]',
    tdata4: '01.16',
    tdata5: '12',
    tdata6: '01.16',
    tdata7: '22',
    tdata8: '01.16',
    tdata9: '32',
    tdata10: '01.16',
    tdata11: '42',
    tdata12: '01.16',
    tdata13: '52',
  },
  {
    idx: 8,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 7,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 6,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 5,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 4,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 3,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 2,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
  {
    idx: 1,
    tdata1: '2022.04.03',
    tdata2: '001',
    tdata3: '김정숙[0031044761]',
    tdata4: '01.16',
    tdata5: '2',
    tdata6: '01.16',
    tdata7: '2',
    tdata8: '01.16',
    tdata9: '2',
    tdata10: '01.16',
    tdata11: '2',
    tdata12: '01.16',
    tdata13: '2',
  },
]);
</script>
