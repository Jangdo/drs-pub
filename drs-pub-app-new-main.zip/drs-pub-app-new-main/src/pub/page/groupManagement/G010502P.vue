<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 small">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">고객의견</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="table_dk">
            <q-table
              :rows="opinionRows"
              :columns="opinionColumns"
              v-model:pagination="opinionPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td key="grade" class="wide_cell align_center">{{
                    props.row.grade
                  }}</q-td>
                  <q-td key="opinion" class="white_space_normal">
                    <div class="q-py-xs">
                      {{ props.row.opinion }}
                    </div>
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const opinionColumns = ref([
  {
    name: 'grade ',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.grade,
  },
  {
    name: 'opinion',
    label: '의견',
    sortable: false,
    align: 'center',
    field: (row) => row.opinion,
  },
]);
const opinionRows = ref([
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초1',
    opinion:
      '선생님께서 지난 학습 점검과 금주 학습 내용을 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초2',
    opinion:
      '선생님께서 지난 학습 점검과 금주 학습 내용을 잘 지도해주셨습니다. 선생님께서 지난 학습 점검과 금주 학습 내용을 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초3',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초4',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초5',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초6',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초1',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초2',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
  {
    state: true,
    flat: false,
    align: 'center',
    grade: '초3',
    opinion: '선생님께서 잘 지도해주셨습니다.',
  },
]);
const opinionPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});

const popForm = ref(true);
</script>
