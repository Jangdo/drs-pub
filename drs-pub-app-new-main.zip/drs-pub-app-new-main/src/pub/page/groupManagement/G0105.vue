<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">고객만족도</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM"
                          years-in-month-view
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                          :emit-immediately="true"
                          default-view="Months"
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM"
                          years-in-month-view
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                          :emit-immediately="true"
                          default-view="Months"
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="브랜드 전체"
                v-model="sysSelect"
                :options="sysSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword2"
                placeholder="채널구분"
              >
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <q-table
            class="multi_head"
            :rows="dataRows"
            row-key="data1"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="2" class="">시행년월</th>
                <th rowspan="2" class="">본부</th>
                <th rowspan="2" class="">조직</th>
                <th rowspan="2" class="">팀</th>
                <th rowspan="2" class="">채널</th>
                <th rowspan="2" class="">이름</th>
                <th rowspan="2" class="">설문 참여자수</th>
                <th colspan="5" class="">
                  문항별 평점
                  <!-- tooltip -->
                  <q-fab
                    direction="right"
                    hide-icon
                    class="tooltip_custom term"
                    flat
                  >
                    <q-fab-action
                      square
                      label=""
                      label-position="left"
                      color="primary"
                      style="width: 200px"
                    >
                      <span class="btn_close"></span>
                      <div class="txt text-body2">
                        <p>툴팁내용작성</p>
                      </div>
                    </q-fab-action>
                  </q-fab>
                  <!--// tooltip -->
                </th>
                <th rowspan="2" class="">최종 평점</th>
                <th rowspan="2" class="">추천도</th>
                <th rowspan="2" class="">고객의견</th>
              </tr>
              <tr>
                <th class="border_left_1">Q1</th>
                <th class="">Q2</th>
                <th class="">Q3</th>
                <th class="">Q4</th>
                <th class="">Q5</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="text-center">{{
                  props.row.tdata1
                }}</q-td>
                <q-td key="tdata2" class="text-center">{{
                  props.row.tdata2
                }}</q-td>
                <q-td key="tdata3" class="text-center">{{
                  props.row.tdata3
                }}</q-td>
                <q-td key="tdata4" class="text-center">{{
                  props.row.tdata4
                }}</q-td>
                <q-td key="tdata5" class="text-center">{{
                  props.row.tdata5
                }}</q-td>
                <q-td key="tdata6" class="text-center">{{
                  props.row.tdata6
                }}</q-td>
                <q-td key="tdata7" class="text-center">{{
                  props.row.tdata7
                }}</q-td>
                <q-td key="tdata8" class="text-center">{{
                  props.row.tdata8
                }}</q-td>
                <q-td key="tdata9" class="text-center">{{
                  props.row.tdata9
                }}</q-td>
                <q-td key="tdata10" class="text-center">{{
                  props.row.tdata10
                }}</q-td>
                <q-td key="tdata11" class="text-center">{{
                  props.row.tdata11
                }}</q-td>
                <q-td key="tdata12" class="text-center">{{
                  props.row.tdata12
                }}</q-td>
                <q-td key="tdata13" class="text-center">{{
                  props.row.tdata13
                }}</q-td>
                <q-td key="tdata14" class="text-center">{{
                  props.row.tdata14
                }}</q-td>
                <q-td key="opinionBtn" class="text-center">
                  <q-btn
                    outline
                    class="size_xxs btn_detail_view"
                    label="확인"
                  />
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- 모바일에선 페이지 max 조정이 필요합니다. -->
        </div>
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2019.02',
  to: '2019.02',
});
const sysSelect = ref(['브랜드 전체']);
const sysSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
//data테이블
const dataRows = ref([
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울강북본부',
    tdata3: '구로교육국',
    tdata4: '999',
    tdata5: '러닝15센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '5',
    tdata10: '5',
    tdata11: '5',
    tdata12: '5',
    tdata13: '25',
    tdata14: '100',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울강남본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서남본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
  {
    tdata1: '2023.02',
    tdata2: '서울서북본부',
    tdata3: '영등포교육국',
    tdata4: '001',
    tdata5: '러닝1센터',
    tdata6: '홍길동 (003204425)',
    tdata7: '10',
    tdata8: '5',
    tdata9: '4',
    tdata10: '3',
    tdata11: '2',
    tdata12: '1',
    tdata13: '15',
    tdata14: '70',
    opinionBtn: '',
    allow: false,
    align: 'center',
  },
]);

//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
