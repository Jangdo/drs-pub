<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->
        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="wrapper_tab">
                <q-tabs
                  v-model="tabintab"
                  inline-label
                  class="tab_line"
                  active-bg-color="white"
                  active-color="primary"
                  indicator-color="primary"
                  align="justify"
                  narrow-indicator
                  outside-arrows
                >
                  <q-tab name="tab41" label="원칙" :ripple="false" />
                  <q-tab name="tab42" label="직원명부" :ripple="false" />
                  <q-tab name="tab43" label="지도점검기록부" :ripple="false" />
                  <q-tab name="tab44" label="학원강사 게시표" :ripple="false" />
                  <q-tab name="tab45" label="교습비 게시표" :ripple="false" />
                  <q-tab
                    name="tab46"
                    label="교습비 반환 규정"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab47"
                    label="문서접수 및 발송대장"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab48"
                    label="교습비 게시표(옥외)"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab49"
                    label="학원 안전점검 체크리스트"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab410"
                    label="자체 실태 점검표 "
                    :ripple="false"
                  />
                </q-tabs>
                <q-tab-panels v-model="tabintab" animated>
                  <!-- tab41 컨텐츠 -->
                  <q-tab-panel name="tab41">41</q-tab-panel>
                  <!--// tab41 컨텐츠 -->
                  <!-- tab42 컨텐츠 -->
                  <q-tab-panel name="tab42">42</q-tab-panel>
                  <!--// tab42 컨텐츠 -->
                  <!-- tab43 컨텐츠 -->
                  <q-tab-panel name="tab43">43</q-tab-panel>
                  <!--// tab43 컨텐츠 -->
                  <!-- tab44 컨텐츠 -->
                  <q-tab-panel name="tab44">44</q-tab-panel>
                  <!--// tab44 컨텐츠 -->

                  <!-- tab45 컨텐츠 -->
                  <q-tab-panel name="tab45">
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">
                            보존기간 : <span>변경시까지</span>
                          </li>
                          <li class="mk_disc">비치 서류</li>
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.03.04</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>

                    <div class="document_rule">
                      <div class="outline_box">
                        <!-- 타이틀 -->
                        <div class="title1">교습비 게시표</div>
                        <!-- // 타이틀 -->

                        <div class="group">
                          <div class="body1">
                            <div class="row-5">
                              <div class="row-4">
                                <span>학원(교습소)명</span>
                                <q-input
                                  class="inp_basic"
                                  outlined
                                  v-model="input1"
                                  placeholder="입력하세요"
                                />
                              </div>
                              <div class="row-6">
                                <q-btn
                                  class="size_sm btn_basic"
                                  outline
                                  label="행추가"
                                />
                                <q-btn
                                  class="size_sm btn_basic"
                                  outline
                                  label="수정"
                                />
                                <q-btn
                                  class="size_sm btn_basic"
                                  outline
                                  label="삭제"
                                />
                                <q-btn
                                  fill
                                  unelevated
                                  color="black"
                                  class="size_sm"
                                  label="등록"
                                />
                              </div>
                            </div>
                          </div>
                          <div class="content">
                            <!-- markup-table multi_head -->
                            <q-markup-table
                              separator="cell"
                              class="combine_table mt20 scrollable tbl_row_8"
                            >
                              <thead>
                                <tr>
                                  <th rowspan="2">선택</th>
                                  <th rowspan="2">NO.</th>
                                  <th rowspan="2">
                                    교습과목
                                    <!-- tooltip_up -->
                                    <q-fab
                                      direction="up"
                                      hide-icon
                                      class="tooltip_custom term"
                                      flat
                                    >
                                      <q-fab-action
                                        square
                                        label=""
                                        label-position="left"
                                        color="primary"
                                        style="width: 380px"
                                      >
                                        <span class="btn_close"></span>
                                        <div class="txt text-body2">
                                          <p>
                                            교육청에 신고한 과목명과 동일하게
                                            작성해야 합니다.
                                          </p>
                                        </div>
                                      </q-fab-action>
                                    </q-fab>
                                    <!--// tooltip_up -->
                                  </th>
                                  <th rowspan="2">교습비</th>
                                  <th rowspan="2">징수단위(월/분기)</th>
                                  <th colspan="6">
                                    교습비(교습료) 명세
                                    <!-- tooltip_up -->
                                    <q-fab
                                      direction="up"
                                      hide-icon
                                      class="tooltip_custom term"
                                      flat
                                    >
                                      <q-fab-action
                                        square
                                        label=""
                                        label-position="left"
                                        color="primary"
                                        style="width: 380px"
                                      >
                                        <span class="btn_close"></span>
                                        <div class="txt text-body2">
                                          <p>
                                            눈높이러닝센터는 "해당사항 없음"으로
                                            기재하면 됨
                                          </p>
                                        </div>
                                      </q-fab-action>
                                    </q-fab>
                                    <!--// tooltip_up -->
                                  </th>
                                </tr>
                                <tr>
                                  <th class="row_first">모의고사비</th>
                                  <th>재료</th>
                                  <th>피복비</th>
                                  <th>급식</th>
                                  <th>기숙사</th>
                                  <th>차량비</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check1"
                                      color="black"
                                    />
                                  </td>
                                  <td>1</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp2"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp3"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp4"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp5"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp6"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp7"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp8"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp9"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check2"
                                      color="black"
                                    />
                                  </td>
                                  <td>2</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp21"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp22"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp23"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp24"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp25"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp26"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp27"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp28"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp29"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check2"
                                      color="black"
                                    />
                                  </td>
                                  <td>10</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp31"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp32"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp33"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp34"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp35"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp36"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp37"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp38"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp39"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check1"
                                      color="black"
                                    />
                                  </td>
                                  <td>1</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp2"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp3"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp4"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp5"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp6"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp7"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp8"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp9"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check2"
                                      color="black"
                                    />
                                  </td>
                                  <td>2</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp21"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp22"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp23"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp24"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp25"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp26"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp27"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp28"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp29"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                                <tr>
                                  <td>
                                    <q-checkbox
                                      v-model="dataCheck.check2"
                                      color="black"
                                    />
                                  </td>
                                  <td>10</td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp31"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp32"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp33"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp34"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp35"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp36"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp37"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp38"
                                      placeholder=""
                                    />
                                  </td>
                                  <td>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp39"
                                      placeholder=""
                                      input-class="text-right"
                                    />
                                  </td>
                                </tr>
                              </tbody>
                            </q-markup-table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </q-tab-panel>
                  <!--// tab45 컨텐츠 -->

                  <!-- tab46 컨텐츠 -->
                  <q-tab-panel name="tab46">46</q-tab-panel>
                  <!--// tab46 컨텐츠 -->
                  <!-- tab47 컨텐츠 -->
                  <q-tab-panel name="tab47">47</q-tab-panel>
                  <!--// tab47 컨텐츠 -->
                  <!-- tab48 컨텐츠 -->
                  <q-tab-panel name="tab48">48</q-tab-panel>
                  <!--// tab48 컨텐츠 -->
                  <!-- tab49 컨텐츠 -->
                  <q-tab-panel name="tab49">49</q-tab-panel>
                  <!--// tab49 컨텐츠 -->
                  <!-- tab410 컨텐츠 -->
                  <q-tab-panel name="tab410">410</q-tab-panel>
                  <!--// tab410 컨텐츠 -->
                </q-tab-panels>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab4');
const tabintab = ref('tab45');

const dataCheck = ref({
  check1: true,
  check2: false,
  check3: false,
  check4: false,
  check6: false,
  check2: false,
});
// 인풋창
const inp1 = ref('');
const inp2 = ref('');
const inp3 = ref('');
const inp4 = ref('');
const inp5 = ref('');
const inp6 = ref('');
const inp7 = ref('');
const inp8 = ref('');
const inp9 = ref('');
const inp21 = ref('');
const inp22 = ref('');
const inp23 = ref('');
const inp24 = ref('');
const inp25 = ref('');
const inp26 = ref('');
const inp27 = ref('');
const inp28 = ref('');
const inp29 = ref('');
const inp31 = ref('');
const inp32 = ref('');
const inp33 = ref('');
const inp34 = ref('');
const inp35 = ref('');
const inp36 = ref('');
const inp37 = ref('');
const inp38 = ref('');
const inp39 = ref('');

// const input1 = ref("");

//테이블
// const data1Columns = ref([
//   {
//     name: 'tdata1_1',
//     label: '설립(신고)자',
//     sortable: false,
//     align: 'center',
//     field: (row) =>row.tdata1_1,
//   },
// ]);
</script>
<style scoped>
.tooltip_custom.term .q-fab__actions > .q-btn {
  top: 101px;
  left: 170px;
}
</style>
