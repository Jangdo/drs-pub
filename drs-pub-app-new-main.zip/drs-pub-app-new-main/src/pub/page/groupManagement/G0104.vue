<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label box_l"
                label="변경항목 전체"
                v-model="codeSelect1"
                :options="codeSelect1Option"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label box_l"
                label="브랜드 전체"
                v-model="codeSelect2"
                :options="codeSelect2Option"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label box_l"
                label="조직코드"
                v-model="codeSelect"
                :options="codeSelectOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword2"
                placeholder="입력"
              >
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- <div class="btn_area type_g1 mt16">
        
        <div
          class="wrap_info_box bg-white p0"
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
        >
          <div class="tit_area">
            <q-icon name="icon-info02" class="icon_svg"></q-icon>
            <span>조회조건</span>
          </div>
          <div class="content">
            <p>눈높이서비스부문 > 서울서북본부 > 영등포교육국</p>
          </div>
        </div>
      </div> -->

        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-8">
              총 <span>00</span>건의 검색결과가 있습니다
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="icon-info02" class="icon_svg"></q-icon>
                  <span>조회조건</span>
                </div>
                <div class="content">
                  <p>눈높이서비스부문 > 서울서북본부 > 영등포교육국</p>
                </div>
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-4 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
              <q-btn unelevated color="black" class="size_sm" label="이전" />
            </div>
          </div>
          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
          </q-table>
          <!-- pagination -->
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- // pagination -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword2 = ref('');
const codeSelect1 = ref('변경항목 전체');
const codeSelect1Option = ref([
  {
    id: 'c1',
    desc: '조직코드1',
  },
  {
    id: 'c2',
    desc: '조직코드2',
  },
]);
const codeSelect2 = ref('브랜드 전체');
const codeSelect2Option = ref([
  {
    id: 'c1',
    desc: '브랜드1',
  },
  {
    id: 'c2',
    desc: '브랜드2',
  },
]);
const codeSelect = ref('');
const codeSelectOption = ref([
  {
    id: 'c1',
    desc: '조직코드1',
  },
  {
    id: 'c2',
    desc: '조직코드2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '변경일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '변경항목',
    sortable: false,
    align: 'center',
    classes: 'text-grey-1',
    field: (row) => row.tdata2,
  },
  // {
  //   name: 'tdata3',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata3,
  // },
  {
    name: 'tdata4',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '조직코드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '변경전 내용',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '변경후 내용',
    sortable: false,
    align: 'center',
    classes: 'text-orange',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '변경자 (사번)',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 9,
    tdata1: '2023.01.25',
    tdata2: '시작일',
    // tdata3: '눈높이서비스1 부문',
    tdata4: '서울서북본부',
    tdata5: '영등포10 교육국',
    tdata6: 'PC0010',
    tdata7: '2023.01.25',
    tdata8: '2023.01.20',
    tdata9: '대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 8,
    tdata1: '2023.01.25',
    tdata2: '명칭',
    // tdata3: '눈높이 부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC0',
    tdata7: '양천A 교육국',
    tdata8: '양천1 교육국',
    tdata9: '이대교 (320411425)',
    state: true,
    flat: false,
  },
  {
    idx: 7,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 6,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 5,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 4,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 3,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 2,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
  {
    idx: 1,
    tdata1: '2023.01.25',
    tdata2: '전화',
    // tdata3: '눈높이서비스부문',
    tdata4: '서울서북본부',
    tdata5: '영등포 교육국',
    tdata6: 'PC010',
    tdata7: '02-329-2010',
    tdata8: '02-329-2011',
    tdata9: '이대교 (3204425)',
    state: true,
    flat: false,
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
