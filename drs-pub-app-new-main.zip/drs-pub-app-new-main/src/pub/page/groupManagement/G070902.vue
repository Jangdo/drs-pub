<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">현금영수증관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="증빙번호 등록" :ripple="false" />
          <q-tab name="tab2" label="현금영수증조회/취소요청" :ripple="false" />
          <q-tab name="tab3" label="체납공제현금영수증승인" :ripple="false" />
          <q-tab name="tab4" label="증빙번호 수정이력" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="tab1">증빙번호 등록</q-tab-panel>
          <q-tab-panel name="tab2">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      for="id2"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            transition-show="scale"
                            transition-hide="scale"
                            self="top middle"
                          >
                            <q-date
                              minimal
                              mask="YYYY"
                              years-in-month-view
                              :emit-immediately="true"
                              default-view="Years"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>조직</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="row q-col-gutter-sm" v-if="stateHandle">
                  <div class="col-12 col-md-3">
                    <q-input
                      class="box_l"
                      outlined
                      dense
                      placeholder="증빙번호"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-input class="box_l" outlined placeholder="회원">
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <h3 class="title1 mb24">현금영수증 내역</h3>
              <!-- general_table -->
              <div class="table_dk">
                <q-table
                  class="scrollable sticky_table_header"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  :rows-per-page-options="[0]"
                  hide-pagination
                  style="max-height: 436px"
                  separator="cell"
                >
                </q-table>
              </div>
              <!-- // general_table -->

              <h3 class="title1 mb24 mt50">상세내역</h3>
              <!-- general_table -->
              <div class="general_table">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    <div class="search_item w100">
                      <q-select
                        class="hide_label w100"
                        label="2022"
                        v-model="yearType"
                        :options="yearTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                        <!-- <template v-slot:before
                        ><span class="text-body2 text-grey-1"
                          >년도</span
                        ></template
                      > -->
                      </q-select>
                    </div>
                  </div>
                  <div class="btn_wrap col-12 col-md-8 gap10">
                    <q-checkbox
                      v-model="dataCheck"
                      label="일괄입력"
                      color="black"
                    />
                    <div class="row-6">
                      <span class="text-body2 text-grey-1">선택한 건의</span>
                      <div class="search_item w200">
                        <q-select
                          class="hide_label"
                          label="사유를 선택하세요"
                          v-model="reason2"
                          :options="reason2Option"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                          readonly
                        >
                        </q-select>
                      </div>
                      <span class="text-body2 text-grey-1"
                        >일괄입력 합니다.</span
                      >
                    </div>
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>

                <q-table
                  :rows="detailRows"
                  :columns="detailColumns"
                  row-key="idx"
                  v-model:pagination="detailPagination"
                  v-model:selected="detailSelected"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                  selection="multiple"
                  color="black"
                >
                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th
                        ><q-checkbox v-model="props.selected" color="black"
                      /></q-th>
                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td class="select">
                        <q-checkbox v-model="props.selected" color="black" />
                      </q-td>
                      <q-td key="tdata1" class="text-center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="text-right">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata3" class="text-center">
                        {{ props.row.tdata3 }}
                      </q-td>
                      <q-td key="tdata4" class="text-center">
                        {{ props.row.tdata4 }}
                      </q-td>
                      <q-td key="tdata5" class="text-center">
                        {{ props.row.tdata5 }}
                      </q-td>
                      <q-td key="tdata6" class="text-center">
                        {{ props.row.tdata6 }}
                      </q-td>
                      <q-td key="tdata7" class="text-center">
                        {{ props.row.tdata7 }}
                      </q-td>
                      <q-td key="tdata8" class="text-right">
                        {{ props.row.tdata8 }}
                      </q-td>
                      <q-td key="tdata9" class="text-center">
                        {{ props.row.tdata9 }}
                      </q-td>
                      <q-td key="tdata10" class="text-center">
                        {{ props.row.tdata10 }}
                      </q-td>
                      <q-td key="tdata11" class="text-center">
                        {{ props.row.tdata11 }}
                      </q-td>
                      <q-td key="tdata12" class="text-center">
                        {{ props.row.tdata12 }}
                      </q-td>
                      <q-td key="tdata13" class="text-center">
                        {{ props.row.tdata13 }}
                        <template v-if="props.row.tdata13 == ''">
                          <q-select
                            class="hide_label w180"
                            label="사유를 선택하세요"
                            v-model="reason"
                            :options="reasonOption"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </template>
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
                <!-- pagination -->
                <div class="pagination_container">
                  <q-pagination
                    v-model="dataPagination.current"
                    v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                    input
                    class="justify-center"
                  />
                  <q-pagination
                    v-model="dataPagination.current"
                    v-if="$q.screen.name == 'lg'"
                    :max="10"
                    :max-pages="8"
                    direction-links
                    boundary-links
                    rounded
                    icon-first="keyboard_double_arrow_left"
                    icon-last="keyboard_double_arrow_right"
                    class="justify-center type_01"
                  />
                </div>
                <!-- // pagination -->
              </div>
              <!-- // general_table -->

              <div class="btn_area btn_bottom_type01">
                <q-btn
                  unelevated
                  color="black"
                  class="size_lg"
                  label="승인요청"
                />
              </div>
            </div>
          </q-tab-panel>
          <q-tab-panel name="tab3">체납공제현금영수증승인</q-tab-panel>
          <q-tab-panel name="tab4">증빙번호 수정이력</q-tab-panel>
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const tab = ref('tab2');
const searchDate = ref({
  from: '2019',
});
const yearType = ref(['']);
const yearTypeOption = ref([
  {
    id: 'ss11',
    desc: '2023',
  },
  {
    id: 'ss12',
    desc: '2024',
  },
]);
const dataCheck = ref(false);
const reason = ref(['']);
const reasonOption = ref([
  {
    id: 'r11',
    desc: '사유1',
  },
  {
    id: 'r12',
    desc: '사유2',
  },
]);
const reason2 = ref(['']);
const reason2Option = ref([
  {
    id: 'r21',
    desc: '사유1',
  },
  {
    id: 'r22',
    desc: '사유2',
  },
]);
//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '증빙번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '성별',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '전화번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 10,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 10,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 10,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 9,
    tdata1: '21111124322',
    tdata2: '홍홍길동',
    tdata3: '눈높이수학 써밋스코어1-1',
    tdata4: '월요일',
    tdata5: '1234567890111',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 8,
    tdata1: '1121322',
    tdata2: '길동',
    tdata3: '눈높이수학',
    tdata4: '월요일',
    tdata5: '01234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 7,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 6,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 5,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 4,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 3,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 2,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
  {
    idx: 1,
    tdata1: '213124322',
    tdata2: '홍길동',
    tdata3: '눈높이수학 써밋스코어1',
    tdata4: '월요일',
    tdata5: '1234567890',
    tdata6: '초등1',
    tdata7: '남',
    tdata8: '010-5555-5555',
  },
]);

const detailSelected = ref([]);
const detailPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const detailColumns = ref([
  {
    name: 'tdata1',
    label: '마감일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '입금금액',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '브랜드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata4',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata5',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata6',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata7',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata8',
    label: '요청금액',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata9',
    label: '증빙번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata10',
    label: '승인일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '승인번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '승인결과',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '제승인사유',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
]);
const detailRows = ref([
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '',
  },
  {
    idx: 9,
    tdata1: '2023.01.01',
    tdata2: '10,000',
    tdata3: '높이',
    tdata4: '써밋스코어수학',
    tdata5: 'LC',
    tdata6: '월',
    tdata7: '1',
    tdata8: '110,000',
    tdata9: '1111',
    tdata10: '2023.01.01',
    tdata11: '111',
    tdata12: '-',
    tdata13: '사유',
  },
  {
    idx: 8,
    tdata1: '2023.01.01',
    tdata2: '1,111,000,000',
    tdata3: '눈높이눈높이',
    tdata4: '써밋스코어수학 중등1-5',
    tdata5: 'YC',
    tdata6: '월',
    tdata7: '110',
    tdata8: '11,000,000',
    tdata9: '21312431122',
    tdata10: '2023.01.01',
    tdata11: '213124321112',
    tdata12: '승인완료',
    tdata13: '재승인사유',
  },
  {
    idx: 7,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '재승인사유',
  },
  {
    idx: 6,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '',
  },
  {
    idx: 5,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '재승인사유',
  },
  {
    idx: 4,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '',
  },
  {
    idx: 3,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '재승인사유',
  },
  {
    idx: 2,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '',
  },
  {
    idx: 1,
    tdata1: '2023.01.01',
    tdata2: '1,000,000',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등1',
    tdata5: 'HC',
    tdata6: '월',
    tdata7: '10',
    tdata8: '1,000,000',
    tdata9: '213124322',
    tdata10: '2023.01.01',
    tdata11: '213124322',
    tdata12: '승인완료',
    tdata13: '재승인사유',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
