<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 huge">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">매출목표 변경이력</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row-2 mb24">
            <h4 class="title1 text-grey-1">2023년 순증지수 변경이력</h4>
            <div class="row-6 body2 text-grey-3">
              <span>김대교</span>
              <span>(<span>2023.01.02</span> <span>11:00:12</span>)</span>
            </div>
          </div>

          <!-- general_table multi_head 합계 -->
          <div class="table_dk">
            <q-table
              class="multi_head"
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header>
                <tr>
                  <th rowspan="2">본부</th>
                  <th colspan="16">연목표 실적</th>
                </tr>
                <tr>
                  <th class="row_first">1월</th>
                  <th>2월</th>
                  <th>3월</th>
                  <th>1Q</th>
                  <th>4월</th>
                  <th>5월</th>
                  <th>6월</th>
                  <th>2Q</th>
                  <th>7월</th>
                  <th>8월</th>
                  <th>9월</th>
                  <th>3Q</th>
                  <th>10월</th>
                  <th>11월</th>
                  <th>12월</th>
                  <th>4Q</th>
                </tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="section" class="text-center">
                    {{ props.row.section }}
                  </q-td>
                  <q-td key="tdata1" class="text-right">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="text-right">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="text-right">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="text-right">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="text-right">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="text-right">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td key="tdata7" class="text-right">
                    {{ props.row.tdata7 }}
                  </q-td>
                  <q-td key="tdata8" class="text-right">
                    {{ props.row.tdata8 }}
                  </q-td>
                  <q-td key="tdata9" class="text-right">
                    {{ props.row.tdata9 }}
                  </q-td>
                  <q-td key="tdata10" class="text-right">
                    {{ props.row.tdata10 }}
                  </q-td>
                  <q-td key="tdata11" class="text-right">
                    {{ props.row.tdata11 }}
                  </q-td>
                  <q-td key="tdata12" class="text-right">
                    {{ props.row.tdata12 }}
                  </q-td>
                  <q-td key="tdata13" class="text-right">
                    {{ props.row.tdata13 }}
                  </q-td>
                  <q-td key="tdata14" class="text-right">
                    {{ props.row.tdata14 }}
                  </q-td>
                  <q-td key="tdata15" class="text-right">
                    {{ props.row.tdata15 }}
                  </q-td>
                  <q-td key="tdata16" class="text-right">
                    {{ props.row.tdata16 }}
                  </q-td>
                </q-tr>
              </template>
              <template v-slot:bottom-row="props">
                <q-tr class="tr_btm" :props="props">
                  <q-td class="text-center">합계</q-td>
                  <q-td class="text-right">1,000.0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">100.0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">10.0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">1.0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">100.0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                  <q-td class="text-right">0</q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!--// general_table multi_head -->

          <h3 class="title1 mt60 mb24">수정내용</h3>
          <!-- q-markup-table -->
          <q-markup-table separator="cell" wrap-cells class="scrollable">
            <tbody>
              <tr>
                <td>서울 서북 교육국 매출 목표 수정</td>
              </tr>
            </tbody>
          </q-markup-table>
          <!-- // q-markup-table -->
        </q-card-section>
        <!--
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="primary"
            class="size_sm"
            label="확인"
          />
        </q-card-actions>
        -->
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const dataRows = ref([
  {
    idx: 12,
    section: '서울서북',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 11,
    section: '서울강북',
    tdata1: '111,000.0',
    tdata2: '100.0',
    tdata3: '10.0',
    tdata4: '111,111,000.0',
    tdata5: '11,000.0',
    tdata6: '100.0',
    tdata7: '11,000.0',
    tdata8: '111,000.0',
    tdata9: '0.0',
    tdata10: '100.0',
    tdata11: '11,000.0',
    tdata12: '111,000.0',
    tdata13: '111,111,000.0',
    tdata14: '1,111,000.0',
    tdata15: '11,111,000.0',
    tdata16: '10.0',
  },
  {
    idx: 10,
    section: '서울강동',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 9,
    section: '서울남동',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 8,
    section: '경기',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 7,
    section: '인천',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 6,
    section: '부산',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 5,
    section: '경남',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 4,
    section: '호남',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 3,
    section: '강원',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 2,
    section: '제주',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
  {
    idx: 1,
    section: '대전세종',
    tdata1: '1,000.0',
    tdata2: '1,000.0',
    tdata3: '1,000.0',
    tdata4: '1,000.0',
    tdata5: '1,000.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
  },
]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: false,
  page: 1,
  rowsPerPage: 999,
});
</script>
