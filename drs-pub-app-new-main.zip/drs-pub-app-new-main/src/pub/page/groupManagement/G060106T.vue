<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영현황</h2>
      <Breadcrumbs />
    </div>
    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_contents_box">
        <!-- 상단정보 -->
        <div class="con_tab_head">
          <div class="con_tab_head-top">
            <p class="title1">2023년 11월</p>
          </div>
          <div class="con_tab_head-bottom">
            <div class="title4 text-grey-4 dept_info">
              <span>서울서북본부</span>
              <span>강서교육국</span>
              <span>001팀</span>
              <span class="title3 text-grey-1">YC1[바다꿈] 운영현황</span>
              <!-- 서울서북본부 > 강서교육국 > 001팀 > YC1[바다꿈] 운영현황 -->
            </div>
            <div class="body2 text-grey-3 manager_info" 담당자>
              <span>팀장 <strong class="text-black">홍길동</strong></span>
              <span>SC교사 <strong class="text-black">김대교</strong></span>
              <span class="text-orange">직영</span>
            </div>
          </div>
        </div>
        <!-- //상단정보 -->

        <!-- 콘텐츠박스 내 탭 픽스타입 -->
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            inline-label
            class="tab_line type02"
            active-bg-color="white"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator
            outside-arrows
            keep-alive
          >
            <q-tab name="tab1" label="영업현황" :ripple="false" />
            <q-tab name="tab2" label="회원매출/입금" :ripple="false" />
            <q-tab name="tab3" label="관리지표" :ripple="false" />
            <q-tab name="tab4" label="서비스지표" :ripple="false" />
            <q-tab name="tab5" label="출결율" :ripple="false" />
            <q-tab name="tab6" label="과목/학습방법 현황" :ripple="false" />
          </q-tabs>
          <q-tab-panels v-model="tab">
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1">상하단라인 좌측여백 fix 내용1</q-tab-panel>
            <!--// tab1 컨텐츠 -->

            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2"> 하단라인 좌측여백 fix 내용2 </q-tab-panel>
            <!--// tab2 컨텐츠 -->

            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3"> 하단라인 좌측여백 fix 내용3 </q-tab-panel>
            <!--// tab3 컨텐츠 -->

            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4">상하단라인 좌측여백 fix 내용4</q-tab-panel>
            <!--// tab4 컨텐츠 -->

            <!-- tab5 컨텐츠 -->
            <q-tab-panel name="tab5">
              상하단라인 좌측여백 fix 내용6
            </q-tab-panel>
            <!--// tab5 컨텐츠 -->

            <!-- tab6 컨텐츠 -->
            <q-tab-panel name="tab6" class="no-scroll">
              <h3 class="title1 text-grey-1 mb20">과목현황</h3>
              <div class="wrap_flex_half_g30">
                <div class="wrap_highcharts" style="max-height: 466px">
                  <vue-highcharts :options="chart_pie"></vue-highcharts>
                </div>

                <div class="col_tbl">
                  <!-- 마크업테이블 헤더 푸터 있는 타입 -->
                  <q-markup-table
                    separator="horizontal"
                    class="subject_state scrollable sticky_table_header sticky_table_footer"
                    wrap-cells
                    style="max-height: 466px"
                  >
                    <thead>
                      <tr>
                        <th>구분</th>
                        <th>과목수</th>
                        <th>제품지수</th>
                        <th>평가점수</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center">국어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">영어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">수학</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">사회과학</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">내신완공</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">한자일본어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">국어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">영어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">수학</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">사회과학</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">내신완공</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">한자일본어</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr class="tr_btm bg-white border">
                        <td class="text-center">
                          <q-badge color="black " class="medium">총계</q-badge>
                        </td>
                        <td class="text-center">116</td>
                        <td class="text-center">4.8</td>
                        <td class="text-center">100</td>
                      </tr>
                    </tfoot>
                  </q-markup-table>
                </div>
              </div>

              <h3 class="title1 text-grey-1 mt60 mb20">학습방법 현황</h3>
              <div class="wrap_flex_half_g30">
                <div class="wrap_highcharts" style="max-height: 466px">
                  <vue-highcharts :options="chart_pie2"></vue-highcharts>
                </div>

                <div class="col_tbl">
                  <!-- 마크업테이블 헤더 푸터 있는 타입 -->
                  <q-markup-table
                    separator="horizontal"
                    class="subject_state scrollable sticky_table_header sticky_table_footer"
                    wrap-cells
                    style="max-height: 466px"
                  >
                    <thead>
                      <tr>
                        <th>구분</th>
                        <th>과목수</th>
                        <th>제품지수</th>
                        <th>전체 비중(%)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">디지털학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                      <tr>
                        <td class="text-center">페이퍼학습</td>
                        <td class="text-center">28</td>
                        <td class="text-center">0.8</td>
                        <td class="text-center">15</td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr class="tr_btm bg-white border">
                        <td class="text-center">
                          <q-badge color="black " class="medium">총계</q-badge>
                        </td>
                        <td class="text-center">116</td>
                        <td class="text-center">4.8</td>
                        <td class="text-center">100</td>
                      </tr>
                    </tfoot>
                  </q-markup-table>
                </div>
              </div>
            </q-tab-panel>
            <!--// tab6 컨텐츠 -->
          </q-tab-panels>
        </div>
        <!-- //콘텐츠박스 내 탭 픽스타입 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

import VueHighcharts from 'vue3-highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import accessibility from 'highcharts/modules/accessibility';
import Highcharts from 'highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

HighchartsMore(Highcharts);
accessibility(Highcharts);
// table_search_area
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');
// const searchExpand = ref(true);

const searchDate = ref({
  from: '2023.05.03',
});

// 탭
const tab = ref('tab6');

// 차트
const chart_pie = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
    type: 'pie',
    backgroundColor: '#F1F7FB',
  },
  colors: [
    '#85BDFF',
    '#9747FF',
    '#44B87B',
    '#EFD26A',
    '#0964CE',
    '#BD0000',
    '#00B2BD',
    '#BD00AA',
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontSize: '14',
      lineHight: '16',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  title: false,
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },
  accessibility: {
    point: {
      valueSuffix: '%',
    },
  },
  plotOptions: {
    series: {
      animation: false,
    },
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '{point.percentage:.2f}',
        style: {
          textOutline: false,
          color: '#fff',
          fontSize: 9,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
        distance: -20,
        filter: {
          property: 'percentage',
          operator: '>',
          value: 1,
        },
      },
      showInLegend: true,
    },
  },
  series: [
    {
      name: '과목',
      borderWidth: 0,

      data: [
        { name: '국어', y: 35.7 },
        { name: '영어', y: 38.0 },
        { name: '수학', y: 12.5 },
        { name: '사회과학', y: 7.1 },
        { name: '내신완공', y: 3.1 },
        { name: '한자일본어', y: 3.6 },
        { name: '유아', y: 3.6 },
        { name: '기타', y: 3.6 },
      ],
    },
  ],
};
const chart_pie2 = {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: 0,
    plotShadow: false,
    type: 'pie',
    backgroundColor: '#F1F7FB',
  },
  colors: ['#85BDFF', '#0964CE'],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontSize: '14',
      lineHight: '16',
      fontWeight: 400,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  title: false,
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
  },
  accessibility: {
    point: {
      valueSuffix: '%',
    },
  },
  plotOptions: {
    series: {
      animation: false,
    },
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '{point.percentage:.2f}',
        style: {
          textOutline: false,
          color: '#fff',
          fontSize: 9,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
        distance: '-50%',

        filter: {
          property: 'percentage',
          operator: '>',
          value: 1,
        },
      },
      showInLegend: true,
    },
  },
  series: [
    {
      name: '과목',
      borderWidth: 0,
      data: [
        { name: '디지털 학습', y: 51.9 },
        { name: '페이퍼 학습', y: 46.1 },
      ],
    },
  ],
};
</script>
