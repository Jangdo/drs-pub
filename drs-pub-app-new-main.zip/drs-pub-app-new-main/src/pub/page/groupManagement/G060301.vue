<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회원 현황 분석 상세</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="채널/학년별 회원현황" :ripple="false" />
          <q-tab name="tab2" label="과목/학년별 회원현황" :ripple="false" />
          <q-tab name="tab3" label="순수회원별 현황" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        for="id2"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              transition-show="scale"
                              transition-hide="scale"
                              self="top middle"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                :emit-immediately="true"
                                default-view="Months"
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <div class="wrap_opt_group">
                        <q-option-group
                          class="opt_group_custom week_type"
                          type="checkbox"
                          color="blue-3"
                          v-model="day"
                          :options="dayOption"
                        />
                      </div>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-select
                        class="box_m hide_label"
                        label="브랜드 전체"
                        v-model="brand"
                        :options="brandOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-input
                        v-model="keyword"
                        class="inp_search box_m"
                        outlined
                        dense
                        placeholder="채널 구분"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>
            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <!-- 버튼영역 -->
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                  <div class="btn_wrap col-12 col-md-8">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>
                <!-- // 버튼영역 -->
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  :rows-per-page-options="[0]"
                  hide-pagination
                  style="max-height: 436px"
                  class="scrollable sticky_table_header sticky_table_footer"
                  separator="cell"
                >
                  <template v-slot:bottom-row>
                    <q-tr class="tr_btm">
                      <q-td class="align_center">합계</q-td>
                      <q-td class="border_left_0" colspan="4"></q-td>
                      <q-td class="align_right">0</q-td>
                      <q-td class="align_right">0</q-td>
                      <q-td class="align_right">0</q-td>
                      <q-td class="align_right">0</q-td>
                      <q-td class="align_right">0</q-td>
                      <q-td class="align_right">0</q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table -->
              <!-- 참고하세요 + 더보기 -->
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>
                    소개입회지수 - 눈높이 교육국 간 소개입회를 제외한
                    소개입회실적<br />※ 팀장(러닝센터장 포함) 평가총원성장
                    지수율 실적 산정을 위한 소개입회지수, 소개퇴회지수 실적임
                  </p>
                </div>
                <div class="btn_area">
                  <q-btn
                    fill
                    unelevated
                    color="grey-4"
                    class="size_xs"
                    label="더보기"
                  />
                </div>
              </div>
              <!-- // 참고하세요 + 더보기 -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>
<style scoped>
:deep() .q-table thead {
  position: sticky;
  top: 0;
  z-index: 1999;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');

const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
const brand = ref('브랜드 전체');
const brandOption = ref([
  {
    id: 'brand1',
    desc: 'brand1',
  },
  {
    id: 'brand2',
    desc: 'brand2',
  },
]);
const keyword = ref();

//data테이블
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '만 0세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '만 1세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '만 2세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '만 3세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '만 4세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '만 5세',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata11,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '999,999,999',
    tdata7: '99,999,999',
    tdata8: '9,999,999',
    tdata9: '999,999',
    tdata10: '99,999',
    tdata11: '9,999',
  },
  {
    idx: 10,
    tdata1: '경인본부',
    tdata2: '교육국',
    tdata3: '01팀',
    tdata4: 'Y1 [바다]',
    tdata5: '홍길[002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 9,
    tdata1: '서울서북BCG본부',
    tdata2: '의정부교육국',
    tdata3: '0011팀',
    tdata4: 'YC123 [바다꿈]',
    tdata5: '홍길동[1132002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 8,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 7,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 6,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 5,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 4,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 3,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 2,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    idx: 1,
    tdata1: '서울서북본부',
    tdata2: '강서교육국',
    tdata3: '001팀',
    tdata4: 'YC1 [바다꿈]',
    tdata5: '홍길동[32002596]',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
]);
const searchDate = ref({
  from: '2019.02',
  to: '2019.02',
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
