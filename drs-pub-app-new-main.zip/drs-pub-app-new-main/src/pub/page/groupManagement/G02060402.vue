<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->
        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <div class="wrap_table_box">
              <div class="wrapper_tab">
                <q-tabs
                  v-model="tabintab"
                  inline-label
                  class="tab_line"
                  active-bg-color="white"
                  active-color="primary"
                  indicator-color="primary"
                  align="justify"
                  narrow-indicator
                  outside-arrows
                >
                  <q-tab name="tab41" label="원칙" :ripple="false" />
                  <q-tab name="tab42" label="직원명부" :ripple="false" />
                  <q-tab name="tab43" label="지도점검기록부" :ripple="false" />
                  <q-tab name="tab44" label="학원강사 게시표" :ripple="false" />
                  <q-tab name="tab45" label="교습비 게시표" :ripple="false" />
                  <q-tab
                    name="tab46"
                    label="교습비 반환 규정"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab47"
                    label="문서접수 및 발송대장"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab48"
                    label="교습비 게시표(옥외)"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab49"
                    label="학원 안전점검 체크리스트"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab410"
                    label="자체 실태 점검표 "
                    :ripple="false"
                  />
                </q-tabs>
                <q-tab-panels v-model="tabintab" animated>
                  <!-- tab41 컨텐츠 -->
                  <q-tab-panel name="tab41">
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">
                            보존기간 : <span>준영구</span>
                          </li>
                          <li class="mk_disc">비치 서류</li>
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.03.04</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>

                    <div class="document_rule">
                      <div class="outline_box">
                        <div class="title1">
                          <span>눈높이 러닝센터</span>
                          <q-input
                            class="inp_basic box_m"
                            outlined
                            v-model="inp1"
                            placeholder=""
                          />
                          <span>학원원칙 (예시)</span>
                        </div>

                        <div class="group group1">
                          <div class="body1">제 1조(목적)</div>
                          <div class="content hasinput">
                            <span
                              >이 학원은 학원의 설립ㆍ운영 및 과외교습에 관한
                              법률에 의거하여</span
                            >
                            <q-input
                              class="inp_basic box_m"
                              outlined
                              v-model="inp1"
                              placeholder=""
                            />
                            <span>교육을 실시함을 목적으로 한다.</span>
                          </div>
                        </div>

                        <div class="group group2">
                          <div class="body1">제 2조(명칭)</div>
                          <div class="content hasinput">
                            <span>이 학원은 눈높이 러닝센터</span>
                            <q-input
                              class="inp_basic box_m"
                              outlined
                              v-model="inp1"
                              placeholder=""
                            />
                            <span>보습학원이라 한다.</span>
                          </div>
                        </div>

                        <div class="group group3">
                          <div class="body1">제 3조(위치)</div>
                          <div class="content hasinput">
                            <span>이 학원은</span>
                            <q-input
                              class="inp_basic box_m"
                              outlined
                              v-model="inp1"
                              placeholder=""
                            />
                            <span>라 한다.</span>
                          </div>
                        </div>

                        <div class="group group4">
                          <div class="body1">
                            제 4조(일시수용능력인원)
                            <!-- tooltip_up -->
                            <q-fab
                              direction="up"
                              hide-icon
                              class="tooltip_custom term"
                              flat
                            >
                              <q-fab-action
                                square
                                label=""
                                label-position="left"
                                color="primary"
                                style="width: 300px"
                              >
                                <span class="btn_close"></span>
                                <div class="txt text-body2">
                                  <p>일시 수용인원 산정방법</p>
                                  <ul>
                                    <li>ㆍ교실 총 면적(00㎡) / 1.2㎡</li>
                                    <li>ㆍ예시 75㎡ / 1.2㎡ = 62명</li>
                                  </ul>
                                  <p>
                                    적정인원 계산을 눌러 면적을 입력하면 인원이
                                    자동 계산됩니다(수정가능).
                                  </p>
                                </div>
                              </q-fab-action>
                            </q-fab>
                            <!--// tooltip_up -->
                          </div>
                          <div class="content hasinput">
                            <span>이 학원의 수강생 일시수용능력인원은 총</span>
                            <q-input
                              class="inp_basic box_m"
                              outlined
                              v-model="inp1"
                              placeholder=""
                            />
                            <span
                              >명 &#60;적정인원계산&#62;으로 하며, 교습과목은
                              다음과 같다.</span
                            >
                          </div>
                          <!-- markup-table body rowspan -->
                          <q-markup-table
                            separator="cell"
                            class="combine_table"
                          >
                            <thead>
                              <tr>
                                <th class="">계열</th>
                                <th class="">교습과정</th>
                                <th class="">
                                  교습과목
                                  <!-- tooltip_up -->
                                  <q-fab
                                    direction="up"
                                    hide-icon
                                    class="tooltip_custom term"
                                    flat
                                  >
                                    <q-fab-action
                                      square
                                      label=""
                                      label-position="left"
                                      color="primary"
                                      style="width: 310px"
                                    >
                                      <span class="btn_close"></span>
                                      <div class="txt text-body2">
                                        <p>
                                          교습과목은 교육청에 신고한 과목별 작성
                                        </p>
                                      </div>
                                    </q-fab-action>
                                  </q-fab>
                                  <!--// tooltip_up -->
                                </th>
                                <th class="">
                                  반
                                  <!-- tooltip_up -->
                                  <q-fab
                                    direction="up"
                                    hide-icon
                                    class="tooltip_custom term"
                                    flat
                                  >
                                    <q-fab-action
                                      square
                                      label=""
                                      label-position="left"
                                      color="primary"
                                      style="width: 170px"
                                    >
                                      <span class="btn_close"></span>
                                      <div class="txt text-body2">
                                        <p>요일별 운영 기록</p>
                                      </div>
                                    </q-fab-action>
                                  </q-fab>
                                  <!--// tooltip_up -->
                                </th>
                                <th class="">
                                  일시수용능력인원
                                  <!-- tooltip_up -->
                                  <q-fab
                                    direction="up"
                                    hide-icon
                                    class="tooltip_custom term"
                                    flat
                                  >
                                    <q-fab-action
                                      square
                                      label=""
                                      label-position="left"
                                      color="primary"
                                      style="width: 270px"
                                    >
                                      <span class="btn_close"></span>
                                      <div class="txt text-body2">
                                        <p>반별 일시 수용인원 산정방법</p>
                                        <ul>
                                          <li>ㆍ교실 총 면적(00㎡) / 1.2㎡</li>
                                          <li>ㆍ예시 75㎡ / 1.2㎡ = 62명</li>
                                        </ul>
                                      </div>
                                    </q-fab-action>
                                  </q-fab>
                                  <!--// tooltip_up -->
                                </th>
                                <th class="">비고</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td rowspan="5" class="rowspan">보통교과</td>
                                <td rowspan="5" class="rowspan">보습</td>
                                <td class="">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">요일강의</td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>강의실</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class=""></td>
                              </tr>
                              <tr>
                                <td class="row_first">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">요일강의</td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>강의실</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class=""></td>
                              </tr>
                              <tr>
                                <td class="row_first">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">요일강의</td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>강의실</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class=""></td>
                              </tr>
                              <tr>
                                <td class="row_first">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">요일강의</td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>강의실</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class=""></td>
                              </tr>
                              <tr>
                                <td class="row_first">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">요일강의</td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>강의실</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class=""></td>
                              </tr>
                              <tr class="tr_btm">
                                <td class="border_none"></td>
                                <td class="border_none"></td>
                                <td class="border_none"></td>
                                <td class="border_none"></td>
                                <td class="">
                                  <div class="row_custom">
                                    <span>계</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>명</span>
                                  </div>
                                </td>
                                <td class="border_none"></td>
                              </tr>
                            </tbody>
                          </q-markup-table>
                          <!-- //markup-table body rowspan -->
                        </div>

                        <div class="group group5">
                          <div class="body1">제 5조(교습과정)</div>
                          <div class="content">
                            <span
                              >이 학원의 교습과정 및 수료기간과 교과목별
                              이수시간은 다음과 같다.</span
                            >
                          </div>
                          <!-- markup-table multi_head -->
                          <q-markup-table
                            separator="cell"
                            class="combine_table"
                          >
                            <thead>
                              <tr>
                                <th rowspan="2">교습과정</th>
                                <th rowspan="2">1일 교습시간</th>
                                <th rowspan="2">수료기간</th>
                                <th colspan="2">교과목</th>
                                <th rowspan="2">비고</th>
                              </tr>
                              <tr>
                                <th class="row_first">과목명</th>
                                <th>총 이수시간</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>개월</span>
                                  </div>
                                </td>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td class="">
                                  <div class="text-center row_custom">
                                    <span>주</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>회</span>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>개월</span>
                                  </div>
                                </td>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td>
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td>
                                  <div class="text-center row_custom">
                                    <span>주</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>회</span>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td class="text-center">
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>개월</span>
                                  </div>
                                </td>
                                <td>
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td>
                                  <div class="text-center row_custom">
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>시간</span>
                                  </div>
                                </td>
                                <td>
                                  <div class="text-center row_custom">
                                    <span>주</span>
                                    <q-input
                                      class="inp_basic"
                                      outlined
                                      v-model="inp1"
                                      placeholder=""
                                    />
                                    <span>회</span>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </q-markup-table>
                          <!-- //markup-table multi_head -->
                        </div>

                        <div class="group group6">
                          <div class="body1">
                            제 6조(입원자격)
                            <!-- tooltip_up -->
                            <q-fab
                              direction="up"
                              hide-icon
                              class="tooltip_custom term"
                              flat
                            >
                              <q-fab-action
                                square
                                label=""
                                label-position="left"
                                color="primary"
                                style="width: 430px; left: 100px"
                              >
                                <span class="btn_close"></span>
                                <div class="txt text-body2">
                                  <p>
                                    제4조, 5조, 6조에는 6과목까지 입력 가능하며,
                                    교육청에 신고한 이외의 과목은 별첨문서로
                                    제출하십시오.
                                  </p>
                                </div>
                              </q-fab-action>
                            </q-fab>
                            <!--// tooltip_up -->
                          </div>
                          <div class="content">
                            <span
                              >이 학원에 입원할 수 있는 자의 자격은 다음과
                              같다.</span
                            >
                          </div>
                          <!-- markup-table -->
                          <q-markup-table separator="cell" class="">
                            <thead>
                              <tr>
                                <th class="">교습과정</th>
                                <th class="">교습과목</th>
                                <th class="">해임년월일</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td class="text-center">보습 강의</td>
                                <td class="">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">본원에서 보습교육을 원하는 자</td>
                              </tr>
                              <tr>
                                <td class="text-center">보습 강의</td>
                                <td class="">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">본원에서 보습교육을 원하는 자</td>
                              </tr>
                              <tr>
                                <td class="text-center">보습 강의</td>
                                <td class="">
                                  <q-input
                                    class="inp_basic"
                                    outlined
                                    v-model="inp1"
                                    placeholder=""
                                  />
                                </td>
                                <td class="">본원에서 보습교육을 원하는 자</td>
                              </tr>
                            </tbody>
                          </q-markup-table>
                          <!-- //markup-table -->
                        </div>

                        <div class="group group7">
                          <div class="body1">제 7조(휴강일)</div>
                          <div class="content">
                            <ol class="ol_custom">
                              <li>
                                이 학원의 휴강일은 다음과 같다.
                                <ol class="ol_custom type_inner">
                                  <li>1&#41; 국경일 및 공휴일</li>
                                  <li>2&#41; 정기휴일</li>
                                  <li>3&#41; 개원기념일</li>
                                </ol>
                              </li>
                              <li>
                                제1항 각 호외에 비상재변, 특별한 사유, 기타
                                급박한 사정이 발생한 때에는 임시 휴강할 수 있다.
                              </li>
                              <li>
                                휴강일이라도 필요한 때에는 교습을 할 수 있다.
                              </li>
                            </ol>
                          </div>
                        </div>
                      </div>

                      <div class="outline_box">
                        <div class="title1">
                          <span>학원필수 장부_게시서류</span>
                        </div>

                        <div class="group group8">
                          <div class="body1">제 8조</div>
                          <div class="content">
                            <ol class="ol_custom">
                              <li>
                                이 학원의 교습비는 주무관청에 통보한 금액을
                                징수한다.
                              </li>
                              <li>
                                이미 납입된 교습비중 반환사유가 발생한 경우에는
                                별표 3의 반환기준에 의하여 교습비 등을 반환사유
                                발생 일부터 5일 이내에 반환하여야 한다.

                                <div class="list_inner_content">
                                  <div class="body1">교습비 반환기준</div>
                                  <!-- markup-table body rowspan 텍스트 줄바꿈 -->
                                  <q-markup-table
                                    separator="cell"
                                    class="combine_table"
                                    wrap-cells
                                  >
                                    <thead>
                                      <tr>
                                        <th colspan="2" class="">구분</th>
                                        <th class="">반환사유 발생일</th>
                                        <th class="">반환금액</th>
                                        <th class="">비고</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td colspan="2" class="">
                                          제18조 제2항 제1호 및 제2호의
                                          반환사유에 의한 경우
                                        </td>
                                        <td class="text-left">
                                          교습을 할 수 없거나, 교습장소를 제공할
                                          수 없게 된 날
                                        </td>
                                        <td class="text-left">
                                          이미 납부한 교습비를 일할 계산한 금액
                                        </td>
                                        <td rowspan="7" class="border_btm_0">
                                          총 교습시간은 교습비 징수기간 중의 총
                                          교습시간을 말하며, 반환금액의 산정은
                                          반환사유가 발생한 날까지 경과된
                                          교습시간을 기준으로 한다.
                                        </td>
                                      </tr>
                                      <tr>
                                        <td
                                          rowspan="6"
                                          class="rowspan border_btm_0"
                                        >
                                          제18조제2항제3호의 반환사유에 의한
                                          경우
                                        </td>
                                        <td rowspan="4" class="rowspan">
                                          교습비 징수기간이 1월 이내인 경우
                                        </td>
                                        <td class="text-left">교습개시 이전</td>
                                        <td class="text-left">
                                          이미 납부한 교습비 전액
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="row_first text-left">
                                          총 교습시간의 1/3경과 전
                                        </td>
                                        <td class="text-left">
                                          이미 납부한 교습비의 2/3 해당 액
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="row_first text-left">
                                          총 교습시간의 1/2경과 전
                                        </td>
                                        <td class="text-left">
                                          이미 납부한 교습비의 1/2 해당 액
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="row_first text-left">
                                          총 교습시간의 1/2경과 후
                                        </td>
                                        <td class="text-left">
                                          반환하지 아니함
                                        </td>
                                      </tr>
                                      <tr>
                                        <td
                                          rowspan="2"
                                          class="row_first border_btm_0"
                                        >
                                          교습비 징수기간이 1월을 초과하는 경우
                                        </td>
                                        <td class="text-left">교습개시 이전</td>
                                        <td class="text-left">
                                          이미 납부한 교습비 전액
                                        </td>
                                      </tr>
                                      <tr>
                                        <td class="row_first text-left">
                                          교습개시 이후
                                        </td>
                                        <td class="text-left">
                                          반환사유가 발생한 당해 월의 반환 대상
                                          교습비(교습비 징수기간이 1월 이내인
                                          경우에 따라 산출된 교습비를 말한다)와
                                          나머지 월의 교습비 전액을 합산한 금액
                                        </td>
                                      </tr>
                                    </tbody>
                                  </q-markup-table>
                                  <!-- //markup-table body rowspan 텍스트 줄바꿈 -->
                                </div>
                              </li>
                              <li>
                                다음 각 호의 1에 해당하는 자는 교습비를 면제
                                또는 감액할 수 있다.
                                <ol class="ol_custom type_inner">
                                  <li>
                                    1&#41; 근로청소년 등 경제적 사정이 곤란한 자
                                  </li>
                                  <li>
                                    2&#41; 천재지변 등의 사유로 교습비의 납입이
                                    곤란한 자
                                  </li>
                                  <li>
                                    3&#41; 보훈대상자 등 국가 유공자 또는 그
                                    자녀
                                  </li>
                                  <li>
                                    3&#41; 당해 교습과목에 관한 재능이 탁월한 자
                                  </li>
                                </ol>
                              </li>
                            </ol>
                          </div>
                        </div>

                        <div class="group group9">
                          <div class="body1">제9조 (시행세칙)</div>
                          <div class="content">
                            이 원칙상 필요한 세칙은 학원의 설립ㆍ운영자가 이를
                            결정한다.
                          </div>
                        </div>
                      </div>
                    </div>
                  </q-tab-panel>
                  <!--// tab41 컨텐츠 -->
                  <!-- tab42 컨텐츠 -->
                  <q-tab-panel name="tab42">
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">보존기간 : <span>계속</span></li>
                          <li class="mk_disc">비치 서류</li>
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.04.07</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>

                    <div class="document_rule">
                      <div class="outline_box">
                        <div class="title1">
                          <span>직원 명부</span>
                          <q-space />
                          <div class="btn_area">
                            <q-btn
                              class="size_sm btn_edit"
                              outline
                              label="수정"
                            />
                            <q-btn
                              class="size_sm btn_delete"
                              outline
                              label="삭제"
                            />
                            <q-btn
                              class="size_sm btn_save"
                              fill
                              unelevated
                              color="black"
                              label="등록"
                            />
                          </div>
                        </div>

                        <!-- selectable_table -->
                        <div class="table_dk">
                          <q-table
                            :rows="msgRows"
                            :columns="msgColumns"
                            row-key="idx"
                            v-model:selected="msg_selected"
                            selection="multiple"
                            v-model:pagination="msg_pagination"
                            hide-bottom
                            hide-pagination
                            separator="cell"
                          >
                            <template v-slot:header="props">
                              <q-tr :props="props">
                                <q-th class="select">선택</q-th>
                                <q-th
                                  v-for="col in props.cols"
                                  :key="col.name"
                                  :props="props"
                                >
                                  {{ col.label }}
                                </q-th>
                              </q-tr>
                            </template>
                            <template v-slot:body="props">
                              <q-tr :class="props.row.state" :props="props">
                                <q-td class="select"
                                  ><q-checkbox
                                    v-model="props.selected"
                                    color="black"
                                /></q-td>
                                <q-td key="idx" class="idx">{{
                                  props.row.idx
                                }}</q-td>
                                <q-td key="data1" class="text-center">
                                  {{ props.row.data1 }}</q-td
                                >
                                <q-td key="data2" class="name text-center">
                                  {{ props.row.data2 }}</q-td
                                >
                                <q-td key="data3" class="birth text-center">
                                  {{ props.row.data3 }}</q-td
                                >
                                <q-td key="data4" class="address text-left">
                                  {{ props.row.data4 }}</q-td
                                >
                                <q-td key="data5" class="tel text-center">
                                  {{ props.row.data5 }}</q-td
                                >
                                <q-td key="data6" class="text-left">
                                  {{ props.row.data6 }}</q-td
                                >
                                <q-td key="data7" class="text-left">
                                  {{ props.row.data7 }}</q-td
                                >
                                <q-td key="data8" class="text-center">
                                  {{ props.row.data8 }}</q-td
                                >
                                <q-td key="data9" class="text-center">
                                  {{ props.row.data9 }}</q-td
                                >
                              </q-tr>
                            </template>
                          </q-table>
                        </div>
                        <!--// selectable_table-->
                      </div>
                      <div class="mt20">
                        <div class="info_caution">
                          <strong class="info_caution_tit"
                            ><q-icon
                              name="icon-info02"
                              class="icon_svg"
                            ></q-icon>
                            주의사항</strong
                          >
                          <p>
                            1. 직원명부의 대상자는 학원강사로 등록된 인원 이외에
                            센터에서 업무 하는 사람을 등록하세요.
                          </p>
                          <p>
                            &nbsp;&nbsp;&nbsp;ex) 국장 : 행정실장-교무행정 /
                            업무직원 : 서무, 서무직원 - 학원운영관리 및 기본
                            상담
                          </p>
                          <p>
                            2. 해당 교육청마다 양식에 다소 차이가 있을 수 있으니
                            확인하시기 바랍니다.
                          </p>
                          <p>
                            3. 개인정보보호법에 의거하여, 주민등록번호는 작성
                            시에만 보이고 출력시에는 123456-1******의 형태로
                            표시됩니다.
                          </p>
                        </div>
                      </div>
                    </div>
                  </q-tab-panel>
                  <!--// tab42 컨텐츠 -->
                  <!-- tab43 컨텐츠 -->
                  <q-tab-panel name="tab43">43</q-tab-panel>
                  <!--// tab43 컨텐츠 -->
                  <!-- tab44 컨텐츠 -->
                  <q-tab-panel name="tab44">44</q-tab-panel>
                  <!--// tab44 컨텐츠 -->
                  <!-- tab45 컨텐츠 -->
                  <q-tab-panel name="tab45">45</q-tab-panel>
                  <!--// tab45 컨텐츠 -->
                  <!-- tab46 컨텐츠 -->
                  <q-tab-panel name="tab46">46</q-tab-panel>
                  <!--// tab46 컨텐츠 -->
                  <!-- tab47 컨텐츠 -->
                  <q-tab-panel name="tab47">47</q-tab-panel>
                  <!--// tab47 컨텐츠 -->
                  <!-- tab48 컨텐츠 -->
                  <q-tab-panel name="tab48">48</q-tab-panel>
                  <!--// tab48 컨텐츠 -->
                  <!-- tab49 컨텐츠 -->
                  <q-tab-panel name="tab49">49</q-tab-panel>
                  <!--// tab49 컨텐츠 -->
                  <!-- tab410 컨텐츠 -->
                  <q-tab-panel name="tab410">410</q-tab-panel>
                  <!--// tab410 컨텐츠 -->
                </q-tab-panels>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab4');
const tabintab = ref('tab42');

// table_search_area
// const check1 = ref(false);
// const check2 = ref(false);
// const check3 = ref(false);
// const check5 = ref(false);

// 인풋창
const inp1 = ref();

//table데이터
const msg_selected = ref([]);
// const pagesNumber = computed(() =>
//   Math.ceil(msgRows.value.length / msg_pagination.value.rowsPerPage)
// );
const msgColumns = ref([
  {
    name: 'idx',
    label: 'NO',
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'data1',
    label: '직명',
    align: 'center',
    field: (row) => row.data1,
  },
  {
    name: 'data2',
    label: '성명',
    align: 'center',
    field: (row) => row.data2,
  },
  {
    name: 'data3',
    label: '생년월일',
    align: 'center',
    field: (row) => row.data3,
  },
  {
    name: 'data4',
    label: '주소',
    align: 'center',
    field: (row) => row.data4,
  },
  {
    name: 'data5',
    label: '전화번호',
    align: 'center',
    field: (row) => row.data5,
  },
  {
    name: 'data6',
    label: '출신학교',
    align: 'center',
    field: (row) => row.data6,
  },
  {
    name: 'data7',
    label: '담당업무',
    align: 'center',
    field: (row) => row.data7,
  },
  {
    name: 'data8',
    label: '채용년월일',
    align: 'center',
    field: (row) => row.data8,
  },
  {
    name: 'data9',
    label: '해임년월일',
    align: 'center',
    field: (row) => row.data9,
  },
]);
const msgRows = ref([
  {
    idx: '1',
    data1: '-',
    data2: '김김김',
    data3: '2023.01.00',
    data4: '서울',
    data5: '000-000-0000',
    data6: '-',
    data7: '-',
    data8: '2023.00.00',
    data9: '2023.00.00',
  },
  {
    idx: '2',
    data1: '-',
    data2: '김김김',
    data3: '2023.01.00',
    data4: '서울',
    data5: '000-000-0000',
    data6: '-',
    data7: '-',
    data8: '2023.00.00',
    data9: '2023.00.00',
  },
  {
    idx: '3',
    data1: '-',
    data2: '김김김',
    data3: '2023.01.00',
    data4: '서울',
    data5: '000-000-0000',
    data6: '-',
    data7: '-',
    data8: '2023.00.00',
    data9: '2023.00.00',
  },
  {
    idx: '1',
    data1: '-',
    data2: '김김김',
    data3: '2023.01.00',
    data4: '서울',
    data5: '000-000-0000',
    data6: '-',
    data7: '-',
    data8: '2023.00.00',
    data9: '2023.00.00',
  },
]);
const msg_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 5,
});
</script>
