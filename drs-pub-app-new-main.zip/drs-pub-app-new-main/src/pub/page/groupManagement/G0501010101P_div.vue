<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree row5" v-if="$q.screen.name == 'lg'">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="single_form">
            <h3 class="title3">부문</h3>
            <q-select
              class="box_xl hide_label"
              v-model="tree0"
              :options="tree0Option"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              multiple
              map-options
              dense
              outlined
              label="선택하세요"
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>
          <div class="row_tree_group">
            <div class="item_tree">
              <p class="tree_group_tit">본부</p>
              <div class="wrap_as_tree">
                <div class="as_tree">
                  <div class="fold">
                    <q-btn
                      flat
                      v-model="foldingTree1"
                      @click="foldingTree1 = !foldingTree1"
                    >
                      <q-icon
                        name="play_arrow"
                        color="grey-4"
                        :class="foldingTree1 ? 'rotate' : ''"
                      />
                      <q-icon name="icon-folder" class="icon_svg"></q-icon>
                      <div class="title3">눈높이서비스부분</div>
                    </q-btn>
                  </div>
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분"
                    val="a1"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분2"
                    val="a2"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분3"
                    val="a3"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                  <q-radio
                    v-show="foldingTree1"
                    v-model="tree1"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                </div>
              </div>

              <!-- pc -->
            </div>
            <!-- 한결 요청 -->
            <div class="item_tree">
              <h3 class="tree_group_tit">조직</h3>
              <div class="wrap_as_tree">
                <h4>서울서북본부 > 강서교육국</h4>
                <div class="as_tree">
                  <div class="fold">
                    <q-btn
                      flat
                      v-model="foldingTree2"
                      @click="foldingTree2 = !foldingTree2"
                    >
                      <q-icon
                        name="play_arrow"
                        color="grey-4"
                        :class="foldingTree2 ? 'rotate' : ''"
                      />
                      <q-icon name="icon-folder" class="icon_svg"></q-icon>
                      <div class="title3">눈높이서비스부분22</div>
                    </q-btn>
                  </div>
                  <q-checkbox
                    v-show="foldingTree2"
                    v-model="tree2"
                    label="눈높이서비스부분"
                    val="a"
                  />
                  <q-checkbox
                    v-show="foldingTree2"
                    v-model="tree2"
                    label="눈높이서비스부분2"
                    val="a2"
                  />
                  <q-checkbox
                    v-show="foldingTree2"
                    v-model="tree2"
                    label="눈높이서비스부분3"
                    val="a3"
                  />
                  <q-checkbox
                    v-show="foldingTree2"
                    v-model="tree2"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                </div>
                <q-separator class="mb15 mr15" />
                <h4>서울서북본부 > 강남본부</h4>
                <div class="as_tree">
                  <div class="fold">
                    <q-btn flat v-model="tree2_1" @click="tree2_1 = !tree2_1">
                      <q-icon
                        name="play_arrow"
                        color="grey-4"
                        :class="tree2_1 ? 'rotate' : ''"
                      />
                      <q-icon name="icon-folder" class="icon_svg"></q-icon>
                      <div class="title3">눈높이서비스부분333</div>
                    </q-btn>
                  </div>
                  <q-checkbox
                    v-show="tree2_1"
                    v-model="tree2_1"
                    label="눈높이서비스부분"
                    val="b"
                  />
                  <q-checkbox
                    v-show="tree2_1"
                    v-model="tree2_1"
                    label="눈높이서비스부분2"
                    val="b2"
                  />
                  <q-checkbox
                    v-show="tree2_1"
                    v-model="tree2_1"
                    label="눈높이서비스부분3"
                    val="b3"
                  />
                  <q-checkbox
                    v-show="tree2_1"
                    v-model="tree2_1"
                    label="눈높이서비스부분4"
                    val="b4"
                  />
                </div>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit">팀</h3>
              <div class="wrap_as_tree">
                <h4>서울서북본부 > 강남본부</h4>
                <div class="as_tree">
                  <q-checkbox
                    v-model="tree3"
                    label="눈높이서비스부분"
                    class="head"
                    val="all"
                  />
                  <q-checkbox
                    v-model="tree3"
                    label="눈높이서비스부분"
                    val="a"
                  />
                  <q-checkbox
                    v-model="tree3"
                    label="눈높이서비스부분2"
                    val="a2"
                  />
                  <q-checkbox
                    v-model="tree3"
                    label="눈높이서비스부분3"
                    val="a3"
                  />
                  <q-checkbox
                    v-model="tree3"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                </div>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit">채널</h3>
              <div class="wrap_as_tree">
                <div class="as_tree">
                  <q-checkbox
                    v-model="tree4"
                    label="눈높이서비스부분"
                    class="head"
                    val="['a1','a3','a4','a2']"
                  />
                  <q-checkbox
                    v-model="tree4"
                    label="눈높이서비스부분"
                    val="a"
                  />
                  <q-checkbox
                    v-model="tree4"
                    label="눈높이서비스부분2"
                    val="a2"
                  />
                  <q-checkbox
                    v-model="tree4"
                    label="눈높이서비스부분3"
                    val="a3"
                  />
                  <q-checkbox
                    v-model="tree4"
                    label="눈높이서비스부분4"
                    val="a4"
                  />
                </div>
              </div>
            </div>
            <div class="item_tree">
              <h3 class="tree_group_tit">선생님</h3>

              <div class="wrap_as_tree">
                <div class="as_tree">
                  <q-checkbox
                    v-model="tree5"
                    label="눈높이서비스부분"
                    class="head"
                    val="['a1','a3','a4','a2']"
                  />
                  <q-checkbox
                    v-model="tree5"
                    label="눈높이서비스부분"
                    val="tree5_a"
                  />
                  <q-checkbox
                    v-model="tree5"
                    label="눈높이서비스부분2"
                    val="tree5_a2"
                  />
                  <q-checkbox
                    v-model="tree5"
                    label="눈높이서비스부분3"
                    val="tree5_a3"
                  />
                  <q-checkbox
                    v-model="tree5"
                    label="눈높이서비스부분4"
                    val="tree5_a4"
                  />
                </div>
                <div class="as_tree">
                  <q-checkbox
                    v-model="tree5_1"
                    label="눈높이서비스부분"
                    class="head"
                    val="tree_5_all"
                  />
                  <q-checkbox
                    v-model="tree5_1"
                    label="눈높이서비스부분"
                    val="tree_5_1_"
                  />
                  <q-checkbox
                    v-model="tree5_1"
                    label="눈높이서비스부분2"
                    val="tree_5_1_2"
                  />
                  <q-checkbox
                    v-model="tree5_1"
                    label="눈높이서비스부분3"
                    val="tree_5_1_3"
                  />
                  <q-checkbox
                    v-model="tree5_1"
                    label="눈높이서비스부분4"
                    val="tree_5_1_4"
                  />
                </div>
              </div>
            </div>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <div class="btn_area response">
            <q-btn
              unelevated
              outline
              v-close-popup
              class="size_lg"
              label="취소"
            />
            <q-btn
              unelevated
              v-close-popup
              color="black"
              class="size_lg"
              label="확인"
            />
            <q-btn
              class="size_md btn_reset btn_position_end"
              icon=""
              unelevated
              dense
              outline
              label="초기화"
            />
          </div>
        </q-card-actions>
      </q-card>

      <q-card
        class="respons_card type_tree"
        v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
      >
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <q-list class="list_custom type01">
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">부문</span>
                    <q-badge
                      v-for="(items, idx) in tree0"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div class="wrap_as_tree">
                    <div class="as_tree">
                      <q-checkbox
                        v-model="tree0"
                        label="눈높이서비스부분"
                        class="head"
                        val="all"
                      />
                      <q-checkbox
                        v-model="tree0"
                        label="눈높이서비스부분1"
                        val="a1"
                      />
                      <q-checkbox
                        v-model="tree0"
                        label="눈높이서비스부분2"
                        val="a2"
                      />
                      <q-checkbox
                        v-model="tree0"
                        label="눈높이서비스부분3"
                        val="a3"
                      />
                      <q-checkbox
                        v-model="tree0"
                        label="눈높이서비스부분4"
                        val="a4"
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">본부</span>
                    <!-- 라디오 일때 q-badge -->
                    <q-badge
                      v-if="tree1"
                      color="grey-4"
                      class="medium"
                      :label="tree1"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div class="wrap_as_tree">
                    <div class="as_tree">
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분"
                        class="head"
                        val="all"
                      />
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분"
                        val="a"
                      />
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분2"
                        val="a2"
                      />
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분3"
                        val="a3"
                      />
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분4"
                        val="a4"
                      />
                      <q-radio
                        v-model="tree1"
                        label="눈높이서비스부분4"
                        val="a4"
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">조직</span>
                    <q-badge
                      v-for="(items, idx) in tree2"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                    <q-badge
                      v-for="(items, idx) in tree2_1"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div class="wrap_as_tree">
                    <div class="as_tree">
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분"
                        class="head"
                        val="all"
                      />
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분"
                        val="a"
                      />
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분2"
                        val="a2"
                      />
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분3"
                        val="a3"
                      />
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분4"
                        val="a4"
                      />
                      <q-checkbox
                        v-model="tree2"
                        label="눈높이서비스부분4"
                        val="a4"
                      />
                    </div>
                    <div class="as_tree">
                      <q-checkbox
                        v-model="tree2_1"
                        label="눈높이서비스부분"
                        class="head"
                        val="b_all"
                      />
                      <q-checkbox
                        v-model="tree2_1"
                        label="눈높이서비스부분"
                        val="b"
                      />
                      <q-checkbox
                        v-model="tree2_1"
                        label="눈높이서비스부분2"
                        val="b2"
                      />
                      <q-checkbox
                        v-model="tree2_1"
                        label="눈높이서비스부분3"
                        val="b3"
                      />
                      <q-checkbox
                        v-model="tree2_1"
                        label="눈높이서비스부분4"
                        val="b4"
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">팀</span>
                    <!-- 체크박스 일때 q-badge -->
                    <q-badge
                      v-for="(items, idx) in tree3"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section
                  ><q-card-section>
                    <div class="wrap_as_tree">
                      <div class="as_tree">
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분"
                          class="head"
                          val="all"
                        />
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분"
                          val="a"
                        />
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분2"
                          val="a2"
                        />
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분3"
                          val="a3"
                        />
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분4"
                          val="a4"
                        />
                        <q-checkbox
                          v-model="tree3"
                          label="눈높이서비스부분4"
                          val="a4"
                        />
                      </div>
                    </div> </q-card-section
                ></q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">채널</span>
                    <q-badge
                      v-for="(items, idx) in tree4"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section
                  ><q-card-section>
                    <div class="wrap_as_tree">
                      <div class="as_tree">
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분"
                          class="head"
                          val="all"
                        />
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분"
                          val="a"
                        />
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분2"
                          val="a2"
                        />
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분3"
                          val="a3"
                        />
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분4"
                          val="a4"
                        />
                        <q-checkbox
                          v-model="tree4"
                          label="눈높이서비스부분4"
                          val="a4"
                        />
                      </div>
                    </div> </q-card-section
                ></q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05 h_unset">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">선생님</span>
                    <q-badge
                      v-for="(items, idx) in tree5"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                    <q-badge
                      v-for="(items, idx) in tree5_1"
                      :key="idx"
                      color="grey-4"
                      class="medium"
                      :label="items"
                    />
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <div class="wrap_as_tree">
                    <div class="as_tree">
                      <q-checkbox
                        v-model="tree5"
                        label="눈높이서비스부분"
                        class="head"
                        val="tree5_all"
                      />
                      <q-checkbox
                        v-model="tree5"
                        label="눈높이서비스부분"
                        val="tree5_a"
                      />
                      <q-checkbox
                        v-model="tree5"
                        label="눈높이서비스부분2"
                        val="tree5_a2"
                      />
                      <q-checkbox
                        v-model="tree5"
                        label="눈높이서비스부분3"
                        val="tree5_a3"
                      />
                      <q-checkbox
                        v-model="tree5"
                        label="눈높이서비스부분4"
                        val="tree5_a4"
                      />
                    </div>
                    <div class="as_tree">
                      <q-checkbox
                        v-model="tree5_1"
                        label="눈높이서비스부분"
                        class="head"
                        val="tree_5_all"
                      />
                      <q-checkbox
                        v-model="tree5_1"
                        label="눈높이서비스부분"
                        val="tree_5_1_"
                      />
                      <q-checkbox
                        v-model="tree5_1"
                        label="눈높이서비스부분2"
                        val="tree_5_1_2"
                      />
                      <q-checkbox
                        v-model="tree5_1"
                        label="눈높이서비스부분3"
                        val="tree_5_1_3"
                      />
                      <q-checkbox
                        v-model="tree5_1"
                        label="눈높이서비스부분4"
                        val="tree_5_1_4"
                      />
                    </div>
                  </div>
                </q-card-section>
              </q-card>
            </q-expansion-item>
          </q-list>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            icon=""
            class="size_sm btn_reset"
            label="초기화"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="검색"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// tree

// const treeSelected1 = ref('["teal","red","눈높이서비스부분","눈높이서비스부분2","눈높이서비스부분3","눈높이서비스부분4"]');
const foldingTree1 = ref(true);
const foldingTree2 = ref(true);
// const foldingTree2_1 = ref(true);
// const foldingTree3 = ref(true);
// const foldingTree4 = ref(true);
// const foldingTree5 = ref(true);
// const foldingTree5_1 = ref(true);
const tree0 = ref([]);
const tree1 = ref('');
const tree2_1 = ref([]);
const tree2 = ref([]);
const tree3 = ref([]);
const tree4 = ref([]);
const tree5 = ref([]);
const tree5_1 = ref([]);
const tree0Option = ref([
  {
    id: 'all',
    desc: '눈높이서비스부분 전체',
  },
  {
    id: 'a1',
    desc: '눈높이서비스부분1',
  },
  {
    id: 'a2',
    desc: '눈높이서비스부분2',
  },
  {
    id: 'a3',
    desc: '눈높이서비스부분3',
  },
  {
    id: 'a14',
    desc: '눈높이서비스부분4',
  },
]);
</script>
<style lang="scss" scoped>
// .item_tree {
//   max-width: calc(20% - 15px);
// }

h4 {
  font-weight: 600;
  margin-bottom: 5px;
}
.as_tree .fold {
  margin-left: -35px;

  .q-icon {
    margin-right: 5px;
    transition: 0.3s;

    &.play_arrow.rotate {
      transform: rotate(90deg);
    }
  }
}
</style>
