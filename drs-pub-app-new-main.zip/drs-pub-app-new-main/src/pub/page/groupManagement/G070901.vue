<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">현금영수증관리</h2>
      <Breadcrumbs />
    </div>
    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="증빙번호 등록" :ripple="false" />
          <q-tab name="tab2" label="현금영수증조회/취소요청" :ripple="false" />
          <q-tab name="tab3" label="체납공제현금영수증승인" :ripple="false" />
          <q-tab name="tab4" label="증빙번호 수정이력" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="row q-col-gutter-sm" v-if="stateHandle">
                  <div class="col-12 col-md-3">
                    <q-select
                      class="box_l hide_label"
                      label="학습 유무"
                      v-model="memberType"
                      :options="memberTypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="general_table">
                <!-- 버튼영역 -->
                <div class="table_top">
                  <div class="btn_wrap col-12 gap10">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                    <q-btn class="size_sm" outline label="수정이력보기" />
                  </div>
                </div>
                <!-- // 버튼영역 -->
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  v-model:pagination="dataPagination"
                  v-model:selected="dataSelected"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                  selection="multiple"
                  color="black"
                >
                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="tdata1" class="align_center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="align_center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata3" class="align_center">
                        <q-checkbox
                          v-model="dataCheck1"
                          label=""
                          color="black"
                        />
                      </q-td>
                      <q-td key="tdata4" class="align_center">
                        <q-checkbox
                          v-model="dataCheck2"
                          label=""
                          color="black"
                        />
                      </q-td>
                      <q-td key="tdata5" class="align_center w320">
                        <q-input
                          class=""
                          for=""
                          outlined
                          dense
                          v-model="keyword"
                          placeholder=""
                        />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table -->
              <!-- 참고하세요 + 더보기 -->
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>
                    증빙번호 수정 시 [소비자소득공제용/사업자지출증빙용]을
                    정확히 체크하시기 바랍니다.
                  </p>
                </div>
                <div class="btn_area">
                  <q-btn
                    fill
                    unelevated
                    color="grey-4"
                    class="size_xs"
                    label="더보기"
                  />
                </div>
              </div>
              <!-- // 참고하세요 + 더보기 -->
            </div>
          </q-tab-panel>
          <q-tab-panel name="tab2">현금영수증조회/취소요청</q-tab-panel>
          <q-tab-panel name="tab3">체납공제현금영수증승인</q-tab-panel>
          <q-tab-panel name="tab4">증빙번호 수정이력</q-tab-panel>
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const tab = ref('tab1');
const memberType = ref('학습 유무');
const memberTypeOption = ref([
  {
    id: 'm1',
    desc: '회원1',
  },
  {
    id: 'm2',
    desc: '회원2',
  },
]);
//data테이블
const keyword = ref([]);
const dataCheck1 = ref(true);
const dataCheck2 = ref(false);
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '소비자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '사업자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 10,
    tdata1: '0000000000000',
    tdata2: '홍홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 9,
    tdata1: '0000000',
    tdata2: '길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 8,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 7,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 6,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 5,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 4,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 3,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 2,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
  {
    idx: 1,
    tdata1: '0000000000',
    tdata2: '홍길동',
    tdata3: '',
    tdata4: '',
    tdata5: '',
  },
]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
