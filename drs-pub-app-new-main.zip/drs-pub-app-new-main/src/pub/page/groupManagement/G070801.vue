<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회비조정 신청</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label box_l"
                label="회비조정+"
                v-model="select1Type"
                :options="select1TypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8 gap10">
              <q-btn class="size_sm" outline label="항목설정" />
            </div>
          </div>

          <q-table
            class="multi_head sticky_table_header"
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 260px"
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th key="idx" rowspan="2">번호</th>
                <th colspan="7">회원 학습과목</th>
                <th colspan="4">변경 전 회비</th>
                <th colspan="2">변경 후 회비</th>
              </tr>
              <tr>
                <th key="tdata1" class="row_first">조직</th>
                <th key="tdata2">선생님</th>
                <th key="tdata3">회원명</th>
                <th key="tdata4">회원번호</th>
                <th key="tdata5">과목</th>
                <th key="tdata6">요일</th>
                <th key="tdata7">옵션</th>
                <th key="tdata8">회비년월</th>
                <th key="tdata9">입금액</th>
                <th key="tdata10">학습횟수</th>
                <th key="tdata11">회비</th>
                <th key="tdata12">학습회수</th>
                <th key="tdata13">회비</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <q-td key="tdata1" class="text-center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="text-center">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="text-center">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="text-center">
                  {{ props.row.tdata13 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!-- // general_table -->

        <h3 class="title1 mt60 mb24">회비조정사유 및 첨부파일</h3>
        <table class="table_row_sales">
          <tbody>
            <tr>
              <th><span class="required">회비 조정사유</span></th>
              <td>
                <div class="search_item type_full">
                  <q-input
                    class=""
                    for=""
                    outlined
                    dense
                    v-model="keyword"
                    placeholder="회비조정 사유를 20자 이내로 입력하세요"
                  />
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일1</th>
              <td>
                <div class="row-8 gap10">
                  <div class="search_item type_half">
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataFrom.information"
                      label=""
                      class="hide_label file_custom type_short"
                    >
                      <template v-slot:after>
                        <q-badge color="grey-3" @click.stop>파일찾기</q-badge>
                      </template>
                    </q-file>
                  </div>
                  <p class="txt_exclamation">
                    00MB 이하 용량 / jpg, jpeg, gif, tif, pdf 파일만 등록
                    가능합니다.
                  </p>
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일1</th>
              <td>
                <div class="row-8 gap10">
                  <div class="search_item type_half">
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataFrom.information"
                      label=""
                      class="hide_label file_custom type_short"
                    >
                      <template v-slot:after>
                        <q-badge color="grey-3" @click.stop>파일찾기</q-badge>
                      </template>
                    </q-file>
                  </div>
                  <p class="txt_exclamation">
                    00MB 이하 용량 / jpg, jpeg, gif, tif, pdf 파일만 등록
                    가능합니다.
                  </p>
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일1</th>
              <td>
                <div class="row-8 gap10">
                  <div class="search_item type_half">
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataFrom.information"
                      label=""
                      class="hide_label file_custom type_short"
                    >
                      <template v-slot:after>
                        <q-badge color="grey-3" @click.stop>파일찾기</q-badge>
                      </template>
                    </q-file>
                  </div>
                  <p class="txt_exclamation">
                    00MB 이하 용량 / jpg, jpeg, gif, tif, pdf 파일만 등록
                    가능합니다.
                  </p>
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일1</th>
              <td>
                <div class="row-8 gap10">
                  <div class="search_item type_half">
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataFrom.information"
                      label=""
                      class="hide_label file_custom type_short"
                    >
                      <template v-slot:after>
                        <q-badge color="grey-3" @click.stop>파일찾기</q-badge>
                      </template>
                    </q-file>
                  </div>
                  <p class="txt_exclamation">
                    00MB 이하 용량 / jpg, jpeg, gif, tif, pdf 파일만 등록
                    가능합니다.
                  </p>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <ul class="ul_custom disc text-grey-3">
              <li>증빙자료 (jpg, jpeg, gif, tif, pdf 만 등록 가능합니다.)</li>
              <li>
                차이홍B2B, 드림멘토 사업은 계약서와 회원리스트를 필수로
                첨부하셔야 합니다.
              </li>
              <li>
                체납공제건은 교사가 작성한 체납공제신청서, 회원리스트를 필수로
                첨부하셔야 합니다.
              </li>
            </ul>
          </div>
        </div>

        <!-- 버튼 -->
        <div class="btn_area btn_bottom_type01">
          <q-btn
            unelevated
            outline
            color="grey-4"
            class="size_lg"
            label="취소"
          />
          <q-btn unelevated color="black" class="size_lg" label="신청하기" />
        </div>
        <!-- // 버튼 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const select1Type = ref(['회비조정+']);
const select1TypeOption = ref([
  {
    id: 'select11',
    desc: '회비조정항목1',
  },
  {
    id: 'select12',
    desc: '회비조정항목2 ',
  },
]);

const keyword = ref([]);
const dataFrom = ref({
  id: '',
  name: '',
  txt: '',
  information: null,
  state: '선택하세요',
  allow: 'true',
});

//data테이블
const dataRows = ref([
  {
    idx: 10,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 9,
    tdata1: '눈높이/눈높이/이러닝센터1팀/채널13',
    tdata2: '김김대교[1234567890]',
    tdata3: '홍길길동',
    tdata4: '1234567890123',
    tdata5: '눈높이 수학 초등',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '138,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '11,130,000',
  },
  {
    idx: 8,
    tdata1: '본부/조직/팀/채널',
    tdata2: '대교[12345678]',
    tdata3: '길동',
    tdata4: '12345',
    tdata5: '국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '8,000',
    tdata10: '1',
    tdata11: '3,000',
    tdata12: '1',
    tdata13: '3,000',
  },
  {
    idx: 7,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 6,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 5,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 4,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 3,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 2,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 1,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
]);
</script>
