<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">CMS입금현황조회</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="search1"
                :options="search1Option"
                label="해피콜결과 전체"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="search2"
                :options="search1Option"
                label="담당자명 전체"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword"
                placeholder="주문자명"
              />
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-input
                class="box_l"
                for=""
                outlined
                dense
                v-model="keyword2"
                placeholder="주문자 연락처"
              />
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk row2type">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              총 <span>00</span>건의 검색결과가 있습니다
            </div>
          </div>
          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <q-td key="tdata1" class="text-center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-left">
                  <div>{{ props.row.tdata6 }}</div>
                  <div>{{ props.row.tdata6_2 }}</div>
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>

          <!-- pagination -->
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- // pagination -->
        </div>
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});

const search1 = ref(['해피콜결과 전체']);
const search1Option = ref([
  {
    id: 's11',
    desc: '전체1',
  },
  {
    id: 's12',
    desc: '전체2',
  },
]);
const search2 = ref(['담당자명 전체']);

const keyword = ref(null);
const keyword2 = ref(null);

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '배정일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata2',
    label: '주문일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '쇼핑몰',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '주문자명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '주문자 연락처',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '상품명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '담당자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '해피콜 결과',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '입회등록',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 9,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '11번가',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서',
    tdata6_2: '- 정기배송 독서프로그램',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '12345678',
    tdata10: '회원',
  },
  {
    idx: 8,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '지마켓',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(11개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 100, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '1234567890',
    tdata10: '-',
  },
  {
    idx: 7,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 6,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 5,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 4,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 3,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 2,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
  {
    idx: 1,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    tdata3: '쿠팡',
    tdata4: '백목련',
    tdata5: '010-1234-5678',
    tdata6: '눈높이 창의독서(1개월 구독권)',
    tdata6_2: '- 정기배송 독서프로그램 03, 유아 6세',
    tdata7: '김대교',
    tdata8: '완료',
    tdata9: '123456789',
    tdata10: '비회원',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
