<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree fit_content sales_popup_560">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit w100p text-left">계층/랭킹보기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="ranking_group_btn">
            <q-btn outline class="size_lg" label="전체" />
            <q-btn outline class="size_lg" label="본부별" />
            <q-btn outline class="size_lg" label="조직별" />
            <q-btn outline class="size_lg" label="팀별" />
            <q-btn outline class="size_lg" label="채널별" />
            <q-btn outline class="size_lg" label="선생님" />
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
</script>
<style lang="scss"></style>
