<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">[성장사업] 제품지수현황</h2>
      <Breadcrumbs />
    </div>
    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="제품">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="채널구분">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="학습형태 전체"
                  v-model="searchstudyType"
                  :options="searchstudyTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="계층별 보기"
                  v-model="searchTreeSelected"
                  :options="searchtreeselectedOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <div class="wrap_opt_group">
                  <q-option-group
                    class="opt_group_custom week_type"
                    type="checkbox"
                    color="blue-3"
                    v-model="day"
                    :options="dayOption"
                  />
                </div>
              </div>
              <div class="col-12 col-md-3">
                <q-checkbox
                  v-model="dataCheck"
                  label="교육지원비 적용"
                  class="check_in_search"
                  color="black"
                />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <q-card class="wrap_table_box">
        <!-- general_table type_total -->
        <!-- 합계 있는 테이블 -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 436px"
            class="scrollable sticky_table_header sticky_table_footer"
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :class="props.row.state" :props="props">
                <q-td key="section" class="section text-center">{{
                  props.row.section
                }}</q-td>
                <q-td key="branch" class="organization text-center">
                  {{ props.row.branch }}</q-td
                >
                <q-td key="team" class="team text-center">
                  {{ props.row.team }}</q-td
                >
                <q-td key="chanel" class="chanel text-center">
                  {{ props.row.chanel }}</q-td
                >
                <q-td key="teacher" class="teacher text-center">
                  {{ props.row.teacher }}</q-td
                >
                <q-td key="id" class="employee_number">
                  {{ props.row.id }}</q-td
                >
                <q-td key="countDayIn" class="join_per_day">
                  {{ props.row.countDayIn }}</q-td
                >
                <q-td key="countDayIn2" class="change_per_day">
                  {{ props.row.countDayIn2 }}</q-td
                >
                <q-td key="countDayOut" class="leave_per_day">
                  {{ props.row.countDayOut }}</q-td
                >
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td colspan="6">합계</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
                <q-td class="text-right">0</q-td>
              </q-tr>
            </template>
          </q-table>

          <!-- <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.page"
            direction-links
            boundary-links
            :max-pages="1000"
            :max="pagesNumber"
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
        </div> -->
        </div>
        <!--// general_table type_total-->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>소개입회지수 - 눈높이 교육국 간 소개입회를제외한 소개입회실적</p>
            <p>
              ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
              소개입회지수, 소개퇴회지수 실적임
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
      </q-card>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// const model = ref('tues');
const searchTreeSelected = ref(['계층별 보기']);
const searchtreeselectedOption = ref([
  {
    id: 'tree',
    desc: '계층',
  },
  {
    id: 'lanking',
    desc: '랭킹 ',
  },
]);
const searchstudyType = ref(['학습형태 전체']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
});
const dataCheck = ref(true);
// 검색영역 추가
// const daym1 = ref(['all']);
// const dayOptionm1 = ref([
//   { label: '전체', value: 'all' },
//   { label: '월', value: 'mon' },
//   { label: '화', value: 'tues' },
// ]);
// const daym2 = ref(['wed']);
// const dayOptionm2 = ref([
//   { label: '수', value: 'wed' },
//   { label: '목', value: 'thurs' },
//   { label: '금', value: 'fri' },
// ]);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
// const check1 = ref(false);
// const check2 = ref(false);
// const check3 = ref(false);
// const check4 = ref(false);
// const check5 = ref(false);
// const check6 = ref(false);
// const searchExpand = ref(true);

//data테이블
const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'branch',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.branch,
  },
  {
    name: 'team',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.team,
  },
  {
    name: 'chanel',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.chanel,
  },
  {
    name: 'teacher',
    label: '선생님',
    field: 'teacher',
    sortable: false,
    align: 'center',
    field: (row) => row.teacher,
  },
  {
    name: 'id',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.id,
  },

  {
    name: 'countDayIn',
    label: '일입회     ',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn,
  },
  {
    name: 'countDayIn2',
    label: '일전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn2,
  },
  {
    name: 'countDayOut',
    label: '일퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut,
  },
]);
const dataRows = ref([
  {
    section: '서울본부',
    branch: '강서교육국',
    team: '001팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0000',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '002팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0001',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0002',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '004팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0003',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '005팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0004',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0005',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0006',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0007',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0007',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0008',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0001',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0009',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
  },
  {
    section: '서울서북본부',
    branch: '강서교육국',
    team: '003팀',
    chanel: 'YC1 [바다꿈]',
    teacher: '홍길동',
    id: 'MSG_C0009',
    countDayIn: '111',
    countDayIn2: '22222',
    countDayOut: '3333333333333333',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>

<style lang="scss" scoped>
body
  .q-select.q-field--auto-height.q-field--dense.q-field--labeled
  .q-field__control-container {
  padding-top: 14px;
}
body .q-select.q-field--dense.q-field--float .q-field__label {
  display: block;
}
</style>
<style lang="scss">
// .type_total.top_stikcy {
//   thead {
//     position: sticky;
//     top: 0;
//     z-index: 110;
//     opacity: 1;
//   }
//   .q-tr.tr_btm {
//     position: sticky;
//     bottom: 0;
//     z-index: 110;
//     opacity: 1;
//   }
//   tr > td:first-child,
//   tr > th:first-child {
//     position: sticky;
//     width: 450px;
//     left: 0;
//     z-index: 100;
//     box-shadow: 1px 0px 0px 0px rgba(0, 0, 0, 0.2);
//     background: #fff;
//   }
// }
</style>
