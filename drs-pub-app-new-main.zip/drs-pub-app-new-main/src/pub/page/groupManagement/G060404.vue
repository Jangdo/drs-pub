<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">진도점검관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="선생님별 교재청구점검표" :ripple="false" />
          <q-tab name="tab2" label="진도미결정교사조회" :ripple="false" />
          <q-tab name="tab3" label="진도그래프 점검/추천" :ripple="false" />
          <q-tab name="tab4" label="요일별 진도점검표" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="box_l normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <div class="wrap_opt_group">
                        <q-option-group
                          class="opt_group_custom week_type"
                          type="checkbox"
                          color="blue-3"
                          v-model="day"
                          :options="dayOption"
                        />
                      </div>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-input
                        class="box_l"
                        outlined
                        dense
                        placeholder="제품"
                        v-model="keyword"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-input
                        class="box_l"
                        outlined
                        dense
                        placeholder="회원"
                        v-model="keyword2"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-select
                        class="box_l hide_label"
                        label="발행순서 기본"
                        v-model="search1"
                        :options="search1Option"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>
            <!-- <q-space class="sp30" /> -->
            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                </div>
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="idx"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                </q-table>
              </div>
              <!-- // general_table -->
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab4');
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
const search1 = ref();
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const searchDate = ref({
  from: '2023.06.01',
});
const keyword = ref('');
const keyword2 = ref('');

//data테이블
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: 'No.',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '선생님명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '학년',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '학습과목',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '학습영역',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '진도',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '부교재',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '선택부교재',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 10,
    tdata1: '김김정숙[110031044761]',
    tdata2: '김김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학 1-5',
    tdata5: '10',
    tdata6: '5A40',
    tdata7: '눈높이 수학',
    tdata8: '',
  },
  {
    idx: 9,
    tdata1: '정숙[0031044761]',
    tdata2: '윤찬',
    tdata3: '초등1',
    tdata4: '수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글',
    tdata8: '',
  },
  {
    idx: 8,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 7,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 6,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 5,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 4,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 3,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 2,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
  {
    idx: 1,
    tdata1: '김정숙[0031044761]',
    tdata2: '김윤찬',
    tdata3: '초등1',
    tdata4: '눈높이 수학',
    tdata5: '1',
    tdata6: 'C15',
    tdata7: '눈높이한글똑똑',
    tdata8: '',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
