<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">김대교 [1234567890] 본부명/조직명/팀명/채널명</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <!-- general_table -->
          <div class="table_dk">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                <div class="text-body2 text-grey-1">
                  <span class="text-primary">[인수인계]</span> 00과목의 이동이
                  있습니다
                </div>
              </div>
            </div>

            <q-table
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
            </q-table>
          </div>
          <!-- // general_table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

//data테이블
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '회원',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '과목명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
    classes: 'lw_break',
  },
  {
    name: 'tdata6',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 9,
    tdata1: '김김윤찬',
    tdata2: 'P110909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어 1-2 (DS12345678)',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 8,
    tdata1: '윤찬',
    tdata2: 'P109',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 7,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 6,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 5,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 4,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 3,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 2,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
  {
    idx: 1,
    tdata1: '김윤찬',
    tdata2: 'P10909',
    tdata3: '초등1',
    tdata4: '화',
    tdata5: '대교 써밋 스텝영어',
    tdata6: '화',
    tdata7: '내방',
  },
]);
</script>
