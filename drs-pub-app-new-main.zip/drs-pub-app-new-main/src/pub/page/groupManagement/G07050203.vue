<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">회원/과목 이동 확인서</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="wrap_grey_r_box h82 mb30">
            <p class="title1 text-grey-1">
              승인 <span class="text-primary">처리중</span>입니다.
            </p>
          </div>

          <table class="table_row_sales">
            <tbody>
              <tr>
                <th>이동구분</th>
                <td><span class="text-primary">회원별</span></td>
                <th class="line_l">신청자</th>
                <td>김행정 (00234567)<br />본부명조직명/팀명/채널명</td>
              </tr>
              <tr>
                <th>이동신청일</th>
                <td>2023.02.01</td>
                <th class="line_l">이동예정일</th>
                <td>2023.02.14</td>
              </tr>
              <tr>
                <th>이동사유</th>
                <td colspan="3">이동사유를 이곳에 노출합니다.</td>
              </tr>
            </tbody>
          </table>

          <h4 class="mt60 title1 text-grey-1">이동정보</h4>
          <h5 class="mt30 mb20 title3 text-grey-2">
            김대교 [32002562] - 본부명/조직명/팀명/채널명
          </h5>
          <!-- general_table -->
          <div class="table_dk">
            <q-table
              :rows="data1Rows"
              :columns="data1Columns"
              row-key="idx"
              v-model:pagination="data1Pagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="align_center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="align_center lw_break w220">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td
                    key="tdata7"
                    class="align_center lw_break w320 last_multi_td"
                    rowspan="2"
                  >
                    <div class="text-grey-4">대기중</div>
                    {{ props.row.tdata7 }}
                  </q-td>
                </q-tr>
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="align_center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="align_center lw_break w220">
                    {{ props.row.tdata6 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->

          <h5 class="mt60 mb20 title3 text-grey-2">
            김대교 [32002562] - 본부명/조직명/팀명/채널명
          </h5>
          <!-- general_table -->
          <div class="table_dk">
            <q-table
              :rows="data2Rows"
              :columns="data2Columns"
              row-key="idx"
              v-model:pagination="data2Pagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="align_center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="align_center lw_break w220">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td
                    key="tdata7"
                    class="align_center lw_break w320 last_multi_td"
                    rowspan="2"
                  >
                    <div class="text-red">반려</div>
                    {{ props.row.tdata7 }}
                  </q-td>
                </q-tr>
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="align_center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="align_center lw_break w220">
                    {{ props.row.tdata6 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

//data테이블
const data1Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const data1Columns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '회원',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '과목명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '이동선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '팀장승인',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const data1Rows = ref([
  {
    idx: 10,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 9,
    tdata1: '김김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어 1-5',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [123451167890] 본부1명/조직1명/팀1명/채널1명 - 월',
    tdata7: '-',
  },
  {
    idx: 8,
    tdata1: '윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1567890] 본부/조직/팀/채널 - 월',
    tdata7: '-',
  },
  {
    idx: 7,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 6,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 5,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 4,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 3,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 2,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
  {
    idx: 1,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '-',
  },
]);

const data2Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const data2Columns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '회원',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '과목명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '이동선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '팀장승인',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const data2Rows = ref([
  {
    idx: 10,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 9,
    tdata1: '김김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어 1-5',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1112345890] 본부1명/조직1명/팀1명/채널1명 - 월',
    tdata7:
      '(2023.03.01) 반려사유가 노출됩니다 최대 1000글 노출반려사유가 노출됩니다 최대 1000글 노출반려사유가 노출됩니다 최대 1000글 노출',
  },
  {
    idx: 8,
    tdata1: '윤찬',
    tdata2: '초등1',
    tdata3: '눈높이 국어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [14567890] 본부/조직/팀/채널 - 월',
    tdata7: '(2023.03.01) 반려사유',
  },
  {
    idx: 7,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 6,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 5,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 4,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 3,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 2,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
  {
    idx: 1,
    tdata1: '김윤찬',
    tdata2: '초등1',
    tdata3: '대교 써밋 스텝영어',
    tdata4: '화',
    tdata5: '외방',
    tdata6: '박대교 [1234567890] 본부명/조직명/팀명/채널명 - 월',
    tdata7: '(2023.03.01) 반려사유가 노출됩니다',
  },
]);
</script>
