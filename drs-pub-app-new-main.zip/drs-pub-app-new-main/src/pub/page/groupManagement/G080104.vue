<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">입금미마감현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-12">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <!-- <q-td key="tdata1" class="text-center">
                {{ props.row.tdata1 }}
              </q-td> -->
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="text-center">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="text-center">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="text-center">
                  {{ props.row.tdata13 }}
                </q-td>
                <q-td key="tdata14" class="text-center">
                  {{ props.row.tdata14 }}
                </q-td>
                <q-td key="tdata15" class="text-center">
                  {{ props.row.tdata15 }}
                </q-td>
                <q-td key="tdata16" class="text-right">
                  {{ props.row.tdata16 }}
                </q-td>
                <q-td key="tdata17" class="text-center">
                  {{ props.row.tdata17 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // pagination -->
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  // {
  //   name: 'tdata1',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata1,
  // },
  {
    name: 'tdata2',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '학습상태',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '결제구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
  {
    name: 'tdata14',
    label: '결제일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata14,
  },
  {
    name: 'tdata15',
    label: '최종회비월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
  {
    name: 'tdata16',
    label: '결제금액',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata16,
  },
  {
    name: 'tdata17',
    label: '결제취소/환불일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata17,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '10,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 9,
    // tdata1: '눈높이 사업부문',
    tdata2: '경기 1본부',
    tdata3: '경기병점 1교육국',
    tdata4: '10팀',
    tdata5: '홍홍길동',
    tdata6: '000000000000',
    tdata7: '써밋스코어수학 중동1-5',
    tdata8: 'LC',
    tdata9: '월',
    tdata10: '홍홍길동',
    tdata11: '000000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '11,110,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 8,
    // tdata1: '눈높이',
    tdata2: '본부',
    tdata3: '경기 교육국',
    tdata4: '1팀',
    tdata5: '홍길',
    tdata6: '00000000',
    tdata7: '써밋스코어수학',
    tdata8: 'YC',
    tdata9: '월',
    tdata10: '홍동',
    tdata11: '00000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '111,110,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 7,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '110,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 6,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '1,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 5,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '100',
    tdata17: '2022.11.01',
  },
  {
    idx: 4,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '90',
    tdata17: '2022.11.01',
  },
  {
    idx: 3,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '0',
    tdata17: '2022.11.01',
  },
  {
    idx: 2,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '10,000',
    tdata17: '2022.11.01',
  },
  {
    idx: 1,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '써밋스코어수학 중동1',
    tdata8: 'HC',
    tdata9: '월',
    tdata10: '홍길동',
    tdata11: '0000000000',
    tdata12: '학습중',
    tdata13: '결제구분',
    tdata14: '2022.01.01',
    tdata15: '2022.11.01',
    tdata16: '10,000',
    tdata17: '2022.11.01',
  },
]);
</script>
