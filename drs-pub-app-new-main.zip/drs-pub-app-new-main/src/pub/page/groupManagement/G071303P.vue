<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrap_table_box">
        <!-- sales_subtit_area -->
        <div class="sales_subtit_area">
          <h3 class="title1">기본정보</h3>
        </div>
        <!-- //sales_subtit_area -->

        <table class="table_row_sales">
          <tbody>
            <tr>
              <th>조직코드</th>
              <td>PC010</td>
            </tr>
            <tr>
              <th>조직명</th>
              <td>수원교육국</td>
            </tr>
            <tr>
              <th>부문/본부</th>
              <td><span>눈높이서비스부문</span> I <span>서울서북본부</span></td>
            </tr>
            <tr>
              <th>조직구분</th>
              <td>영업</td>
            </tr>
            <tr>
              <th>조직순번</th>
              <td>0005</td>
            </tr>
            <tr>
              <th>코스트센터</th>
              <td>선택한 코스트센터 표시</td>
            </tr>
            <tr>
              <th>손익센터</th>
              <td>선택한 손익센터 표시</td>
            </tr>
            <tr>
              <th>HR부서코드</th>
              <td>선택한 부서코드 표시</td>
            </tr>
            <tr>
              <th>시작일</th>
              <td>2021.02.01</td>
            </tr>
            <tr>
              <th>종료일</th>
              <td>
                <span>2022.02.01</span> <span>통합</span
                ><span>(대상 교육국 : 수원동부)</span>
              </td>
            </tr>
            <tr>
              <th>전화번호</th>
              <td>02-329-2013</td>
            </tr>
            <tr>
              <th>팩스번호</th>
              <td>02-329-2013</td>
            </tr>
            <tr>
              <th>주소</th>
              <td>[12345] 경기도 수원시 영통구 영통로 21번길 82-12번지 4층</td>
            </tr>
          </tbody>
        </table>

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area">
          <h3 class="title1">변경이력</h3>
        </div>
        <!-- //sales_subtit_area -->

        <div class="general_table mb30">
          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
            class="scrollable tbl_row_4"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="changeDate" class="text-center">
                  {{ props.row.changeDate }}
                </q-td>
                <q-td key="changer" class="text-center">
                  {{ props.row.changer }}
                </q-td>
                <q-td key="changeItem" class="text-center">
                  {{ props.row.changeItem }}
                </q-td>
                <q-td key="changeContents" class="text-center">
                  {{ props.row.changeContents }}
                </q-td>
                <q-td key="changeToContents" class="text-center color_point">
                  {{ props.row.changeToContents }}
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>

        <!-- sales_line_tit_area -->
        <div class="sales_line_tit_area">
          <h3 class="title1">구성원리스트</h3>
          <q-btn
            fill
            unelevated
            color="grey-2"
            class="size_sm"
            label="상세보기"
          />
        </div>
        <!-- //sales_line_tit_area -->

        <div class="btn_area response">
          <q-btn unelevated class="size_lg wide" color="black" label="수정" />
          <q-btn
            unelevated
            color="grey-2"
            class="size_lg btn_position_end"
            label="목록"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataColumns = ref([
  {
    name: 'changeDate',
    label: '변경일자',
    sortable: false,
    align: 'center',
    field: (row) => row.changeDate,
  },
  {
    name: 'changer',
    label: '변경자',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.changer,
  },
  {
    name: 'changeItem',
    label: '변경항목',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.changeItem,
  },
  {
    name: 'changeContents',
    label: '변경전 내용',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.changeContents,
  },
  {
    name: 'changeToContents',
    label: '변경후 내용',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.changeToContents,
  },
]);
const dataRows = ref([
  {
    changeDate: '2023.02.01',
    changer: '이대교(341234)',
    changeItem: '전화',
    changeContents: '02-329-2011',
    changeToContents: '02-329-2011',
    state: true,
    flat: false,
  },
  {
    changeDate: '2023.02.01',
    changer: '이대교(341234)',
    changeItem: '주소',
    changeContents: '경기도 수원시 영통구 영통로 453 2층 ',
    changeToContents: '경기도 수원시 영통구 영통로 453 3층 ',
    state: true,
    flat: false,
  },
  {
    changeDate: '2023.02.01',
    changer: '이대교(341234)',
    changeItem: '명칭',
    changeContents: '양천A 교육국',
    changeToContents: '양천1 교육국',
    state: true,
    flat: false,
  },
  {
    changeDate: '2023.02.01',
    changer: '이대교(341234)',
    changeItem: '주소',
    changeContents: '경기도 수원시 영통구 영통로 450 1층 ',
    changeToContents: '경기도 수원시 영통구 영통로 453 2층 ',
    state: true,
    flat: false,
  },
  {
    changeDate: '2023.02.01',
    changer: '이대교(341234)',
    changeItem: '명칭',
    changeContents: '양천3 교육국',
    changeToContents: '양천4 교육국',
    state: true,
    flat: false,
  },
]);
</script>
