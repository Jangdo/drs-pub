<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
                style="flex: 10000 1 0%"
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_contents_box">
        <!-- 상단정보 -->
        <div class="con_tab_head">
          <div class="con_tab_head-top">
            <p class="title1">2023년 11월</p>
          </div>
          <div class="con_tab_head-bottom">
            <div class="title4 text-grey-4 dept_info">
              <span>서울서북본부</span>
              <span>강서교육국</span>
              <span>001팀</span>
              <span class="title3 text-grey-1">YC1[바다꿈] 운영현황</span>
              <!-- 서울서북본부 > 강서교육국 > 001팀 > YC1[바다꿈] 운영현황 -->
            </div>
            <div class="body2 text-grey-3 manager_info" 담당자>
              <span>팀장 <strong class="text-black">홍길동</strong></span>
              <span>SC교사 <strong class="text-black">김대교</strong></span>
              <span class="text-orange">직영</span>
            </div>
          </div>
        </div>
        <!-- //상단정보 -->

        <!-- 콘텐츠박스 내 탭 픽스타입 -->
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            inline-label
            class="tab_line type02"
            active-bg-color="white"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" label="영업현황" :ripple="false" />
            <q-tab name="tab2" label="회원매출/입금" :ripple="false" />
            <q-tab name="tab3" label="관리지표" :ripple="false" />
            <q-tab name="tab4" label="서비스지표" :ripple="false" />
            <q-tab name="tab5" label="출결율" :ripple="false" />
            <q-tab name="tab6" label="과목/학습방법 현황" :ripple="false" />
          </q-tabs>
          <q-tab-panels v-model="tab" animated>
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1">
              <div class="row row_sales_complex">
                <div class="col left chart">
                  <!-- 차트 -->
                  <div class="wrap_highcharts">
                    <vue-highcharts
                      :options="chart_column_stack"
                    ></vue-highcharts>
                  </div>
                  <!-- //차트 -->
                </div>
                <div class="col right expansion">
                  <q-list class="sales_state">
                    <!-- 기본 열림상태 default-opened 추가 -->
                    <q-expansion-item
                      class="expansion_custom type_sales"
                      expand-icon-toggle
                      default-opened
                    >
                      <template v-slot:header>
                        <q-item-section class="title3"> 입회 </q-item-section>
                        <q-item-section side>
                          <div class="row items-center title3">
                            <span class="text-warning">316</span
                            ><span class="text-grey-3">/</span
                            ><span>1,237.4</span>
                          </div>
                        </q-item-section>
                      </template>
                      <q-card>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>과목수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc black">외방(비중)</th>
                              <td class="normal">
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc positive">내방(비중)</th>
                              <td class="normal">
                                <span>14</span>
                                <span>(70%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                        <q-separator class=""></q-separator>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>제품지수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th>평가점수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                      </q-card>
                    </q-expansion-item>
                    <q-expansion-item
                      class="expansion_custom type_sales"
                      expand-icon-toggle
                    >
                      <template v-slot:header>
                        <q-item-section class="title3"> 퇴회 </q-item-section>
                        <q-item-section side>
                          <div class="row items-center title3">
                            <span class="text-orange">316</span
                            ><span class="text-grey-3">/</span
                            ><span>1,237.4</span>
                          </div>
                        </q-item-section>
                      </template>
                      <q-card>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>과목수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc black">외방(비중)</th>
                              <td class="normal">
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc positive">내방(비중)</th>
                              <td class="normal">
                                <span>14</span>
                                <span>(70%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                        <q-separator class=""></q-separator>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>제품지수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th>평가점수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                      </q-card>
                    </q-expansion-item>
                    <q-expansion-item
                      class="expansion_custom type_sales"
                      expand-icon-toggle
                    >
                      <template v-slot:header>
                        <q-item-section class="title3"> 순증 </q-item-section>
                        <q-item-section side>
                          <div class="row items-center title3">
                            <span class="text-positive">316</span
                            ><span class="text-grey-3">/</span
                            ><span>1,237.4</span>
                          </div>
                        </q-item-section>
                      </template>
                      <q-card>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>과목수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc black">외방(비중)</th>
                              <td class="normal">
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th class="list_disc positive">내방(비중)</th>
                              <td class="normal">
                                <span>14</span>
                                <span>(70%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                        <q-separator class=""></q-separator>
                        <q-card-section>
                          <table class="expansion_content_tbl">
                            <tr>
                              <th>제품지수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                            <tr>
                              <th>평가점수(율)</th>
                              <td>
                                <span>20</span>
                                <span>(3.83%)</span>
                              </td>
                            </tr>
                          </table>
                        </q-card-section>
                      </q-card>
                    </q-expansion-item>
                    <q-expansion-item
                      class="expansion_custom type_sales"
                      expand-icon-toggle
                    >
                      <template v-slot:header>
                        <q-item-section class="title3"> 현재 </q-item-section>
                        <q-item-section side>
                          <div class="row items-center title3">
                            <span class="text-primary">316</span
                            ><span class="text-grey-3">/</span
                            ><span>1,237.4</span>
                          </div>
                        </q-item-section>
                      </template>
                      <q-card>
                        <q-card-section class="pd0">
                          <div class="tbl_total_box">
                            <div class="body1">과목수</div>
                            <div class="total_box_area">
                              <div class="body1 first"></div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >현재</q-badge
                                  >
                                </div>
                                99,250
                              </div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >월초</q-badge
                                  >
                                </div>
                                96,946
                              </div>
                            </div>
                            <div class="bg-white">
                              <div class="total_box_area">
                                <div class="body2 text-grey-2 first">
                                  <span class="bullet black">외방</span>
                                </div>
                                <div class="body2 text-grey-2 text-right">
                                  56,500
                                </div>
                                <div class="body2 text-grey-2 text-right">
                                  56,500
                                </div>
                              </div>
                              <div class="total_box_area">
                                <div class="body2 text-grey-2 first">
                                  <span class="bullet positive">내방</span>
                                </div>
                                <div class="body2 text-grey-2 text-right">
                                  56,500
                                </div>
                                <div class="body2 text-grey-2 text-right">
                                  56,500
                                </div>
                              </div>
                            </div>
                            <div class="bg-white mt10">
                              <div class="text-center body1 text-primary">
                                +2,304
                              </div>
                            </div>
                            <q-separator class="mt20 mb20"></q-separator>
                            <div class="body1">제품목수</div>
                            <div class="total_box_area">
                              <div class="body1 first"></div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >현재</q-badge
                                  >
                                </div>
                                399,250.1
                              </div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >월초</q-badge
                                  >
                                </div>
                                96,946
                              </div>
                            </div>
                            <div class="bg-white mt10">
                              <div class="text-center body1 text-primary">
                                -8,304.1
                              </div>
                            </div>
                            <q-separator class="mt20 mb20"></q-separator>
                            <div class="body1">평가목수</div>
                            <div class="total_box_area">
                              <div class="body1 first"></div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >현재</q-badge
                                  >
                                </div>
                                399,250.1
                              </div>
                              <div class="body1 text-right">
                                <div class="mb5">
                                  <q-badge color="grey-4" class="small"
                                    >월초</q-badge
                                  >
                                </div>
                                96,946
                              </div>
                            </div>
                            <div class="bg-white mt10">
                              <div class="text-center body1 text-primary">
                                -8,304.1
                              </div>
                            </div>
                          </div>
                        </q-card-section>
                      </q-card>
                    </q-expansion-item>
                  </q-list>
                </div>
              </div>
            </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2">
              상하단라인 좌측여백 fix 내용2
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3">
              상하단라인 좌측여백 fix 내용3
            </q-tab-panel>
            <!--// tab3 컨텐츠 -->
            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4">
              상하단라인 좌측여백 fix 내용4
            </q-tab-panel>
            <!--// tab4 컨텐츠 -->
            <!-- tab5 컨텐츠 -->
            <q-tab-panel name="tab5">
              상하단라인 좌측여백 fix 내용5
            </q-tab-panel>
            <!--// tab5 컨텐츠 -->
            <!-- tab6 컨텐츠 -->
            <q-tab-panel name="tab6">
              상하단라인 좌측여백 fix 내용6
            </q-tab-panel>
            <!--// tab6 컨텐츠 -->
          </q-tab-panels>
        </div>
        <!-- //콘텐츠박스 내 탭 픽스타입 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
// import HighchartsMore from 'highcharts/highcharts-more';
// import accessibility from 'highcharts/modules/accessibility';
// import Highcharts from 'highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const chart_column_stack = {
  colors: ['#339F63', '#000000', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'], // 차트바 컬럼 색상 배열
  chart: {
    type: 'column',
    backgroundColor: '#F1F7FB', // 차트 배경색
  },
  title: false,
  subtitle: false,
  xAxis: {
    categories: ['입회', '퇴회', '순증', '현재'],
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: {
    title: false,
    labels: {
      style: {
        textOutline: false,
        color: '#000',
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'Pretendard',
      },
    },
  },
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 10, // 칼럼 레전드 상단 여백
    itemMarginBottom: 10, // 칼럼 레전드 하단 여백
    itemStyle: {
      color: '#000',
      fontWeight: 500,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  tooltip: {
    headerFormat: '<b>{point.x}</b><br/>',
    pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}',
  },
  plotOptions: {
    column: {
      stacking: 'normal',
      dataLabels: {
        enabled: true,
      },
    },
  },
  series: [
    {
      borderWidth: 0,
      name: '내방',
      data: [180, 180, 30, 100],
      dataLabels: [
        {
          // pointFormat:
          //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          format: '{point.y}%',
          enabled: false,
          inside: true,
          style: {
            textOutline: false,
            color: '#fff',
            fontSize: 12,
            fontWeight: '400',
            fontFamily: 'Pretendard',
          },
        },
      ],
    },
    {
      borderWidth: 0,
      name: '외방',
      data: [119, 120, 30, 280],
      dataLabels: [
        {
          // pointFormat:
          //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          format: '{point.y}%',
          enabled: false,
          inside: true,
          style: {
            textOutline: false,
            color: '#fff',
            fontSize: 12,
            fontWeight: '400',
            fontFamily: 'Pretendard',
          },
        },
      ],
    },
  ],
};

// table_search_area

// const readonlyInput1 = ref('부문');
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');
// const searchExpand = ref(true);

const searchDate = ref({
  from: '2023.05.03',
  to: '2023.05.03',
});

// 탭
const tab = ref('tab1');
</script>
