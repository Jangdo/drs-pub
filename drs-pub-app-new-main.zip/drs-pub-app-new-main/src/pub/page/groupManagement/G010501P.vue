<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 small">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">문항별 평점</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <q-expansion-item class="expansion_custom type07" default-opened>
            <template v-slot:header>
              <div class="qna">
                <q-badge color="brown-2" class="square">Q1</q-badge>
                <span class="question"
                  >선생님께서 수업 약속 시간을 잘 지켜주셨나요? 을 잘
                  지켜주셨나요? 을 잘 지켜주셨나요? 을 잘 지켜주셨나요?</span
                >
              </div>
            </template>
            <p class="answer">
              회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요. 회원이 센터 등을 방문하는 경우는
              선생님께서 출석현황을 파악하고 관리해주셨는지 응답해주세요. 회원이
              센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요.
            </p>
          </q-expansion-item>

          <q-expansion-item class="expansion_custom type07">
            <template v-slot:header>
              <div class="qna">
                <q-badge color="brown-2" class="square">Q2</q-badge>
                <span class="question"
                  >지난 학습 점검과 금주 학습 내용을 지도해주셨나요?</span
                >
              </div>
            </template>
            <p class="answer">
              회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요.
            </p>
          </q-expansion-item>

          <q-expansion-item class="expansion_custom type07">
            <template v-slot:header>
              <div class="qna">
                <q-badge color="brown-2" class="square">Q3</q-badge>
                <span class="question"
                  >회원에게 칭찬과 격려 등 동기부여를 해주셨나요?</span
                >
              </div>
            </template>
            <p class="answer">
              회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요.
            </p>
          </q-expansion-item>

          <q-expansion-item class="expansion_custom type07">
            <template v-slot:header>
              <div class="qna">
                <q-badge color="brown-2" class="square">Q4</q-badge>
                <span class="question"
                  >학습현황, 계획 등 학습상담을 해주셨나요? (면대면,전화,문자
                  등)</span
                >
              </div>
            </template>
            <p class="answer">
              회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요.
            </p>
          </q-expansion-item>

          <q-expansion-item class="expansion_custom type07">
            <template v-slot:header>
              <div class="qna">
                <q-badge color="brown-2" class="square">Q5</q-badge>
                <span class="question"
                  >선생님의 학습관리에 대해 전반적으로 만족하셨나요?</span
                >
              </div>
            </template>
            <p class="answer">
              회원이 센터 등을 방문하는 경우는 선생님께서 출석현황을 파악하고
              관리해주셨는지 응답해주세요.
            </p>
          </q-expansion-item>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);
</script>
