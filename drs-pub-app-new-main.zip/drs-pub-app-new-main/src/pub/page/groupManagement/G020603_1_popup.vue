<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="dialog_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">순증지수 변경 이력</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row justify-between items-center mb14">
            <dl class="row">
              <dt class="title1">2022년 09월 수입금액 :</dt>
              <dd class="title1 pl5"><span>48,998,000</span>원</dd>
            </dl>
            <div class="row justify-end">
              <q-btn class="size_sm" outline label="선택삭제" />
              <q-btn class="size_sm ml10" outline label="행추가" />
            </div>
          </div>
          <!-- table -->
          <div class="general_table">
            <q-table
              class="multi_head"
              :rows="dataRows"
              v-model:selected="selected"
              selection="multiple"
              row-key="tdata1"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header>
                <tr>
                  <th rowspan="2">선택</th>
                  <th rowspan="2">지출항목</th>
                  <th colspan="2">본부</th>
                  <th rowspan="2">금액</th>
                  <th rowspan="2">비고(내용추가)</th>
                </tr>
                <tr>
                  <th class="row_first text-center">년월</th>
                  <th class="text-center">일</th>
                </tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="check" class="text-center">
                    <q-checkbox v-model="props.selected" color="black" />
                  </q-td>
                  <q-td key="tdata1" class="text-center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="text-center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="selectDay" class="text-center">
                    <q-select
                      class="box_m"
                      v-model="props.row.selectDay"
                      :options="selectDayOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                      :class="[dataSelect == 0 ? 'placehoder' : '']"
                    >
                    </q-select>
                  </q-td>
                  <q-td key="writePrice" class="text-center">
                    <q-input
                      outlined
                      v-model="props.row.writePrice"
                      :error="props.row.writePrice.sample_err"
                      placeholder="0"
                      dense
                      input-class="text-right"
                    >
                    </q-input>
                  </q-td>
                  <q-td key="tdata3" class="text-left">
                    {{ props.row.tdata3 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

//data테이블
const selected = ref([]);
const selectDayOption = ref([
  {
    id: 'day1',
    desc: '1',
  },
  {
    id: 'day2',
    desc: '2',
  },
  {
    id: 'day3',
    desc: '3',
  },
]);
const dataRows = ref([
  {
    check: '',
    tdata1: '임차료',
    tdata2: '2022.09',
    selectDay: '1',
    writePrice: '500',
    tdata3: '-',
  },
  {
    check: '',
    tdata1: '관리비',
    tdata2: '2022.10',
    selectDay: '2',
    writePrice: '0',
    tdata3: '비고내용',
  },
  {
    check: '',
    tdata1: '커피 및 기타 음료',
    tdata2: '2022.11',
    selectDay: '1',
    writePrice: '1,000,000,000',
    tdata3: '랩노쉬프로틴드링크',
  },
  {
    check: '',
    tdata1: '강사료',
    tdata2: '2022.12',
    selectDay: '2',
    writePrice: '1,000,000',
    tdata3: '',
  },
  {
    check: '',
    tdata1: '소모품비',
    tdata2: '2023.01',
    selectDay: '3',
    writePrice: '500',
    tdata3: '-',
  },
]);

const popForm = ref(true);
</script>
