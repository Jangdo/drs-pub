<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">성과관리현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="[눈높이] 성과관리 현황" :ripple="false" />
          <q-tab name="tab2" label="[솔루니] 성과관리 현황" :ripple="false" />
          <q-tab name="tab3" label="[눈높이] 총원성장/매출" :ripple="false" />
          <q-tab name="tab4" label="[솔루니] 총원성장 /매출" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="box_l normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM"
                              years-in-month-view
                              :emit-immediately="true"
                              default-view="Months"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </div>

            <div class="wrap_table_box">
              <!-- q-markup table -->
              <q-markup-table wrap-cells>
                <thead>
                  <tr>
                    <th></th>
                    <th>목표</th>
                    <th>실적</th>
                    <th class="text-orange">달성률(%)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th class="bg-grey-8 text-left">순증</th>
                    <td class="text-center">24</td>
                    <td class="text-center">16</td>
                    <td class="text-center text-orange text-h3">54</td>
                  </tr>
                  <tr>
                    <th class="bg-grey-8 text-left border_top_1">순증지수</th>
                    <td class="text-center">24.4</td>
                    <td class="text-center">24.3</td>
                    <td class="text-center text-orange text-h3">98</td>
                  </tr>
                </tbody>
              </q-markup-table>
              <!-- // q-markup table -->
            </div>

            <!-- sub tab-->
            <div class="wrapper_tab mt30">
              <q-tabs
                v-model="tabSub"
                inline-label
                class="tab_line border_top_1"
                active-bg-color="white"
                active-color="primary"
                indicator-color="primary"
                align="justify"
                narrow-indicator
                outside-arrows
              >
                <q-tab name="tab1" label="총원성장" :ripple="false" />
                <q-tab name="tab2" label="매출" :ripple="false" />
              </q-tabs>
              <q-tab-panels v-model="tabSub" animated>
                <!-- tab1 컨텐츠 -->
                <q-tab-panel name="tab1">
                  <div class="wrap_table_box">
                    <!-- 버튼 -->
                    <div class="btn_area type_g1">
                      <q-btn class="size_sm btn_excel" outline label="">
                        <q-icon class="svg_icon filter-positive" />
                      </q-btn>
                    </div>
                    <!-- // 버튼 -->

                    <!-- 차트 + 테이블 -->
                    <div class="wrap_flex_l927">
                      <!-- 차트 -->
                      <div class="wrap_highcharts" style="min-height: 400px">
                        <vue-highcharts
                          :options="chart_column_shadow_line"
                        ></vue-highcharts>
                      </div>
                      <!-- // 차트 -->
                      <!-- 테이블 -->
                      <div class="table_dk">
                        <div class="table_top">
                          <div class="info_wrap col-12 col-md-4">
                            <div class="row-4 title4">
                              <span>서울서북본부</span>
                              <span class="text-grey-4">></span>
                              <span class="title3 text-grey-1">강서교육국</span>
                            </div>
                          </div>
                        </div>

                        <!-- q-markup table -->
                        <q-markup-table
                          separator="cell"
                          class="scrollable h930 sticky_table_header"
                          wrap-cells
                        >
                          <thead>
                            <tr>
                              <th colspan="2">구분</th>
                              <th>순증수</th>
                              <th>순증지수</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-center">1월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>10,000.0</div>
                                  <div>100,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">2월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">3월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center bg-blue-3">1Q</td>
                              <td class="text-center bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">4월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">5월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">6월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center bg-blue-3">2Q</td>
                              <td class="text-center bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">7월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">8월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">9월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center bg-blue-3">3Q</td>
                              <td class="text-center bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">10월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">11월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center">12월</td>
                              <td class="text-center pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td class="text-center bg-blue-3">4Q</td>
                              <td class="text-center bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>목표</div>
                                  <div>실적</div>
                                  <div>달성율</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                              <td class="text-right bg-blue-3 pa0">
                                <div class="w100p">
                                  <div>100</div>
                                  <div>1,000.0</div>
                                  <div>1,000.0</div>
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </q-markup-table>
                        <!-- // q-markup table -->
                      </div>
                    </div>
                    <!-- 참고하세요 -->
                    <div class="wrap_info_box">
                      <div class="tit_area">
                        <q-icon name="info" class="icon_svg filter-grey-3" />
                        <span>참고하세요</span>
                      </div>
                      <div class="content">
                        <p>
                          성과관리현황 매출액은 D+10일 이후 전월 실적이 업로드
                          됩니다.
                        </p>
                      </div>
                    </div>
                    <!-- // 참고하세요 -->
                    <!-- // 차트 + 테이블 -->
                  </div>
                </q-tab-panel>
                <!--// tab1 컨텐츠 -->

                <!-- tab2 컨텐츠 -->
                <q-tab-panel name="tab2"> tab2 </q-tab-panel>
                <!--// tab2 컨텐츠 -->
              </q-tab-panels>
            </div>
            <!-- // sub tab -->
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> 탭2 </q-tab-panel>
          <!-- // tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> 탭3 </q-tab-panel>
          <!-- // tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> 탭4 </q-tab-panel>
          <!-- // tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// import HighchartsMore from 'highcharts/highcharts-more';
// import accessibility from 'highcharts/modules/accessibility';
// import Highcharts from 'highcharts';

const tab = ref('tab1');
const tabSub = ref('tab1');

// table_search_area
const searchDate = ref({
  from: '2023.06',
});

const chart_column_shadow_line = {
  chart: {
    backgroundColor: '#F1F7FB',
  },
  title: false,
  xAxis: {
    lineColor: '#000',
    lineWidth: 2,
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    labels: {
      format: '{value}',
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: [
    {
      // Primary yAxis
      labels: {
        format: '{value}',
        style: {
          color: '#000',
          fontSize: 12,
          fontWeight: 700,
          fontFamily: 'Pretendard',
        },
      },
      title: false,
    },
    {
      // Secondary yAxis
      title: false,
      labels: {
        format: '{value} %',
        style: {
          color: '#000',
          fontSize: 12,
          fontWeight: 700,
          fontFamily: 'Pretendard',
        },
      },
      opposite: true,
    },
  ],
  legend: {
    //  layout: 'vertical',
    align: 'left',
    verticalAlign: 'top',
    itemMarginTop: 0,
    itemMarginBottom: 8,
    itemStyle: {
      color: '#000',
      fontWeight: 700,
      fontFamily: 'Pretendard',
      fontSize: '14px',
    },
  },
  tooltip: {
    shared: false,
  },
  plotOptions: {
    column: {
      grouping: false,
      shadow: false,
      borderWidth: 0,
      borderRadius: 2,
      pointWidth: 24,
    },
  },

  series: [
    {
      type: 'column',
      name: '목표',
      color: 'rgba(85 ,93, 103 ,0.4)',
      data: [50, 50, 50, 50, 50],
      pointPadding: 0.3,
      // pointPlacement: -0.2,
    },
    {
      type: 'column',
      name: '실적',
      color: '#555D67',
      data: [11, 33, 17, 34, 28],
      pointPadding: 0.3,
      // pointPlacement: -0.2,
      dataLabels: [
        {
          // pointFormat:
          //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          format: '{point.y}',
          enabled: true,
          inside: true,
          style: {
            textOutline: false,
            color: '#fff',
            fontSize: 12,
            fontWeight: '400',
            fontFamily: 'Pretendard',
          },
        },
      ],
    },
    {
      yAxis: 1,
      type: 'line',
      name: '달성율',
      data: [88, 90, 82, 94, 90],
      marker: {
        lineWidth: 2,
        lineColor: '#F27321',
        fillColor: '#F27321',
      },
    },
  ],
};
</script>
