<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="기본정보" :ripple="false" />
          <q-tab name="tab2" label="채널정보" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2">
            <div class="wrap_table_box">
              <!-- sales_subtit_area -->
              <div class="sales_subtit_area">
                <h3 class="title1">채널정보</h3>
              </div>
              <!-- //sales_subtit_area -->

              <table class="table_row_sales">
                <tbody>
                  <tr>
                    <th>소개</th>
                    <td>
                      <div class="search_item type_full">
                        <q-input
                          class="box_xl inp_search"
                          outlined
                          placeholder="입력하세요"
                        ></q-input>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>이미지 등록</th>
                    <td>
                      <!-- 이미지 등록 : 파일 첨부 후 -->
                      <div class="select_img_area">
                        <!-- 입력 영역 -->
                        <div class="write_group">
                          <div class="search_item type_small">
                            <q-input
                              class="box_xl inp_search"
                              outlined
                              placeholder="순번 입력"
                            ></q-input>
                          </div>
                          <div class="search_item">
                            <q-input
                              class="box_xl inp_search"
                              outlined
                              placeholder="이미지 제목을 입력하세요"
                            ></q-input>
                          </div>
                        </div>
                        <!-- // 입력 영역 -->

                        <!-- 파일 찾기 -->
                        <q-file
                          outlined
                          dense
                          clearable
                          v-model="dataFrom.information"
                          label="영등포 교육국_2월이벤트.jpg"
                          class="hide_label file_custom type_short"
                        >
                          <template v-slot:after>
                            <q-badge color="grey-2" @click.stop
                              >찾아보기</q-badge
                            >
                          </template>
                        </q-file>
                        <!-- // 파일 찾기 -->

                        <!-- 파일명 -->
                        <div class="file_name_area">
                          <span class="file_name"
                            >영등포 교육국_2월이벤트.jpg</span
                          >
                          <q-btn fill class="btn_delete" />
                        </div>
                        <!-- // 파일명 -->
                      </div>
                      <!-- // 이미지 등록 : 파일 첨부 후-->
                      <!-- 이미지 등록 : 파일 첨부 전-->
                      <div class="select_img_area">
                        <!-- 입력 영역 -->
                        <div class="write_group">
                          <div class="search_item type_small">
                            <q-input
                              class="box_xl inp_search"
                              outlined
                              placeholder="순번 입력"
                            ></q-input>
                          </div>
                          <div class="search_item">
                            <q-input
                              class="box_xl inp_search"
                              outlined
                              placeholder="이미지 제목을 입력하세요"
                            ></q-input>
                          </div>
                        </div>
                        <!-- // 입력 영역 -->

                        <!-- 파일 찾기 -->
                        <q-file
                          outlined
                          dense
                          clearable
                          v-model="dataFrom.information"
                          label=""
                          class="hide_label file_custom type_short"
                        >
                          <template v-slot:after>
                            <q-badge color="grey-2" @click.stop
                              >찾아보기</q-badge
                            >
                          </template>
                        </q-file>
                        <!-- // 파일 찾기 -->

                        <!-- 추가 버튼 -->
                        <q-btn
                          fill
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="추가"
                        />
                        <!-- // 추가 버튼 -->
                      </div>
                      <!-- // 이미지 등록 : 파일 첨부 전-->
                      <p class="txt_exclamation">
                        이미지는 최대 8장까지 등록할 수 있습니다.
                      </p>
                    </td>
                  </tr>
                  <tr>
                    <th>운영시간</th>
                    <td>
                      <div class="time_area">
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            v-model="timeStart"
                            :options="timeStartOption"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            label="09:00"
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <span class="text-body2 hidden_m">~</span>
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            v-model="timeFinish"
                            :options="timeFinishOption"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            label="09:00"
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>학원등록번호</th>
                    <td>
                      <div class="search_item">
                        <q-input class="box_xl inp_search" outlined></q-input>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>SNS URL관리</th>
                    <td>
                      <!-- item -->
                      <div class="sns_url_area">
                        <!-- 드롭다운 -->
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            v-model="snsUrlType"
                            :options="snsUrlTypeOption"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            label="선택하세요"
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <!-- // 드롭다운 -->
                        <!-- 인풋 -->
                        <div class="search_item type_large">
                          <q-input
                            class="box_xl inp_search"
                            outlined
                            placeholder="입력하세요"
                          ></q-input>
                        </div>
                        <!-- // 인풋 -->
                      </div>
                      <!-- // item -->

                      <!-- item -->
                      <div class="sns_url_area">
                        <!-- 드롭다운 -->
                        <div class="search_item type_medium">
                          <q-select
                            class="hide_label"
                            v-model="snsUrlType2"
                            :options="snsUrlTypeOption2"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            label="선택하세요"
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <!-- // 드롭다운 -->
                        <!-- 인풋 -->
                        <div class="search_item type_large">
                          <q-input
                            class="box_xl inp_search"
                            outlined
                            placeholder="입력하세요"
                          ></q-input>
                        </div>
                        <!-- // 인풋 -->
                      </div>
                      <!-- // item -->
                      <q-btn
                        fill
                        unelevated
                        color="grey-3"
                        class="size_sm"
                        label="추가"
                      />
                    </td>
                  </tr>
                  <tr>
                    <th>편의시설</th>
                    <td>
                      <q-option-group
                        v-model="convenientOptionsGroup"
                        :options="convenientOptions"
                        color="black"
                        type="checkbox"
                        inline
                      />
                    </td>
                  </tr>
                  <tr>
                    <th>교실수</th>
                    <td>
                      <div class="search_item type_small">
                        <q-input class="box_xl inp_search" outlined></q-input>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>좌석수</th>
                    <td>
                      <div class="search_item type_small">
                        <q-input class="box_xl inp_search" outlined></q-input>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>

              <div class="btn_area response">
                <q-btn unelevated outline class="size_lg wide" label="취소" />
                <q-btn
                  unelevated
                  color="black"
                  class="size_lg wide"
                  label="저장"
                />
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_lg btn_position_end"
                  label="목록"
                />
              </div>
            </div>
          </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab2');

// table_search_area
const dataFrom = ref({
  information: null,
});

const convenientOptionsGroup = ref(['op1']);
const convenientOptions = ref([
  {
    label: '주차',
    value: 'op1',
  },
  {
    label: '학부모 대기공간',
    value: 'op2',
  },
  {
    label: '멀티학습관',
    value: 'op3',
  },
]);

const snsUrlType = ref(['']);
const snsUrlTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const snsUrlType2 = ref(['']);
const snsUrlTypeOption2 = ref([
  {
    id: 'type3',
    desc: '타입1',
  },
  {
    id: 'type4',
    desc: '타입2',
  },
]);

const timeStart = ref(['']);
const timeStartOption = ref([
  {
    id: 'timeStartType1',
    desc: '09:00',
  },
  {
    id: 'timeStartType2',
    desc: '10:00',
  },
  {
    id: 'timeStartType3',
    desc: '11:00',
  },
  {
    id: 'timeStartType4',
    desc: '12:00',
  },
  {
    id: 'timeStartType5',
    desc: '13:00',
  },
  {
    id: 'timeStartType6',
    desc: '14:00',
  },
  {
    id: 'timeStartType7',
    desc: '15:00',
  },
  {
    id: 'timeStartType8',
    desc: '16:00',
  },
  {
    id: 'timeStartType9',
    desc: '17:00',
  },
  {
    id: 'timeStartType10',
    desc: '18:00',
  },
]);

const timeFinish = ref(['']);
const timeFinishOption = ref([
  {
    id: 'timeFinishType1',
    desc: '09:00',
  },
  {
    id: 'timeFinishType2',
    desc: '10:00',
  },
  {
    id: 'timeFinishType3',
    desc: '11:00',
  },
  {
    id: 'timeFinishType4',
    desc: '12:00',
  },
  {
    id: 'timeFinishType5',
    desc: '13:00',
  },
  {
    id: 'timeFinishType6',
    desc: '14:00',
  },
  {
    id: 'timeFinishType7',
    desc: '15:00',
  },
  {
    id: 'timeFinishType8',
    desc: '16:00',
  },
  {
    id: 'timeFinishType9',
    desc: '17:00',
  },
  {
    id: 'timeFinishType10',
    desc: '18:00',
  },
]);
</script>
