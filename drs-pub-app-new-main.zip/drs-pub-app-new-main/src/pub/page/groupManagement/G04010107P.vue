<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 small">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">참고하세요</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="mb20">
            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">1</span>
                  </q-badge>
                  <span class="question">평가총원성장지수</span>
                </div>
              </template>
              <p class="answer">
                현재총원지수 - 월초총원지수 + 전출지수 - 전입지수
              </p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">2</span>
                  </q-badge>
                  <span class="question">평가총원성장지수 달성률</span>
                </div>
              </template>
              <p class="answer">평가총원성장지수 / 목표지수 x 100</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">3</span>
                  </q-badge>
                  <span class="question">평가총원성장지수율</span>
                </div>
              </template>
              <p class="answer">평가총원성장지수 / 월초총원지수 x 100</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">4</span>
                  </q-badge>
                  <span class="question">제품지수</span>
                </div>
              </template>
              <p class="answer">현재총원지수 / 현재총원</p>
            </q-expansion-item>

            <q-expansion-item
              class="expansion_custom type071"
              default-opened
              expand-icon-toggle
            >
              <template v-slot:header>
                <div class="qna">
                  <q-badge color="grey-7" class="square">
                    <span class="body1 text-grey-2">5</span>
                  </q-badge>
                  <span class="question"
                    >디스크립션 없는 타입 : 증빙번호 수정시
                    [소비자소득공제용/사업자지출증빙요]을 정확히 체크하시기
                    바랍니다.</span
                  >
                </div>
              </template>
            </q-expansion-item>
          </div>
        </q-card-section>
        <!-- <q-card-actions class="dialog_actions">
          <q-btn
            outline
            v-close-popup
            icon=""
            class="size_sm btn_reset"
            label="초기화"
          />
          <q-btn
            fill unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="검색"
          />
        </q-card-actions> -->
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
</script>

<style scoped>
body.screen--lg .q-dialog .q-card.respons_card.type_02.small {
  width: 600px;
  min-height: unset;
}
</style>
