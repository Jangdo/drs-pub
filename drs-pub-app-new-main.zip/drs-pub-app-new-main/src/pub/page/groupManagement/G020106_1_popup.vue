<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class=" ">
      <q-card class="respons_card border">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">이미지 확대보기</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <ul>
            <li class="title3">이미지 제목 노출영역</li>
            <li class="img_outline">
              <q-img :src="url" spinner-color="white" class="" />
            </li>
          </ul>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

// img
const url = ref('https://picsum.photos/700/520');
</script>
