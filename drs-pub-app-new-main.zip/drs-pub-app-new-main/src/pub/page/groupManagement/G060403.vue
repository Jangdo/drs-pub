<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">이체제외/수정</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- 탭 영역 -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="선생님별 교재청구점검표 " :ripple="false" />
          <q-tab name="tab2" label="진도미결정교사 조회" :ripple="false" />
          <q-tab name="tab3" label="진도그래프 점검/추천" :ripple="false" />
          <q-tab name="tab4" label="요일별 진도점검표" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> tab1 내용 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 내용 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="row q-col-gutter-sm" v-if="stateHandle">
                  <div class="col-12 col-md-3">
                    <div class="wrap_opt_group">
                      <q-option-group
                        class="opt_group_custom week_type"
                        type="checkbox"
                        color="blue-3"
                        v-model="day"
                        :options="dayOption"
                      />
                    </div>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-input
                      class="inp_search"
                      outlined
                      dense
                      placeholder="제품"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-select
                      class="box_l hide_label"
                      label="과목 전체"
                      v-model="subject"
                      :options="subjectOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-option-group
                      v-model="optgrRadio"
                      :options="optgrRadioOptions"
                      color="black"
                      type="radio"
                      inline
                    />
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>
            <!-- <q-space class="sp30" /> -->
            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                </div>
                <!-- 테이블 바디 row 10줄 이상이면 스크롤 생김 -->
                <q-table
                  class="scrollable tbl_row_11"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="section"
                  v-model:pagination="paginationSample"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:body="props">
                    <q-tr :class="props.row.state" :props="props">
                      <q-td class="text-center">{{ props.row.idx }}</q-td>
                      <q-td class="text-center">{{
                        props.row.businessTeam
                      }}</q-td>
                      <q-td class="text-center">{{ props.row.chanel }}</q-td>
                      <q-td class="text-center">{{ props.row.member }}</q-td>
                      <q-td class="text-center">{{ props.row.subject }}</q-td>
                      <q-td class="text-center">{{ props.row.teacher }}</q-td>
                      <q-td class="text-center">{{ props.row.week }}</q-td>
                      <q-td class="text-center">{{ props.row.time }}</q-td>
                      <q-td class="text-center">{{ props.row.option }}</q-td>
                      <q-td class="text-center">{{ props.row.endDay }}</q-td>
                      <q-td class="text-center">
                        <q-btn
                          outline
                          class="size_xxs btn_inner_table w60"
                          label="진도점검"
                        />
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table -->
            </div>
          </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 내용 </q-tab-panel>
          <!--// tab4 컨텐츠 -->
        </q-tab-panels>
      </div>
      <!-- // 탭 영역 -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// 현재탭 활성
const tab = ref('tab3');

// 검색 펼치기
// const searchExpand = ref(true);

// // const readonlyInput1 = ref('부문');
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('지점');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');

// 과목을 선택해주세요
const subject = ref(['과목 전체']);
const subjectOption = ref([
  {
    id: 'sb1',
    desc: '옵션1',
  },
  {
    id: 'sb2',
    desc: '옵션2',
  },
]);

// 검색영역 요일선택 옵션 그룹 체크박스
// const daym1 = ref(['all']);
// const dayOptionm1 = ref([
//   { label: '전체', value: 'all' },
//   { label: '월', value: 'mon' },
//   { label: '화', value: 'tues' },
// ]);
// const daym2 = ref(['wed']);
// const dayOptionm2 = ref([
//   { label: '수', value: 'wed' },
//   { label: '목', value: 'thurs' },
//   { label: '금', value: 'fri' },
// ]);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);

// 과목 회원명 옵션 그룹 라디오
const optgrRadio = ref('radio1');
const optgrRadioOptions = ref([
  {
    label: '과목',
    value: 'radio1',
  },
  {
    label: '회원명',
    value: 'radio2',
  },
]);

//data테이블 페이징
const paginationSample = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 0,
});

// 테이블 헤더 칼럼명
const dataColumns = ref([
  {
    name: 'idx',
    label: 'No.',
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'businessTeam',
    label: '사업팀',
    align: 'center',
    field: (row) => row.businessTeam,
  },
  {
    name: 'chanel',
    label: '채널',
    align: 'center',
    field: (row) => row.chanel,
  },
  {
    name: 'member',
    label: '회원',
    align: 'center',
    field: (row) => row.member,
  },
  {
    name: 'subject',
    label: '과목',
    align: 'center',
    field: (row) => row.subject,
  },
  {
    name: 'teacher',
    label: '선생님',
    align: 'center',
    field: (row) => row.teacher,
  },
  {
    name: 'week',
    label: '요일',
    align: 'center',
    field: (row) => row.week,
  },
  {
    name: 'time',
    label: '시간',
    align: 'center',
    field: (row) => row.time,
  },
  {
    name: 'option',
    label: '옵션',
    align: 'center',
    field: (row) => row.option,
  },
  {
    name: 'endDay',
    label: '최종 점검일',
    align: 'center',
    field: (row) => row.endDay,
  },
  {
    name: 'check',
    label: '',
    align: 'center',
    field: (row) => row.check,
  },
]);

// 테이블 row 데이터
const dataRows = ref([
  {
    idx: 10,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 9,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 8,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 7,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 6,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 5,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 4,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 3,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 2,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
  {
    idx: 1,
    businessTeam: '1팀',
    chanel: 'YC1[바다꿈]',
    member: '김윤찬',
    subject: '눈높이 수학',
    teacher: '김정숙[0031044761]',
    week: '월',
    time: '10:00',
    option: '내방',
    endDay: '2023.05.04',
    check: '진도점검',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
