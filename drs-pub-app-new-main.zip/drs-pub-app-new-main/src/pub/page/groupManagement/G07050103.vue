<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">요일별 회원이동 확인서</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="wrap_grey_r_box h82 mb30">
            <p class="title1 text-grey-1">
              승인 <span class="text-primary">처리중</span>입니다.
            </p>
          </div>

          <table class="table_row_sales">
            <tbody>
              <tr>
                <th>이동구분</th>
                <td><span class="text-primary">회원별</span></td>
                <th class="line_l">신청자</th>
                <td>김행정 (00234567)<br />본부명조직명/팀명/채널명</td>
              </tr>
              <tr>
                <th>이동신청일</th>
                <td>2023.02.01</td>
                <th class="line_l">이동예정일</th>
                <td>2023.02.14</td>
              </tr>
              <tr>
                <th>이동사유</th>
                <td colspan="3">이동사유를 이곳에 노출합니다.</td>
              </tr>
            </tbody>
          </table>

          <h4 class="mt60 title1 text-grey-1">이동정보</h4>
          <h5 class="mt30 mb20 title3 text-grey-2">
            김대교 [32002562] - 본부명/조직명/팀명/채널명
          </h5>
          <!-- general_table -->
          <div class="table_dk">
            <q-table
              :rows="data1Rows"
              :columns="data1Columns"
              row-key="idx"
              v-model:pagination="data1Pagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center lw_break">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td
                    key="tdata5"
                    class="align_center last_multi_td"
                    rowspan="2"
                  >
                    <div class="text-grey-4">대기중</div>
                    {{ props.row.tdata5 }}
                  </q-td>
                </q-tr>
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center lw_break">
                    {{ props.row.tdata4 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->

          <h5 class="mt60 mb20 title3 text-grey-2">
            김대교 [32002562] - 본부명/조직명/팀명/채널명
          </h5>
          <!-- general_table -->
          <div class="table_dk">
            <q-table
              :rows="data2Rows"
              :columns="data2Columns"
              row-key="idx"
              v-model:pagination="data2Pagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center lw_break">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td
                    key="tdata5"
                    class="align_center last_multi_td"
                    rowspan="2"
                  >
                    <div class="text-red">반려</div>
                    {{ props.row.tdata5 }}
                  </q-td>
                </q-tr>
                <q-tr :props="props">
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="align_center lw_break">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

//data테이블
const data1Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const data1Columns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '과목수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '이동선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '승인',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
]);
const data1Rows = ref([
  {
    idx: 10,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 9,
    tdata1: '화',
    tdata2: '1,124',
    tdata3: '124',
    tdata4: '김대교 [11132005260] 본부1명/조직1명/팀1명/채널1명 - 월',
    tdata5: '-',
  },
  {
    idx: 8,
    tdata1: '화',
    tdata2: '4',
    tdata3: '4',
    tdata4: '김대교 [32260] 본부/조직/팀/채널 - 월',
    tdata5: '-',
  },
  {
    idx: 7,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 6,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 5,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 4,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 3,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 2,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
  {
    idx: 1,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '-',
  },
]);

const data2Pagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const data2Columns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '과목수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '이동선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '승인',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
]);
const data2Rows = ref([
  {
    idx: 10,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 9,
    tdata1: '화',
    tdata2: '1,124',
    tdata3: '124',
    tdata4: '김대교 [11132005260] 본부1명/조직1명/팀1명/채널1명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 8,
    tdata1: '화',
    tdata2: '4',
    tdata3: '4',
    tdata4: '김대교 [32260] 본부/조직/팀/채널 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 7,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 6,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 5,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 4,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 3,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 2,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
  {
    idx: 1,
    tdata1: '화',
    tdata2: '24',
    tdata3: '24',
    tdata4: '김대교 [32005260] 본부명/조직명/팀명/채널명 - 월',
    tdata5: '2023.04.05 반려사유를 이곳에 표시합니다',
  },
]);
</script>
