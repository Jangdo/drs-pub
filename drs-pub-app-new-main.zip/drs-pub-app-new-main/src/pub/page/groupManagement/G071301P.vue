<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">온라인구매 회원상담 상세</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales w140_pc">
            <tbody>
              <tr>
                <th>주문일</th>
                <td>
                  <div class="search_item type_full">2023.02.30</div>
                </td>
                <th class="line_l">배정일자</th>
                <td>
                  <div class="search_item type_full">2023.02.31</div>
                </td>
              </tr>
              <tr>
                <th>쇼핑몰</th>
                <td>
                  <div class="search_item type_full">GS홈쇼핑</div>
                </td>
                <th class="line_l">담당자</th>
                <td>
                  <div class="search_item type_full">이은희</div>
                </td>
              </tr>
              <tr>
                <th>제품</th>
                <td>
                  <div class="search_item type_full">창의독서</div>
                </td>
                <th class="line_l">단계</th>
                <td>
                  <div class="search_item type_full">
                    <q-input class="" for="" outlined dense v-model="input1" />
                  </div>
                </td>
              </tr>
              <tr>
                <th>주문자명</th>
                <td>
                  <div class="search_item type_full">백목련</div>
                </td>
                <th class="line_l">해피콜결과</th>
                <td>
                  <div class="search_item type_full">
                    <q-select
                      class=""
                      v-model="search1"
                      :options="search1Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>주문자 연락처</th>
                <td>
                  <div class="contact_area">
                    <div>010-5667-9179</div>
                    <div class="btn_group">
                      <q-btn
                        fill
                        unelevated
                        color="grey-5"
                        class="btn_circle32"
                        label="circle"
                      >
                        <q-icon
                          name="icon-call-white2"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                      <q-btn
                        fill
                        unelevated
                        color="grey-5"
                        class="btn_circle32"
                        label="circle"
                      >
                        <q-icon
                          name="icon-mail-white"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                    </div>
                  </div>
                </td>
                <th class="line_l">회원명</th>
                <td>
                  <div class="search_item type_full">
                    <q-input class="" for="" outlined dense v-model="input2" />
                  </div>
                </td>
              </tr>
              <tr>
                <th rowspan="2">상품명</th>
                <td rowspan="2">
                  <div class="search_item type_full">
                    눈높이 창의독서(1개월 구독권) 정기배송 독서프로그램 03, 유아
                    6세 [1]
                  </div>
                </td>
                <th class="line_l">회원번호</th>
                <td>
                  <div class="search_item type_full">
                    <q-input class="" for="" outlined dense v-model="input3" />
                  </div>
                </td>
              </tr>
              <tr>
                <th class="line_l">입회등록</th>
                <td>
                  <div class="search_item type_full">
                    <q-select
                      class=""
                      v-model="search2"
                      :options="search2Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>판매가</th>
                <td>
                  <div class="search_item type_full">32,000원</div>
                </td>
                <th class="line_l">진도마감(불출)</th>
                <td>
                  <div class="search_item type_full">
                    <q-select
                      class=""
                      v-model="search3"
                      :options="search3Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>수취인명</th>
                <td>
                  <div class="search_item type_full">
                    백목련(주문자 : 백목련)
                  </div>
                </td>
                <th class="line_l">수취인 주소</th>
                <td>
                  <div class="search_item type_full">
                    경남창원시 성산구 내동 456-32번지 일성그라미아파트 102동
                    450호
                  </div>
                </td>
              </tr>
              <tr>
                <th>메시지</th>
                <td>
                  <div class="search_item type_full">-</div>
                </td>
                <th class="line_l">휴대폰 번호</th>
                <td>
                  <div class="contact_area">
                    <div>010-5667-9179</div>
                    <div class="btn_group">
                      <q-btn
                        fill
                        unelevated
                        color="grey-5"
                        class="btn_circle32"
                        label="circle"
                      >
                        <q-icon
                          name="icon-call-white2"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                      <q-btn
                        fill
                        unelevated
                        color="grey-5"
                        class="btn_circle32"
                        label="circle"
                      >
                        <q-icon
                          name="icon-mail-white"
                          class="icon_svg"
                        ></q-icon>
                      </q-btn>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th>주문자명</th>
                <td>
                  <div class="search_item type_full" style="height: 98px">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea"
                      placeholder=""
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </div>
                </td>
                <th class="line_l">해피콜결과</th>
                <td>
                  <div class="search_item type_full" style="height: 98px">
                    <q-input
                      class="basic"
                      outlined
                      v-model="dataTextArea2"
                      placeholder=""
                      type="textarea"
                    >
                      <template v-slot:label>메시지 내용</template>
                    </q-input>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <!-- 230509 디자인에 버튼 없어서 임의로 추가 -->
          <q-btn
            unelevated
            v-close-popup
            class="size_sm btn_reset"
            label="저장"
            style="float: right; margin-top: -30px"
          />
          <h4 class="title1 text-grey-1 mt60 mb30">상담관리현황</h4>
          <!-- general_table -->
          <div class="general_table">
            <q-table
              class="scrollable tbl_row_4"
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="paginationSample"
              hide-bottom
              hide-pagination
              separator="cell"
            >
            </q-table>
          </div>
          <!--// general_table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const input1 = ref('');
const input2 = ref('');
const input3 = ref('');
const dataTextArea = ref('');
const dataTextArea2 = ref('');

const search1 = ref(['전체']);
const search1Option = ref([
  {
    id: 's11',
    desc: '전체1',
  },
  {
    id: 's12',
    desc: '전체2',
  },
]);
const search2 = ref(['비회원']);
const search2Option = ref([
  {
    id: 's21',
    desc: '회원',
  },
  {
    id: 's22',
    desc: '비회원',
  },
]);
const search3 = ref(['전체']);
const search3Option = ref([
  {
    id: 's31',
    desc: '전체1',
  },
  {
    id: 's32',
    desc: '전체2',
  },
]);

//data테이블
const paginationSample = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 1000,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '녹취시작',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata2',
    label: '녹취종료',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '녹취시간',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '녹취파일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '상담내용',
    sortable: false,
    align: 'center',
    classes: 'w350 text-primary lw_break',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '해피콜',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '등로길',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 9,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '7',
    tdata4: '17',
    tdata5:
      '한일 국방 당국은 내달 2~4일 싱가포르에서 열리는 아시아안보회의(일명 샹그릴라 대화) 기간에 국방장관 회담을 개최할 것으로 보인다고 복수의 소식통이 8일 전했다. 윤석열 대통령과 기시다 후미오 일본 총리가 전날 열린 정상회담에서 한일관계 발전을 통한 전방위 협력 확대에 뜻을 모은 만큼 후속 논의를 위한 국방 당국 간 고위급 만남이 조기에 개최되는 것이다.',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 8,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 7,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 6,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 5,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 4,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 3,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 2,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
  {
    idx: 1,
    tdata1: '17:56:28',
    tdata2: '17:56:28',
    tdata3: '107',
    tdata4: '107',
    tdata5: '내용',
    tdata6: '승인완료',
    tdata7: '2023.02.11(금) 11:07:23',
  },
]);

const popForm = ref(true);
</script>
