<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">온라인구매 회원관리</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_column_sales">
            <tbody>
              <tr>
                <th>받는분</th>
                <td>
                  <div>
                    <q-checkbox
                      v-model="dataCheck"
                      label="010-5667-9179"
                      color="black"
                      dense
                    />
                  </div>
                  <div class="row mt15">
                    <q-checkbox
                      v-model="dataCheck2"
                      label="기타"
                      color="black"
                      dense
                    />
                    <q-input
                      class="basic ml10"
                      outlined
                      v-model="dataPhone"
                      placeholder="‘-’없이 숫자만 입력하세요"
                    >
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th>문자발송</th>
                <td>
                  <div class="row mb10 al_center">
                    <span class="body2 text-grey-3">보내는 선생님</span>
                    <q-input
                      class="basic ml10"
                      outlined
                      v-model="dataPhone2"
                      placeholder="‘-’없이 숫자만 입력하세요"
                    >
                    </q-input>
                  </div>
                  <q-option-group
                    v-model="sendSubject"
                    :options="sendSubjectOptions"
                    color="black"
                    inline
                  />

                  <div class="wrap_opt_radio mt20" v-if="sendSubject === 'op1'">
                    <q-option-group
                      class="radio_group_custom type01 flex_height"
                      v-model="sendMsg"
                      :options="sendMsgoptions"
                    />
                  </div>

                  <div
                    class="search_item type_full mt20"
                    v-if="sendSubject === 'op1'"
                  >
                    <div class="wrap_counsel_form">
                      <div class="wrap_textarea">
                        <q-input
                          class="basic text-phara1 small"
                          outlined
                          v-model="dataTextArea"
                          placeholder="입력하세요"
                          type="textarea"
                        >
                        </q-input>
                        <div class="check_val">
                          <span>0</span>/<span>1000</span>
                        </div>
                      </div>
                    </div>
                    <div class="row mt15">
                      <q-space />
                      <q-btn
                        class="size_sm shadow w160"
                        color="grey-4"
                        unelevated
                        label="문자 보내기"
                      />
                    </div>
                  </div>

                  <div class="wrap_opt_radio mt20" v-if="sendSubject === 'op2'">
                    <q-option-group
                      class="radio_group_custom type01 flex_height"
                      v-model="sendMsg"
                      :options="sendMsgoptionsTok"
                    />
                    <div class="checkbox_clist mt30">
                      <div class="tok_wrap">
                        <div class="col phone">
                          <div class="view-box">
                            안녕하세요. <br />
                            대교 다이렉트 상담실입니다.<br /><br />
                            #(이름) 회원님의 눈높이 창의독서 #해당월 월 회비입금
                            안내드립니다.<br /><br />
                            *회원이름(학습자명)으로 입금하셔야 빠른 확인이
                            가능합니다.<br /><br />
                            [우리은행 005-000-00000 (주)대교 #(원)원]<br /><br />
                            감사합니다.
                          </div>
                        </div>
                        <div class="col wrap_inp">
                          <div class="text-body2 text-grey-3">(이름)</div>
                          <q-input outlined placeholder="이름을 입력하세요" />
                          <div class="text-body2 text-grey-3">(해당월)</div>
                          <q-select
                            class="opt_items hide_label"
                            label="해당월을 입력하세요"
                            v-model="Selector"
                            :options="SelectorOption"
                            option-value="value"
                            option-label="label"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          />
                          <div class="text-body2 text-grey-3">(원)</div>
                          <q-input outlined placeholder="금액을 입력하세요" />
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="보내기"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const dataCheck = ref(true);
const dataCheck2 = ref(false);

const sendSubject = ref('op1');
const sendSubjectOptions = ref([
  {
    label: 'SMS',
    value: 'op1',
  },
  {
    label: '알림톡',
    value: 'op2',
  },
]);

const sendMsg = ref('op1');
const sendMsgoptions = ref([
  {
    label: '해피콜[학습신청안내]',
    value: 'op1',
  },
  {
    label: '부재중[교재배송확인]',
    value: 'op2',
  },
  {
    label: '부재중[학습관리]',
    value: '3',
  },
  {
    label: '부재중[전입회원]',
    value: 'op4',
  },
  {
    label: '회비안내[추가이체]',
    value: 'op5',
  },
  {
    label: '입회[감사안내]',
    value: 'op6',
  },
  {
    label: '입회[사이트이용안내]',
    value: 'op7',
  },
  {
    label: '',
    value: 'op8',
    disable: true,
  },
]);

const dataTextArea = ref('');
const popForm = ref(true);

const sendMsgoptionsTok = ref([
  {
    label: '해피콜[학습신청안내]',
    value: 'op1',
  },
  {
    label: '부재중[교재배송확인]',
    value: 'op2',
  },
  {
    label: '부재중[학습관리]',
    value: '3',
  },
  {
    label: '부재중[접입회원]',
    value: 'op4',
  },
  {
    label: '해피콜[전입_눈높이]',
    value: 'op5',
  },
  {
    label: '회비안내[추가이체]',
    value: 'op6',
  },
  {
    label: '입회[감사안내]',
    value: 'op7',
  },
  {
    label: '입회[사이트이용안내]',
    value: 'op8',
  },

  {
    label: '해피콜[전입_눈높이]',
    value: 'op9',
  },
  {
    label: '회비안내[추가이체]',
    value: 'op10',
  },
  {
    label: '입회[감사안내]',
    value: 'op11',
  },
  {
    label: '입회[사이트이용안내]',
    value: 'op12',
  },
]);

const dataPhone = ref('');
const dataPhone2 = ref('');

const Selector = ref('');
const SelectorOption = ref([
  {
    label: '01월',
    value: '01월',
  },
  {
    label: '02월',
    value: '02월',
  },
]);
</script>
