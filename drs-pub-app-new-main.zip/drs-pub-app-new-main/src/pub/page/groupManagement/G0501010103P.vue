<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">채널 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="wrapper_tab">
            <q-tabs
              v-model="tab"
              dense
              class="tab_round"
              active-bg-color="black"
              active-color="white"
              indicator-color="transparent"
              align="left"
              narrow-indicator
              outside-arrows
            >
              <q-tab name="tab1" label="눈높이" :ripple="false" />
              <q-tab name="tab2" label="솔루니" :ripple="false" />
              <q-tab name="tab3" label="중등수행논술" :ripple="false" />
              <q-tab name="tab4" label="다이렉트" :ripple="false" />
              <q-tab name="tab5" label="드림멘토" :ripple="false" />
              <q-tab name="tab6" label="디지털사업본부" :ripple="false" />
            </q-tabs>
            <q-tab-panels v-model="tab" animated>
              <!-- tab1 컨텐츠 -->
              <q-tab-panel name="tab1">
                <q-list class="list_custom type01">
                  <q-expansion-item class="expansion_custom type05">
                    <template v-slot:header>
                      <q-item-section>
                        <div class="item_head">
                          <span class="title">채널</span>
                        </div>
                      </q-item-section>
                    </template>
                    <q-card>
                      <q-card-section>
                        <q-tree
                          :nodes="treeData1"
                          node-key="id"
                          text-color="grey-2"
                          selected-color="black"
                          class="tree type01"
                          v-model:selected="treeSelected1"
                          default-expand-all
                          @update:selected="temp('트리1', treeSelected1)"
                        >
                        </q-tree>
                      </q-card-section>
                    </q-card>
                  </q-expansion-item>
                </q-list>
              </q-tab-panel>
              <!--// tab1 컨텐츠 -->
              <!-- tab2 컨텐츠 -->
              <q-tab-panel name="tab2"> tab2 내용 </q-tab-panel>
              <!--// tab2 컨텐츠 -->
              <!-- tab3 컨텐츠 -->
              <q-tab-panel name="tab3"> tab3 내용 </q-tab-panel>
              <!--// tab3 컨텐츠 -->
              <!-- tab4 컨텐츠 -->
              <q-tab-panel name="tab4"> tab4 내용 </q-tab-panel>
              <!--// tab4 컨텐츠 -->
              <!-- tab5 컨텐츠 -->
              <q-tab-panel name="tab5"> tab5 내용 </q-tab-panel>
              <!--// tab5 컨텐츠 -->
              <!-- tab6 컨텐츠 -->
              <q-tab-panel name="tab6"> tab6 내용 </q-tab-panel>
              <!--// tab6 컨텐츠 -->
            </q-tab-panels>
          </div>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            icon=""
            class="size_sm btn_reset"
            label="초기화"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="검색"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const tab = ref('tab1');

// tree
const treeData1 = [
  {
    label: '눈높이',
    id: 'a_1',
    img: '/icons/icon-tree-folder.svg',
    children: [
      {
        id: 'a_2',
        label: 'HC',
      },
      {
        label: 'LC',
        id: 'a_7',
      },
      {
        label: 'YC',
        id: 'a_4',
      },
      {
        label: 'OC',
        id: 'a_5',
      },
      {
        label: 'SC',
        id: 'a_6',
      },
    ],
  },
];
const treeSelected1 = ref('메시지 카테고리');

//  트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}
</script>
