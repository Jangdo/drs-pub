<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">피소개자 정보</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>이름</th>
                <td>홍길동 [32002596]</td>
              </tr>
              <tr>
                <th>직무/직책</th>
                <td>SC교사(사업)</td>
              </tr>
              <tr>
                <th>조직정보</th>
                <td>부산본부 (T329) / 부산교육국 (P956) / Step (001)</td>
              </tr>
              <tr>
                <th>연락처</th>
                <td>센터 02-5555-5555</td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);
</script>
