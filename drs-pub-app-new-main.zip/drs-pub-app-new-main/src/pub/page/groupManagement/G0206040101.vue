<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">학원운영 필수 이행사항 안내</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <h4 class="title3 text-grey-1 mb16">1. 학원비치 장부 및 서류</h4>
          <q-markup-table separator="cell" wrap-cells class="table_dk">
            <thead>
              <tr>
                <th>구분</th>
                <th>장부 및 서류명</th>
                <th>서식</th>
                <th>보존기간</th>
                <th>비고</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th rowspan="14" class="border_bottom_1">학원</th>
                <td>01. 원칙</td>
                <td class="text-center">학원작성</td>
                <td class="text-center">준영구</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">02. 학원설립ㆍ운영등록증</td>
                <td class="text-center">교육청에서 교부</td>
                <td class="text-center">변경시까지</td>
                <td class="text-center">게시</td>
              </tr>
              <tr>
                <td class="border_left_1">03. 등록관계 서류철</td>
                <td class="text-center">정관, 법인등기부등본 등</td>
                <td class="text-center">준영구</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">04. 현금 출납부</td>
                <td class="text-center"></td>
                <td class="text-center">5년</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">05. 교습비 등 영수증 원부</td>
                <td class="text-center"></td>
                <td class="text-center">5년</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">06. 수강생 대장</td>
                <td class="text-center"></td>
                <td class="text-center">1년</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">07. 직원명부</td>
                <td class="text-center"></td>
                <td class="text-center">계속</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">08. 수강생 출석부</td>
                <td class="text-center"></td>
                <td class="text-center">1년</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">09. 문서접수 및 발송대장</td>
                <td class="text-center"></td>
                <td class="text-center">3년</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">10. 학원강사 게시표</td>
                <td class="text-center"></td>
                <td class="text-center">계속</td>
                <td class="text-center">게시</td>
              </tr>
              <tr>
                <td class="border_left_1">11. 교습비 등 게시ㆍ표시</td>
                <td class="text-center"></td>
                <td class="text-center">변경시까지</td>
                <td class="text-center">게시</td>
              </tr>
              <tr>
                <td class="border_left_1">12. 교습비 등 반환에 관한 사항</td>
                <td class="text-center"></td>
                <td>계속</td>
                <td class="text-center">게시</td>
              </tr>
              <tr>
                <td class="border_left_1">13. 지도점검 기록부</td>
                <td class="text-center"></td>
                <td>계속</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td class="border_left_1">14. 학원책임보상보험 증서</td>
                <td class="text-center"></td>
                <td>갱신/계속</td>
                <td class="text-center">비치</td>
              </tr>
              <tr>
                <td colspan="5" class="text-center pt20 pb20">
                  학원의 설립ㆍ운영 및 과외교습에 관한 법률 시행규칙 제
                  16조(장부 및 서류비치등)<br />학원에는 위의 장부 및 서류를
                  비치하고 항상 정확하게 기록, 유지해야 한다.
                </td>
              </tr>
            </tbody>
          </q-markup-table>

          <div class="wrap_info_box">
            <div class="tit_area">
              <q-icon name="icon-info" class="icon_svg"></q-icon>
              <span>주의사항</span>
            </div>
            <div class="content">
              <ul class="ul_custom disc text-grey-3">
                <li>
                  학원책임배상보험 증서는 갱신 시에 변경하여 게시해 주십시오.
                </li>
                <li>
                  게시서류 작성시 교육청에 신고한 교습과목과 동일한
                  교습과목명으로 작성해 주십시오.<br />
                  ex) 신고 시 "국어"라고 신고하였으면 "국어" 작성
                  "눈높이국어"라고 신고하였으면 "눈높이<br />
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;국어"로 작성 또한,
                  과목은 외부인이 보았을 때도 보편적으로 이해할 수 있는
                  명칭으로<br />
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;작성해야 합니다.
                </li>
                <li>모든 서식에 날짜는 공란으로 두시기 바랍니다.</li>
                <li>
                  학원강사(러닝센터교사) 변경 시 교육청에 반드시 변경신고
                  하십시오.
                </li>
              </ul>
            </div>
          </div>

          <div class="wrap_info_box">
            <div class="tit_area items-center">
              <q-icon name="icon-info" class="icon_svg"></q-icon>
              <span>[참조]학원강사 채용ㆍ해임 통보 절차</span>
            </div>
            <div class="content">
              <ul class="ul_custom disc text-grey-3">
                <li>
                  강사채용시 10일 이내, 해임시 10일 이내 교육지원청에 통보
                  (양식에 의함)
                </li>
                <li>
                  교육지원청 별 신고기간과 사유 발생일 前과 以內의 규정은 相異
                  함
                </li>
              </ul>
            </div>
          </div>

          <q-markup-table separator="cell" wrap-cells class="table_dk">
            <thead>
              <tr>
                <th>강사채용</th>
                <th>강사 해임</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="pt20 pb20">
                  <ul class="ul_custom disc text-grey-3">
                    <li>강사채용통보서</li>
                    <li>강사 성범죄경력조회 확인서</li>
                    <li>졸업증명서 원본(또는 자격증 원본)</li>
                    <li>학원장신분증 사본</li>
                  </ul>
                  <p class="text-grey-3">※ 통보방법 : 방문</p>
                </td>
                <td>
                  <ul class="ul_custom disc text-grey-3">
                    <li>강사해임통보서</li>
                    <li>학원장신분증 사본</li>
                    <li>사직원</li>
                  </ul>
                  <p class="text-grey-3">※ 통보방법 : 방문</p>
                </td>
              </tr>
            </tbody>
          </q-markup-table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            class="size_lg"
            color="black"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);
</script>
