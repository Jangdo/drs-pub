<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">월업무계획결산</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          years-in-month-view
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          years-in-month-view
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="searchSubmitType"
                :options="searchSubmitTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                label="제출여부 전체"
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table type_total 합계 있는 테이블 -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="tdata1"
            class="scrollable sticky_table_header sticky_table_footer"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 436px"
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="align_center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="align_center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="align_center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="align_center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="align_center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="align_center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="align_center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="align_center">
                  <template v-if="props.row.tdata8 == '조회'">
                    <q-btn
                      outline
                      class="size_xxs btn_inner_table"
                      label="조회"
                    />
                  </template>
                  <template v-else>
                    <q-btn
                      fill
                      unelevated
                      color="grey-4"
                      class="size_xxs btn_inner_table"
                      label="등록"
                    />
                  </template>
                </q-td>
                <q-td key="tdata9" class="align_right">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="align_right">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="align_right">
                  {{ props.row.tdata11 }}
                </q-td>
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td class="align_center">합계</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="align_center">-</q-td>
                <q-td class="text-right">0.00</q-td>
                <q-td class="text-right">0.00</q-td>
                <q-td class="text-right">0.00</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table type_total-->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>
              해당 테이블의 항목별 설명이 두줄 가량 노출됩니다. 해당 테이블의
              항목별 설명이 두줄 가량 노출됩니다. 해당 테이블의 항목별 설명이
              두줄 가량 노출됩니다.
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchSubmitType = ref(['제출여부 전체']);
const searchSubmitTypeOption = ref([
  {
    id: 'submitY',
    desc: 'Yes',
  },
  {
    id: 'submitN',
    desc: 'No ',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.09',
});

//data테이블
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '팀장명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '년월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },

  {
    name: 'tdata7',
    label: '제출여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '내용',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '입회',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '퇴회',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '순증',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
]);
const dataRows = ref([
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '조회',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '미제출',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
  {
    tdata1: '서울서북본부',
    tdata2: '강서조직',
    tdata3: '가양등촌',
    tdata4: '김대교',
    tdata5: 'LC1',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '234',
    tdata10: '0.00',
    tdata11: '0.00',
  },
  {
    tdata1: '서울본부',
    tdata2: '조직',
    tdata3: '가양',
    tdata4: '김대교',
    tdata5: 'LC1111',
    tdata6: '2021.02.10',
    tdata7: '2021.02.10',
    tdata8: '',
    tdata9: '111,234',
    tdata10: '1.00',
    tdata11: '10.00',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
