<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">[눈높이]제품지수 총원성장</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="제품">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="채널구분">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="학습형태 전체"
                  v-model="searchstudyType"
                  :options="searchstudyTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="본부별 보기"
                  v-model="searchTreeSelected"
                  :options="searchtreeselectedOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <div class="wrap_opt_group">
                  <q-option-group
                    class="opt_group_custom week_type"
                    type="checkbox"
                    color="blue-3"
                    v-model="day"
                    :options="dayOption"
                  />
                </div>
              </div>
              <div class="col-12 col-md-3">
                <q-checkbox
                  v-model="dataCheck"
                  label="교육지원비 적용"
                  class="check_in_search"
                  color="black"
                />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table type_tree -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <q-table
            class="stickty_left_table"
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="2" class="division">구분</th>
                <th rowspan="2">월초총원지수</th>
                <th rowspan="2">현재총원지수</th>
                <th rowspan="2">전입지수</th>
                <th rowspan="2">전출지수</th>
                <th colspan="2">평가총원</th>
                <th rowspan="2">제품지수</th>
              </tr>
              <tr>
                <th class="row_first">성장지수</th>
                <th>성장지수율</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td
                  key="section"
                  class="section hastree"
                  :class="props.row.depth"
                >
                  <q-btn
                    outline
                    v-show="props.row.flat == false"
                    class="btn_tree_expand_tbl"
                    :icon="
                      props.row.state == true
                        ? 'ion-arrow-dropup'
                        : 'ion-arrow-dropdown'
                    "
                  >
                  </q-btn>
                  <p :class="props.row.flat == true ? 'flat_txt' : ''">
                    {{ props.row.section }}
                  </p>
                  <q-img
                    v-show="props.row.img"
                    :src="
                      props.row.img +
                      '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                    "
                    spinner-color="white"
                    class="user_thumb"
                  />
                </q-td>
                <q-td key="tdata1" class="goal text-right">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="results text-right">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="rate text-right">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="goal text-right">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="results text-right">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="rate text-right">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="goal text-right">
                  {{ props.row.tdata7 }}
                </q-td>
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td class="bg-grey-8">전사계</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
                <q-td class="text-right">100</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table type_tree -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>소개입회지수 - 눈높이 교육국 간 소개입회를제외한 소개입회실적</p>
            <p>
              ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
              소개입회지수, 소개퇴회지수 실적임
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchTreeSelected = ref(['본부별 보기']);
const searchtreeselectedOption = ref([
  {
    id: 'tree',
    desc: '계층',
  },
  {
    id: 'lanking',
    desc: '랭킹 ',
  },
]);
const searchstudyType = ref(['학습형태 전체']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
});
const dataCheck = ref(true);
// 검색영역 추가
// const daym1 = ref(['all']);
// const dayOptionm1 = ref([
//   { label: '전체', value: 'all' },
//   { label: '월', value: 'mon' },
//   { label: '화', value: 'tues' },
// ]);
// const daym2 = ref(['wed']);
// const dayOptionm2 = ref([
//   { label: '수', value: 'wed' },
//   { label: '목', value: 'thurs' },
//   { label: '금', value: 'fri' },
// ]);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
// const check1 = ref(false);
// const check2 = ref(false);
// const check3 = ref(false);
// const check4 = ref(false);
// const check5 = ref(false);
// const check6 = ref(false);
// const searchExpand = ref(true);

//data테이블 컬럼명 - slot 템플릿으로 적용중
const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'tdata1',
    label: '월초총원지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '현재총원지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '전입지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '전출지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '성장지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '성장지수율',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '제품지수',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const dataRows = ref([
  {
    section: '서울서북',
    depth: 'depth1',
    state: true,
    flat: false,
    tdata1: '11111111111',
    tdata2: '22222222222',
    tdata3: '33333333333',
    tdata4: '44444444444',
    tdata5: '55555555555',
    tdata6: '66666666666',
    tdata7: '77777777777',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: false,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth3',
    state: true,
    flat: false,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth4',
    state: true,
    flat: false,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth4',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth4',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth4',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth4',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: true,
    tdata1: '11',
    tdata2: '22',
    tdata3: '33',
    tdata4: '44',
    tdata5: '55',
    tdata6: '66',
    tdata7: '77',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 9999,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>

<style scoped>
/* 트리구조 테이블 모바일에서만 고정 해제 */
body.screen--sm .q-table__container.stickty_left_table tr > td:first-child,
body.screen--sm .q-table__container.stickty_left_table tr > th:first-child {
  position: relative;
}
</style>
