<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="dialog_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">직원명부</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <p class="required_msg">
            <span class="text-orange">* 항목</span>은 필수입력입니다
          </p>
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th><b class="essential">직명</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-select
                      class=""
                      v-model="search1Type"
                      :options="search1TypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">성명</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="입력해주세요."
                    ></q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">생년월일</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      outlined
                      v-model="searchDate.from1"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from1"
                              @update:model-value="
                                searchDate.from1, $refs.qDateProxyFrom1.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">주소</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="주소를 검색해주세요."
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">전화번호</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      class="inp_search"
                      outlined
                      placeholder="-없이 번호만 입력해주세요."
                    ></q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">출신학교</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input class="inp_search" outlined></q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">담당업무</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-select
                      class=""
                      v-model="search2Type"
                      :options="search2TypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th><b class="essential">채용년월일</b></th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      outlined
                      v-model="searchDate.from2"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from2"
                              @update:model-value="
                                searchDate.from2, $refs.from2.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th>해임년월일</th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      outlined
                      v-model="searchDate.from3"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from3"
                              @update:model-value="
                                searchDate.from3, $refs.from3.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const search1Type = ref(['선택해주세요']);
const search1TypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const search2Type = ref(['선택해주세요']);
const search2TypeOption = ref([
  {
    id: 'type21',
    desc: '타입1',
  },
  {
    id: 'type22',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from1: '선택해주세요.',
  from2: '선택해주세요.',
  from3: '선택해주세요.',
});

const popForm = ref(true);
</script>
