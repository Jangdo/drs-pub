<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 medium">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">목표수립 기본설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <!-- 테이블 -->
          <table class="table_row_sales">
            <tbody>
              <tr>
                <th>목표연도</th>
                <td>
                  <div class="search_item type_fix">
                    <q-select
                      class="hide_label"
                      v-model="searchYearType"
                      :options="searchYearTypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      label="년도를 선택하세요"
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>총원성장 연목표</th>
                <td>
                  <div class="search_item type_fix">
                    <q-input
                      class=""
                      outlined
                      placeholder=""
                      input-class="text-right"
                      v-model="test1"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>평균 ASP</th>
                <td>
                  <div class="data_area">
                    <div class="search_item type_fix">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </div>
                    <span class="text-body2">12월 월초총원 과목/지수</span>
                  </div>
                </td>
              </tr>
              <tr>
                <th>매출 목표</th>
                <td>
                  <div class="data_area">
                    <div class="search_item type_fix">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </div>
                    <span class="text-body2">단위, 억</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <div class="as_table">
            <div class="as_th" style="background: #f7f7f7">월별 비중</div>

            <div class="as_td wrap_q-markup-table m_2col type_month_temp">
              <!-- 1~6월 -->
              <q-markup-table separator="cell" class="mb10">
                <thead>
                  <tr>
                    <th class="">1월</th>
                    <th class="">2월</th>
                    <th class="">3월</th>
                    <th class="">4월</th>
                    <th class="">5월</th>
                    <th class="">6월</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                  </tr>
                </tbody>
              </q-markup-table>
              <!-- // 1~6월 -->

              <!-- 7~12월 -->
              <q-markup-table separator="cell" class="">
                <thead>
                  <tr>
                    <th class="">7월</th>
                    <th class="">8월</th>
                    <th class="">9월</th>
                    <th class="">10월</th>
                    <th class="">11월</th>
                    <th class="">12월</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                    <td class="border_btm_0">
                      <q-input
                        class=""
                        outlined
                        placeholder=""
                        input-class="text-right"
                        v-model="test1"
                      />
                    </td>
                  </tr>
                </tbody>
              </q-markup-table>
              <!-- // 7~12월 -->
            </div>
          </div>
          <!-- 테이블 하단-->
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>전략대상고객</th>
                <td>
                  <div class="data_area">
                    <!-- 파일 찾기 -->
                    <q-file
                      outlined
                      dense
                      clearable
                      v-model="dataFrom.information"
                      label="파일을 업로드해주세요"
                      class="hide_label file_custom type_short"
                    >
                      <template v-slot:after>
                        <q-badge color="grey-2" @click.stop>찾아보기</q-badge>
                      </template>
                    </q-file>
                    <!-- // 파일 찾기 -->
                    <q-btn
                      fill
                      unelevated
                      icon=""
                      color="grey-3"
                      class="size_sm btn_down_white"
                      label="Sample Download"
                    />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <!-- // 테이블 -->
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            icon=""
            unelevated
            class="size_lg btn_reset"
            outline
            label="초기화"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const test1 = ref('100');

const searchYearType = ref(['']);
const searchYearTypeOption = ref([
  {
    id: 'year1',
    desc: '2023',
  },
  {
    id: 'year1',
    desc: '2024',
  },
]);
const dataFrom = ref({
  information: null,
});
</script>
<style>
body.screen--lg .as_table .as_td.wrap_q-markup-table.type_month_temp .q-table {
  width: 100%;
  max-width: 100%;
  min-width: 100%;
}
</style>
<style lang="scss" scoped>
body.screen--lg
  .q-dialog
  .q-dialog__inner
  .q-card.respons_card.type_02
  .q-card__section.dialog_content
  .q-table__container {
  width: 100%;
  max-width: 100%;
  overflow: hidden;
}
.screen--lg {
  .q-dialog .q-dialog__inner .q-card.respons_card.type_02.medium {
    width: 800px;
  }
  .as_table .as_td.wrap_q-markup-table.m_2col .q-table th {
    padding: 0;
  }
  .as_table .as_td.wrap_q-markup-table.m_2col .q-table th,
  .as_table .as_td.wrap_q-markup-table.m_2col .q-table td {
    min-width: 50px;
    width: 58px;
  }
}
body.screen--lg
  .q-dialog
  .q-dialog__inner
  .q-card.respons_card.type_02
  .q-card__section.dialog_content
  .q-table__container {
  width: 100%;
  max-width: 100%;
  overflow: hidden;
}
</style>
