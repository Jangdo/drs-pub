<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">성과관리현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- table_search_area type_flexable -->
      <div class="table_search_area type_flexable">
        <div class="search_hide" v-if="searchExpand">
          <div class="search_item">
            <h3 class="item_tit">2023년 10월 서울서북</h3>
            <!-- searchDate start.from -->
            <q-input
              outlined
              v-model="searchDate.from"
              class="inp_date normal"
              readonly
            >
              <template v-slot:append>
                <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                  <q-popup-proxy
                    ref="qDateProxyFrom"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      minimal
                      mask="YYYY.MM.DD"
                      v-model="searchDate.from"
                      @update:model-value="
                        searchDate.from, $refs.qDateProxyFrom.hide()
                      "
                    >
                    </q-date>
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
            <!--// searchDate start.from -->
          </div>
        </div>
        <div class="search_expand">
          <q-btn
            class="size_sm btn_contract"
            v-if="searchExpand"
            fill
            unelevated
            icon=""
            label="검색 닫기"
            @click="searchExpand = false"
          />
          <q-btn
            class="size_sm btn_expand"
            v-else
            fill
            unelevated
            icon=""
            label="검색 펼치기"
            @click="searchExpand = true"
          />
        </div>
      </div>
      <!--// table_search_area type_flexable -->

      <!-- 순증수 카드 -->
      <div class="wrap_rate_card">
        <q-card class="rate_card">
          <q-card-section class="title_area">
            <p class="title">목표</p>
          </q-card-section>
          <q-card-section class="content_area">
            <div class="item">
              <span class="tit">순증수</span>
              <span class="num">24</span>
            </div>
            <div class="item">
              <span class="tit">순증지수</span>
              <span class="num">24.4</span>
            </div>
          </q-card-section>
        </q-card>
        <q-card class="rate_card">
          <q-card-section class="title_area">
            <p class="title">목표</p>
          </q-card-section>
          <q-card-section class="content_area">
            <div class="item">
              <span class="tit">순증수</span>
              <span class="num">24</span>
            </div>
            <div class="item">
              <span class="tit">순증지수</span>
              <span class="num">24.4</span>
            </div>
          </q-card-section>
        </q-card>
        <q-card class="rate_card">
          <q-card-section class="title_area">
            <p class="title">목표</p>
          </q-card-section>
          <q-card-section class="content_area">
            <div class="item">
              <span class="tit">순증수</span>
              <span class="num orange">24</span>
            </div>
            <div class="item">
              <span class="tit">순증지수</span>
              <span class="num primary">24.4</span>
            </div>
          </q-card-section>
        </q-card>
      </div>

      <!-- 탭 영역 -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="평가총원성장" :ripple="false" />
          <q-tab name="tab2" label="매출현황" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="wrap_table_box">
              <!-- general_table multi_head -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="btn_wrap col-12 gap10">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>
                <q-table
                  class="multi_head scrollable"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="section"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th rowspan="2" class="rowspan">본부</th>
                      <th rowspan="2" class="rowspan">구분</th>
                      <th colspan="3" class="singlecol">1월</th>
                      <th colspan="3">2월</th>
                      <th colspan="3">3월</th>
                    </tr>
                    <tr>
                      <th class="row_first">목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="tdata1" class="headquater text-center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="section text-center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata3" class="goal text-right">
                        {{ props.row.tdata3 }}</q-td
                      >
                      <q-td key="tdata4" class="results text-right">
                        {{ props.row.tdata4 }}</q-td
                      >
                      <q-td key="tdata5" class="rate text-right">
                        {{ props.row.tdata5 }}</q-td
                      >
                      <q-td key="tdata6" class="goal text-right">
                        {{ props.row.tdata6 }}</q-td
                      >
                      <q-td key="tdata7" class="results text-right">
                        {{ props.row.tdata7 }}</q-td
                      >
                      <q-td key="tdata8" class="rate text-right">
                        {{ props.row.tdata8 }}</q-td
                      >
                      <q-td key="tdata9" class="goal text-right">
                        {{ props.row.tdata9 }}</q-td
                      >
                      <q-td key="tdata10" class="results text-right">
                        {{ props.row.tdata10 }}</q-td
                      >
                      <q-td key="tdata11" class="rate text-right">
                        {{ props.row.tdata11 }}</q-td
                      >
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table multi_head -->
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>
                    성과관리현황 매출액은 D+10일 이후 전월 실적이 업로드 됩니다.
                  </p>
                </div>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 내용 </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchExpand = ref(true);
const searchDate = ref({
  from: '2023.04.03',
});

const tab = ref('tab1');

//data테이블
const dataRows = ref([
  {
    tdata1: '서울서북',
    tdata2: '순증수',
    tdata3: '0',
    tdata4: '0',
    tdata5: '0',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    tdata1: '서울서북',
    tdata2: '순증지수',
    tdata3: '0',
    tdata4: '0',
    tdata5: '0',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
  {
    tdata1: '서울서북',
    tdata2: '순증지수',
    tdata3: '011111111110',
    tdata4: '011111111110',
    tdata5: '01111111111',
    tdata6: '0111111111111',
    tdata7: '011111111111',
    tdata8: '11111110',
    tdata9: '01111111111',
    tdata10: '011111111110',
    tdata11: '011111111110',
  },
  {
    tdata1: '서울서북',
    tdata2: '순증지수',
    tdata3: '0',
    tdata4: '0',
    tdata5: '0',
    tdata6: '0',
    tdata7: '0',
    tdata8: '0',
    tdata9: '0',
    tdata10: '0',
    tdata11: '0',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 999,
});
</script>

<style scoped>
/* 트리구조 테이블 모바일에서만 고정 해제 */
body.screen--sm .q-table__container.stickty_left_table tr > td:first-child,
body.screen--sm .q-table__container.stickty_left_table tr > th:first-child {
  position: relative;
}
</style>
