<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_contents_box">
        <!-- 상단정보 -->
        <div class="con_tab_head">
          <div class="con_tab_head-top">
            <p class="title1">2023년 11월</p>
          </div>
          <div class="con_tab_head-bottom">
            <div class="title4 text-grey-4 dept_info">
              <span>서울서북본부</span>
              <span>강서교육국</span>
              <span>001팀</span>
              <span class="title3 text-grey-1">YC1[바다꿈] 운영현황</span>
              <!-- 서울서북본부 > 강서교육국 > 001팀 > YC1[바다꿈] 운영현황 -->
            </div>
            <div class="body2 text-grey-3 manager_info" 담당자>
              <span>팀장 <strong class="text-black">홍길동</strong></span>
              <span>SC교사 <strong class="text-black">김대교</strong></span>
              <span class="text-orange">직영</span>
            </div>
          </div>
        </div>
        <!-- //상단정보 -->

        <!-- 콘텐츠박스 내 탭 픽스타입 -->
        <div class="wrapper_tab">
          <q-tabs
            v-model="tab"
            inline-label
            class="tab_line type02"
            active-bg-color="white"
            active-color="primary"
            indicator-color="primary"
            align="justify"
            narrow-indicator
            outside-arrows
          >
            <q-tab name="tab1" label="영업현황" :ripple="false" />
            <q-tab name="tab2" label="회원매출/입금" :ripple="false" />
            <q-tab name="tab3" label="관리지표" :ripple="false" />
            <q-tab name="tab4" label="서비스지표" :ripple="false" />
            <q-tab name="tab5" label="출결율" :ripple="false" />
            <q-tab name="tab6" label="과목/학습방법 현황" :ripple="false" />
          </q-tabs>
          <q-tab-panels v-model="tab" animated>
            <!-- tab1 컨텐츠 -->
            <q-tab-panel name="tab1"> 탭1 </q-tab-panel>
            <!--// tab1 컨텐츠 -->
            <!-- tab2 컨텐츠 -->
            <q-tab-panel name="tab2">
              상하단라인 좌측여백 fix 내용2
            </q-tab-panel>
            <!--// tab2 컨텐츠 -->
            <!-- tab3 컨텐츠 -->
            <q-tab-panel name="tab3">
              상하단라인 좌측여백 fix 내용3
            </q-tab-panel>
            <!--// tab3 컨텐츠 -->
            <!-- tab4 컨텐츠 -->
            <q-tab-panel name="tab4" class="no-scroll">
              <h3 class="title1 text-grey-1 mb16">고객만족도</h3>
              <div class="wrap_flex_half_g30 mb60">
                <div class="col w77p">
                  <!-- 차트 -->
                  <div class="wrap_highcharts">
                    <vue-highcharts :options="chart_bubble"></vue-highcharts>
                  </div>
                  <!-- //차트 -->
                </div>
                <div class="w23p">
                  <q-table
                    class=""
                    :rows="dataRows"
                    :columns="dataColumns"
                    row-key="idx"
                    v-model:pagination="dataPagination"
                    hide-bottom
                    hide-pagination
                    separator="cell"
                  >
                  </q-table>
                </div>
              </div>

              <h3 class="title1 text-grey-1 mb16">진도/교재</h3>
              <div class="wrap_flex_half_g30">
                <div class="col w77p">
                  <!-- 차트 -->
                  <div class="wrap_highcharts">
                    <vue-highcharts :options="chart_column"></vue-highcharts>
                  </div>
                  <!-- //차트 -->
                </div>
                <div class="w23p">
                  <q-table
                    class=""
                    :rows="dataRows2"
                    :columns="dataColumns2"
                    row-key="idx"
                    v-model:pagination="dataPagination2"
                    hide-bottom
                    hide-pagination
                    separator="cell"
                  >
                  </q-table>
                </div>
              </div>

              <!-- <h3 class="title1 text-grey-1 mb16">진도/교재</h3>
            <div class="wrap_roundbox">
              <dl class="fix_first">
                <dt class="title1">진도점검수</dt>
                <dd class="text-h1">343</dd>
              </dl>

              <div class="flexible_multi">
                <h4 class="title_block title1 text-grey-2">긴급교재</h4>
                <dl class="trisection">
                  <dt class="title1">신청건수</dt>
                  <dd class="text-h1">343</dd>
                </dl>
                <dl class="trisection">
                  <dt class="title1">신청권수</dt>
                  <dd class="text-h1">12,767</dd>
                </dl>
                <dl class="trisection">
                  <dt class="title1">비중</dt>
                  <dd class="text-h1">112,767</dd>
                </dl>
              </div>
            </div> -->
            </q-tab-panel>
            <!--// tab4 컨텐츠 -->
            <!-- tab5 컨텐츠 -->
            <q-tab-panel name="tab5">
              상하단라인 좌측여백 fix 내용5
            </q-tab-panel>
            <!--// tab5 컨텐츠 -->
            <!-- tab6 컨텐츠 -->
            <q-tab-panel name="tab6">
              상하단라인 좌측여백 fix 내용6
            </q-tab-panel>
            <!--// tab6 컨텐츠 -->
          </q-tab-panels>
        </div>
        <!-- //콘텐츠박스 내 탭 픽스타입 -->
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
body.screen--lg .wrap_highcharts {
  max-height: 408px;
}
</style>
<script setup>
import { ref } from 'vue';
import VueHighcharts from 'vue3-highcharts';
import HighchartsMore from 'highcharts/highcharts-more';
import accessibility from 'highcharts/modules/accessibility';
import Highcharts from 'highcharts';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

HighchartsMore(Highcharts);
accessibility(Highcharts);

// const readonlyInput1 = ref('부문');
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');
// const searchExpand = ref(true);

const searchDate = ref({
  from: '2023.05.03',
  to: '2023.05.03',
});

// 탭
const tab = ref('tab4');

// 고객만족도 버블차트
const chart_bubble = {
  colors: ['#0080B6', '#44B87B', '#F27321', '#FCB813', '#0080B6', '#44B87B'],
  chart: {
    type: 'bubble',
    plotBorderWidth: 0,
    // zoomType: 'xy',
    backgroundColor: '#F1F7FB',
  },
  legend: {
    enabled: false,
  },
  title: false,
  subtitle: false,
  accessibility: {
    point: {
      valueDescriptionFormat:
        '{index}. {point.name}, fat: {point.x}g, sugar: {point.y}g, obesity: {point.z}%.',
    },
  },
  xAxis: {
    lineColor: '#000',
    lineWidth: 2,
    categories: ['1월', '2월', '3월', '4월 ', '5월', '6월', ''], // 가로 항목
    gridLineWidth: 1,
    gridLineDashStyle: 'longdash',
    labels: {
      format: '{value}',
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
    plotLines: [
      {
        color: 'black',
        width: 2,
        label: {
          rotation: 0,
          y: 15,
          style: {
            fontStyle: 'italic',
          },
        },
        zIndex: 3,
      },
    ],
    accessibility: {
      rangeDescription: 'Range: 60 to 100 grams.',
    },
  },
  yAxis: {
    min: 0,
    max: 110,
    startOnTick: true,
    endOnTick: true,
    title: false,
    subtitle: false,
    labels: { enabled: false, format: '{value}월' },
    maxPadding: 0,
    plotLines: [
      {
        // color: 'black',
        // dashStyle: 'dot',
        // width: 2,
        value: 0,
        label: {
          align: 'right',
          style: {
            fontStyle: 'italic',
          },
          x: -10,
        },
        zIndex: 3,
      },
    ],
    accessibility: {
      rangeDescription: 'Range: 0 to 160 grams.',
    },
  },
  tooltip: {
    enabled: false,
    useHTML: true,
    headerFormat: '<table>',
    pointFormat:
      '<tr><th colspan="2"><h3>{point.country}</h3></th></tr>' +
      '<tr><th>Fat intake:</th><td>{point.x}g</td></tr>' +
      '<tr><th>Sugar intake:</th><td>{point.y}g</td></tr>' +
      '<tr><th>Obesity (adults):</th><td>{point.z}%</td></tr>',
    footerFormat: '</table>',
    followPointer: true,
  },
  plotOptions: {
    series: {
      dataLabels: {
        enabled: true,
        format: '{point.y}',
      },
    },
    bubble: {
      color: 'white',
      marker: {
        fillOpacity: 1,
      },
      minSize: 40,
      maxSize: 60,
      dataLabels: {
        style: {
          textOutline: false,
          color: '#000',
          fontSize: 12,
          fontWeight: '400',
          fontFamily: 'Pretendard',
        },
      },
    },
  },
  series: [
    {
      data: [
        { y: 30, z: 30 },
        { y: 52.15, z: 52.15 },
        { y: 88, z: 88 },
        { y: 88, z: 88 },
        { y: 45, z: 45 },
        { y: 66.08, z: 66.08 }, // 차트 값 들어가는 곳
      ],
      colorByPoint: true,
    },
  ],
};

// 성장판회원 활용도 칼럼 차트
const chart_column = {
  colors: ['#0964CE', '#BCD5F2', '#44b87b', '#0080b6', '#555d67', '#c0c4cd'],
  chart: {
    type: 'column',
    backgroundColor: '#F1F7FB',
  },
  title: false,
  subtitle: false,
  legend: false,
  // legend: {
  //   //  layout: 'vertical',
  //   align: 'left',
  //   verticalAlign: 'top',
  //   itemMarginTop: 0,
  //   itemMarginBottom: 8,
  //   itemStyle: {
  //     color: '#000',
  //     fontWeight: 700,
  //     fontFamily: 'Pretendard',
  //     fontSize: '14px',
  //   },
  // },
  xAxis: {
    lineColor: '#000',
    lineWidth: 2,
    categories: ['1월', '2월', '3월', '4월', '5월', '6월'],
    crosshair: true,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  yAxis: {
    min: 0,
    tickInterval: 100,
    title: false,
    labels: {
      format: '{value:,.0f}', // y축 천단위 콤마
      style: {
        color: '#000',
        fontSize: 12,
        fontWeight: 700,
        fontFamily: 'Pretendard',
      },
    },
  },
  tooltip: {
    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    // pointFormat:
    //   '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    //   '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
    footerFormat: '</table>',
    shared: true,
    useHTML: true,
  },
  plotOptions: {
    column: {
      pointPadding: 0.4,
      borderWidth: 0,
      borderRadius: 3,
      pointWidth: 7,
    },
  },
  series: [
    {
      data: [230, 110, 310, 480, 100, 100], // 차트 칼럼별 값 들어가는 곳
    },
  ],
};

// dataRows1
//data테이블1
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});

const dataColumns = ref([
  {
    name: 'tdata1',
    label: '1월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '2월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '3월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '4월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '5월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '6월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  // {
  //   name: 'tdata7',
  //   label: '7월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata7,
  // },
  // {
  //   name: 'tdata8',
  //   label: '8월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata8,
  // },
  // {
  //   name: 'tdata9',
  //   label: '9월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata9,
  // },
  // {
  //   name: 'tdata10',
  //   label: '10월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata1,
  // },
  // {
  //   name: 'tdata11',
  //   label: '11월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata11,
  // },
  // {
  //   name: 'tdata12',
  //   label: '12월',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata12,
  // },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '30.00',
    tdata2: ' 52.15',
    tdata3: '88.00',
    tdata4: '30.00',
    tdata5: '88.00',
    tdata6: '30.00',
    // tdata7: '45.00',
    // tdata8: '30.00',
    // tdata9: '30.00',
    // tdata10: '30.00',
    // tdata11: '30.00',
    // tdata12: '30.00',
    // tdata13: '2,000',
  },
  // {
  //   idx: 9,
  //   tdata1: '30.00',
  //   tdata2: ' 52.15',
  //   tdata3: '88.00',
  //   tdata4: '30.00',
  //   tdata5: '88.00',
  //   tdata6: '30.00',
  //   // tdata7: '45.00',
  //   // tdata8: '30.00',
  //   // tdata9: '30.00',
  //   // tdata10: '30.00',
  //   // tdata11: '30.00',
  //   // tdata12: '30.00',
  //   // tdata13: '2,000',
  // },
  // {
  //   idx: 8,
  //   tdata1: '2022.04.03',
  //   tdata2: '202301_C1_001',
  //   tdata3: '회비',
  //   tdata4: '승인',
  //   tdata5: '눈높이부분',
  //   tdata6: '서북본부',
  //   tdata7: '강서교육국',
  //   tdata8: '01',
  //   tdata9: '[LC]달빛',
  //   tdata10: '홍동[123456790]',
  //   tdata11: '길동',
  //   tdata12: '123456',
  //   tdata13: '10,000',
  // },
  // {
  //   idx: 7,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 6,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 5,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 4,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 3,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 2,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
  // {
  //   idx: 1,
  //   tdata1: '2022.04.03',
  //   tdata2: '20230331_C1_001',
  //   tdata3: '회비조정',
  //   tdata4: '임원승인',
  //   tdata5: '눈높이사업부분',
  //   tdata6: '서울서북본부',
  //   tdata7: '서울강서교육국',
  //   tdata8: '001',
  //   tdata9: '[LC]달빛드림',
  //   tdata10: '홍길동[1234567890]',
  //   tdata11: '홍길동',
  //   tdata12: '1234567890',
  //   tdata13: '2,000',
  // },
]);

//data테이블2
const dataPagination2 = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});

const dataColumns2 = ref([
  {
    name: 'tdata0',
    label: '',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata1',
    label: '진도 점검수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata2',
    label: '긴급교재 비중',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '긴급교재 신청건수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
]);
const dataRows2 = ref([
  {
    idx: '10',
    tdata1: '1월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  {
    idx: 9,
    tdata1: '2월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  {
    idx: 8,
    tdata1: '3월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  {
    idx: 7,
    tdata1: '4월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  {
    idx: 6,
    tdata1: '5월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  {
    idx: 5,
    tdata1: '6월',
    tdata2: '29',
    tdata3: '245',
    tdata4: '211',
    tdata5: '211',
  },
  // {
  //   idx: 4,
  //   tdata1: '1월',
  //   tdata2: '29',
  //   tdata3: '245',
  //   tdata4: '211',
  //   tdata5: '211',
  // },
  // {
  //   idx: 3,
  //   tdata1: '1월',
  //   tdata2: '29',
  //   tdata3: '245',
  //   tdata4: '211',
  //   tdata5: '211',
  // },
  // {
  //   idx: 2,
  //   tdata1: '1월',
  //   tdata2: '29',
  //   tdata3: '245',
  //   tdata4: '211',
  //   tdata5: '211',
  // },
  // {
  //   idx: 1,
  //   tdata1: '1월',
  //   tdata2: '29',
  //   tdata3: '245',
  //   tdata4: '211',
  //   tdata5: '211',
  // },
]);
</script>
