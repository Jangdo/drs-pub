<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">적정인원계산</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>교실면적</th>
                <td>
                  <div class="row-8 gap10">
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="keyword"
                        placeholder=""
                        input-class="text-right"
                      />
                    </div>
                    <span class="text-body3 text-grey-3">m² =</span>
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="keyword2"
                        placeholder=""
                        input-class="text-right"
                      />
                    </div>
                    <span class="text-body3 text-grey-3">명</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const keyword = ref('');
const keyword2 = ref('');
</script>
