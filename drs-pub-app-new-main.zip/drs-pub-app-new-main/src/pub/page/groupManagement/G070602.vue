<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">선납관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrap_table_box">
        <h3 class="title1 text-grey-1 mb24">입금내역</h3>
        <table class="table_row_sales">
          <tbody>
            <tr>
              <th><span class="required">입금 선생님/회원</span></th>
              <td colspan="3">
                <div class="row">
                  <!-- input -->
                  <div class="search_item type_fix">
                    <q-input
                      v-model="dataInput1"
                      class="inp_search"
                      outlined
                      dense
                      placeholder="선생님을 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <!-- // input -->
                  <!-- input -->
                  <div class="search_item type_fix">
                    <q-input
                      v-model="dataInput2"
                      class="inp_search"
                      outlined
                      placeholder="회원명"
                    />
                  </div>
                  <!-- // input -->
                </div>
              </td>
            </tr>
            <tr>
              <th><span class="required">입금과목</span></th>
              <td colspan="3">
                <!-- select -->
                <div class="search_item type_fix">
                  <q-select
                    class="hide_label"
                    label="과목/요일/옵션/학습상태"
                    v-model="search1"
                    :options="search1Option"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <!-- // select -->
              </td>
            </tr>
            <tr>
              <th>입금일자</th>
              <td>
                <!-- date -->
                <div class="search_item type_fix">
                  <q-input
                    outlined
                    v-model="searchDate.from"
                    class="normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.from"
                            @update:model-value="
                              searchDate.from, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
                <!-- // date -->
              </td>
              <th class="line_l">영수증 순번</th>
              <td>
                <!-- input -->
                <div class="search_item type_fix">
                  <q-input
                    v-model="dataInput3"
                    class="inp_search"
                    outlined
                    placeholder="영수증 순번"
                  />
                </div>
                <!-- // input -->
              </td>
            </tr>
            <tr>
              <th>결제유형</th>
              <td>
                <!-- input -->
                <div class="search_item type_full">
                  <q-input
                    v-model="dataInput4"
                    class="inp_search"
                    outlined
                    placeholder="결제유형"
                  />
                </div>
                <!-- // input -->
              </td>
              <th class="line_l">회비입금액</th>
              <td>
                <!-- input -->
                <div class="search_item type_fix">
                  <q-input
                    v-model="dataInput5"
                    class="inp_search"
                    outlined
                    placeholder="금액"
                  />
                </div>
                <!-- // input -->
              </td>
            </tr>
            <tr>
              <th>회비입금액</th>
              <td>
                <!-- input -->
                <div class="search_item type_fix">
                  <q-input
                    v-model="dataInput6"
                    class="inp_search"
                    outlined
                    placeholder="할인적용금액"
                  />
                </div>
                <!-- // input -->
              </td>
              <th class="line_l">할인적용금액</th>
              <td>
                <!-- input -->
                <div class="search_item type_fix">
                  <q-input
                    v-model="dataInput7"
                    class="inp_search"
                    outlined
                    placeholder=""
                    readonly
                  />
                </div>
                <!-- // input -->
              </td>
            </tr>
          </tbody>
        </table>

        <h3 class="title1 text-grey-1 mb24 mt60">대체입금내역</h3>
        <table class="table_row_sales">
          <tbody>
            <tr>
              <th><span class="required">대체입금일자</span></th>
              <td>
                <!-- date -->
                <div class="search_item type_fix">
                  <q-input
                    outlined
                    v-model="searchDate.to"
                    class="normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyTo"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.to"
                            @update:model-value="
                              searchDate.to, $refs.qDateProxyTo.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
                <!-- // date -->
              </td>
            </tr>
            <tr>
              <th><span class="required">대체선생님/회원</span></th>
              <td>
                <div class="row">
                  <!-- input -->
                  <div class="search_item type_fix">
                    <q-input
                      v-model="dataInput8"
                      class="inp_search"
                      outlined
                      dense
                      placeholder="이름으로 검색하세요"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <!-- // input -->
                  <!-- input -->
                  <div class="search_item type_fix">
                    <q-input
                      v-model="dataInput9"
                      class="inp_search"
                      outlined
                      placeholder="회원명"
                    />
                  </div>
                  <!-- // input -->
                </div>
              </td>
            </tr>
            <tr>
              <th><span class="required">대체과목</span></th>
              <td>
                <!-- select -->
                <div class="search_item type_fix">
                  <q-select
                    class="hide_label"
                    label="과목/요일/옵션/학습상태"
                    v-model="search2"
                    :options="search2Option"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
                <!-- // select -->
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 버튼 -->
        <div class="btn_area response mt50">
          <q-btn unelevated outline class="size_lg wide" label="삭제" />
          <q-btn unelevated color="black" class="size_lg wide" label="저장" />
          <q-btn
            unelevated
            color="grey-2"
            class="size_lg btn_position_end"
            label="목록"
          />
        </div>
        <!-- // 버튼 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataInput1 = ref('');
const dataInput2 = ref('');
const dataInput3 = ref('');
const dataInput4 = ref('');
const dataInput5 = ref('');
const dataInput6 = ref('');
const dataInput7 = ref('2022.01.01');
const dataInput8 = ref('');
const dataInput9 = ref('');

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const search1 = ref(['']);
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const search2 = ref(['']);
const search2Option = ref([
  {
    id: 's21',
    desc: 'op1',
  },
  {
    id: 's22',
    desc: 'op2',
  },
]);
</script>
