<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">월별 매출 목표</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                          :emit-immediately="true"
                          default-view="Years"
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="searchSubjectType"
                :options="searchSubjectTypeOption"
                option-value="sysytemCategory"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                label="구분"
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="searchOfficType"
                :options="searchOfficTypeOption"
                option-value="sysytemCategory"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                label="본부"
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="general_table type_total">
          <!-- 버튼영역 -->
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm" outline label="수정완료" />
              <q-btn
                fill
                unelevated
                v-close-popup
                color="black"
                class="size_sm"
                label="최종완료"
              />
            </div>
          </div>
          <!-- // 버튼영역 -->

          <q-table
            class="multi_head"
            :rows="dataRows"
            row-key="tdata1"
            hide-bottom
            v-model:pagination="dataPagination"
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="2">본부</th>
                <th rowspan="2">조직</th>
                <th colspan="17">순증지수 목표</th>
              </tr>
              <tr>
                <th class="row_first">1월</th>
                <th>2월</th>
                <th>3월</th>
                <th>1Q</th>
                <th>4월</th>
                <th>5월</th>
                <th>6월</th>
                <th>2Q</th>
                <th>7월</th>
                <th>8월</th>
                <th>9월</th>
                <th>3Q</th>
                <th>10월</th>
                <th>11월</th>
                <th>12월</th>
                <th>4Q</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="align_center" rowspan="2">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata19" class="align_center" rowspan="2">
                  {{ props.row.tdata19 }}
                </q-td>
                <q-td key="tdata2" class="align_right">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="align_right">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="align_right">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="align_right">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="align_right">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="align_right">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="align_right">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="align_right">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="align_right">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="align_right">
                  <span class="fc_orange">{{ props.row.tdata11 }}</span>
                </q-td>
                <q-td key="tdata12" class="align_right">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="align_right">
                  {{ props.row.tdata13 }}
                </q-td>
                <q-td key="tdata14" class="align_right">
                  {{ props.row.tdata14 }}
                </q-td>
                <q-td key="tdata15" class="align_right">
                  {{ props.row.tdata15 }}
                </q-td>
                <q-td key="tdata16" class="align_right">
                  {{ props.row.tdata16 }}
                </q-td>
                <q-td key="tdata17" class="align_right">
                  {{ props.row.tdata17 }}
                </q-td>
                <q-td key="tdata18" class="align_right">
                  {{ props.row.tdata18 }}
                </q-td>
              </q-tr>
              <q-tr :props="props">
                <q-td key="tdata2_1" class="align_right row_first">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata3_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata4_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata5_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata6_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata7_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata8_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata9_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata10_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata11_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata12_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata13_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata14_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata15_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata16_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata17_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
                <q-td key="tdata18_1" class="align_right">
                  <q-input
                    class=""
                    outlined
                    placeholder=""
                    input-class="text-right"
                    v-model="test1"
                  />
                </q-td>
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td colspan="2" class="align_center">합계</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">80.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
                <q-td class="align_right">1,000.0</q-td>
              </q-tr>
              <q-tr class="tr_btm type_total">
                <q-td colspan="2" class="align_center">수정합계</q-td>
                <q-td class="align_right">100.0</q-td>
                <q-td class="align_right">8,000.0</q-td>
                <q-td class="align_right">990.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right"
                  ><span class="fc_orange">1.0</span></q-td
                >
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">1.0</q-td>
                <q-td class="align_right">100.0</q-td>
                <q-td class="align_right">1.0</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table -->
        <!-- 참고하세요 + 더보기 -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>해당 테이블의 항목별 설명이 두줄 가량 노출됩니다.</p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
        <!-- // 참고하세요 + 더보기 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const searchDate = ref({
  from: '2023',
});

const searchSubjectType = ref(['구분']);
const searchSubjectTypeOption = ref([
  {
    id: 'subject1',
    desc: '구분1',
  },
  {
    id: 'subject2',
    desc: '구분2 ',
  },
]);

const searchOfficType = ref(['본부']);
const searchOfficTypeOption = ref([
  {
    id: 'office1',
    desc: '본부1',
  },
  {
    id: 'office2',
    desc: '본부2 ',
  },
]);

//data테이블
const dataRows = ref([
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '9.0',
    tdata3: '99.0',
    tdata4: '999.0',
    tdata5: '9,999.0',
    tdata6: '999,999.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
  {
    tdata1: '서울서북',
    tdata19: '강서조직',
    tdata2: '1,000.0',
    tdata3: '100.0',
    tdata4: '10.0',
    tdata5: '1.0',
    tdata6: '1,000.0',
    tdata7: '1,000.0',
    tdata8: '1,000.0',
    tdata9: '1,000.0',
    tdata10: '1,000.0',
    tdata11: '1,000.0',
    tdata12: '1,000.0',
    tdata13: '1,000.0',
    tdata14: '1,000.0',
    tdata15: '1,000.0',
    tdata16: '1,000.0',
    tdata17: '1,000.0',
    tdata18: '1,000.0',
  },
]);

const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 9999,
});

// const test1 = ref("100");
</script>
