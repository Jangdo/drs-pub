<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">수입지출장부 조회/출력</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->

        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2" keep-alive="true">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                                :emit-immediately="true"
                                default-view="Months"
                              />
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <span class="text-body2">~</span>
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.to"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyTo"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM"
                                years-in-month-view
                                v-model="searchDate.to"
                                @update:model-value="
                                  searchDate.to, $refs.qDateProxyTo.hide()
                                "
                                :emit-immediately="true"
                                default-view="Months"
                              />
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <!-- general_table type_tree -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-8">
                    <p class="txt_exclamation">
                      센터 개설 월 <b>2018.08</b>월 이후 부터 조회
                      가능합니다.<br />다시 조회하실 경우 상단의
                      <b>수입지출 장부 조회/출력 텝 메뉴</b>를 클릭하여 페이지를
                      다시 열어주시기 바랍니다.
                    </p>
                  </div>
                  <div class="btn_wrap col-12 col-md-4">
                    <q-btn class="size_sm btn_print" outline icon="" label="" />
                  </div>
                </div>
                <q-table
                  class="scrollable sticky_table_header"
                  :rows="dataRows"
                  row-key="tdata1"
                  :rows-per-page-options="[0]"
                  hide-pagination
                  style="max-height: 440px"
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th colspan="2">날짜</th>
                      <th rowspan="2">내용</th>
                      <th rowspan="2">수입</th>
                      <th rowspan="2">지출</th>
                      <th rowspan="2">잔액</th>
                    </tr>
                    <tr>
                      <th>년/월</th>
                      <th>총 이수시간</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="tdata1" class="text-center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="text-center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <q-td key="tdata3" class="text-left">
                        {{ props.row.tdata3 }}
                      </q-td>
                      <q-td key="tdata4" class="text-right">
                        {{ props.row.tdata4 }}
                      </q-td>
                      <q-td key="tdata5" class="text-right">
                        {{ props.row.tdata5 }}
                      </q-td>
                      <q-td key="tdata6" class="text-right">
                        {{ props.row.tdata6 }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table type_tree -->
            </div>
          </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab2');

const searchDate = ref({
  from: '2019.02',
  to: '2019.02',
});

//data테이블
const dataRows = ref([
  {
    tdata1: '2023.01',
    tdata2: '01',
    tdata3: '전월이월금',
    tdata4: '0',
    tdata5: '0',
    tdata6: '0',
  },
  {
    tdata1: '2023.02',
    tdata2: '14',
    tdata3: '회비(수납)',
    tdata4: '5,289,000',
    tdata5: '0',
    tdata6: '5,289,000',
  },
  {
    tdata1: '2023.03',
    tdata2: '02',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '0',
    tdata6: '5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
  {
    tdata1: '2023.04',
    tdata2: '10',
    tdata3: '회비(수납)',
    tdata4: '0',
    tdata5: '11,000,000',
    tdata6: '-5,289,000',
  },
]);
</script>
