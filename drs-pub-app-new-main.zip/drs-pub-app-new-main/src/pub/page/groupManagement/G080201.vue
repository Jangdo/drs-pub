<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">CMS입금현황조회</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date box_m normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date box_m normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="마감여부 전체"
                v-model="search1"
                :options="search1Option"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input class="inp_search" outlined dense placeholder="은행코드">
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
          </div>

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <!-- <q-td key="tdata1" class="text-center">
                {{ props.row.tdata1 }}
              </q-td> -->
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="text-left">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="text-center">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="text-right">
                  {{ props.row.tdata13 }}
                </q-td>
                <q-td key="tdata14" class="text-center">
                  {{ props.row.tdata14 }}
                </q-td>
                <q-td key="tdata15" class="text-center">
                  {{ props.row.tdata15 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // pagination -->
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
const search1 = ref(['마감여부 전체']);
const search1Option = ref([
  {
    id: 's11',
    desc: '마감여부1',
  },
  {
    id: 's12',
    desc: '마감여부2',
  },
]);

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  // {
  //   name: 'tdata1',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata3,
  // },
  {
    name: 'tdata2',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '입금자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '입금일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '은행명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '입금코드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '입금항목명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '입금액',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
  {
    name: 'tdata14',
    label: '수정여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata14,
  },
  {
    name: 'tdata15',
    label: '마감여부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '10,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 9,
    // tdata1: '눈높이1 사업부문',
    tdata2: '경기북부본부',
    tdata3: '경기 교육국',
    tdata4: '10팀',
    tdata5: '홍홍길동',
    tdata6: '000000000000',
    tdata7: '홍길동동',
    tdata8: '2022.01.01',
    tdata9: '카카오뱅크',
    tdata10: '000000000000',
    tdata11: '입금',
    tdata12: '9',
    tdata13: '111,110,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 8,
    // tdata1: '눈높이 부문',
    tdata2: '본부',
    tdata3: '교육국',
    tdata4: '-',
    tdata5: '길동',
    tdata6: '00000000',
    tdata7: '동동',
    tdata8: '2022.01.01',
    tdata9: '농협',
    tdata10: '00000000',
    tdata11: '입금',
    tdata12: '8',
    tdata13: '11,110,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 7,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '1,110,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 6,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '110,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 5,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '1,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 4,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '100',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 3,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '0',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 2,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '10,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
  {
    idx: 1,
    // tdata1: '눈높이사업부문',
    tdata2: '경기본부',
    tdata3: '경기병점 교육국',
    tdata4: '1팀',
    tdata5: '홍길동',
    tdata6: '0000000000',
    tdata7: '홍길동',
    tdata8: '2022.01.01',
    tdata9: '우리',
    tdata10: '0000000000',
    tdata11: '입금',
    tdata12: '10',
    tdata13: '10,000',
    tdata14: '수정여부',
    tdata15: '마감여부',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
