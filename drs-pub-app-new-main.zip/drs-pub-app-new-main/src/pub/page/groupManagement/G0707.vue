<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">이월금변경</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-12">
              <q-input
                class="inp_search normal cursor-pointer"
                readonly
                outlined
                dense
                v-model="searchTop"
                placeholder="부문 > 본부 > 조직 > 팀 > 채널 > 선생님"
              >
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-input
                class="inp_search"
                outlined
                dense
                placeholder="회원"
                v-model="dataInput2"
              >
                <template v-slot:append>
                  <q-icon name="icon-search" class="icon_svg" />
                </template>
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <h3 class="title1 text-grey-1 mb16">
            전달하고자 하는 회원/과목 이월금선택
          </h3>
          <q-table
            class="scrollable sticky_table_header"
            :rows="data1Rows"
            :columns="data1Columns"
            v-model:selected="data1Selected"
            row-key="idx"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 450px"
            selection="multiple"
            separator="cell"
            color="black"
          >
            <template v-slot:header="props">
              <q-tr :props="props">
                <q-th class="select">선택</q-th>
                <q-th v-for="col in props.cols" :key="col.name" :props="props">
                  {{ col.label }}
                </q-th>
              </q-tr>
            </template>
          </q-table>
        </div>
        <div class="general_table">
          <h3 class="title1 text-grey-1 mt60 mb16">
            전달하고자 하는 회원/과목 이월금선택
          </h3>
          <q-table
            :rows="data2Rows"
            :columns="data2Columns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="text-center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="text-center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="text-center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="text-center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="text-center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="field" class="text-center">
                  <q-input class="w180" outlined placeholder="" />
                </q-td>
              </q-tr>
            </template>
          </q-table>
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
        </div>
        <!-- // general_table -->
        <div class="btn_area btn_bottom_type01">
          <q-btn unelevated color="black" class="size_lg" label="저장" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const dataInput2 = ref('');

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const data1Selected = ref([]);
const data1Columns = ref([
  {
    name: 'tdata1',
    label: '사업팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '브랜드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '학습횟수',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '이월금',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata11,
  },
]);
const data1Rows = ref([
  {
    idx: 10,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 10,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 10,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 9,
    tdata1: '10팀',
    tdata2: '김김길동[1234567890]',
    tdata3: '홍홍길동',
    tdata4: '112234567890',
    tdata5: '눈높이눈높이',
    tdata6: '써밋스코어수학 중등2-7',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'LC',
    tdata10: '10회차',
    tdata11: '111,110,000',
  },
  {
    idx: 8,
    tdata1: '1팀',
    tdata2: '김길[1234567890]',
    tdata3: '홍동',
    tdata4: '12567890',
    tdata5: '눈높이',
    tdata6: '써밋 수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '1,000',
  },
  {
    idx: 7,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 6,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 5,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 4,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 3,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 2,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
  {
    idx: 1,
    tdata1: '1팀',
    tdata2: '김길동[1234567890]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이',
    tdata6: '써밋스코어수학 중등2',
    tdata7: '월',
    tdata8: 'HC',
    tdata9: 'HC',
    tdata10: '1회차',
    tdata11: '10,000',
  },
]);
const data2Columns = ref([
  {
    name: 'tdata1',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata3',
    label: '브랜드',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata4',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata5',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata6',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata7',
    label: '순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata8',
    label: '현재 이월금',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata9',
    label: '이월금 변경 입력',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
]);

const data2Rows = ref([
  {
    idx: 10,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 9,
    tdata1: '홍홍길동',
    tdata2: '123456789012',
    tdata3: '눈높이눈높이',
    tdata4: '써밋스코어수학 중등2-2',
    tdata5: '월요일',
    tdata6: '내방',
    tdata7: '15',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 8,
    tdata1: '길동',
    tdata2: '12347890',
    tdata3: '높이',
    tdata4: '수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '2',
    tdata8: '-',
    field: '',
  },
  {
    idx: 7,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '20,000',
    field: '',
  },
  {
    idx: 6,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 5,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 4,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 3,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 2,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
  {
    idx: 1,
    tdata1: '홍길동',
    tdata2: '1234567890',
    tdata3: '눈높이',
    tdata4: '써밋스코어수학 중등2',
    tdata5: '월요일',
    tdata6: '외방',
    tdata7: '5',
    tdata8: '10,000',
    field: '',
  },
]);

const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
