<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">목표수립</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="평가총원성장" :ripple="false" />
          <q-tab name="tab2" label="매출현황" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      for="id2"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            transition-show="scale"
                            transition-hide="scale"
                            self="top middle"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <q-select
                        class="box_l hide_label"
                        v-model="searchSys"
                        :options="searchSysOption"
                        option-value="sysytemCategory"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        label="년도를 선택하세요"
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <div class="col-12 col-md-3 row-4">
                      <q-radio
                        v-model="dataRadio"
                        dense
                        val="data1"
                        label="순증수"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                      <q-radio
                        v-model="dataRadio"
                        dense
                        val="data2"
                        label="순증지수"
                        color="black"
                        checked-icon="trip_origin"
                        unchecked-icon="radio_button_unchecked"
                        class="check_to_radio"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <!-- general_table type_tree -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="btn_wrap col-12 gap10">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>
                <q-table
                  class="stickty_left_table"
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="section"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:header>
                    <tr>
                      <th rowspan="3" class="division">구분</th>
                      <th colspan="9">연 목표 성과관리현황</th>
                    </tr>
                    <tr>
                      <th colspan="3" class="no-sticky">1월</th>
                      <th colspan="3">2월</th>
                      <th colspan="3">3월</th>
                    </tr>
                    <tr>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                      <th>목표</th>
                      <th>실적</th>
                      <th>달성률</th>
                    </tr>
                  </template>
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td
                        key="section"
                        class="section hastree"
                        :class="props.row.depth"
                      >
                        <q-btn
                          outline
                          v-show="props.row.flat == false"
                          class="btn_tree_expand_tbl"
                          :icon="
                            props.row.state == true
                              ? 'ion-arrow-dropup'
                              : 'ion-arrow-dropdown'
                          "
                        >
                        </q-btn>
                        <p :class="props.row.flat == true ? 'flat_txt' : ''">
                          {{ props.row.section }}
                        </p>
                        <q-img
                          v-show="props.row.img"
                          :src="
                            props.row.img +
                            '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                          "
                          spinner-color="white"
                          class="user_thumb"
                        />
                      </q-td>
                      <q-td key="goal1" class="goal text-right">
                        {{ props.row.goal1 }}</q-td
                      >
                      <q-td key="result1" class="results text-right">
                        {{ props.row.result1 }}</q-td
                      >
                      <q-td key="rate1" class="rate text-right">
                        {{ props.row.rate1 }}</q-td
                      >
                      <q-td key="goal2" class="goal text-right">
                        {{ props.row.goal2 }}</q-td
                      >
                      <q-td key="result2" class="results text-right">
                        {{ props.row.result2 }}</q-td
                      >
                      <q-td key="rate2" class="rate text-right">
                        {{ props.row.rate2 }}</q-td
                      >
                      <q-td key="goal3" class="goal text-right">
                        {{ props.row.goal3 }}</q-td
                      >
                      <q-td key="result3" class="results text-right">
                        {{ props.row.result3 }}</q-td
                      >
                      <q-td key="rate3" class="rate text-right">
                        {{ props.row.rate3 }}</q-td
                      >
                    </q-tr>
                  </template>
                  <template v-slot:bottom-row>
                    <q-tr class="tr_btm">
                      <q-td>합계</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                      <q-td class="text-right">0</q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!--// general_table type_tree -->
              <div class="wrap_info_box">
                <div class="tit_area">
                  <q-icon name="info" class="icon_svg filter-grey-3" />
                  <span>참고하세요</span>
                </div>
                <div class="content">
                  <p>
                    소개입회지수 - 눈높이 교육국 간 소개입회를제외한
                    소개입회실적
                  </p>
                  <p>
                    ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
                    소개입회지수, 소개퇴회지수 실적임
                  </p>
                </div>
                <div class="btn_area">
                  <q-btn
                    fill
                    unelevated
                    color="grey-4"
                    class="size_xs"
                    label="더보기"
                  />
                </div>
              </div>
            </div>
          </q-tab-panel>

          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 내용 </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
const searchSys = ref(['']);
const searchSysOption = ref([
  {
    id: 'a1',
    desc: '2022',
  },
  {
    id: 'a2',
    desc: '2023 ',
  },
]);
const searchDate = ref({
  from: '2023.04.01',
});
// const check2 = ref(false);
// const check3 = ref(false);
// const searchExpand = ref(true);

//data테이블 컬럼명 - slot 템플릿으로 적용중
const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'goal1',
    label: '목표',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.goal1,
  },
  {
    name: 'result1',
    label: '실적',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.result1,
  },
  {
    name: 'rate1',
    label: '달성률',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.rate1,
  },
  {
    name: 'goal2',
    label: '목표',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.goal2,
  },
  {
    name: 'result2',
    label: '실적',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.result2,
  },
  {
    name: 'rate2',
    label: '달성률',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.rate2,
  },
  {
    name: 'goal3',
    label: '목표',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.goal3,
  },
  {
    name: 'result3',
    label: '실적',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.result3,
  },
  {
    name: 'rate3',
    label: '달성률',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.rate3,
  },
]);
const dataRows = ref([
  {
    section: '서울서북',
    depth: 'depth1',
    state: true,
    flat: false,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
  },
  {
    section: '강서교육국 [김대교]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '0',
    result1: '0',
    rate1: '0',
    goal2: '0',
    result2: '0',
    rate2: '0',
    goal3: '0',
    result3: '0',
    rate3: '0',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
  {
    section: '강서교육국 [강정현]',
    depth: 'depth2',
    state: true,
    flat: true,
    goal1: '1111111111111',
    result1: '1111111111111',
    rate1: '111111111111111',
    goal2: '222222222222',
    result2: '2222222222222',
    rate2: '22222222222222',
    goal3: '333333333333',
    result3: '33333333333',
    rate3: '33333333333',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 0,
});
const tab = ref('tab1');
const dataRadio = ref('data1');
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>

<style scoped>
/* 트리구조 테이블 모바일에서만 고정 해제 */
body.screen--sm .q-table__container.stickty_left_table tr > td:first-child,
body.screen--sm .q-table__container.stickty_left_table tr > th:first-child {
  position: relative;
}
</style>
