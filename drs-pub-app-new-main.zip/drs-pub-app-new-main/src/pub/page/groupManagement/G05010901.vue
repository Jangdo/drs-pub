<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">[성장사업] 제품지수현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.from"
                for="id2"
                class="inp_date normal"
                readonly
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyFrom"
                      transition-show="scale"
                      transition-hide="scale"
                      self="top middle"
                    >
                      <q-date
                        minimal
                        mask="YYYY.MM.DD"
                        v-model="searchDate.from"
                        @update:model-value="
                          searchDate.from, $refs.qDateProxyFrom.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="제품">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-input class="box_xl" outlined placeholder="채널구분">
                  <template v-slot:append>
                    <q-icon
                      name="icon-search"
                      class="icon_svg"
                      flat
                      :ripple="false"
                    />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="학습형태 전체"
                  v-model="searchstudyType"
                  :options="searchstudyTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="계층별 보기"
                  v-model="searchTreeSelected"
                  :options="searchtreeselectedOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <div class="wrap_opt_group">
                  <q-option-group
                    class="opt_group_custom week_type"
                    type="checkbox"
                    color="blue-3"
                    v-model="day"
                    :options="dayOption"
                  />
                </div>
              </div>
              <div class="col-12 col-md-3">
                <q-checkbox
                  v-model="dataCheck"
                  label="교육지원비 적용"
                  class="check_in_search"
                  color="black"
                />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table type_tree -->
        <div class="table_dk">
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <q-table
            class="stickty_left_table scrollable sticky_table_header"
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 400px"
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td
                  key="section"
                  class="section hastree"
                  :class="props.row.depth"
                >
                  <q-btn
                    outline
                    v-show="props.row.flat == false"
                    class="btn_tree_expand_tbl"
                    :icon="
                      props.row.state == true
                        ? 'ion-arrow-dropup'
                        : 'ion-arrow-dropdown'
                    "
                  >
                  </q-btn>
                  <p :class="props.row.flat == true ? 'flat_txt' : ''">
                    {{ props.row.section }}
                  </p>
                  <q-icon
                    :name="props.row.img"
                    class="icon_svg ml6"
                    size="20px"
                  ></q-icon>
                  <!-- <q-img
                  v-show="props.row.img"
                  :src="
                    props.row.img +
                    '?w=48&h=48&f=webp&q=10&o=contain&p=left|top'
                  "
                  spinner-color="white"
                  class="user_thumb"
                /> -->
                </q-td>
                <q-td key="countDayIn" class="join_per_day">
                  {{ props.row.countDayIn }}</q-td
                >
                <q-td key="countDayIn2" class="change_per_day">
                  {{ props.row.countDayIn2 }}</q-td
                >
                <q-td key="countDayOut" class="leave_per_day">
                  {{ props.row.countDayOut }}</q-td
                >
                <q-td
                  key="countDayOut2"
                  class="leave_change_per_day align_right"
                >
                  {{ props.row.countDayOut2 }}</q-td
                >
                <q-td key="countMonthIn" class="join_per_month align_right">
                  {{ props.row.countMonthIn }}</q-td
                >
                <q-td key="countMonthIn2" class="change_per_month align_right">
                  {{ props.row.countMonthIn2 }}</q-td
                >
                <q-td key="countAllIn" class="join_all align_right">
                  {{ props.row.countAllIn }}</q-td
                >
              </q-tr>
            </template>
            <!-- <template v-slot:bottom-row>
            <q-tr class="tr_btm">
              <q-td>합계</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
              <q-td class="text-right">0</q-td>
            </q-tr>
          </template> -->
          </q-table>
        </div>
        <!--// general_table type_tree -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>소개입회지수 - 눈높이 교육국 간 소개입회를제외한 소개입회실적</p>
            <p>
              ※ 팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
              소개입회지수, 소개퇴회지수 실적임
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
// const readonlyInput1 = ref('부문');
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');

const searchTreeSelected = ref(['']);
const searchtreeselectedOption = ref([
  {
    id: 'tree',
    desc: '계층',
  },
  {
    id: 'lanking',
    desc: '랭킹 ',
  },
]);
const searchstudyType = ref(['']);
const searchstudyTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
});
const dataCheck = ref(true);
// 검색영역 추가
// const daym1 = ref(['all']);
// const dayOptionm1 = ref([
//   { label: '전체', value: 'all' },
//   { label: '월', value: 'mon' },
//   { label: '화', value: 'tues' },
// ]);
// const daym2 = ref(['wed']);
// const dayOptionm2 = ref([
//   { label: '수', value: 'wed' },
//   { label: '목', value: 'thurs' },
//   { label: '금', value: 'fri' },
// ]);
const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
// const check1 = ref(false);
// const check2 = ref(false);
// const check3 = ref(false);
// const check4 = ref(false);
// const check5 = ref(false);
// const check6 = ref(false);
// const searchExpand = ref(true);

//data테이블
const dataColumns = ref([
  {
    name: 'section',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.section,
  },
  {
    name: 'countDayIn',
    label: '일입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn,
  },
  {
    name: 'countDayIn2',
    label: '일전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayIn2,
  },
  {
    name: 'countDayOut',
    label: '일퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut,
  },
  {
    name: 'countDayOut2',
    label: '일전환퇴회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countDayOut2,
  },
  {
    name: 'countMonthIn',
    label: '월입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countMonthIn,
  },
  {
    name: 'countMonthIn2',
    label: '월전환입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countMonthIn2,
  },
  {
    name: 'countAllIn',
    label: '전체입회',
    field: 'type',
    sortable: false,
    align: 'center',
    field: (row) => row.countAllIn,
  },
]);
const dataRows = ref([
  {
    section: 'depth1성장사업본부',
    depth: 'depth1',
    state: true,
    flat: false,
    countDayIn: '0000000000000',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth2 드림멘토사업팀 [김대교]',
    depth: 'depth2',
    state: true,
    flat: false,
    img: 'icon-leader-star',
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth3 [에듀테크멘토링]',
    depth: 'depth3',
    state: true,
    flat: false,
    img: 'icon-leader',
    countDayIn: '00000000',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth4 강정현 [11123456]',
    depth: 'depth4',
    state: true,
    flat: false,
    img: 'icon-manager',
    countDayIn: '000000000000',
    countDayIn2: '00000000000',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth5 강정현 [11123456]',
    depth: 'depth5',
    state: true,
    flat: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 강정현 [11123456]',
    depth: 'depth6',
    flat: false,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
  {
    section: 'depth6 flat 강정현 [11123456]',
    depth: 'depth6',
    flat: true,
    state: false,
    countDayIn: '0',
    countDayIn2: '0',
    countDayOut: '0',
    countDayOut2: '0',
    countMonthIn: '0',
    countMonthIn2: '0',
    countAllIn: '0',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>

<style lang="scss">
/* 트리구조 테이블 모바일에서만 고정 해제 */
body.screen--sm .q-table__container.stickty_left_table tr > td:first-child,
body.screen--sm .q-table__container.stickty_left_table tr > th:first-child {
  position: relative;
}
.stickty_left_table thead tr {
  position: sticky;
  top: 0;
  z-index: 1000;
}
</style>
