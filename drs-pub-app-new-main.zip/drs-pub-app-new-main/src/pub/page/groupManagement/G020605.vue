<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->

        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4"> tab4 </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5" keep-alive="true">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="row-5">
                <!-- 과목 -->
                <div class="table_dk">
                  <!-- sales_subtit_area -->
                  <div class="sales_subtit_area">
                    <h3 class="title1">과목</h3>
                  </div>
                  <!-- //sales_subtit_area -->
                  <!-- markup-table body rowspan -->
                  <q-markup-table
                    separator="cell"
                    class="scrollable sticky_table_header"
                    style="
                      max-height: 450px;
                      border-bottom: 1px solid rgba(0, 0, 0, 0.2);
                    "
                  >
                    <thead>
                      <tr>
                        <th class="select">선택</th>
                        <th class="">그룹명</th>
                        <th class="">과목코드</th>
                        <th class="">과목명</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="select text-center">
                          <q-checkbox v-model="dataCheck.s1" color="black" />
                        </td>
                        <td rowspan="11" class="text-center border_btm_0">
                          눈높이 어문
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s2" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s3" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s4" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s5" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s4" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s5" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s4" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s5" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s4" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                      <tr>
                        <td class="text-center">
                          <q-checkbox v-model="dataCheck.s5" color="black" />
                        </td>
                        <td class="text-center">HSV</td>
                        <td class="">HL써밋어휘력</td>
                      </tr>
                    </tbody>
                  </q-markup-table>
                  <!-- //markup-table body rowspan -->
                </div>
                <!-- // 과목 -->
                <!-- 학년 -->
                <div class="table_dk">
                  <!-- sales_subtit_area -->
                  <div class="sales_subtit_area">
                    <h3 class="title1">학년</h3>
                  </div>
                  <!-- //sales_subtit_area -->
                  <!-- selecable_table -->
                  <q-table
                    :rows="dataRows"
                    v-model:selected="selected"
                    selection="multiple"
                    row-key="dataGrade1"
                    :rows-per-page-options="[0]"
                    hide-pagination
                    separator="cell"
                    class="scrollable sticky_table_header"
                    style="
                      border-bottom: 1px solid rgba(0, 0, 0, 0.2);
                      max-height: 450px;
                    "
                  >
                    <template v-slot:header="props">
                      <q-tr :props="props">
                        <q-th class="select">선택</q-th>
                        <q-th class="">학년코드</q-th>
                        <q-th class="">학년</q-th>
                      </q-tr>
                    </template>
                    <template v-slot:body="props">
                      <q-tr :props="props">
                        <q-td key="dataGradeCh" class="select text-center">
                          <q-checkbox v-model="props.selected" color="black" />
                        </q-td>
                        <q-td key="dataGrade1" class="text-center">
                          {{ props.row.dataGrade1 }}
                        </q-td>
                        <q-td key="dataGrade2" class="text-center">
                          {{ props.row.dataGrade2 }}
                        </q-td>
                      </q-tr>
                    </template>
                  </q-table>
                  <!--// selecable_table -->
                </div>
                <!-- // 학년 -->
              </div>
              <!-- 버튼 -->
              <div class="btn_area btn_bottom_type01">
                <q-btn
                  unelevated
                  outline
                  color="grey-4"
                  class="size_lg"
                  label="취소"
                />
                <q-btn unelevated color="black" class="size_lg" label="저장" />
              </div>
            </div>
          </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab5');

//data테이블
const dataCheck = ref({
  s1: true,
  s2: false,
  s3: false,
  s4: false,
  s5: false,
});
const selected = ref([]);
const dataRows = ref([
  {
    dataGradeCh: '',
    dataGrade1: 'K0',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K2',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K3',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'k4',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'k4',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'k4',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'k4',
    dataGrade2: '유아1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
  {
    dataGradeCh: '',
    dataGrade1: 'K1333333333333333333333333333333333333333331',
    dataGrade2: '초1',
  },
]);
</script>
