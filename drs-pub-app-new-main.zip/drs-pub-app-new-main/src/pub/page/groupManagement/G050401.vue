<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">소개현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>조직</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label="피소개자명"
                  v-model="select1"
                  :options="select1Opt"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-input
                  class="box_m"
                  outlined
                  dense
                  placeholder="이름"
                  v-model="keyword"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label="회원명"
                  v-model="select2"
                  :options="select2Opt"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-input
                  class="box_m"
                  outlined
                  dense
                  placeholder="이름"
                  v-model="keyword2"
                >
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label="승인구분 전체"
                  v-model="select3"
                  :options="select3Opt"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk type_total">
          <!-- 버튼영역 -->
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8 gap10">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>
          <!-- // 버튼영역 -->

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 436px"
            class="scrollable sticky_table_header sticky_table_footer"
            separator="cell"
          >
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td class="align_center">합계</q-td>
                <q-td class="border_left_0" colspan="4"></q-td>
                <q-td class="align_right">0</q-td>
                <q-td class="align_right">0</q-td>
                <q-td class="align_right">0</q-td>
                <q-td class="align_right">0</q-td>
                <q-td class="align_right">0</q-td>
                <q-td class="align_right">0</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table -->
        <!-- 참고하세요 + 더보기 -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>
              소개입회지수 - 눈높이 교육국 간 소개입회를 제외한 소개입회실적<br />※
              팀장(러닝센터장 포함) 평가총원성장 지수율 실적 산정을 위한
              소개입회지수, 소개퇴회지수 실적임
            </p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
        <!-- // 참고하세요 + 더보기 -->
      </div>
      <!-- // 탭 영역 -->
    </div>
  </div>
</template>
<style scoped>
:deep() .q-table thead {
  position: sticky;
  top: 0;
  z-index: 1999;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const keyword = ref();
const keyword2 = ref();

const select1 = ref(['']);
const select1Opt = ref([
  {
    id: 's11',
    desc: '옵션1',
  },
  {
    id: 's12',
    desc: '옵션2',
  },
]);
const select2 = ref(['']);
const select2Opt = ref([
  {
    id: 's21',
    desc: '옵션1',
  },
  {
    id: 's22',
    desc: '옵션2',
  },
]);
const select3 = ref(['']);
const select3Opt = ref([
  {
    id: 's31',
    desc: '옵션1',
  },
  {
    id: 's32',
    desc: '옵션2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

// table data
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '소개일',
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '소개자',
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '피소개자',
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '회원',
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '회원번호',
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '입회과목',
    align: 'left',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '요일',
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '옵션',
    align: 'left',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '매출액',
    align: 'right',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '제품지수',
    align: 'right',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '승인',
    align: 'left',
    field: (row) => row.tdata11,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 10,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 9,
    tdata1: '2023.01.01',
    tdata2: '홍길 [002596]',
    tdata3: '고길 [002596]',
    tdata4: '김길',
    tdata5: '123417',
    tdata6: '수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '7.00',
    tdata10: '8',
    tdata11: '-',
  },
  {
    idx: 8,
    tdata1: '2023.01.01',
    tdata2: '홍홍길동 [320025961]',
    tdata3: '고고길동 [320025961]',
    tdata4: '김김길동',
    tdata5: '1234171711',
    tdata6: '눈높이 수학1-3',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '187.00',
    tdata10: '8',
    tdata11: '국화 (매출 확정)',
  },
  {
    idx: 7,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '가나다',
  },
  {
    idx: 6,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 5,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 4,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 3,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 2,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
  {
    idx: 1,
    tdata1: '2023.01.01',
    tdata2: '홍길동 [32002596]',
    tdata3: '고길동 [32002596]',
    tdata4: '김길동',
    tdata5: '12341717',
    tdata6: '눈높이 수학',
    tdata7: '월',
    tdata8: '내방',
    tdata9: '87.00',
    tdata10: '8',
    tdata11: '국화(매출확정)',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
