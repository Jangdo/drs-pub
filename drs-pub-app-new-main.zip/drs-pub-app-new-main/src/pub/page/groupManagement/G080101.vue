<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">입금현황조회</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          years-in-month-view
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          years-in-month-view
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>조직</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label=""
                  v-model="search1"
                  :options="search1Option"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label=""
                  v-model="search2"
                  :options="search2Option"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_m hide_label"
                  label=""
                  v-model="search4"
                  :options="search4Option"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-input outlined dense v-model="keyword" placeholder="제품">
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-input outlined dense v-model="keyword" placeholder="이름">
                  <template v-slot:append>
                    <q-icon name="icon-search" class="icon_svg" />
                  </template>
                </q-input>
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <dl class="price_wrap mb20 mt20">
            <dt class="title3">결재금액합계</dt>
            <dd class="text-h3"><span class="text-h2">1,000,000</span>원</dd>
            <dt class="title3">취소금액합계</dt>
            <dd class="text-h3"><span class="text-h2">500,000</span>원</dd>
            <dt class="title3">최종입금액합계</dt>
            <dd class="text-h3 text-orange">
              <span class="text-h2">950,000</span>원
            </dd>
          </dl>

          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8">
              <q-btn class="size_sm btn_excel" outline label="">
                <q-icon class="svg_icon filter-positive" />
              </q-btn>
            </div>
          </div>

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="section"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="idx" class="text-center">
                  {{ props.row.idx }}
                </q-td>
                <q-td key="tdata1" class="text-center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="text-center">
                  {{ props.row.tdata2 }}
                </q-td>
                <!-- <q-td key="tdata3" class="text-center">
                {{ props.row.tdata3 }}
              </q-td> -->
                <q-td key="tdata4" class="text-right">
                  {{ props.row.tdata4 }}
                </q-td>
                <!-- <q-td key="tdata5" class="text-right">
                {{ props.row.tdata5 }}
              </q-td> -->
                <!-- <q-td key="tdata6" class="text-center">
                {{ props.row.tdata6 }}
              </q-td> -->
                <q-td key="tdata7" class="text-center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="text-center">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="text-center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="text-center">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="text-center">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="text-center">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="text-center">
                  {{ props.row.tdata13 }}
                </q-td>
                <q-td key="tdata14" class="text-center">
                  {{ props.row.tdata14 }}
                </q-td>
                <q-td key="tdata15" class="text-center">
                  {{ props.row.tdata15 }}
                </q-td>
                <q-td key="tdata16" class="text-center">
                  {{ props.row.tdata16 }}
                </q-td>
                <q-td key="tdata17" class="text-center">
                  {{ props.row.tdata17 }}
                </q-td>
                <q-td key="tdata18" class="text-right">
                  {{ props.row.tdata18 }}
                </q-td>
                <q-td key="tdata19" class="text-right">
                  {{ props.row.tdata19 }}
                </q-td>
                <q-td key="tdata20" class="text-center">
                  {{ props.row.tdata20 }}
                </q-td>
                <q-td key="tdata21" class="text-center">
                  {{ props.row.tdata21 }}
                </q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- // pagination -->
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// table_search_area
// const readonlyInput1 = ref('부문');
// const readonlyInput2 = ref('본부');
// const readonlyInput3 = ref('조직');
// const readonlyInput4 = ref('팀');
// const readonlyInput5 = ref('채널');
// const readonlyInput6 = ref('선생님');
// const searchExpand = ref(true);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
const search1 = ref(['결제승인구분 전체']);
const search1Option = ref([
  {
    id: 's11',
    desc: '결제승인구분1',
  },
  {
    id: 's12',
    desc: '결제승인구분2',
  },
]);
const search2 = ref(['입금구분 전체']);
const search2Option = ref([
  {
    id: 's21',
    desc: '입금구분1',
  },
  {
    id: 's22',
    desc: '입금구분2',
  },
]);
const keyword = ref(null);

const search4 = ref(['상품구분 전체']);
const search4Option = ref([
  {
    id: 's21',
    desc: '상품구분1',
  },
  {
    id: 's22',
    desc: '상품구분2',
  },
]);

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '결제일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '입금구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  // {
  //   name: 'tdata3',
  //   label: '취소구분',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata3,
  // },
  {
    name: 'tdata4',
    label: '입금액',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  // {
  //   name: 'tdata5',
  //   label: '취소금액',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata5,
  // },
  // {
  //   name: 'tdata6',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata6,
  // },
  {
    name: 'tdata7',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '상품구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
  {
    name: 'tdata14',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata14,
  },
  {
    name: 'tdata15',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
  {
    name: 'tdata16',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata16,
  },
  {
    name: 'tdata17',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata17,
  },
  {
    name: 'tdata18',
    label: '결제금액',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata18,
  },
  {
    name: 'tdata19',
    label: '이월급',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata19,
  },
  {
    name: 'tdata20',
    label: '정기결제일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata20,
  },
  {
    name: 'tdata21',
    label: '마감일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata21,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2022.01.01',
    tdata2: '회비대체+',
    tdata3: '회비대체-',
    tdata4: '10,000',
    tdata5: '10,000',
    // tdata6: '눈높이 부문',
    tdata7: '경기본부',
    tdata8: '경기병점 2국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'hc',
    tdata15: '월',
    tdata16: '홍홍길동',
    tdata17: '00000000000',
    tdata18: '10,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 9,
    tdata1: '2022.01.01',
    tdata2: 'CMS입금',
    tdata3: '전환-',
    tdata4: '0',
    tdata5: '11,110,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '10팀',
    tdata10: '홍홍길동',
    tdata11: '000000000',
    tdata12: '입회상품',
    tdata13: '써밋스코어수학 중등1 외 3건',
    tdata14: 'YC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '0000000000',
    tdata18: '110,000',
    tdata19: '1,110,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 8,
    tdata1: '2022.01.01',
    tdata2: '(구)은행자동이체',
    tdata3: '계좌환불',
    tdata4: '100,000',
    tdata5: '110,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1 외 10건',
    tdata14: 'LC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '000000000',
    tdata18: '1,000',
    tdata19: '10',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 7,
    tdata1: '2022.01.01',
    tdata2: '(구)카드자동이체',
    tdata3: '카드취소',
    tdata4: '1,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '1,110,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 6,
    tdata1: '2022.01.01',
    tdata2: '계좌정기결제',
    tdata3: '계좌환불',
    tdata4: '500',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '11,110,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 5,
    tdata1: '2022.01.01',
    tdata2: '카드정기결졔',
    tdata3: '카드취소',
    tdata4: '1,110,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '111,110,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 4,
    tdata1: '2022.01.01',
    tdata2: '즉시이체',
    tdata3: '재해감면신청',
    tdata4: '11,110,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '10,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 3,
    tdata1: '2022.01.01',
    tdata2: '카드결제',
    tdata3: '카드취소',
    tdata4: '111,110,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '10,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 2,
    tdata1: '2022.01.01',
    tdata2: '가상계좌',
    tdata3: '회비조정-',
    tdata4: '10,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '1팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '10,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
  {
    idx: 1,
    tdata1: '2022.01.01',
    tdata2: '공공지원금',
    tdata3: '계좌환불',
    tdata4: '10,000',
    tdata5: '10,000',
    // tdata6: '눈높이사업부문',
    tdata7: '경기본부',
    tdata8: '경기병점 교육국',
    tdata9: '11팀',
    tdata10: '홍길동',
    tdata11: '00000000000',
    tdata12: '일반상품',
    tdata13: '써밋스코어수학 중등1',
    tdata14: 'HC',
    tdata15: '월',
    tdata16: '홍길동',
    tdata17: '00000000000',
    tdata18: '10,000',
    tdata19: '10,000',
    tdata20: '2022.11.01',
    tdata21: '2022.11.01',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
