<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">목표수립</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                          :emit-immediately="true"
                          default-view="Years"
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                v-model="searchSubjectType"
                :options="searchSubjectTypeOption"
                option-value="sysytemCategory"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                label="구분"
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <!-- 버튼영역 -->
          <div class="table_top">
            <div class="btn_wrap col-12 gap10">
              <q-btn class="size_sm" outline label="변경이력조회" />
              <q-btn class="size_sm" outline label="배분" />
              <q-btn class="size_sm" outline label="수정" />
              <q-btn
                fill
                unelevated
                v-close-popup
                color="black"
                class="size_sm"
                label="최종완료"
              />
            </div>
          </div>
          <!-- // 버튼영역 -->

          <q-table
            class="multi_head"
            :rows="dataRows"
            row-key="tdata1"
            hide-bottom
            v-model:pagination="dataPagination"
            hide-pagination
            separator="cell"
          >
            <template v-slot:header>
              <tr>
                <th rowspan="3">본부</th>
                <th colspan="6">조직규모</th>
                <th colspan="2">시장성 50%</th>
                <th rowspan="3">비중합계</th>
                <th rowspan="3">순증수 목표</th>
                <th rowspan="3">순증지수 목표</th>
                <th rowspan="3">매출목표</th>
              </tr>
              <tr>
                <th colspan="2" class="row_first">총원(과목) 10%</th>
                <th colspan="2">교사수 10%</th>
                <th colspan="2">러닝센터수 30%</th>
                <th colspan="2">전략대상고객</th>
              </tr>
              <tr>
                <th class="row_first">전년 12월</th>
                <th>비중</th>
                <th>전년 12월</th>
                <th>비중</th>
                <th>전년 12월</th>
                <th>비중</th>
                <th>목표 년</th>
                <th>비중</th>
              </tr>
            </template>
            <template v-slot:body="props">
              <q-tr :props="props">
                <q-td key="tdata1" class="align_center">
                  {{ props.row.tdata1 }}
                </q-td>
                <q-td key="tdata2" class="align_center">
                  {{ props.row.tdata2 }}
                </q-td>
                <q-td key="tdata3" class="align_center">
                  {{ props.row.tdata3 }}
                </q-td>
                <q-td key="tdata4" class="align_center">
                  {{ props.row.tdata4 }}
                </q-td>
                <q-td key="tdata5" class="align_center">
                  {{ props.row.tdata5 }}
                </q-td>
                <q-td key="tdata6" class="align_center">
                  {{ props.row.tdata6 }}
                </q-td>
                <q-td key="tdata7" class="align_center">
                  {{ props.row.tdata7 }}
                </q-td>
                <q-td key="tdata8" class="align_right">
                  {{ props.row.tdata8 }}
                </q-td>
                <q-td key="tdata9" class="align_center">
                  {{ props.row.tdata9 }}
                </q-td>
                <q-td key="tdata10" class="align_right">
                  {{ props.row.tdata10 }}
                </q-td>
                <q-td key="tdata11" class="align_right bg_blue">
                  {{ props.row.tdata11 }}
                </q-td>
                <q-td key="tdata12" class="align_right bg_blue">
                  {{ props.row.tdata12 }}
                </q-td>
                <q-td key="tdata13" class="align_right bg_blue">
                  {{ props.row.tdata13 }}
                </q-td>
              </q-tr>
            </template>
            <template v-slot:bottom-row>
              <q-tr class="tr_btm">
                <q-td class="align_center">합계</q-td>
                <q-td class="align_center">1,000,000,000</q-td>
                <q-td class="align_center">10.01%</q-td>
                <q-td class="align_center">99,000,000</q-td>
                <q-td class="align_center">5.0%</q-td>
                <q-td class="align_center">10,000</q-td>
                <q-td class="align_center">1.01%</q-td>
                <q-td class="align_right">100</q-td>
                <q-td class="align_center">1.00%</q-td>
                <q-td class="align_right">10.00%</q-td>
                <q-td class="align_right">500</q-td>
                <q-td class="align_right">5,000</q-td>
                <q-td class="align_right">9.00%</q-td>
              </q-tr>
            </template>
          </q-table>
        </div>
        <!--// general_table -->
        <!-- 참고하세요 + 더보기 -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <p>해당 테이블의 항목별 설명이 두줄 가량 노출됩니다.</p>
          </div>
          <div class="btn_area">
            <q-btn
              fill
              unelevated
              color="grey-4"
              class="size_xs"
              label="더보기"
            />
          </div>
        </div>
        <!-- // 참고하세요 + 더보기 -->

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area mt60">
          <h3 class="title1">변경이력조회</h3>
        </div>
        <!-- //sales_subtit_area -->

        <!-- 테이블 -->
        <div class="scrollable_table_row_sales">
          <table class="table_row_sales border">
            <colgroup>
              <col style="width: 176px" />
              <col style="width: auto" />
              <col style="width: 173px" />
              <col style="width: 240px" />
              <col style="width: 150px" />
            </colgroup>
            <tbody>
              <tr>
                <td class="text_center">1000</td>
                <td>서울 서북 교육국 매출 목표 수정</td>
                <td class="text_center">홍길동</td>
                <td class="text_center">2023.03.04 1:00:12</td>
                <td class="text_center">
                  <q-btn
                    fill
                    color="grey-7"
                    class="size_xs"
                    label="변경내용확인"
                  />
                </td>
              </tr>
              <tr>
                <td class="text_center">4</td>
                <td>서울 서북 교육국 매출 목표 수정</td>
                <td class="text_center">홍길동</td>
                <td class="text_center">2023.03.04 1:00:12</td>
                <td class="text_center">
                  <q-btn
                    fill
                    color="grey-7"
                    class="size_xs"
                    label="변경내용확인"
                  />
                </td>
              </tr>
              <tr>
                <td class="text_center">3</td>
                <td>서울 서북 교육국 매출 목표 수정</td>
                <td class="text_center">홍길동</td>
                <td class="text_center">2023.03.04 1:00:12</td>
                <td class="text_center">
                  <q-btn
                    fill
                    color="grey-7"
                    class="size_xs"
                    label="변경내용확인"
                  />
                </td>
              </tr>
              <tr>
                <td class="text_center">2</td>
                <td>서울 서북 교육국 매출 목표 수정</td>
                <td class="text_center">홍길동</td>
                <td class="text_center">2023.03.04 1:00:12</td>
                <td class="text_center">
                  <q-btn
                    fill
                    color="grey-7"
                    class="size_xs"
                    label="변경내용확인"
                  />
                </td>
              </tr>
              <tr>
                <td class="text_center">1</td>
                <td>
                  서울 서북 교육국 매출 목표 수정 서울 서북 교육국 매출 목표
                  수정 서울 서북 교육국 매출 목표 수정 서울 서북 교육국 매출
                  목표 수정
                </td>
                <td class="text_center">홍길동</td>
                <td class="text_center">2023.03.04 1:00:12</td>
                <td class="text_center">
                  <q-btn
                    fill
                    color="grey-7"
                    class="size_xs"
                    label="변경내용확인"
                  />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- // 테이블 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2023',
});

const searchSubjectType = ref(['구분']);
const searchSubjectTypeOption = ref([
  {
    id: 'subject1',
    desc: '구분1',
  },
  {
    id: 'subject2',
    desc: '구분2 ',
  },
]);
// const searchExpand = ref(true);

//data테이블
const dataRows = ref([
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
  {
    tdata1: '서울서북',
    tdata2: '1,000,000',
    tdata3: '0.00%',
    tdata4: '1,000,000',
    tdata5: '0.00%',
    tdata6: '1,000,000',
    tdata7: '0.00%',
    tdata8: '0',
    tdata9: '0.00%',
    tdata10: '0.00%',
    tdata11: '0',
    tdata12: '0',
    tdata13: '0.00%',
  },
  {
    tdata1: '서울 서북',
    tdata2: '1,000',
    tdata3: '1.0%',
    tdata4: '10,000',
    tdata5: '1.01%',
    tdata6: '1,000,000',
    tdata7: '10.00%',
    tdata8: '100',
    tdata9: '1.0%',
    tdata10: '10.06%',
    tdata11: '100,000',
    tdata12: '11,000,000',
    tdata13: '99.99%',
  },
]);
const dataPagination = ref({
  sortBy: 'id',
  descending: false,
  page: 1,
  rowsPerPage: 9999,
});
</script>
