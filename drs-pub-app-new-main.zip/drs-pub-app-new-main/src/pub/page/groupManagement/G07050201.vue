<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회원이동</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-12">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <div class="wrap_opt_group">
                  <q-option-group
                    class="opt_group_custom week_type"
                    type="checkbox"
                    color="blue-3"
                    v-model="day"
                    :options="dayOption"
                  />
                </div>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="box_l hide_label"
                  label="회원/과목"
                  v-model="dateType"
                  :options="dateTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-6">
              <div class="row" style="height: auto; line-height: 1">
                총 <span>00</span>건의 검색결과가 있습니다
                <div class="text-body2 text-grey-1 ml10">
                  [<span class="text-primary">김대교</span>(003204425)
                  <span class="text-primary">선생님</span>] [<span
                    class="text-primary"
                    >화</span
                  >/<span class="text-primary">목</span>/<span
                    class="text-primary"
                    >금</span
                  >] 으로 총 <span>50</span>명의 회원이 검색되었습니다
                </div>
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-6 gap10">
              <div class="search_item">
                <q-select
                  class="hide_label w180"
                  label="학습상태 전체"
                  v-model="statusType"
                  :options="statusTypeOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <q-btn class="size_sm" outline label="인수인계" />
              <q-btn
                class="size_sm"
                fill
                unelevated
                color="black"
                label="본국통합"
              />
            </div>
          </div>
          <q-table
            :rows="memberRows"
            :columns="memberColumns"
            v-model:selected="memberSelected"
            row-key="idx"
            v-model:pagination="memberPagination"
            hide-bottom
            hide-pagination
            selection="multiple"
            separator="cell"
            color="black"
          >
          </q-table>
        </div>
        <!-- // general_table -->

        <!-- 참고하세요 -->
        <div class="wrap_info_box">
          <div class="tit_area">
            <q-icon name="info" class="icon_svg filter-grey-3" />
            <span>참고하세요</span>
          </div>
          <div class="content">
            <ul class="ul_custom disc">
              <li>[인수인계] 조직 내 교사간 회원/과목별 이동 가능합니다.</li>
              <li>
                [분국통합] 조직 내, 조직 외로 교사간 회원/과목별 이동
                가능합니다. (조직개편, 분국통합처리용)
              </li>
            </ul>
          </div>
        </div>
        <!-- // 참고하세요 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);
const dateType = ref();
const dateTypeOption = ref([
  {
    id: 'm1',
    desc: 'type1',
  },
  {
    id: 'm2',
    desc: 'type2',
  },
]);

//data테이블
const statusType = ref();
const statusTypeOption = ref([
  {
    id: 's1',
    desc: 'type1',
  },
  {
    id: 's2',
    desc: 'type2',
  },
]);
const memberSelected = ref([]);
const memberPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const memberColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '소속',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '직책/직무',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '회원',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '과목',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '학습유형',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '학습상태',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
]);
const memberRows = ref([
  {
    idx: 11,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: 'HL써밋 스코어수학고등',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 10,
    tdata1: '본부1명/조직1명/팀1명/채널1명',
    tdata2: '김대교 [1112345678]',
    tdata3: '업무교사',
    tdata4: '김김윤찬',
    tdata5: '초등1',
    tdata6: '대교 써밋 스텝영어 (과목코드)',
    tdata7: '화',
    tdata8: '방문학습',
    tdata9: '체험완료',
  },
  {
    idx: 9,
    tdata1: '본부/조직/팀/채널',
    tdata2: '김대 [123478]',
    tdata3: '교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 8,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 7,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 6,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 5,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 4,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 3,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 2,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
  {
    idx: 1,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교 [12345678]',
    tdata3: '업무교사',
    tdata4: '김윤찬',
    tdata5: '초등1',
    tdata6: '눈높이 국어',
    tdata7: '화',
    tdata8: '센터',
    tdata9: '학습중',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
