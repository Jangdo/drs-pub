<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">퇴회자입금현황조회</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- 탭 영역 -->
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="퇴회미수금현황" :ripple="false" />
          <q-tab name="tab2" label="퇴회이후 입금현황" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-4">
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="inp_date box_m normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                              self="top middle"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!-- // 달력 인풋 -->
                      <span class="text-body2">~</span>
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.to"
                        class="inp_date box_m normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                              self="top middle"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.to"
                                @update:model-value="
                                  searchDate.to, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!-- // 달력 인풋 -->
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <dl class="price_wrap mb20 mt20">
                  <dt class="title3">퇴회미수금합계</dt>
                  <dd class="text-h3">
                    <span class="text-h2">1,000,000</span>원
                  </dd>
                  <dt class="title3">이월금합계</dt>
                  <dd class="text-h3">
                    <span class="text-h2">500,000</span>원
                  </dd>
                </dl>

                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    <div class="text-body2 text-grey-1">
                      총 <span>00</span>건의 검색결과가 있습니다
                    </div>
                  </div>
                  <div class="btn_wrap col-12 col-md-8">
                    <q-btn class="size_sm btn_excel" outline label="">
                      <q-icon class="svg_icon filter-positive" />
                    </q-btn>
                  </div>
                </div>

                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  row-key="section"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  separator="cell"
                >
                  <template v-slot:body="props">
                    <q-tr :props="props">
                      <q-td key="idx" class="text-center">
                        {{ props.row.idx }}
                      </q-td>
                      <q-td key="tdata1" class="text-center">
                        {{ props.row.tdata1 }}
                      </q-td>
                      <q-td key="tdata2" class="text-center">
                        {{ props.row.tdata2 }}
                      </q-td>
                      <!-- <q-td key="tdata3" class="text-center">
                      {{ props.row.tdata3 }}
                    </q-td> -->
                      <q-td key="tdata4" class="text-center">
                        {{ props.row.tdata4 }}
                      </q-td>
                      <q-td key="tdata5" class="text-center">
                        {{ props.row.tdata5 }}
                      </q-td>
                      <q-td key="tdata6" class="text-center">
                        {{ props.row.tdata6 }}
                      </q-td>
                      <q-td key="tdata7" class="text-center">
                        {{ props.row.tdata7 }}
                      </q-td>
                      <q-td key="tdata8" class="text-center">
                        {{ props.row.tdata8 }}
                      </q-td>
                      <q-td key="tdata9" class="text-center">
                        {{ props.row.tdata9 }}
                      </q-td>
                      <q-td key="tdata10" class="text-center">
                        {{ props.row.tdata10 }}
                      </q-td>
                      <q-td key="tdata11" class="text-center">
                        {{ props.row.tdata11 }}
                      </q-td>
                      <q-td key="tdata12" class="text-center">
                        {{ props.row.tdata12 }}
                      </q-td>
                      <q-td key="tdata13" class="text-center">
                        {{ props.row.tdata13 }}
                      </q-td>
                      <q-td key="tdata14" class="text-right">
                        {{ props.row.tdata14 }}
                      </q-td>
                      <q-td key="tdata15" class="text-right">
                        {{ props.row.tdata15 }}
                      </q-td>
                      <q-td key="tdata16" class="text-center">
                        {{ props.row.tdata16 }}
                      </q-td>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- pagination -->
              <div class="pagination_container">
                <q-pagination
                  v-model="dataPagination.current"
                  v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                  input
                  class="justify-center"
                />
                <q-pagination
                  v-model="dataPagination.current"
                  v-if="$q.screen.name == 'lg'"
                  :max="10"
                  :max-pages="8"
                  direction-links
                  boundary-links
                  rounded
                  icon-first="keyboard_double_arrow_left"
                  icon-last="keyboard_double_arrow_right"
                  class="justify-center type_01"
                />
              </div>
              <!-- // pagination -->
              <!--// general_table -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 내용 </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
      <!-- // 탭 영역 -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
  from2: '2019.02.01',
});

//data테이블
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '퇴회일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '최종회비납입일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  // {
  //   name: 'tdata3',
  //   label: '부문',
  //   sortable: false,
  //   align: 'center',
  //   field: (row) => row.tdata3,
  // },
  {
    name: 'tdata4',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
  {
    name: 'tdata14',
    label: '퇴회미수금',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata14,
  },
  {
    name: 'tdata15',
    label: '이월급',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
  {
    name: 'tdata16',
    label: '미납기간',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata16,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이사업부문',
    tdata4: '경기본부',
    tdata5: '경기병점 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '0000000000',
    tdata9: '써밋스코어수학 중동1',
    tdata10: 'HC',
    tdata11: '월',
    tdata12: '홍길동',
    tdata13: '0000000000',
    tdata14: '10,000',
    tdata15: '10,000',
    tdata16: '1개월',
  },
  {
    idx: 9,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기2본부',
    tdata5: '경기 교육국',
    tdata6: '10팀',
    tdata7: '홍홍길동',
    tdata8: '00000000',
    tdata9: '써밋스코어 중동',
    tdata10: 'LC',
    tdata11: '월',
    tdata12: '홍홍길동',
    tdata13: '00000000',
    tdata14: '11,110,000',
    tdata15: '999,999,000',
    tdata16: '10개월',
  },
  {
    idx: 8,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기본부',
    tdata5: '경기 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '00000000000',
    tdata9: '써밋스코어수학 중',
    tdata10: 'YC',
    tdata11: '월',
    tdata12: '홍길',
    tdata13: '00000000000',
    tdata14: '100',
    tdata15: '0',
    tdata16: '1개월',
  },
  {
    idx: 7,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이사업부문',
    tdata4: '경기본부',
    tdata5: '경기병점 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '0000000000',
    tdata9: '써밋스코어수학 중동1',
    tdata10: 'HC',
    tdata11: '월',
    tdata12: '홍길동',
    tdata13: '0000000000',
    tdata14: '10,000',
    tdata15: '10,000',
    tdata16: '1개월',
  },
  {
    idx: 6,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기2본부',
    tdata5: '경기 교육국',
    tdata6: '10팀',
    tdata7: '홍홍길동',
    tdata8: '00000000',
    tdata9: '써밋스코어 중동',
    tdata10: 'LC',
    tdata11: '월',
    tdata12: '홍홍길동',
    tdata13: '00000000',
    tdata14: '11,110,000',
    tdata15: '999,999,000',
    tdata16: '10개월',
  },
  {
    idx: 5,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기본부',
    tdata5: '경기 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '00000000000',
    tdata9: '써밋스코어수학 중',
    tdata10: 'YC',
    tdata11: '월',
    tdata12: '홍길',
    tdata13: '00000000000',
    tdata14: '100',
    tdata15: '0',
    tdata16: '1개월',
  },
  {
    idx: 4,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이사업부문',
    tdata4: '경기본부',
    tdata5: '경기병점 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '0000000000',
    tdata9: '써밋스코어수학 중동1',
    tdata10: 'HC',
    tdata11: '월',
    tdata12: '홍길동',
    tdata13: '0000000000',
    tdata14: '10,000',
    tdata15: '10,000',
    tdata16: '1개월',
  },
  {
    idx: 3,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기2본부',
    tdata5: '경기 교육국',
    tdata6: '10팀',
    tdata7: '홍홍길동',
    tdata8: '00000000',
    tdata9: '써밋스코어 중동',
    tdata10: 'LC',
    tdata11: '월',
    tdata12: '홍홍길동',
    tdata13: '00000000',
    tdata14: '11,110,000',
    tdata15: '999,999,000',
    tdata16: '10개월',
  },
  {
    idx: 2,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이 부문',
    tdata4: '경기본부',
    tdata5: '경기 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '00000000000',
    tdata9: '써밋스코어수학 중',
    tdata10: 'YC',
    tdata11: '월',
    tdata12: '홍길',
    tdata13: '00000000000',
    tdata14: '100',
    tdata15: '0',
    tdata16: '1개월',
  },
  {
    idx: 1,
    tdata1: '2022.01.01',
    tdata2: '2022.01.01',
    // tdata3: '눈높이사업부문',
    tdata4: '경기본부',
    tdata5: '경기병점 교육국',
    tdata6: '1팀',
    tdata7: '홍길동',
    tdata8: '0000000000',
    tdata9: '써밋스코어수학 중동1',
    tdata10: 'HC',
    tdata11: '월',
    tdata12: '홍길동',
    tdata13: '0000000000',
    tdata14: '10,000',
    tdata15: '10,000',
    tdata16: '1개월',
  },
]);
</script>
