<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrap_table_box">
        <!-- 라디오 그룹 -->
        <div class="radio_group_wrap">
          <div class="text-body3">등록하려는 조직을 선택해주세요</div>
          <q-option-group
            v-model="group"
            :options="options"
            color="black"
            inline
          />
        </div>
        <!-- // 라디오 그룹 -->

        <table class="table_row_sales">
          <tbody>
            <tr>
              <th>조직코드</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="조직코드를 조회하세요"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>조직명</th>
              <td>
                <div class="search_item">
                  <q-input class="box_xl inp_search" outlined> </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>부문/본부</th>
              <td>
                <div class="row">
                  <!-- 검색 -->
                  <div class="search_item">
                    <q-input
                      class="box_xl inp_search"
                      outlined
                      placeholder="부문/본부를 조회하세요"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <!-- // 검색 -->
                  <!-- 드롭다운 -->
                  <div class="search_item">
                    <q-select
                      class=""
                      v-model="searchBrandType"
                      :options="searchBrandTypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <!-- // 드롭다운 -->
                </div>
              </td>
            </tr>
            <tr>
              <th>조직구분</th>
              <td>
                <div class="search_item">
                  <q-select
                    class=""
                    v-model="searchOrzType"
                    :options="searchOrzTypeOption"
                    option-value="id"
                    option-label="desc"
                    option-disable="inactive"
                    emit-value
                    map-options
                    dense
                    outlined
                    dropdown-icon="ion-ios-arrow-down"
                  >
                  </q-select>
                </div>
              </td>
            </tr>
            <tr>
              <th>조직순번</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="조직순번을 조회하세요"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>코스트센터</th>
              <td>
                <div class="search_item">
                  <q-input class="box_xl inp_search" outlined> </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>손익센터</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="손익센터를 조회하세요"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>HR부서코드</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="HR부서코드를 조회하세요"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>시작일</th>
              <td>
                <div class="search_item">
                  <q-input
                    outlined
                    v-model="searchDate.from"
                    class="inp_date normal"
                    readonly
                  >
                    <template v-slot:append>
                      <q-icon
                        name="icon-calendar"
                        class="icon_svg cursor-pointer"
                      >
                        <q-popup-proxy
                          ref="qDateProxyFrom"
                          cover
                          transition-show="scale"
                          transition-hide="scale"
                        >
                          <q-date
                            minimal
                            mask="YYYY.MM.DD"
                            v-model="searchDate.from"
                            @update:model-value="
                              searchDate.from, $refs.qDateProxyFrom.hide()
                            "
                          >
                          </q-date>
                        </q-popup-proxy>
                      </q-icon>
                    </template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>종료일</th>
              <td>
                <div class="row">
                  <!-- 달력 -->
                  <div class="search_item">
                    <q-input
                      outlined
                      v-model="searchDate.to"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to"
                              @update:model-value="
                                searchDate.to, $refs.qDateProxyTo.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <!-- // 달력 -->
                  <!-- 드롭다운 -->
                  <div class="search_item">
                    <q-select
                      class=""
                      v-model="searchBranchType"
                      :options="searchBranchTypeOption"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <!-- // 드롭다운 -->
                  <!-- 검색 -->
                  <div class="search_item">
                    <q-input
                      class="box_xl inp_search"
                      outlined
                      placeholder="대상교육국 조직코드 조회"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                  <!-- // 검색 -->
                </div>
              </td>
            </tr>
            <tr>
              <th>전화번호</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="숫자만 입력하세요"
                  >
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>팩스번호</th>
              <td>
                <div class="search_item">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="숫자만 입력하세요"
                  >
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th>주소</th>
              <td>
                <div class="post_btn_area">
                  <div class="search_item">
                    <q-input class="box_xl inp_search" outlined> </q-input>
                  </div>
                  <q-btn
                    unelevated
                    color="grey-2"
                    class="size_sm"
                    label="우편번호"
                  />
                </div>
                <div class="search_item type_full">
                  <q-input class="box_xl inp_search" outlined> </q-input>
                </div>
                <div class="search_item type_full">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="상세주소 입력"
                  >
                  </q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="btn_area response">
          <q-btn unelevated outline class="size_lg wide" label="취소" />
          <q-btn unelevated color="black" class="size_lg wide" label="저장" />
          <q-btn
            unelevated
            color="grey-2"
            class="size_lg btn_position_end"
            label="목록"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// radio group
const group = ref('op1');
const options = ref([
  {
    label: '부문',
    value: 'op1',
  },
  {
    label: '본부',
    value: 'op2',
  },
  {
    label: '조직',
    value: 'op3',
  },
  {
    label: '지원팀',
    value: 'op4',
  },
]);

// table_search_area
const searchBrandType = ref(['브랜드를 선택하세요']);
const searchBrandTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const searchOrzType = ref(['선택하세요']);
const searchOrzTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const searchBranchType = ref(['분국']);
const searchBranchTypeOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
</script>
