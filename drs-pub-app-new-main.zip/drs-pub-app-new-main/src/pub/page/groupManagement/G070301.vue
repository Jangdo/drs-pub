<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">학습일정표 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="학습일정표 출력" :ripple="false" />
          <q-tab name="tab2" label="학습일정표 스티커 발행" :ripple="false" />
          <q-tab name="tab3" label="긴급교재 스티커 발행" :ripple="false" />
          <q-tab
            name="tab4"
            label="분국통합 학습일정표 스티커 발생"
            :ripple="false"
          />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <div class="row-calendar">
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.from"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.from"
                                @update:model-value="
                                  searchDate.from, $refs.qDateProxyFrom.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!-- // 달력 인풋 -->
                      <span class="text-body2 text-grey-3">~</span>
                      <!-- 달력 인풋 -->
                      <q-input
                        outlined
                        v-model="searchDate.to"
                        class="inp_date normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyTo"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.to"
                                @update:model-value="
                                  searchDate.to, $refs.qDateProxyTo.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                      <!-- // 달력 인풋 -->
                    </div>
                  </div>
                  <div class="col-12 col-md-9">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <q-input
                        v-model="searchInput1"
                        class="box_m"
                        outlined
                        placeholder="제품"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-select
                        class="box_m hide_label"
                        label="발행순서 전체"
                        v-model="orderType"
                        :options="orderTypeOption"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                  <div class="btn_wrap col-12 col-md-8">
                    <q-btn class="size_sm btn_print" outline icon="" label="" />
                  </div>
                </div>
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  v-model:selected="dataSelected"
                  row-key="idx"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  selection="multiple"
                  separator="cell"
                  color="black"
                >
                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th class="select">선택</q-th>
                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- // general_table -->
            </div>
          </q-tab-panel>
          <q-tab-panel name="tab2">학습일정표 스티커 발행</q-tab-panel>
          <q-tab-panel name="tab3">긴급교재 스티커 발행</q-tab-panel>
          <q-tab-panel name="tab4">분국통합 학습일정표 스티커 발생</q-tab-panel>
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');

const searchInput1 = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const orderType = ref();
const orderTypeOption = ref([
  {
    id: 'm1',
    desc: '회원1',
  },
  {
    id: 'm2',
    desc: '회원2',
  },
]);

//data테이블

const dataSelected = ref([]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '교재수급일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '교사명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '교실명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '진도순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 10,
    tdata1: '2021.02.01',
    tdata2: '0011',
    tdata3: '31145678002',
    tdata4: '홍홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 신동아2, 삼성, 종합',
    tdata7: '눈높이 수학 1-5',
    tdata8: '10',
    tdata9: '초등4',
    tdata10: '001155191130',
    tdata11: '홍홍길동',
  },
  {
    idx: 9,
    tdata1: '2021.02.01',
    tdata2: '01',
    tdata3: '5678002',
    tdata4: '길동',
    tdata5: '월',
    tdata6: '신동아, 삼성, 종합',
    tdata7: '수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '55191130',
    tdata11: '길동',
  },
  {
    idx: 8,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 7,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 6,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 5,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 4,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 3,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 2,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
  {
    idx: 1,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: '만0세',
    tdata10: '0055191130',
    tdata11: '홍길동',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
