<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="기본정보" :ripple="false" />
          <q-tab name="tab2" label="채널정보" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1"> </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2">
            <div class="wrap_table_box">
              <!-- sales_subtit_area -->
              <div class="sales_subtit_area">
                <h3 class="title1">채널정보</h3>
              </div>
              <!-- //sales_subtit_area -->

              <table class="table_row_sales">
                <tbody>
                  <tr>
                    <th>소개</th>
                    <td>영등포 교육국 1채널을 소개합니다.</td>
                  </tr>
                  <tr>
                    <th>이미지 등록</th>
                    <td>
                      <q-list inline class="list_channer_image">
                        <q-item>
                          <q-item-section>
                            <div class="img_tit">이미지 제목 노출영역</div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">
                              이미지 제목 노출영역 노출영역
                            </div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">
                              이미지제목노출영역이미지제목노출영역이미지제목노출영역
                            </div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">이미지 제목 노출영역</div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">이미지 제목 노출영역</div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">이미지 제목 노출영역</div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>

                        <q-item>
                          <q-item-section>
                            <div class="img_tit">이미지 제목 노출영역</div>
                            <q-img
                              :src="url"
                              spinner-color="white"
                              class="img_channer"
                            />
                            <q-btn
                              outline
                              class="size_xs btn_zoom_channer_img"
                              label="확대"
                            />
                          </q-item-section>
                        </q-item>
                      </q-list>
                    </td>
                  </tr>
                  <tr>
                    <th>운영시간</th>
                    <td><span>09:00</span> ~ <span>18:00</span></td>
                  </tr>
                  <tr>
                    <th>학원등록번호</th>
                    <td>123456</td>
                  </tr>
                  <tr>
                    <th>SNS URL관리</th>
                    <td>
                      <q-list dense class="list_url">
                        <q-item>
                          <q-item-section>
                            <dl class="wrap_detail">
                              <dt><span>인스타그램</span> I</dt>
                              <dd>
                                https://www.instagram.com/max__aaaa_aaaa_aaaa_aaaa_aaaa_aaaa_aamax
                              </dd>
                            </dl>
                          </q-item-section>
                        </q-item>
                        <q-item>
                          <q-item-section>
                            <dl class="wrap_detail">
                              <dt><span>페이스북</span> I</dt>
                              <dd>https://twitter.com/aaaa_aaa_aaaaa</dd>
                            </dl>
                          </q-item-section>
                        </q-item>
                        <q-item>
                          <q-item-section>
                            <dl class="wrap_detail">
                              <dt><span>트위터</span> I</dt>
                              <dd>https://www.facebook.com/aaaa_aaa_aaaaa</dd>
                            </dl>
                          </q-item-section>
                        </q-item>
                      </q-list>
                    </td>
                  </tr>
                  <tr>
                    <th>편의시설</th>
                    <td>주차, 학부모 대기공간</td>
                  </tr>
                  <tr>
                    <th>교실수</th>
                    <td>5</td>
                  </tr>
                  <tr>
                    <th>좌석수</th>
                    <td>100</td>
                  </tr>
                </tbody>
              </table>

              <!-- sales_line_tit_area -->
              <div class="sales_line_tit_area">
                <h3 class="title1">소식/행사</h3>
                <q-btn
                  fill
                  unelevated
                  color="grey-2"
                  class="size_sm"
                  label="상세보기"
                />
              </div>
              <!-- //sales_line_tit_area -->

              <div class="btn_area response">
                <q-btn unelevated outline class="size_lg wide" label="취소" />
                <q-btn
                  unelevated
                  color="black"
                  class="size_lg wide"
                  label="저장"
                />
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_lg btn_position_end"
                  label="목록"
                />
              </div>
            </div>
          </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab2');

// img
const url = ref('https://picsum.photos/700/520');
</script>
