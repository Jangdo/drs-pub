<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">구분 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <q-list class="list_custom type01">
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">부문</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected1.length > 0"
                    >
                      <span>{{ treeSelected1 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData1"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected1"
                    default-expand-all
                    @update:selected="temp('트리1', treeSelected1)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">본부</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected2.length > 0"
                    >
                      <span>{{ treeSelected2 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData2"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected2"
                    default-expand-all
                    @update:selected="temp('트리2', treeSelected2)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">조직</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected3.length > 0"
                    >
                      <span>{{ treeSelected3 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData3"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected3"
                    default-expand-all
                    @update:selected="temp('트리3', treeSelected3)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        <img
                          class="q-tree__img q-mr-sm"
                          src="/icons/icon-tree-folder.svg"
                        />
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">팀</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected4.length > 0"
                    >
                      <span>{{ treeSelected4 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData4"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected4"
                    default-expand-all
                    @update:selected="temp('트리4', treeSelected4)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">채널</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected5.length > 0"
                    >
                      <span>{{ treeSelected5 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData5"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected5"
                    default-expand-all
                    @update:selected="temp('트리5', treeSelected5)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
            <q-expansion-item class="expansion_custom type05">
              <template v-slot:header>
                <q-item-section>
                  <div class="item_head">
                    <span class="title">선생님</span>
                    <q-badge
                      color="grey-4"
                      class="medium"
                      v-if="treeSelected6.length > 0"
                    >
                      <span>{{ treeSelected6 }}</span>
                      <!-- <span class="ex">&nbsp;외&nbsp;</span> -->
                      <!-- <span>1</span> -->
                      <!-- <span>건</span> -->
                    </q-badge>
                  </div>
                </q-item-section>
              </template>
              <q-card>
                <q-card-section>
                  <q-tree
                    :nodes="treeData6"
                    node-key="id"
                    text-color="grey-2"
                    selected-color="black"
                    class="tree type_G"
                    v-model:selected="treeSelected6"
                    default-expand-all
                    @update:selected="temp('트리6', treeSelected6)"
                  >
                    <template v-slot:default-header="prop">
                      <div
                        class="row items-center tree_item"
                        :class="prop.node.selected ? 'tree_selected' : ''"
                      >
                        {{ prop.node.label }}
                      </div>
                    </template>
                  </q-tree>
                </q-card-section>
              </q-card>
            </q-expansion-item>
          </q-list>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            outline
            unelevated
            v-close-popup
            icon=""
            class="size_sm btn_reset"
            label="초기화"
          />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_search"
            label="검색"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);
// tree
const treeData1 = [
  {
    label: '눈높이서비스부문',
    id: 'a_1',
    selected: true,
  },
  {
    label: '성장서비스부문',
    id: 'a_2',
    selected: true,
  },
  {
    label: '디지털서비스부문',
    id: 'a_3',
    selected: false,
  },
];
const treeSelected1 = ref('');

const treeData2 = [
  {
    label: '본부1',
    id: 'b_1',
    selected: false,
  },
  {
    label: '본부2',
    id: 'b_2',
    selected: false,
  },
  {
    label: '본부3',
    id: 'b_3',
    selected: true,
  },
];
const treeSelected2 = ref('');

const treeData3 = [
  {
    label: '경인본부',
    id: 'a_1',
    img: '/icons/icon-tree-folder.svg',
    selected: false,
    children: [
      {
        id: 'a_2',
        label: '권한 정보_뎁스2',
        selected: true,
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            selected: false,
            children: [
              {
                id: 'a_4',
                label: '뎁스4',
                selected: true,
              },
              {
                id: 'a_5',
                label: '뎁스4',
                selected: false,
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            selected: false,
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        selected: false,
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            selected: false,
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4', selected: false },
              { id: 'a_10', label: '뎁스4', selected: false },
            ],
          },
          { id: 'a_11', label: '뎁스3', selected: false },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        selected: false,
        children: [
          { id: 'a_13', label: '뎁스4', selected: false },
          { id: 'a_14', label: '뎁스4', selected: false },
        ],
      },
    ],
  },
];
const treeSelected3 = ref('');
const treeData4 = [
  {
    label: '본부1',
    id: 'd_1',
    selected: false,
  },
  {
    label: '본부2',
    id: 'd_2',
    selected: true,
  },
  {
    label: '본부3',
    id: 'd_3',
    selected: false,
  },
];
const treeSelected4 = ref('');
const treeData5 = [
  {
    label: '본부1',
    id: 'b_1',
    selected: false,
  },
  {
    label: '본부2',
    id: 'b_2',
    selected: true,
  },
  {
    label: '본부3',
    id: 'b_3',
    selected: false,
  },
];
const treeSelected5 = ref('');
const treeData6 = [
  {
    label: '본부1',
    id: 'b_1',
    selected: false,
  },
  {
    label: '본부2',
    id: 'b_2',
    selected: true,
  },
  {
    label: '본부3',
    id: 'b_3',
    selected: false,
  },
];
const treeSelected6 = ref('');
// 트리 셀렉트 이벤트
function temp(tree, treeTarget) {
  console.log(tree, '셀렉트 이벤트 발생', treeTarget);
}

// const ticked = ref('');
</script>
