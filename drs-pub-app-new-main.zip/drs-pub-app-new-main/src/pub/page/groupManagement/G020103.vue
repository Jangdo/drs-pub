<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">기본정보</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="기본정보" :ripple="false" />
          <q-tab name="tab2" label="채널소개" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="wrap_table_box">
              <h3 class="mb20 title1 text-grey-1">기본정보</h3>
              <table class="table_row_sales">
                <tbody>
                  <tr>
                    <th><span class="required">조직</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-input
                          v-model="searchInput3"
                          class=""
                          outlined
                          placeholder="조직을 조회하세요"
                        >
                          <template v-slot:append>
                            <q-icon name="icon-search" class="icon_svg" />
                          </template>
                        </q-input>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">채널구분</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-select
                          class="hide_label"
                          label="선택하세요"
                          v-model="search1"
                          :options="search1Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">채널코드</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-input
                          v-model="searchInput1"
                          class=""
                          outlined
                          readonly
                        />
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">채널명</span></th>
                    <td>
                      <div class="row-4">
                        <div class="search_item type_half">
                          <q-input v-model="searchInput2" class="" outlined />
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="중복확인"
                        />
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">팀</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-select
                          class="hide_label"
                          label="선택하세요"
                          v-model="search2"
                          :options="search2Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">채널순번</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-input
                          v-model="searchInput4"
                          class=""
                          outlined
                          placeholder="조직순번을 조회하세요"
                        >
                          <template v-slot:append>
                            <q-icon name="icon-search" class="icon_svg" />
                          </template>
                        </q-input>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">유형</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-select
                          class="hide_label"
                          label="선택하세요"
                          v-model="search3"
                          :options="search3Opt"
                          option-value="id"
                          option-label="desc"
                          option-disable="inactive"
                          emit-value
                          map-options
                          dense
                          outlined
                          dropdown-icon="ion-ios-arrow-down"
                        >
                        </q-select>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>출결ID</th>
                    <td>
                      <div class="row-8">
                        <div class="search_item type_fix">
                          <q-input
                            v-model="searchInput5"
                            class=""
                            outlined
                            readonly
                          />
                        </div>
                        <q-checkbox
                          v-model="cboxCheck"
                          label="출결ID 생성 여부"
                          color="black"
                          class="text-grey-1"
                        />
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">시작일</span></th>
                    <td>
                      <div class="row-8">
                        <!-- date -->
                        <div class="search_item type_fix">
                          <q-input outlined v-model="searchDate.from" class="">
                            <template v-slot:append>
                              <q-icon
                                name="icon-calendar"
                                class="icon_svg cursor-pointer"
                              >
                                <q-popup-proxy
                                  ref="qDateProxyFrom"
                                  cover
                                  transition-show="scale"
                                  transition-hide="scale"
                                >
                                  <q-date
                                    minimal
                                    mask="YYYY.MM.DD"
                                    v-model="searchDate.from"
                                    @update:model-value="
                                      searchDate.from,
                                        $refs.qDateProxyFrom.hide()
                                    "
                                  >
                                  </q-date>
                                </q-popup-proxy>
                              </q-icon>
                            </template>
                          </q-input>
                        </div>
                        <!-- // date -->
                        <!-- select -->
                        <div class="search_item type_fix">
                          <q-select
                            class="hide_label"
                            label="개설 유형선택"
                            v-model="search4"
                            :options="search4Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <!-- // select -->
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>종료일</th>
                    <td>
                      <div class="row-8">
                        <!-- date -->
                        <div class="search_item type_fix">
                          <q-input outlined v-model="searchDate.to" class="">
                            <template v-slot:append>
                              <q-icon
                                name="icon-calendar"
                                class="icon_svg cursor-pointer"
                              >
                                <q-popup-proxy
                                  ref="qDateProxyTo"
                                  cover
                                  transition-show="scale"
                                  transition-hide="scale"
                                >
                                  <q-date
                                    minimal
                                    mask="YYYY.MM.DD"
                                    v-model="searchDate.to"
                                    @update:model-value="
                                      searchDate.to, $refs.qDateProxyTo.hide()
                                    "
                                  >
                                  </q-date>
                                </q-popup-proxy>
                              </q-icon>
                            </template>
                          </q-input>
                        </div>
                        <!-- // date -->
                        <!-- select -->
                        <div class="search_item type_fix">
                          <q-select
                            class="hide_label"
                            label="폐쇄사요 선택"
                            v-model="search5"
                            :options="search5Opt"
                            option-value="id"
                            option-label="desc"
                            option-disable="inactive"
                            emit-value
                            map-options
                            dense
                            outlined
                            dropdown-icon="ion-ios-arrow-down"
                          >
                          </q-select>
                        </div>
                        <!-- // select -->
                        <!-- input -->
                        <div class="search_item type_fix">
                          <q-input
                            v-model="searchInput6"
                            class=""
                            outlined
                            placeholder="대상 채널코드 조회"
                          >
                            <template v-slot:append>
                              <q-icon name="icon-search" class="icon_svg" />
                            </template>
                          </q-input>
                        </div>
                        <!-- // input -->
                        <!-- btn -->
                        <div class="search_item type_unset">
                          <q-btn
                            unelevated
                            color="grey-3"
                            class="size_sm"
                            label="대상채널 추가"
                          />
                        </div>
                        <!-- // btn -->
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th><span class="required">전화번호</span></th>
                    <td>
                      <div class="search_item type_fix">
                        <q-input
                          v-model="searchInput7"
                          class=""
                          outlined
                          placeholder="숫자만 입력하세요"
                        />
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <th>팩스번호</th>
                    <td>
                      <div class="search_item type_fix">
                        <q-input
                          v-model="searchInput8"
                          class=""
                          outlined
                          placeholder="숫자만 입력하세요"
                        />
                      </div>
                    </td>
                  </tr>

                  <tr>
                    <th><span class="required">주소</span></th>
                    <td>
                      <div class="post_btn_area">
                        <div class="search_item type_fix">
                          <q-input v-model="searchInput9" class="" outlined />
                        </div>
                        <q-btn
                          unelevated
                          color="grey-3"
                          class="size_sm"
                          label="우편번호"
                        />
                      </div>
                      <div class="search_item type_full">
                        <q-input
                          v-model="searchInput10"
                          class=""
                          outlined
                          readonly
                        />
                      </div>
                      <div class="search_item type_full">
                        <q-input
                          v-model="searchInput11"
                          class=""
                          outlined
                          placeholder="상세주소 입력"
                        />
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="btn_area response">
                <q-btn unelevated outline class="size_lg wide" label="취소" />
                <q-btn
                  unelevated
                  color="black"
                  class="size_lg wide"
                  label="저장"
                />
                <q-btn
                  unelevated
                  color="grey-2"
                  class="size_lg btn_position_end"
                  label="목록"
                />
              </div>
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');
const cboxCheck = ref(true);

const search1 = ref(['']);
const search1Opt = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const search2 = ref(['']);
const search2Opt = ref([
  {
    id: 's21',
    desc: 'op1',
  },
  {
    id: 's22',
    desc: 'op2',
  },
]);
const search3 = ref(['']);
const search3Opt = ref([
  {
    id: 's31',
    desc: 'op1',
  },
  {
    id: 's32',
    desc: 'op2',
  },
]);
const search4 = ref(['']);
const search4Opt = ref([
  {
    id: 's41',
    desc: 'op1',
  },
  {
    id: 's42',
    desc: 'op2',
  },
]);
const search5 = ref(['']);
const search5Opt = ref([
  {
    id: 's51',
    desc: 'op1',
  },
  {
    id: 's52',
    desc: 'op2',
  },
]);

const searchInput1 = ref(['']);
const searchInput2 = ref(['']);
const searchInput3 = ref(['']);
const searchInput4 = ref(['']);
const searchInput5 = ref(['']);
const searchInput6 = ref(['']);
const searchInput7 = ref(['']);
const searchInput8 = ref(['']);
const searchInput9 = ref(['']);
const searchInput10 = ref(['']);
const searchInput11 = ref(['']);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});
</script>
