<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">회비조정신청 - 회비조정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <div class="row-7 mb10">
            <h4 class="title1 text-grey-1">회비조정 신청</h4>
            <dl class="price_wrap start">
              <dt class="text-body2 text-grey-1">총 조정 건수</dt>
              <dd class="text-body2 text-grey-1"><span>1</span>건</dd>
              <dt class="text-body2 text-grey-1">총 조정금액</dt>
              <dd class="text-body2 text-grey-1"><span>40,000</span>원</dd>
            </dl>
          </div>

          <!-- general_table -->
          <div class="table_dk">
            <q-table
              :rows="dataRows"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:header>
                <tr>
                  <th key="idx" rowspan="2">번호</th>
                  <th colspan="7">회원 학습과목</th>
                  <th colspan="4">변경 전 회비</th>
                  <th colspan="2">변경 후 회비</th>
                </tr>
                <tr>
                  <th key="tdata1" class="row_first">조직</th>
                  <th key="tdata2">선생님</th>
                  <th key="tdata3">회원명</th>
                  <th key="tdata4">회원번호</th>
                  <th key="tdata5">과목</th>
                  <th key="tdata6">요일</th>
                  <th key="tdata7">옵션</th>
                  <th key="tdata8">회비년월</th>
                  <th key="tdata9">입금액</th>
                  <th key="tdata10">학습횟수</th>
                  <th key="tdata11">회비</th>
                  <th key="tdata12">학습횟수</th>
                  <th key="tdata13">회비</th>
                </tr>
              </template>
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td key="idx" class="text-center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="text-center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="text-center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="text-center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="text-center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="text-center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="text-center">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td key="tdata7" class="text-center">
                    {{ props.row.tdata7 }}
                  </q-td>
                  <q-td key="tdata8" class="text-center">
                    {{ props.row.tdata8 }}
                  </q-td>
                  <q-td key="tdata9" class="text-center">
                    {{ props.row.tdata9 }}
                  </q-td>
                  <q-td key="tdata10" class="text-center">
                    {{ props.row.tdata10 }}
                  </q-td>
                  <q-td key="tdata11" class="text-center">
                    {{ props.row.tdata11 }}
                  </q-td>
                  <q-td key="tdata12" class="text-center">
                    {{ props.row.tdata12 }}
                  </q-td>
                  <q-td key="tdata13" class="text-center">
                    {{ props.row.tdata13 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->

          <h4 class="mt30 mb24 title1 text-grey-1">회비조정사유</h4>
          <table class="table_row_sales">
            <tbody>
              <tr>
                <th>회비조정사유</th>
                <td>회원의 퇴회로 체납회비 수수료공세 신청</td>
              </tr>
              <tr>
                <th>첨부파일</th>
                <td>
                  <ul class="list_file">
                    <li><a href="#">첨부파일 파일명.pdf</a></li>
                    <li>
                      <a href="#">첨부파일 파일명_가나다라마바사아.pdf</a>
                    </li>
                    <li><a href="#">첨부파일 파일명.pdf</a></li>
                    <li>
                      <a href="#">첨부파일 파일명_일이삼사오육칠팔구십.pdf</a>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>

          <h4 class="mt30 mb24 title1 text-grey-1">처리자 / 처리일시</h4>
          <table class="table_row_sales">
            <tbody>
              <tr>
                <th>신청</th>
                <td class="posting">
                  <span>김행정 (00234567)</span><br /><span
                    >2021.07.12 15:04:19</span
                  >
                </td>
                <th class="line_l">취소</th>
                <td class="posting">-</td>
              </tr>
              <tr>
                <th>국확</th>
                <td class="posting w320">-</td>
                <th class="line_l">본확</th>
                <td class="posting w320">-</td>
              </tr>
              <tr>
                <th>반려</th>
                <td class="posting w320">
                  <span>김행정 (00234567)</span><br /><span
                    >2021.07.12 15:04:19</span
                  >
                </td>
                <th class="line_l">기간만료</th>
                <td class="posting w320"></td>
              </tr>
            </tbody>
          </table>

          <!-- 참고하세요 -->
          <div class="wrap_info_box">
            <div class="tit_area">
              <q-icon name="info" class="icon_svg filter-grey-3" />
              <span>참고하세요</span>
            </div>
            <div class="content">
              <ul class="ul_custom disc text-grey-3">
                <li>
                  본사지원금 신청, 체납회비 수수료공제 신청건은 회비조정 신청
                  내역과 첨부 자료가 일치하는지 반드시 확인 하시기 바랍니다.
                </li>
              </ul>
            </div>
          </div>
          <!-- // 참고하세요 -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="승인반려"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="승인확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

//data테이블
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});
const dataRows = ref([
  {
    idx: 10,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 9,
    tdata1: '눈높이/눈높이/이러닝센터1팀/채널13',
    tdata2: '김김대교[1234567890]',
    tdata3: '홍길길동',
    tdata4: '1234567890123',
    tdata5: '눈높이 수학 초등',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '138,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '11,130,000',
  },
  {
    idx: 8,
    tdata1: '본부/조직/팀/채널',
    tdata2: '대교[12345678]',
    tdata3: '길동',
    tdata4: '12345',
    tdata5: '국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '8,000',
    tdata10: '1',
    tdata11: '3,000',
    tdata12: '1',
    tdata13: '3,000',
  },
  {
    idx: 7,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 6,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 5,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 4,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 3,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 2,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
  {
    idx: 1,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '1',
    tdata13: '30,000',
  },
]);
</script>
