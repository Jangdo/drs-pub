<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">운영자료</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <!-- 탭 상단 선택 -->
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          color="white"
          active-color="white"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
          keep-alive="true"
          animated
        >
          <q-tab name="tab1" label="학원운영 관련자료출력" :ripple="false" />
          <q-tab name="tab2" label="수입지출장부 조회/출력" :ripple="false" />
          <q-tab
            name="tab3"
            label="수입지출장부 지출항목입력"
            :ripple="false"
          />
          <q-tab name="tab4" label="필수 비치 서류 " :ripple="false" />
          <q-tab name="tab5" label="운영 자료 설정" :ripple="false" />
        </q-tabs>
        <!--// 탭 상단 선택 -->
        <!-- tab-panels -->
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1" keep-alive="true"> tab1 </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!--// tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!--// tab3 컨텐츠 -->

          <!-- tab4 컨텐츠 -->
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="wrapper_tab">
                <q-tabs
                  v-model="tabintab"
                  inline-label
                  class="tab_line"
                  active-bg-color="white"
                  active-color="primary"
                  indicator-color="primary"
                  align="justify"
                  narrow-indicator
                  outside-arrows
                >
                  <q-tab name="tab41" label="원칙" :ripple="false" />
                  <q-tab name="tab42" label="직원명부" :ripple="false" />
                  <q-tab name="tab43" label="지도점검기록부" :ripple="false" />
                  <q-tab name="tab44" label="학원강사 게시표" :ripple="false" />
                  <q-tab name="tab45" label="교습비 게시표" :ripple="false" />
                  <q-tab
                    name="tab46"
                    label="교습비 반환 규정"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab47"
                    label="문서접수 및 발송대장"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab48"
                    label="교습비 게시표(옥외)"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab49"
                    label="학원 안전점검 체크리스트"
                    :ripple="false"
                  />
                  <q-tab
                    name="tab410"
                    label="자체 실태 점검표 "
                    :ripple="false"
                  />
                </q-tabs>
                <q-tab-panels v-model="tabintab" animated>
                  <!-- tab41 컨텐츠 -->
                  <q-tab-panel name="tab41">41</q-tab-panel>
                  <!--// tab41 컨텐츠 -->
                  <!-- tab42 컨텐츠 -->
                  <q-tab-panel name="tab42">42</q-tab-panel>
                  <!--// tab42 컨텐츠 -->
                  <!-- tab43 컨텐츠 -->
                  <q-tab-panel name="tab43">43</q-tab-panel>
                  <!--// tab43 컨텐츠 -->
                  <!-- tab44 컨텐츠 -->
                  <q-tab-panel name="tab44">44</q-tab-panel>
                  <!--// tab44 컨텐츠 -->
                  <!-- tab45 컨텐츠 -->
                  <q-tab-panel name="tab45">45</q-tab-panel>
                  <!--// tab45 컨텐츠 -->
                  <!-- tab46 컨텐츠 -->
                  <q-tab-panel name="tab46">
                    <div class="btn_area type_g1">
                      <div class="item">
                        <ul class="list_group_row">
                          <li class="mk_disc">
                            보존기간 : <span>준영구</span>
                          </li>
                          <li class="mk_disc">비치 서류</li>
                          <li class="mk_disc">
                            최종 출력일 : <span>2023.03.04</span>
                          </li>
                        </ul>
                      </div>
                      <q-space />
                      <div class="item">
                        <q-btn
                          class="size_sm btn_basic"
                          outline
                          label="학원운영 필수 이행사항 안내"
                        />
                        <q-btn
                          class="size_sm btn_print"
                          outline
                          icon=""
                          label=""
                        />
                      </div>
                    </div>

                    <div class="document_rule">
                      <div class="outline_box">
                        <div class="title1">
                          <span>교습비 반환 규정</span>
                        </div>

                        <div class="group group1">
                          <div class="body1">반환사유</div>
                          <div class="content">
                            <ul class="ol_custom">
                              <li>
                                법 제17조의 규정에 의하여 학원의 등록이
                                말소되거나 교습소가 폐지된 경우 또는 교습소의
                                정지명령을 받은 경우
                              </li>
                              <li>
                                학원설립ㆍ운영자 또는 교습자가 교습을 할 수
                                없거나 교습장소를 제공할 수 없게 된 경우
                              </li>
                              <li>
                                학습자가 본인의 의사로 수강 또는 학습장소 사용을
                                포기한 경우
                              </li>
                            </ul>
                          </div>
                        </div>

                        <div class="group group7">
                          <div class="body1">반환금액</div>
                          <div class="content">
                            <ul class="ul_custom">
                              <li>
                                1과 2에 의한 반환사유가 발생한 경우에는 납부한
                                교습비 등을 일할계산한 금액
                              </li>
                              <li>
                                3에 의한 반환사유가 발생한 경우로써 교습개시
                                이전에는 이미 납부한 교습비등의 전액
                                <ul class="ul_custom">
                                  <li>
                                    - 총교습시간의 1/3 경과전 : 납부한 교습비의
                                    2/3
                                  </li>
                                  <li>
                                    - 총교습시간의 1/2 경과전 : 납부한 교습비의
                                    1/2
                                  </li>
                                  <li>- 총교습시간의 1/2 경과후 : 미 반환</li>
                                  <li>
                                    -
                                    <strong class="text-negative"
                                      >반환사유 발생 일로부터 5일이내에
                                      반환하여야 한다(미반환시 과태료
                                      부과).</strong
                                    >
                                  </li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="mt20">
                        <div class="info_caution">
                          <strong class="info_caution_tit"
                            ><q-icon
                              name="icon-info02"
                              class="icon_svg"
                            ></q-icon>
                            주의사항</strong
                          >
                          <p>
                            이 양식은 점검 나온 교육청 직원이 직접 작성하는
                            것이므로 양식을 출력하여 오프라인에서 관리하시기
                            바랍니다.
                          </p>
                        </div>
                      </div>
                    </div>
                  </q-tab-panel>
                  <!--// tab46 컨텐츠 -->
                  <!-- tab47 컨텐츠 -->
                  <q-tab-panel name="tab47">47</q-tab-panel>
                  <!--// tab47 컨텐츠 -->
                  <!-- tab48 컨텐츠 -->
                  <q-tab-panel name="tab48">48</q-tab-panel>
                  <!--// tab48 컨텐츠 -->
                  <!-- tab49 컨텐츠 -->
                  <q-tab-panel name="tab49">49</q-tab-panel>
                  <!--// tab49 컨텐츠 -->
                  <!-- tab410 컨텐츠 -->
                  <q-tab-panel name="tab410">410</q-tab-panel>
                  <!--// tab410 컨텐츠 -->
                </q-tab-panels>
              </div>
            </div>
          </q-tab-panel>
          <!--// tab4 컨텐츠 -->

          <!-- tab5 컨텐츠 -->
          <q-tab-panel name="tab5"> tab5 </q-tab-panel>
          <!--// tab5 컨텐츠 -->
        </q-tab-panels>
        <!--// tab-panels -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// tab
const tab = ref('tab4');
const tabintab = ref('tab46');
</script>
