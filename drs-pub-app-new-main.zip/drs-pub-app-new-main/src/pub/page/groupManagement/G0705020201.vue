<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">
        회원/과목별 이동 - 분국통합
        <!-- tooltip_down pc -->
        <q-fab
          direction="center"
          hide-icon
          class="tooltip_down type_black"
          flat
          v-if="$q.screen.name == 'lg'"
        >
          <q-fab-action
            square
            label=""
            label-position="left"
            style="margin-top: 170px; width: 400px"
          >
            <span class="btn_close"></span>
            <p class="txt text-body2 lh_x15">
              이동예정일은 영업일 기준 D+3인 경우만 승인 요청 가능합니다.
              이동선생님의 구성원등록 처리는 회원 이동 예정일 전에 필히
              처리하시기 바랍니다.
            </p>
          </q-fab-action>
        </q-fab>
        <!--// tooltip_down pc -->
        <!-- tooltip_down sm,md -->
        <q-fab
          direction="center"
          hide-icon
          class="tooltip_down type_black"
          flat
          v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
        >
          <q-fab-action
            square
            label=""
            label-position="left"
            style="margin-top: 140px; margin-right: 210px; width: 380px"
          >
            <span class="btn_close"></span>
            <p class="txt text-body2 lh_x15">
              이동예정일은 영업일 기준 D+3인 경우만 승인 요청 가능합니다.
              이동선생님의 구성원등록 처리는 회원 이동 예정일 전에 필히
              처리하시기 바랍니다.
            </p>
          </q-fab-action>
        </q-fab>
        <!--// tooltip_down sm,md -->
      </h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="이동사유를 선택하세요"
                v-model="search1"
                :options="search1Opt"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="이동사유를 선택하세요"
                v-model="search2"
                :options="search2Opt"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                outlined
                v-model="searchDate.to"
                class="box_l normal"
                readonly
                placeholder="이동 예정일을 선택하세요"
              >
                <template v-slot:append>
                  <q-icon name="icon-calendar" class="icon_svg cursor-pointer">
                    <q-popup-proxy
                      ref="qDateProxyto"
                      cover
                      transition-show="scale"
                      transition-hide="scale"
                    >
                      <q-date
                        minimal
                        v-model="searchDate.to"
                        mask="YYYY.MM.DD"
                        @update:model-value="
                          searchDate.to, $refs.qDateProxyto.hide()
                        "
                      >
                      </q-date>
                    </q-popup-proxy>
                  </q-icon>
                </template>
              </q-input>
            </div>
          </div>
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                이동선생님을 선택하시고 [승인요청]을 해주세요
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8 gap10">
              <q-btn class="size_sm" outline label="이동선생님 선택하기" />
            </div>
          </div>

          <q-table
            class="scrollable sticky_table_header tbl_row_11"
            :rows="memberRows"
            :columns="memberColumns"
            v-model:selected="memberSelected"
            row-key="idx"
            v-model:pagination="memberPagination"
            hide-bottom
            hide-pagination
            selection="multiple"
            separator="cell"
            color="black"
          >
          </q-table>
        </div>
        <!-- // general_table -->

        <!-- 버튼 -->
        <div class="btn_area btn_bottom_type01">
          <q-btn
            unelevated
            outline
            color="grey-4"
            class="size_lg"
            label="이동취소"
          />
          <q-btn unelevated color="black" class="size_lg" label="승인요청" />
        </div>
        <!-- // 버튼 -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const search1 = ref(['']);
const search1Opt = ref([
  {
    id: 's1',
    desc: 'opt1',
  },
  {
    id: 's2',
    desc: 'opt2',
  },
]);

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});

//data테이블
const memberSelected = ref([]);
const memberPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const memberColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '담당선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
    classes: 'lw_break',
  },
  {
    name: 'tdata2',
    label: '직책/직무',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '회원',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
    classes: 'lw_break',
  },
  {
    name: 'tdata4',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '과목명',
    sortable: false,
    align: 'left',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '이동선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
    classes: 'lw_break',
  },
]);
const memberRows = ref([
  {
    idx: 11,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 10,
    tdata1: '박박대교[1111234567890] 본부1명/조직1명/팀1명/채널1명',
    tdata2: '업무교사1',
    tdata3: '가나다라마바사아자카111',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드) 1111',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890111] 본부1명/조직1명/팀1명/채널1명 - 월',
  },
  {
    idx: 9,
    tdata1: '박대[1234560] 본부/조직/팀/채널',
    tdata2: '교사',
    tdata3: '가나다라마바자카',
    tdata4: '초등1',
    tdata5: '스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박교[12347890] 본부/조직/팀/채널 - 월',
  },
  {
    idx: 8,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 7,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 6,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 5,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 4,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 3,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 2,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
  {
    idx: 1,
    tdata1: '박대교[1234567890] 본부명/조직명/팀명/채널명',
    tdata2: '업무교사',
    tdata3: '가나다라마바사아자카',
    tdata4: '초등1',
    tdata5: '대교 써밋 스텝영어 (과목코드)',
    tdata6: '화',
    tdata7: '내방',
    tdata8: '박대교[1234567890] 본부명/조직명/팀명/채널명 - 월',
  },
]);
</script>
