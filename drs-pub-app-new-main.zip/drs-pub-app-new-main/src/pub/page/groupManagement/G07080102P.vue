<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">회비조정 등록</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <p class="title1 text-grey-1 mb30">검색할 조직을 선택하세요</p>

          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-12">
                  <div class="search_group">
                    <!-- 검색팝업 완료시 class placeholder 삭제 -->
                    <div class="placeholder">
                      <span>경기본부</span>
                      <span>경기병점교육국</span>
                      <span>팀</span>
                      <span>채널</span>
                      <span>선생님</span>
                    </div>
                    <q-icon name="icon-search" class="icon_svg" />
                  </div>
                </div>
              </div>
              <div class="mt10" v-if="stateHandle">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-4">
                    <q-input
                      v-model="keyword"
                      class=""
                      outlined
                      dense
                      placeholder="이름, 회원번호"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <q-btn
            class="btn_search_handle"
            fill
            color="grey-5"
            unelevated
            @click="actionHandle"
          >
            <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
            <q-icon color="white" name="ion-ios-arrow-down" v-else />
          </q-btn>
          <q-space class="sp30" />
          <!-- general_table -->
          <div class="table_dk">
            <!-- 검색결과 -->
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                <div class="text-body2 text-grey-1">
                  총 <span>00</span>건의 검색결과가 있습니다
                </div>
              </div>
            </div>
            <!-- // 검색결과 -->
            <q-table
              class="multi_head scrollable sticky_table_header"
              :rows="dataRows"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              separator="cell"
              style="height: 376px"
            >
              <template v-slot:header>
                <tr>
                  <th key="idx" rowspan="2">번호</th>
                  <th colspan="7">회원 학습과목</th>
                  <th colspan="4">변경 전 회비</th>
                  <th colspan="2">변경 후 회비</th>
                  <th rowspan="2">신청여부</th>
                </tr>
                <tr>
                  <th key="tdata1" class="row_first">조직</th>
                  <th key="tdata2">선생님</th>
                  <th key="tdata3">회원명</th>
                  <th key="tdata4">회원번호</th>
                  <th key="tdata5">과목</th>
                  <th key="tdata6">요일</th>
                  <th key="tdata7">옵션</th>
                  <th key="tdata8">회비년월</th>
                  <th key="tdata9">입금액</th>
                  <th key="tdata10">학습횟수</th>
                  <th key="tdata11">회비</th>
                  <th key="tdata12">학습회수</th>
                  <th key="tdata13">회비</th>
                </tr>
              </template>
              <template v-slot:body="props">
                <q-tr :props="props">
                  <q-td key="idx" class="text-center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="text-center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="text-center">
                    {{ props.row.tdata2 }}
                  </q-td>
                  <q-td key="tdata3" class="text-center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="text-center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="text-center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="text-center">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td key="tdata7" class="text-center">
                    {{ props.row.tdata7 }}
                  </q-td>
                  <q-td key="tdata8" class="text-center">
                    {{ props.row.tdata8 }}
                  </q-td>
                  <q-td key="tdata9" class="text-center">
                    {{ props.row.tdata9 }}
                  </q-td>
                  <q-td key="tdata10" class="text-center">
                    {{ props.row.tdata10 }}
                  </q-td>
                  <q-td key="tdata11" class="text-center">
                    {{ props.row.tdata11 }}
                  </q-td>
                  <q-td key="tdata12" class="text-center">
                    <template v-if="props.row.tdata12 == 'readonly'">
                      <q-select
                        class="hide_label"
                        label="1"
                        v-model="search1"
                        :options="search1Option"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                        readonly
                      >
                      </q-select>
                    </template>
                    <template v-if="props.row.tdata12 == ''">
                      <q-select
                        class="hide_label"
                        label="1"
                        v-model="search1"
                        :options="search1Option"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </template>
                  </q-td>
                  <q-td key="tdata13" class="text-center">
                    {{ props.row.tdata13 }}
                  </q-td>
                  <q-td key="tdata14" class="text-center">
                    {{ props.row.tdata14 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->
          <!-- 참고하세요 -->
          <div class="wrap_info_box mt40">
            <div class="tit_area">
              <q-icon name="info" class="icon_svg filter-grey-3" />
              <span>참고하세요</span>
            </div>
            <div class="content full-width">
              <ul class="ul_custom disc text-grey-3">
                <li>
                  회비조정 신청가능 기준 : a. 학습중 과목 b. 입금완료(완납)된
                  과목 c. ‘당월’과 ‘차월’ 회비만 회비조정 가능
                </li>
                <li>학습횟수 = 불출횟수</li>
                <li>신청여부 : 회비조정 신청이 되어 있는 상태</li>
                <li>
                  회비조정-, 회비조정+ 변경가능한 학습횟수
                  <!-- table -->
                  <q-markup-table
                    separator="cell"
                    wrap-cells
                    class="multi_head mt20"
                  >
                    <colgroup>
                      <col />
                      <col style="width: 40% !important" />
                      <col style="width: 45% !important" />
                    </colgroup>
                    <thead>
                      <tr>
                        <th rowspan="2">변경전<br />학습횟수</th>
                        <th colspan="2">변경가능한 학습횟수</th>
                      </tr>
                      <tr>
                        <th class="row_first">회비조정-, 재해감면신청</th>
                        <th>회비신청+, 재해감면취소</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="align_center">4</td>
                        <td class="align_center">3, 2, 1</td>
                        <td class="align_center">
                          학습횟수 4회 이상 등록은 불가
                        </td>
                      </tr>
                      <tr>
                        <td class="align_center">3</td>
                        <td class="align_center">2, 1</td>
                        <td class="align_center">4</td>
                      </tr>
                      <tr>
                        <td class="align_center">2</td>
                        <td class="align_center">1</td>
                        <td class="align_center">3, 4</td>
                      </tr>
                      <tr>
                        <td class="align_center">1</td>
                        <td class="align_center">
                          학습횟수 1회 이하 등록은 불가
                        </td>
                        <td class="align_center">2, 3, 4</td>
                      </tr>
                      <tr>
                        <td class="align_center">0</td>
                        <td class="align_center">학습횟수 0으로 신청불가</td>
                        <td class="align_center">
                          익월회비 입금액만큼 학습횟수 조정가능
                        </td>
                      </tr>
                    </tbody>
                  </q-markup-table>
                  <!-- // table -->
                </li>
              </ul>
            </div>
          </div>
          <!-- // 참고하세요 -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="신청등록"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const keyword = ref();

//data테이블
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});
const dataRows = ref([
  {
    idx: 10,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: 'readonly',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 9,
    tdata1: '눈높이/눈높이/이러닝센터1팀/채널13',
    tdata2: '김김대교[1234567890]',
    tdata3: '홍길길동',
    tdata4: '1234567890123',
    tdata5: '눈높이 수학 초등',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '138,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '11,130,000',
    tdata14: '-',
  },
  {
    idx: 8,
    tdata1: '본부/조직/팀/채널',
    tdata2: '대교[12345678]',
    tdata3: '길동',
    tdata4: '12345',
    tdata5: '국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '8,000',
    tdata10: '1',
    tdata11: '3,000',
    tdata12: '',
    tdata13: '3,000',
    tdata14: '국장승인',
  },
  {
    idx: 7,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '신청',
  },
  {
    idx: 6,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 5,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 4,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 3,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 2,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
  {
    idx: 1,
    tdata1: '본부명/조직명/팀명/채널명',
    tdata2: '김대교[12345678]',
    tdata3: '홍길동',
    tdata4: '1234567890',
    tdata5: '눈높이국어',
    tdata6: '월',
    tdata7: '내방',
    tdata8: '2022.01',
    tdata9: '38,000',
    tdata10: '1',
    tdata11: '30,000',
    tdata12: '',
    tdata13: '30,000',
    tdata14: '-',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
