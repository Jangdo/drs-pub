<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 medium">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">코드 조회</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <!-- table_search_area type_flexable -->
          <div class="table_search_area type_01">
            <div class="search_item">
              <q-input
                class="box_xl inp_search"
                outlined
                placeholder="코드를 입력하세요"
              >
              </q-input>
            </div>
            <div class="search_item">
              <q-input
                class="box_xl inp_search"
                outlined
                placeholder="명칭을 입력하세요"
              >
              </q-input>
            </div>
            <div class="btn_area">
              <q-btn fill unelevated class="size_sm btn_search" label="조회" />
            </div>
          </div>
          <!--// table_search_area type_flexable -->

          <p class="inner_tit">조회결과</p>
          <div class="table_dk">
            <q-table
              :rows="resultRows"
              :columns="resultColumns"
              :pagination="resultPagination"
              v-model:selected="result_selected"
              selection="multiple"
              row-key="idx"
              separator="cell"
              hide-bottom
              hide-pagination
              class="scrollable"
            >
              <template v-slot:header="props">
                <q-tr :props="props">
                  <q-th class="select"
                    ><q-checkbox v-model="props.selected" color="black"
                  /></q-th>
                  <q-th
                    v-for="col in props.cols"
                    :key="col.name"
                    :props="props"
                  >
                    {{ col.label }}
                  </q-th>
                </q-tr>
              </template>
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td class="select">
                    <q-checkbox v-model="props.selected" color="black" />
                  </q-td>
                  <q-td key="code" class="align_center">
                    {{ props.row.code }}</q-td
                  >
                  <q-td key="orzName" class="align_center">
                    {{ props.row.orzName }}</q-td
                  >
                </q-tr>
              </template>
            </q-table>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

//msg_table데이터
const result_selected = ref([]);
const resultColumns = ref([
  {
    name: 'code',
    label: '조직코드',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },
  {
    name: 'orzName',
    label: '조직명',
    sortable: false,
    align: 'center',
    field: (row) => row.orzName,
  },
]);
const resultRows = ref([
  {
    idx: '1',
    select: '',
    code: 'A001',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '2',
    select: '',
    code: 'A002',
    orzName: '서울서북본부',
    allow: false,
    align: 'center',
  },
  {
    idx: '3',
    select: '',
    code: 'A004',
    orzName: '서울강북본부',
    allow: false,
    align: 'center',
  },
  {
    idx: '4',
    select: '',
    code: 'A005',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '5',
    select: '',
    code: 'A006',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '6',
    select: '',
    code: 'A007',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '7',
    select: '',
    code: 'A005',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '8',
    select: '',
    code: 'A006',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
  {
    idx: '9',
    select: '',
    code: 'A007',
    orzName: '조직명',
    allow: false,
    align: 'center',
  },
]);

const resultPagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const popForm = ref(true);
</script>
