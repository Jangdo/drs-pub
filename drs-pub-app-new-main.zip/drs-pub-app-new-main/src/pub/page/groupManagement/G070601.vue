<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회비대체</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date box_m normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date box_m normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyTo"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!-- // 달력 인풋 -->
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="table_dk">
          <!-- 검색결과,정렬 -->
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              <div class="text-body2 text-grey-1">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
            </div>
            <div class="btn_wrap col-12 col-md-8">
              <q-btn
                unelevated
                class="size_sm ml10"
                color="black"
                label="신규등록"
              />
            </div>
          </div>
          <!-- // 검색결과,정렬 -->

          <q-table
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            v-model:pagination="dataPagination"
            hide-bottom
            hide-pagination
            separator="cell"
          >
          </q-table>
        </div>
        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            :max="3"
            direction-links
            boundary-links
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
          <q-pagination
            v-model="dataPagination"
            v-if="$q.screen.name == 'lg'"
            :max="5"
            direction-links
            boundary-links
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
        </div>
        <!-- // pagination -->
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.20',
});

// const pageSelected = ref(['20']);
// const pageSelectedOption = ref([
//   {
//     id: 's31',
//     desc: '10',
//   },
//   {
//     id: 's32',
//     desc: '20',
//   },
// ]);

//data테이블
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});

const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '입금일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata2',
    label: '입금구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata3',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '옵션',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '학습상태',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '입금액',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '대체회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '대체회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '대체과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
  {
    name: 'tdata13',
    label: '대체학습상태',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata13,
  },
  {
    name: 'tdata14',
    label: '마감',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata14,
  },
  {
    name: 'tdata15',
    label: '승인구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
  {
    name: 'tdata15',
    label: '승인일자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata15,
  },
]);
const dataRows = ref([
  {
    idx: 10,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 9,
    tdata1: '2022.01.01',
    tdata2: '정기결제11',
    tdata3: '000000000000011',
    tdata4: '홍홍길동',
    tdata5: '써밋스코어수학 중등1-5',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '11,110,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1-5',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '승인완료',
    tdata16: '2022.11.01',
  },
  {
    idx: 8,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000',
    tdata4: '길동',
    tdata5: '써밋스코어수학',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '1,000',
    tdata10: '000000000',
    tdata11: '홍길',
    tdata12: '써밋스코어',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 7,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 6,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 5,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 4,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 3,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 2,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
  {
    idx: 1,
    tdata1: '2022.01.01',
    tdata2: '정기결제',
    tdata3: '0000000000000',
    tdata4: '홍길동',
    tdata5: '써밋스코어수학 중등1',
    tdata6: '월요일',
    tdata7: '내방',
    tdata8: '학습상태',
    tdata9: '10,000',
    tdata10: '00000000000',
    tdata11: '홍길동',
    tdata12: '써밋스코어수학 중등1',
    tdata13: '학습상태',
    tdata14: '마감',
    tdata15: '미승인',
    tdata16: '2022.11.01',
  },
]);
</script>
