<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">마감 외 진도 수정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales mb30">
            <tbody>
              <tr>
                <th><span class="required">사업팀</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-select
                      class="hide_label"
                      label="선택해주세요"
                      v-model="search1"
                      :options="search1Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
                <th class="line_l"><span class="required">선생님</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-select
                      class="hide_label"
                      label="선택해주세요"
                      v-model="search2"
                      :options="search2Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">교재수급일</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
                <th class="line_l">적용년월</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      v-model="input1"
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>신청번호</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      v-model="input2"
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                    />
                  </div>
                </td>
                <th class="line_l">적용년월</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      v-model="input3"
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                    />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <div class="wrap_scroll_x">
            <q-markup-table separator="cell" class="combine_table" wrap-cells>
              <thead>
                <tr>
                  <th>요일</th>
                  <th>월</th>
                  <th>화</th>
                  <th>수</th>
                  <th>목</th>
                  <th>금</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th class="text-center border_bottom_1">출장일</th>
                  <td>
                    <q-input
                      outlined
                      v-model="searchDate.to1"
                      class="w150 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo1"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to1"
                              @update:model-value="
                                searchDate.to1, $refs.qDateProxyTo1.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </td>
                  <td>
                    <q-input
                      outlined
                      v-model="searchDate.to2"
                      class="w150 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo2"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to2"
                              @update:model-value="
                                searchDate.to2, $refs.qDateProxyTo2.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </td>
                  <td>
                    <q-input
                      outlined
                      v-model="searchDate.to3"
                      class="w150 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo3"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to3"
                              @update:model-value="
                                searchDate.to3, $refs.qDateProxyTo3.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </td>
                  <td>
                    <q-input
                      outlined
                      v-model="searchDate.to4"
                      class="w150 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo4"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to4"
                              @update:model-value="
                                searchDate.to4, $refs.qDateProxyTo4.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </td>
                  <td>
                    <q-input
                      outlined
                      v-model="searchDate.to5"
                      class="w150 normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo5"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to5"
                              @update:model-value="
                                searchDate.to5, $refs.qDateProxyTo5.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </td>
                </tr>
                <tr>
                  <th class="text-center">출장주분</th>
                  <td>
                    <div class="row-4">
                      <q-input
                        v-model="input4"
                        class="w100"
                        for=""
                        outlined
                        dense
                      />
                      <span>주분</span>
                    </div>
                  </td>
                  <td>
                    <div class="row-4">
                      <q-input
                        v-model="input5"
                        class="w100"
                        for=""
                        outlined
                        dense
                      />
                      <span>주분</span>
                    </div>
                  </td>
                  <td>
                    <div class="row-4">
                      <q-input
                        v-model="input6"
                        class="w100"
                        for=""
                        outlined
                        dense
                      />
                      <span>주분</span>
                    </div>
                  </td>
                  <td>
                    <div class="row-4">
                      <q-input
                        v-model="input7"
                        class="w100"
                        for=""
                        outlined
                        dense
                      />
                      <span>주분</span>
                    </div>
                  </td>
                  <td>
                    <div class="row-4">
                      <q-input
                        v-model="input8"
                        class="w100"
                        for=""
                        outlined
                        dense
                      />
                      <span>주분</span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </q-markup-table>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="삭제"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
const popForm = ref(true);

const input1 = ref('2023.01.01');
const input2 = ref('100');
const input3 = ref('2023.01.28');
const input4 = ref('2');
const input5 = ref('1');
const input6 = ref('3');
const input7 = ref('1');
const input8 = ref('4');

const searchDate = ref({
  from: '2019.02.01',
  to1: '2020.03.02',
  to2: '2020.03.04',
  to3: '2020.03.06',
  to4: '2020.03.07',
  to5: '2020.03.11',
});
const search1 = ref(['']);
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const search2 = ref(['']);
const search2Option = ref([
  {
    id: 's21',
    desc: 'op1',
  },
  {
    id: 's22',
    desc: 'op2',
  },
]);
</script>
