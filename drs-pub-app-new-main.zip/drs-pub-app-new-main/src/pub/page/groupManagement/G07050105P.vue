<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02 large">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">이동 선생님 및 요일 선택</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <p class="title1 text-grey-1 mb20">검색할 조직을 선택하세요</p>

          <div class="search_wrap">
            <div class="search_cnt">
              <div class="row q-col-gutter-sm">
                <div class="col-12 col-md-12">
                  <div class="search_group">
                    <!-- 검색팝업 완료시 class placeholder 삭제 -->
                    <div class="placeholder">
                      <span>경기본부</span>
                      <span>경기병점교육국</span>
                      <span>팀</span>
                      <span>채널</span>
                      <span>선생님</span>
                    </div>
                    <q-icon name="icon-search" class="icon_svg" />
                  </div>
                </div>
              </div>
              <div class="mt10" v-if="stateHandle">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-4">
                    <q-input
                      v-model="keyword"
                      class=""
                      outlined
                      dense
                      placeholder="이름, 회원번호"
                    >
                      <template v-slot:append>
                        <q-icon name="icon-search" class="icon_svg" />
                      </template>
                    </q-input>
                  </div>
                </div>
              </div>
            </div>
            <div class="btn_area">
              <q-btn outline class="size_sm btn_reset" icon="" label="">
                <span class="a11y">초기화</span>
              </q-btn>
              <q-btn class="size_sm btn_search" fill unelevated label="조회" />
            </div>
          </div>
          <q-btn
            class="btn_search_handle"
            fill
            color="grey-5"
            unelevated
            @click="actionHandle"
          >
            <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
            <q-icon color="white" name="ion-ios-arrow-down" v-else />
          </q-btn>

          <!-- general_table -->
          <div class="general_table pt20">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                <div class="text-body2 text-grey-1">
                  총 <span>00</span>건의 검색결과가 있습니다
                </div>
              </div>
            </div>

            <q-table
              :rows="dataRows"
              :columns="dataColumns"
              row-key="idx"
              v-model:pagination="dataPagination"
              v-model:selected="dataSelected"
              hide-bottom
              hide-pagination
              separator="cell"
            >
              <template v-slot:body="props">
                <q-tr :class="props.row.state" :props="props">
                  <q-td key="radio">
                    <q-radio
                      v-model="props.selected"
                      color="black"
                      checked-icon="trip_origin"
                      unchecked-icon="radio_button_unchecked"
                      class="check_to_radio"
                    />
                  </q-td>
                  <q-td key="idx" class="align_center">
                    {{ props.row.idx }}
                  </q-td>
                  <q-td key="tdata1" class="align_center">
                    {{ props.row.tdata1 }}
                  </q-td>
                  <q-td key="tdata2" class="align_center">
                    <q-select
                      class="hide_label w100"
                      label="선택"
                      v-model="dayselect"
                      :options="dayselectOpt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </q-td>
                  <q-td key="tdata3" class="align_center">
                    {{ props.row.tdata3 }}
                  </q-td>
                  <q-td key="tdata4" class="align_center">
                    {{ props.row.tdata4 }}
                  </q-td>
                  <q-td key="tdata5" class="align_center">
                    {{ props.row.tdata5 }}
                  </q-td>
                  <q-td key="tdata6" class="align_center">
                    {{ props.row.tdata6 }}
                  </q-td>
                  <q-td key="tdata7" class="align_center">
                    {{ props.row.tdata7 }}
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
          <!-- // general_table -->
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="선택완료"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

const popForm = ref(true);

const keyword = ref();

//data테이블
const dayselect = ref(['']);
const dayselectOpt = ref([
  {
    id: 'd1',
    desc: '월',
  },
  {
    id: 'd2',
    desc: '화',
  },
]);

const dataSelected = ref();
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});

const dataColumns = ref([
  {
    name: 'radio',
    label: '',
    sortable: false,
    align: 'center',
    field: (row) => row.radio,
  },
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '선생님',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '본부',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '조직',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
    classes: 'lw_break',
  },
  {
    name: 'tdata6',
    label: '채널',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '직책/직무',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 10,
    radio: false,
    tdata1: '김김대교[111234567890]',
    tdata2: '',
    tdata3: '서울서북1본부',
    tdata4: '강서1교육국',
    tdata5: '0011',
    tdata6: 'yc11바디꿈',
    tdata7: '업무 교사',
  },
  {
    idx: 9,
    radio: true,
    tdata1: '김대[1237890]',
    tdata2: '',
    tdata3: '서북본부',
    tdata4: '강서국',
    tdata5: '01',
    tdata6: 'yc1',
    tdata7: '교사',
  },
  {
    idx: 8,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 7,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 6,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 5,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 4,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 3,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 2,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
  {
    idx: 1,
    radio: true,
    tdata1: '김대교[1234567890]',
    tdata2: '',
    tdata3: '서울서북본부',
    tdata4: '강서교육국',
    tdata5: '001',
    tdata6: 'yc1바디꿈',
    tdata7: '업무교사',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
