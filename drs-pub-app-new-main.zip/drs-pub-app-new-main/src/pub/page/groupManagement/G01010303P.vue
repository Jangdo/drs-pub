<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="wrap_move_tr">
      <q-card class="respons_card type_tree">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">조직순번 설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content wrap_mov_tr">
          <div class="table_dk">
            <q-table
              :rows="setTurnRows"
              :columns="setTurnColumns"
              :pagination="setTurnPagination"
              separator="cell"
              hide-pagination
              hide-bottom
              class="scrollable sticky_table_header"
            >
              <template v-slot:body="props">
                <q-tr
                  class="move_tr"
                  :class="[props.row.state ? 'select' : '']"
                  :props="props"
                  @click="clickTr(props.row.code)"
                >
                  <q-td key="code" class="align_center cursor">{{
                    props.row.code
                  }}</q-td>
                  <q-td key="orzName" class="cursor td_check">
                    <div class="row justify-between align-center">
                      <span class="">{{ props.row.orzName }}</span>
                      <q-icon
                        name="icon-check"
                        :class="[props.row.state ? '' : 'filter-white']"
                        class="icon_svg"
                      />
                    </div>
                  </q-td>
                </q-tr>
              </template>
            </q-table>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <div class="btn_area_move_tr mb30">
            <q-btn outline class="size_sm" label="맨위로" />
            <q-btn outline class="size_sm" label="위로" />
            <q-btn outline class="size_sm" label="아래로" />
            <q-btn outline class="size_sm" label="맨아래로" />
          </div>
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
const setTurnColumns = ref([
  {
    name: 'code',
    label: '조직코드',
    sortable: false,
    align: 'center',
    field: (row) => row.code,
  },
  {
    name: 'orzName',
    label: '조직명',
    sortable: false,
    align: 'center',
    field: (row) => row.orzName,
  },
]);
const setTurnRows = ref([
  {
    code: 'A001',
    orzName: '강서교육국',
    state: true,
    align: 'center',
  },
  {
    code: 'A002',
    orzName: '조직명1',
    state: false,
    align: 'center',
  },
  {
    code: 'A003',
    orzName: '조직명2',
    state: false,
    align: 'center',
  },
  {
    code: 'A004',
    orzName: '강서교육국',
    state: false,
    align: 'center',
  },
  {
    code: 'A005',
    orzName: '조직명1',
    state: false,
    align: 'center',
  },
  {
    code: 'A006',
    orzName: '조직명2',
    state: false,
    align: 'center',
  },
  {
    code: 'A007',
    orzName: '강서교육국',
    state: false,
    align: 'center',
  },
  {
    code: 'A008',
    orzName: '조직명1',
    state: false,
    align: 'center',
  },
  {
    code: 'A009',
    orzName: '조직명2',
    state: false,
    align: 'center',
  },
  {
    code: 'A010',
    orzName: '강서교육국',
    state: false,
    align: 'center',
  },
]);
function clickTr(code) {
  console.log(code + '선택');
}
const setTurnPagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
  // rowsNumber: xx if getting data from a server
});

const popForm = ref(true);
</script>
