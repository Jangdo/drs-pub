<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">내용증명서 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-12">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                  <span>팀</span>
                  <span>채널</span>
                  <span>선생님</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="처리현황 전체"
                v-model="search1"
                :options="search1Option"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrapper_tab">
        <div class="wrap_table_box">
          <!-- general_table -->
          <div class="table_dk">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
              <div class="btn_wrap col-12 col-md-8">
                <q-btn outline class="size_sm" label="내용증명서 출력" />
              </div>
            </div>
            <q-table
              :rows="dataRows"
              :columns="dataColumns"
              v-model:selected="dataSelected"
              row-key="idx"
              v-model:pagination="dataPagination"
              hide-bottom
              hide-pagination
              selection="multiple"
              separator="cell"
              color="black"
            >
            </q-table>
          </div>
          <!-- pagination -->
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- // pagination -->
          <!-- // general_table -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const search1 = ref();
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);

//data테이블
const dataSelected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const dataColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '체납과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '체납회비',
    sortable: false,
    align: 'right',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '체납기간',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '우편번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '주소',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '신청 사유',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '담당교사',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '처리현황',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 10,
    tdata1: '김김윤찬',
    tdata2: '110031044761',
    tdata3: '전화영어2',
    tdata4: '1,155,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워 11층',
    tdata8: '체납',
    tdata9: '김미옥 [110031044761]',
    tdata10: '발송요청 대기',
  },
  {
    idx: 9,
    tdata1: '윤찬',
    tdata2: '044761',
    tdata3: '수학',
    tdata4: '5,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23',
    tdata8: '체납',
    tdata9: '김미옥 [003104]',
    tdata10: '발송요청',
  },
  {
    idx: 8,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 7,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 6,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 5,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 4,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 3,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 2,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
  {
    idx: 1,
    tdata1: '김윤찬',
    tdata2: '0031044761',
    tdata3: '통신수학',
    tdata4: '55,000원',
    tdata5: '2022.10.01~2022.10.31',
    tdata6: '00000',
    tdata7: '서울 관악구 보라매로3길 23 대교타워',
    tdata8: '체납',
    tdata9: '김미옥 [0031044761]',
    tdata10: '발송요청',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
