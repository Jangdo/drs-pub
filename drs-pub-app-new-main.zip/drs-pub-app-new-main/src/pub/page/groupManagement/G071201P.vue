<template>
  <div class="page_sales">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="">
      <q-card class="respons_card type_02">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">내용증명서 상세</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <q-card-section class="dialog_content">
          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>회원명</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input1"
                    />
                  </div>
                </td>
                <th class="line_l"><span class="required">선생님</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input2"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>체납기록</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input3"
                    />
                  </div>
                </td>
                <th class="line_l h0" colspan="2"></th>
              </tr>
              <tr>
                <th><span class="required">통신유입일</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
                <th class="line_l">퇴회일자</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input4"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>체납회비</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      input-class="text-right"
                      outlined
                      dense
                      readonly
                      v-model="input5"
                    />
                  </div>
                </td>
                <th class="line_l"><span class="required">입금기한</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      outlined
                      v-model="searchDate.to"
                      class="normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to"
                              @update:model-value="
                                searchDate.to, $refs.qDateProxyTo.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">체납기간</span></th>
                <td colspan="3">
                  <div class="row-8 gap10">
                    <!-- 달력 인풋 -->
                    <div class="search_item type_medium">
                      <q-input
                        outlined
                        v-model="searchDate.from2"
                        class="normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom2"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.from2"
                                @update:model-value="
                                  searchDate.from2, $refs.qDateProxyFrom2.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                    <!-- // 달력 인풋 -->
                    <span class="text-body2 text-grey-3">-</span>
                    <!-- 달력 인풋 -->
                    <div class="search_item type_medium">
                      <q-input
                        outlined
                        v-model="searchDate.to2"
                        class="normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyTo2"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.to2"
                                @update:model-value="
                                  searchDate.to2, $refs.qDateProxyTo2.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                    <!-- // 달력 인풋 -->
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">주소</span></th>
                <td colspan="3">
                  <div class="row-8 gap10">
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input6"
                      />
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="grey-3"
                      class="size_sm"
                      label="우편번호"
                    />
                  </div>
                  <div class="row-8 mt10">
                    <div class="search_item flex_auto">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input7"
                      />
                    </div>
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input8"
                      />
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">신청사유</span></th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input9"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>세부내용</th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input10"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>관리자사유</th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input11"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <div class="title1 text-pink mt30 mb30">
            위 아래 2종 중 알맞는 케이스의 table을 사용하세요. 개발하실 때에 이
            div는 삭제 하세요.
          </div>

          <table class="table_row_sales mb0">
            <tbody>
              <tr>
                <th>회원명</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input1"
                    />
                  </div>
                </td>
                <th class="line_l"><span class="required">선생님</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input2"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>체납기록</th>
                <td colspan="3">
                  <div class="search_item type_fix">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input3"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">통신유입일</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
                <th class="line_l">퇴회일자</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      readonly
                      v-model="input4"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>체납회비</th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      class=""
                      for=""
                      input-class="text-right"
                      outlined
                      dense
                      readonly
                      v-model="input5"
                    />
                  </div>
                </td>
                <th class="line_l"><span class="required">입금기한</span></th>
                <td>
                  <div class="search_item type_medium">
                    <q-input
                      outlined
                      v-model="searchDate.to"
                      class="normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyTo"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.to"
                              @update:model-value="
                                searchDate.to, $refs.qDateProxyTo.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">체납기간</span></th>
                <td colspan="3">
                  <div class="row-8 gap10">
                    <!-- 달력 인풋 -->
                    <div class="search_item type_medium">
                      <q-input
                        outlined
                        v-model="searchDate.from2"
                        class="normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyFrom2"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.from2"
                                @update:model-value="
                                  searchDate.from2, $refs.qDateProxyFrom2.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                    <!-- // 달력 인풋 -->
                    <span class="text-body2 text-grey-3">-</span>
                    <!-- 달력 인풋 -->
                    <div class="search_item type_medium">
                      <q-input
                        outlined
                        v-model="searchDate.to2"
                        class="normal"
                        readonly
                      >
                        <template v-slot:append>
                          <q-icon
                            name="icon-calendar"
                            class="icon_svg cursor-pointer"
                          >
                            <q-popup-proxy
                              ref="qDateProxyTo2"
                              cover
                              transition-show="scale"
                              transition-hide="scale"
                            >
                              <q-date
                                minimal
                                mask="YYYY.MM.DD"
                                v-model="searchDate.to2"
                                @update:model-value="
                                  searchDate.to2, $refs.qDateProxyTo2.hide()
                                "
                              >
                              </q-date>
                            </q-popup-proxy>
                          </q-icon>
                        </template>
                      </q-input>
                    </div>
                    <!-- // 달력 인풋 -->
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">주소</span></th>
                <td colspan="3">
                  <div class="row-8 gap10">
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input6"
                      />
                    </div>
                    <q-btn
                      fill
                      unelevated
                      color="grey-3"
                      class="size_sm"
                      label="우편번호"
                    />
                  </div>
                  <div class="row-8 mt10">
                    <div class="search_item flex_auto">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input7"
                      />
                    </div>
                    <div class="search_item type_medium">
                      <q-input
                        class=""
                        for=""
                        outlined
                        dense
                        v-model="input8"
                      />
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">신청사유</span></th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input12"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th>세부내용</th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input13"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="required">우편발송구분</span></th>
                <td colspan="3">
                  <div class="search_item type_fix">
                    <q-select
                      class="hide_label"
                      label="선택해주세요"
                      v-model="search1"
                      :options="search1Option"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </td>
              </tr>
              <tr>
                <th>관리자사유</th>
                <td colspan="3">
                  <div class="search_item type_full">
                    <q-input
                      class=""
                      for=""
                      outlined
                      dense
                      v-model="input14"
                      placeholder="입력해주세요."
                    />
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="저장"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
const popForm = ref(true);

const input1 = ref('김윤찬');
const input2 = ref('123456789');
const input3 = ref('전화영어');
const input4 = ref('2023.05.03');
const input5 = ref('120,000원');
const input6 = ref('12345');
const input7 = ref('서울 관악구 보라매로3길 23 대교타워');
const input8 = ref('');
const input9 = ref('');
const input10 = ref('');
const input11 = ref('');
const input12 = ref('체납');
const input13 = ref('관리교사가 입력한 내용 보여줌.');
const input14 = ref('기입 된 내용 노출 혹은 추가입력 가능');

const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
  from2: '2020.03.01',
  to2: '2020.03.02',
});

const search1 = ref(['']);
const search1Option = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
</script>
