<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">학습일정표 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="학습일정표 출력" :ripple="false" />
          <q-tab name="tab2" label="학습일정표 스티커 발행" :ripple="false" />
          <q-tab name="tab3" label="긴급교재 스티커 발행" :ripple="false" />
          <q-tab
            name="tab4"
            label="분국통합 학습일정표 스티커 발생"
            :ripple="false"
          />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <q-tab-panel name="tab1">학습일정표 출력</q-tab-panel>
          <q-tab-panel name="tab2">학습일정표 스티커 발행</q-tab-panel>
          <q-tab-panel name="tab3">긴급교재 스티커 발행</q-tab-panel>
          <q-tab-panel name="tab4">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-3">
                    <q-input
                      outlined
                      v-model="searchDate.from"
                      class="inp_date normal"
                      readonly
                    >
                      <template v-slot:append>
                        <q-icon
                          name="icon-calendar"
                          class="icon_svg cursor-pointer"
                        >
                          <q-popup-proxy
                            ref="qDateProxyFrom"
                            cover
                            transition-show="scale"
                            transition-hide="scale"
                          >
                            <q-date
                              minimal
                              mask="YYYY.MM.DD"
                              v-model="searchDate.from"
                              @update:model-value="
                                searchDate.from, $refs.qDateProxyFrom.hide()
                              "
                            >
                            </q-date>
                          </q-popup-proxy>
                        </q-icon>
                      </template>
                    </q-input>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-select
                      class="box_l hide_label"
                      label="본부 선택"
                      v-model="search1"
                      :options="search1Opt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-select
                      class="box_l hide_label"
                      label="변경전 조직 선택"
                      v-model="search2"
                      :options="search2Opt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                  <div class="col-12 col-md-3">
                    <q-select
                      class="box_l hide_label"
                      label="변경후 조직 선택"
                      v-model="search3"
                      :options="search3Opt"
                      option-value="id"
                      option-label="desc"
                      option-disable="inactive"
                      emit-value
                      map-options
                      dense
                      outlined
                      dropdown-icon="ion-ios-arrow-down"
                    >
                    </q-select>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>

            <div class="wrap_table_box">
              <div class="table_top">
                <div
                  class="info_wrap col-12 col-md-6"
                  style="align-items: center"
                >
                  <span class="text-body2 mr10">발행형태</span>
                  <q-radio
                    v-model="dataRadio"
                    val="print"
                    label="5열 발행"
                    color="black"
                    checked-icon="trip_origin"
                    unchecked-icon="radio_button_unchecked"
                    class="check_to_radio"
                  />
                  <span class="text-body2 ml80" v-if="$q.screen.name == 'lg'"
                    >인쇄유형</span
                  >
                  <span
                    class="text-body2"
                    v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                    >인쇄유형</span
                  >
                  <q-option-group
                    v-model="printGroup"
                    :options="printGroupOpt"
                    color="black"
                    inline
                  />
                </div>
                <div class="btn_wrap col-12 col-md-6">
                  <q-btn class="size_sm btn_print" outline icon="" label="" />
                </div>
              </div>
              <!-- general_table -->
              <div class="table_dk">
                <q-table
                  :rows="dataRows"
                  :columns="dataColumns"
                  v-model:selected="dataSelected"
                  row-key="idx"
                  v-model:pagination="dataPagination"
                  hide-bottom
                  hide-pagination
                  selection="multiple"
                  separator="cell"
                  color="black"
                >
                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th class="select">선택</q-th>
                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- // general_table -->
            </div>
          </q-tab-panel>
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const tab = ref('tab4');

// table_search_area
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const search1 = ref();
const search1Opt = ref([
  {
    id: 's11',
    desc: 'op1',
  },
  {
    id: 's12',
    desc: 'op2',
  },
]);
const search2 = ref();
const search2Opt = ref([
  {
    id: 's21',
    desc: 'op1',
  },
  {
    id: 's22',
    desc: 'op2',
  },
]);
const search3 = ref();
const search3Opt = ref([
  {
    id: 's31',
    desc: 'op1',
  },
  {
    id: 's32',
    desc: 'op2',
  },
]);

const dataRadio = ref('print');
const printGroup = ref('op1');
const printGroupOpt = ref([
  {
    label: '가로',
    value: 'op1',
  },
  {
    label: '세로',
    value: 'op2',
  },
]);

//data테이블
const dataSelected = ref([]);
const dataPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 10,
});
const dataColumns = ref([
  {
    name: 'tdata1',
    label: '교재수급일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '사번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '교사명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '교실명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '진도순번',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
  {
    name: 'tdata9',
    label: '진도',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata9,
  },
  {
    name: 'tdata10',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata10,
  },
  {
    name: 'tdata11',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata11,
  },
  {
    name: 'tdata12',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata12,
  },
]);
const dataRows = ref([
  {
    idx: 11,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 10,
    tdata1: '2021.02.01',
    tdata2: '00111',
    tdata3: '11345678002',
    tdata4: '홍홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 신동아2, 삼성, 종합',
    tdata7: '눈높이 수학 1-5',
    tdata8: '1',
    tdata9: 'G104',
    tdata10: '초등4',
    tdata11: '10055191130',
    tdata12: '홍홍길동',
  },
  {
    idx: 9,
    tdata1: '2021.02.01',
    tdata2: '01',
    tdata3: '3458002',
    tdata4: '길동',
    tdata5: '월',
    tdata6: '신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G1',
    tdata10: '만6세',
    tdata11: '00591130',
    tdata12: '홍길',
  },
  {
    idx: 8,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 7,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 6,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 5,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 4,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 3,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 2,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
  {
    idx: 1,
    tdata1: '2021.02.01',
    tdata2: '001',
    tdata3: '345678002',
    tdata4: '홍길동',
    tdata5: '월',
    tdata6: '우성 1,2,3, 신동아, 삼성, 종합',
    tdata7: '눈높이수학',
    tdata8: '1',
    tdata9: 'G04',
    tdata10: '만0세',
    tdata11: '0055191130',
    tdata12: '홍길동',
  },
]);
</script>
