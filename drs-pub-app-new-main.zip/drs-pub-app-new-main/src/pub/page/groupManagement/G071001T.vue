<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회원학습현황</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="wrapper_tab">
        <q-tabs
          v-model="tab"
          dense
          class="tab_basic"
          :active-bg-color="
            $route.matched[1].props.default.userType === 'teacher'
              ? 'positive'
              : 'primary'
          "
          active-color="white"
          indicator-color="transparent"
          align="justify"
          narrow-indicator
          outside-arrows
        >
          <q-tab name="tab1" label="회원관리일지" :ripple="false" />
          <q-tab name="tab2" label="총원명부" :ripple="false" />
          <q-tab name="tab3" label="가구별 학습현황" :ripple="false" />
        </q-tabs>
        <q-tab-panels v-model="tab" animated>
          <!-- tab1 컨텐츠 -->
          <q-tab-panel name="tab1">
            <div class="search_wrap">
              <div class="search_cnt">
                <div class="row q-col-gutter-sm">
                  <div class="col-12 col-md-12">
                    <div class="search_group">
                      <!-- 검색팝업 완료시 class placeholder 삭제 -->
                      <div class="placeholder">
                        <span>부문</span>
                        <span>본부</span>
                        <span>교육국</span>
                        <span>팀</span>
                        <span>채널</span>
                        <span>선생님</span>
                      </div>
                      <q-icon name="icon-search" class="icon_svg" />
                    </div>
                  </div>
                </div>
                <div class="mt10" v-if="stateHandle">
                  <div class="row q-col-gutter-sm">
                    <div class="col-12 col-md-3">
                      <div class="wrap_opt_group">
                        <q-option-group
                          class="opt_group_custom week_type"
                          type="checkbox"
                          color="blue-3"
                          v-model="day"
                          :options="dayOption"
                        />
                      </div>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-input
                        class="inp_search"
                        outlined
                        dense
                        placeholder="제품"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                    <div class="col-12 col-md-3">
                      <q-input
                        class="inp_search"
                        outlined
                        dense
                        placeholder="학년"
                      >
                        <template v-slot:append>
                          <q-icon name="icon-search" class="icon_svg" />
                        </template>
                      </q-input>
                    </div>
                  </div>
                </div>
              </div>
              <div class="btn_area">
                <q-btn outline class="size_sm btn_reset" icon="" label="">
                  <span class="a11y">초기화</span>
                </q-btn>
                <q-btn
                  class="size_sm btn_search"
                  fill
                  unelevated
                  label="조회"
                />
              </div>
            </div>
            <q-btn
              class="btn_search_handle"
              fill
              color="grey-5"
              unelevated
              @click="actionHandle"
            >
              <q-icon
                color="white"
                name="ion-ios-arrow-up"
                v-if="stateHandle"
              />
              <q-icon color="white" name="ion-ios-arrow-down" v-else />
            </q-btn>

            <div class="wrap_table_box">
              <!-- general_table -->
              <div class="table_dk">
                <div class="table_top">
                  <div class="info_wrap col-12 col-md-4">
                    총 <span>00</span>건의 검색결과가 있습니다
                  </div>
                  <div class="btn_wrap col-12 col-md-8">
                    <q-btn class="size_sm btn_print" outline icon="" label="" />
                  </div>
                </div>
                <q-table
                  :rows="memberRows"
                  :columns="memberColumns"
                  v-model:selected="memberSelected"
                  row-key="idx"
                  v-model:pagination="memberPagination"
                  hide-bottom
                  hide-pagination
                  selection="multiple"
                  separator="cell"
                  color="black"
                >
                  <template v-slot:header="props">
                    <q-tr :props="props">
                      <q-th class="select">선택</q-th>
                      <q-th
                        v-for="col in props.cols"
                        :key="col.name"
                        :props="props"
                      >
                        {{ col.label }}
                      </q-th>
                    </q-tr>
                  </template>
                </q-table>
              </div>
              <!-- // general_table -->
            </div>
          </q-tab-panel>
          <!--// tab1 컨텐츠 -->

          <!-- tab2 컨텐츠 -->
          <q-tab-panel name="tab2"> tab2 </q-tab-panel>
          <!-- // tab2 컨텐츠 -->

          <!-- tab3 컨텐츠 -->
          <q-tab-panel name="tab3"> tab3 </q-tab-panel>
          <!-- // tab3 컨텐츠 -->
        </q-tab-panels>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tab = ref('tab1');

const day = ref(['tues']);
const dayOption = ref([
  { label: '전체', value: 'all' },
  { label: '월', value: 'mon' },
  { label: '화', value: 'tues' },
  { label: '수', value: 'wed' },
  { label: '목', value: 'thurs' },
  { label: '금', value: 'fri' },
]);

//data테이블
const memberSelected = ref([]);
const memberPagination = ref({
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 9999,
});
const memberColumns = ref([
  {
    name: 'idx',
    label: 'No',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '사업팀',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '선생님명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '회원명',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '회원번호',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
  {
    name: 'tdata5',
    label: '학습요일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata5,
  },
  {
    name: 'tdata6',
    label: '학습과목',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata6,
  },
  {
    name: 'tdata7',
    label: '학년',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata7,
  },
  {
    name: 'tdata8',
    label: '학습개월',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata8,
  },
]);
const memberRows = ref([
  {
    idx: 11,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 10,
    tdata1: '0011',
    tdata2: '김정정숙[11003111044761]',
    tdata3: '김김윤찬',
    tdata4: '003104476111',
    tdata5: '월요일',
    tdata6: '눈높이 초등 수학 1-5',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 9,
    tdata1: '001',
    tdata2: '김숙[00310761]',
    tdata3: '김윤',
    tdata4: '003101',
    tdata5: '월요일',
    tdata6: '수학',
    tdata7: '초등 2',
    tdata8: '6개월',
  },
  {
    idx: 8,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 7,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 6,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 5,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 4,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 3,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 2,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
  {
    idx: 1,
    tdata1: '001',
    tdata2: '김정숙[0031044761]',
    tdata3: '김윤찬',
    tdata4: '0031044761',
    tdata5: '월요일',
    tdata6: '눈높이 수학',
    tdata7: '초등 2',
    tdata8: '24개월',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
