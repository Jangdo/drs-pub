<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">월업무계획결산</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <!-- 결산 검색 범위 -->
      <div class="makeup_scope">
        <div class="title1">2023년 03월</div>
        <div class="scope title4">
          <span>서울서북본부</span> > <span>강서조직</span> >
          <span>가양등촌</span> > <span>LC1</span>
        </div>
      </div>
      <!--// 결산 검색 범위 -->

      <q-card class="wrap_table_box">
        <!-- sales_subtit_area -->
        <div class="sales_subtit_area">
          <h3 class="title1">주요 보급 성과 결과</h3>
        </div>
        <!-- //sales_subtit_area -->
        <!-- markup-table -->
        <q-markup-table separator="cell" class="table_dk" wrap-cells>
          <thead>
            <tr>
              <th>구분</th>
              <th>입회</th>
              <th>퇴회</th>
              <th>순증</th>
              <th>입회율</th>
              <th>퇴회율</th>
              <th>순증률</th>
              <th>월초총원</th>
              <th>월말총원</th>
              <th>총원증감</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">목표</td>
              <td class="text-right">100</td>
              <td class="text-right">20</td>
              <td class="text-right">1</td>
              <td class="text-right bg_grey"></td>
              <td class="text-right bg_grey"></td>
              <td class="text-right bg_grey"></td>
              <td class="text-right bg_grey"></td>
              <td class="text-right">581</td>
              <td class="text-right bg_grey"></td>
            </tr>
            <tr>
              <td class="text-center">결과</td>
              <td class="text-right">10</td>
              <td class="text-right">5</td>
              <td class="text-right">3</td>
              <td class="text-right">3.18%</td>
              <td class="text-right">3.68%</td>
              <td class="text-right">-0.50%</td>
              <td class="text-right">601</td>
              <td class="text-right">581</td>
              <td class="text-right">-5</td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- //markup-table -->

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area mt60">
          <h3 class="title1">주요 관리 항목 결과</h3>
        </div>
        <!-- //sales_subtit_area -->
        <!-- markup-table -->
        <q-markup-table separator="cell" class="table_dk" wrap-cells>
          <thead>
            <tr>
              <th>구분</th>
              <th>1월</th>
              <th>2월</th>
              <th>3월</th>
              <th>4월</th>
              <th>5월</th>
              <th>6월</th>
              <th>7월</th>
              <th>8월</th>
              <th>9월</th>
              <th>10월</th>
              <th>11월</th>
              <th>12월</th>
              <th>누적</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">순증</td>
              <td class="text-right">-26</td>
              <td class="text-right">-26</td>
              <td class="text-right">1</td>
              <td class="text-right">-26</td>
              <td class="text-right">-261</td>
              <td class="text-right">-26</td>
              <td class="text-right">100</td>
              <td class="text-right">-26</td>
              <td class="text-right">-26</td>
              <td class="text-right">-26</td>
              <td class="text-right">-26</td>
              <td class="text-right">-126</td>
              <td class="text-right">-26</td>
            </tr>
            <tr>
              <td class="text-center">퇴회율</td>
              <td class="text-right">1</td>
              <td class="text-right">10</td>
              <td class="text-right">100</td>
              <td class="text-right">1,00</td>
              <td class="text-right">10,000</td>
              <td class="text-right">10</td>
              <td class="text-right">100</td>
              <td class="text-right">1,00</td>
              <td class="text-right">10,000</td>
              <td class="text-right">10</td>
              <td class="text-right">100</td>
              <td class="text-right">1,00</td>
              <td class="text-right">10,000</td>
            </tr>
            <tr>
              <td class="text-center">입금율</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
              <td class="text-right">94.81</td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- //markup-table -->

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area mt60">
          <h3 class="title1">세부 업무결과</h3>
        </div>
        <!-- //sales_subtit_area -->
        <!-- markup-table -->
        <q-markup-table separator="cell" wrap-cells>
          <colgroup>
            <col style="width: 180px" />
            <col style="width: 200px" />
            <col style="width: auto; min-width: 268px" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>계획</th>
              <th>결과</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">내방회원관리</td>
              <td>내방회원관리 내용을 불러옵니다.</td>
              <td>
                <div style="min-height: 180px; height: 100%">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n1"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">마케팅 활동</td>
              <td>
                내방회원관리 내용을 불러옵니다. 내방회원관리 내용을 불러옵니다.
                내방회원관리 내용을 불러옵니다. 내방회원관리 내용을 불러옵니다.
                내방회원관리 내용을 불러옵니다. 내방회원관리 내용을 불러옵니다.
                내방회원관리 내용을 불러옵니다.
              </td>
              <td>
                <div style="min-height: 180px; height: 100%">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n2"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">구성원 역량강화</td>
              <td>
                내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다. <br />내방회원관리 내용을
                불러옵니다. <br />내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다. <br />내방회원관리 내용을
                불러옵니다.
              </td>
              <td>
                <div style="min-height: 180px; height: 100%">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n3"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">기타</td>
              <td>
                내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다. <br />내방회원관리 내용을
                불러옵니다. <br />내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다. <br />내방회원관리 내용을
                불러옵니다. <br />내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다. <br />내방회원관리 내용을
                불러옵니다. <br />내방회원관리 내용을 불러옵니다.
                <br />내방회원관리 내용을 불러옵니다.
              </td>
              <td>
                <div style="min-height: 180px; height: 100%">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n4"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </q-markup-table>
        <!--// markup-table -->

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area mt60">
          <h3 class="title1">보급 분석 결과</h3>
        </div>
        <!-- //sales_subtit_area -->
        <!-- markup-table -->
        <q-markup-table separator="cell" wrap-cells>
          <colgroup>
            <col style="width: 180px" />
            <col style="width: auto; min-width: 468px" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>계획</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">입회 회원의 주요 경로 및 특이사항</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n5"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">퇴화회원의 원인 및 특이사항</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n6"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">기타 및 시장 변화</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n7"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- // markup-table -->

        <!-- sales_subtit_area -->
        <div class="sales_subtit_area mt60">
          <h3 class="title1">당월 업무 계획</h3>
        </div>
        <!-- //sales_subtit_area -->
        <!-- markup-table -->
        <q-markup-table separator="cell" class="" wrap-cells>
          <colgroup>
            <col style="width: 180px" />
            <col style="width: auto; min-width: 117px" />
            <col style="width: auto; min-width: 117px" />
            <col style="width: auto; min-width: 117px" />
            <col style="width: auto; min-width: 117px" />
          </colgroup>
          <thead>
            <tr>
              <th>구분</th>
              <th>입회</th>
              <th>퇴회</th>
              <th>순증</th>
              <th>총원증감</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">목표</td>
              <td>
                <q-input
                  class="inp_basic"
                  outlined
                  v-model="inp1"
                  placeholder=""
                />
              </td>
              <td>
                <q-input
                  class="inp_basic"
                  outlined
                  v-model="inp1"
                  placeholder=""
                />
              </td>
              <td>
                <q-input
                  class="inp_basic"
                  outlined
                  v-model="inp1"
                  placeholder=""
                />
              </td>
              <td>
                <q-input
                  class="inp_basic"
                  outlined
                  v-model="inp1"
                  placeholder=""
                />
              </td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- // markup-table -->
        <!-- markup-table -->
        <q-markup-table separator="cell" class="mt20" wrap-cells>
          <colgroup>
            <col style="width: 180px" />
            <col style="width: auto; min-width: 468px" />
          </colgroup>
          <thead>
            <tr>
              <th class="">구분</th>
              <th class="">계획</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center">입회 회원의 주요 경로 및 특이사항</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n8"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">퇴화회원의 원인 및 특이사항</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n9"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-center">기타 및 시장 변화</td>
              <td>
                <div style="height: 180px">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea.n10"
                    placeholder=""
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </q-markup-table>
        <!-- // markup-table -->

        <!-- 버튼 -->
        <div class="btn_area response mt50">
          <q-btn outline class="size_lg wide" label="임시저장" />
          <q-btn unelevated color="black" class="size_lg wide" label="제출" />
          <q-btn
            unelevated
            color="grey-2"
            class="size_lg btn_position_end"
            label="목록"
          />
        </div>
        <!-- // 버튼 -->
      </q-card>

      <q-card class="wrap_table_box mt40">
        <!-- general_table -->
        <div class="table_dk">
          <div class="row justify-between items-center mb14">
            <h3 class="title1">의견내용</h3>
            <q-btn class="size_sm" outline label="신규작성" />
          </div>
          <q-table
            class="scrollable sticky_table_header"
            :rows="dataRows"
            :columns="dataColumns"
            row-key="idx"
            :rows-per-page-options="[0]"
            hide-pagination
            style="max-height: 220px"
            separator="cell"
          >
          </q-table>
        </div>
        <!--// general_table type_total-->

        <div class="row justify-between items-center mb14 mt60">
          <h3 class="title1">의견작성/수정</h3>
          <div>
            <q-btn class="size_sm" outline label="삭제" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_sm ml10"
              label="저장"
            >
            </q-btn>
          </div>
        </div>

        <!-- textarea -->
        <div class="wrap_textarea_sales">
          <q-input
            class="basic"
            outlined
            v-model="dataTextArea.n0"
            placeholder=""
            type="textarea"
          >
            <template v-slot:label>메시지 내용</template>
          </q-input>
        </div>
        <!-- // textarea -->
      </q-card>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataTextArea = ref({
  n0: '내용을 입력합니다.',
  n1: '결과값노출1',
  n2: '결과값노출2',
  n3: '결과값노출3',
  n4: '결과값노출4',
  n5: '결과값노출5',
  n6: '결과값노출6',
  n7: '결과값노출7',
  n8: '결과값노출8',
  n9: '결과값노출9',
  n10: '결과값노출10',
});

//data테이블
const dataColumns = ref([
  {
    name: 'idx',
    label: '번호',
    sortable: false,
    align: 'center',
    field: (row) => row.idx,
  },
  {
    name: 'tdata1',
    label: '입회',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata1,
  },
  {
    name: 'tdata2',
    label: '구분',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata2,
  },
  {
    name: 'tdata3',
    label: '작성자',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata3,
  },
  {
    name: 'tdata4',
    label: '등록일',
    sortable: false,
    align: 'center',
    field: (row) => row.tdata4,
  },
]);
const dataRows = ref([
  {
    idx: '10',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '9',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '8',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '7',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '6',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '5',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '4',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '3',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '2',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '1',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '2',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '1',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '2',
    tdata1: '내방회원쪽 내용을 좀 더 보완해야 할 것으로 보입니다......',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
  {
    idx: '1',
    tdata1: '경기 화성시 진안동 월드메르디앙 3단지 아파트 306동 1802호',
    tdata2: '서울서북본부 | 강서조직',
    tdata3: '홍*동[12212111][본부권한]',
    tdata4: '2023.01.01',
  },
]);
</script>
