<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">목표수립</h2>
      <Breadcrumbs />
    </div>

    <div class="page_sales">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                          :emit-immediately="true"
                          default-view="Years"
                        />
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label box_l"
                label="본부 선택"
                v-model="search2"
                :options="search2Option"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
const searchDate = ref({
  from: '2023',
});

const search2 = ref(['본부 선택']);
const search2Option = ref([
  {
    id: 's21',
    desc: '본부1',
  },
  {
    id: 's22',
    desc: '본부12',
  },
]);
</script>
