<template>
  <!-- C 수업 파트 구분 클래스 -->
  <div class="page_lecture">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">감성 문자</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="pd20">
          <div class="title3 text-grey-3">당월 감성 문자</div>
          <div class="info_list_box mt10 pd0">
            <q-btn
              unelevated
              class="size_xxl text-grey-1 w100p"
              color="transparent"
              align="left"
            >
              <span class="text"
                >더운여름 아이스크림보다 팥빙수보다 더 시원한 것은 해맑은
                어린이들의 미소 입니다. 시원한 한주 보내세요</span
              >
            </q-btn>
          </div>
          <div class="info_list_box mt10 pd0">
            <q-btn
              unelevated
              class="size_xxl text-grey-1 w100p"
              color="transparent"
              align="left"
            >
              <span class="text"
                >더운여름 아이스크림보다 팥빙수보다 더 시원한 것은 해맑은
                어린이들의 미소 입니다. 시원한 한주 보내세요</span
              >
            </q-btn>
          </div>
          <div class="title3 text-grey-3 mt20">기본 감성 문자</div>
          <div class="info_list_box mt10 pd0">
            <q-btn
              unelevated
              class="size_xxl text-grey-1 w100p"
              color="transparent"
              align="left"
            >
              <span class="text"
                >##name## 어미님 아시하시느라 고생 많으셔조? 저의 방문요일은
                #요일 입니다.</span
              >
            </q-btn>
          </div>
          <div class="info_list_box mt10 pd0">
            <q-btn
              unelevated
              class="size_xxl text-grey-1 w100p"
              color="transparent"
              align="left"
            >
              <span class="text"
                >어머님! ##name## 와 제가 빠른 시간 안에 친해질 수 있도록 도움
                부탁 드립니다.</span
              >
            </q-btn>
          </div>
          <div class="info_list_box mt10 pd0">
            <q-btn
              unelevated
              class="size_xxl text-grey-1 w100p"
              color="transparent"
              align="left"
            >
              <span class="text"
                >어머님~ 매일 같은시간, 같은장소에서 학습습관을 길러주세요.
                자기주도학습의 밑거름이 됩니다.</span
              >
            </q-btn>
          </div>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);
</script>
<style lang="scss">
.info_list_box .q-btn {
  white-space: normal;
  .text {
    text-align: left;
  }
  &.size_xxl {
    height: auto;
  }
}
</style>
