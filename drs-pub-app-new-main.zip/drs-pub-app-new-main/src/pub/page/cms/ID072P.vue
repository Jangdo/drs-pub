<template>
  <!-- C 수업 파트 구분 클래스 -->
  <div class="page_lecture">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">감성 문자</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <section class="section_form">
            <div class="wrap_counsel_form">
              <ul class="checkbox_clist">
                <li>
                  <q-checkbox
                    class="check_black"
                    dense
                    v-model="dataCheck1.check1"
                    label="김윤찬"
                    color="black"
                  />
                  010-1234-5678
                </li>
                <li>
                  <q-checkbox
                    dense
                    class="check_black"
                    v-model="dataCheck1.check2"
                    label="김윤찬 어머님"
                    color="black"
                  />
                  010-1234-5678
                </li>
                <li>
                  <q-checkbox
                    dense
                    class="check_black"
                    v-model="dataCheck1.check3"
                    label="김윤찬 아버님"
                    color="black"
                  />
                  010-1234-5678
                </li>
              </ul>
              <div class="list_btm">
                <q-btn
                  style="width: 72px"
                  unelevated
                  color="grey-4"
                  class="size_sm"
                  label="문자양식"
                />
              </div>
              <!-- 내용 -->
              <div class="wrap_counsel_form mt10">
                <div class="wrap_textarea">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea"
                    placeholder="내용을 입력해주세요."
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                  <div class="check_val">
                    <span class="text-black">1</span>/<span>1000</span>
                  </div>
                </div>
              </div>
              <!-- // 내용 -->
            </div>
          </section>
          <q-card-actions class="dialog_actions">
            <q-btn
              fill
              v-close-popup
              class="size_lg btn_search"
              color="black"
              label="발송하기"
            />
          </q-card-actions>
        </q-card-section>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

// const textbook = ref(false);

const dataCheck1 = ref({
  check1: false,
  check2: false,
  check3: false,
  check4: false,
});

const dataTextArea = ref('');
</script>
<style lang="scss">
.checkbox_clist li {
  color: black;
  font-size: 18px;
  line-height: 22px;
  font-weight: 600;
}
.q-checkbox {
  min-width: 200px;
}
.q-checkbox.check_black .q-checkbox__label {
  color: black;
  font-size: 20px;
  line-height: 22px;
  font-weight: 700;
}
</style>
