<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">상담요청</h2>
      <Breadcrumbs />
    </div>
    <div class="page_consulting">
      <div class="wrap_contents_box">
        <div class="wrap_counsel_form">
          <h3 class="text-body1">상담요청 선생님</h3>
          <div class="wrap_input">
            <q-input
              outlined
              v-model="dataInput"
              placeholder="read only"
              dense
              readonly
            />
          </div>
          <div class="wrap_textarea">
            <q-input
              class="basic"
              outlined
              v-model="dataTextArea"
              placeholder=""
              type="textarea"
            >
              <template v-slot:label>메시지 내용</template>
            </q-input>
            <div class="check_val"><span>1</span>/<span>100</span></div>
          </div>
          <!-- 버튼 -->
          <div class="btn_area">
            <q-btn outline unelevated class="size_lg" label="취소" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_lg"
              label="상담요청"
            />
          </div>
          <!-- // 버튼 -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataInput = ref('김대교 001000/서울교육국/눈높이센터');
const dataTextArea = ref(
  '고객상담 답변내용을 작성해주세요. 고객상담작성해주세요.'
);
</script>
