<template>
  <div class="page_consulting">
    <!-- dialog -->
    <q-dialog :modelValue="popForm">
      <q-card class="respons_card inner_form">
        <q-card-section class="pop_title_wrap">
          <h3 class="tit">상담메모</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <section class="section_form">
            <!-- 내용 -->
            <div class="wrap_counsel_form">
              <div class="wrap_textarea">
                <q-input
                  class="basic"
                  outlined
                  v-model="dataTextArea"
                  placeholder=""
                  type="textarea"
                >
                  <template v-slot:label>메시지 내용</template>
                </q-input>
                <div class="check_val"><span>1</span>/<span>100</span></div>
              </div>
            </div>
            <!-- // 내용 -->
          </section>
        </q-card-section>
        <q-card-actions class="dialog_actions">
          <q-btn
            fill
            v-close-popup
            class="size_lg"
            color="black"
            label="등록"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';

// dialog
const popForm = ref(true);

const dataTextArea = ref(
  '고객상담 답변내용을 작성해주세요. 고객상담작성해주세요.'
);
</script>
