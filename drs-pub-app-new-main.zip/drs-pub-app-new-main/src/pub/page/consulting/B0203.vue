<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">입회상담</h2>
      <Breadcrumbs />
    </div>
    <div class="page_consulting">
      <div class="wrap_contents_box">
        <!-- group -->
        <div class="wrap_detail_counsel">
          <!-- 뱃지 -->
          <div class="badge_area">
            <q-badge
              class="badge20"
              rounded
              color="brown-2"
              label="마카다미아"
            />
            <q-badge class="badge20" rounded color="orange" label="입회상담" />
            <q-badge class="badge20" rounded color="grey-4" label="상담종료" />
          </div>
          <!-- // 뱃지 -->

          <!-- 상담요청일 -->
          <dl class="date_area">
            <dt class="text-body2">상담요청일</dt>
            <dd class="text-body2">2023.03.15(수)</dd>
            <dt class="text-body2">상담시작일</dt>
            <dd class="text-body2">2023.03.16(목)</dd>
          </dl>
          <!-- // 상담요청일 -->

          <h3 class="title1">회원정보</h3>
          <!-- 상세 정보 -->
          <div class="detail_area">
            <div class="detail_top">
              <div class="text-h3">
                김윤찬 <span class="text-body1">(P15907)</span>
              </div>
              <q-btn
                fill
                unelevated
                color="grey-5"
                class="btn_circle"
                label="circle"
              >
                <q-icon name="icon-user-white" class="icon_svg"></q-icon>
              </q-btn>
            </div>

            <dl class="detail_infor">
              <dt class="title4">학년</dt>
              <dd class="title4">초등 1학년</dd>
              <dt class="title4">생년월일</dt>
              <dd class="title4">2016.01.01</dd>
              <dt class="title4">주소</dt>
              <dd class="title4">
                [12345] 서울특별시 관악구 신대방로 11길 12 대교아파트 1동 101호
              </dd>
            </dl>
          </div>
          <!-- // 상세 정보 -->
        </div>
        <!-- // group -->
      </div>

      <div class="wrap_contents_box">
        <!-- group expansion -->
        <q-expansion-item class="expansion_custom type08" default-opened>
          <template v-slot:header>
            <h3 class="title1">대표보호자 정보</h3>
          </template>
          <div class="detail_top">
            <div class="text-h3">이나래</div>
            <q-btn
              fill
              unelevated
              color="grey-5"
              class="btn_circle"
              label="circle"
            >
              <q-icon name="icon-call-white2" class="icon_svg"></q-icon>
            </q-btn>
          </div>
          <dl class="detail_infor">
            <dt class="title4">관계</dt>
            <dd class="title4">어머니</dd>
            <dt class="title4">휴대폰 번호</dt>
            <dd class="title4">010-1234-5678</dd>
          </dl>
        </q-expansion-item>
        <!-- // group expansion -->
      </div>

      <div class="wrap_contents_box">
        <!-- group expansion -->
        <q-expansion-item class="expansion_custom type08" default-opened>
          <template v-slot:header>
            <h3 class="title1">상담내용</h3>
          </template>
          <dl class="counsel_time">
            <dt class="text-body2">상담가능시간</dt>
            <dd class="text-body2">09:00 ~ 18:00</dd>
          </dl>
          <dl class="counsel_contents">
            <dt>
              상담실에서 직접 유선 통화를 한 건이 아닌, 인터넷 제품 상담 신청
              접수건입니다.
            </dt>
            <dd>
              상담 내용이 노출됩니다. 상담실에서 직접 유선 통화를 한 건이 아닌,
              인터넷 제품 상담 신청 접수 건입니다 고객 메모와 주소 및 학년/연령
              정보 재학인 부탁합니다. 상담 시 예전에 학습했던 회원인지 혹은 현재
              다른 과목을 학습하고 있는 회원인지 확인 부탁드립니다. 감사합니다.
            </dd>
          </dl>
          <div class="counsel_answer_contents">
            <h4 class="title1">답변내용</h4>
            <div class="counsel_answer">
              <!-- 답변 작성 후 -->
              <div class="text-body2">2023.03.16 (목)</div>
              <div class="answer">
                안녕하세요. 회원님<br />
                상담 답변내용이 노출됩니다. 상담시 알려주신 내용에 대한 답변이
                노출됩니다.
              </div>
            </div>
          </div>
        </q-expansion-item>
        <!-- // group expansion -->
      </div>

      <div class="wrap_contents_box">
        <!-- group -->
        <div class="wrap_detail_counsel">
          <h3 class="title1">관심학습</h3>
          <!-- 상세 정보 -->
          <div class="detail_area">
            <div class="title4">
              눈높이 수학
              <q-badge class="badge20" rounded color="orange" label="체험중" />
            </div>
            <div class="study_infor">
              <span class="text-body2">김대교(001000)</span>
              <span class="text-body2 line">서울교육국</span>
              <span class="text-body2">눈높이신대방센터</span>
            </div>
          </div>
          <!-- // 상세 정보 -->
        </div>
        <!-- // group -->
      </div>

      <div class="wrap_contents_box">
        <!-- group expansion -->
        <q-expansion-item class="expansion_custom type08" default-opened>
          <template v-slot:header>
            <h3 class="title1">이관 선생님</h3>
          </template>
          <!-- 상담 선생님 정보 -->
          <div class="teacher_profile">
            <div class="photo">
              <img src="https://drs-imaged.daekyo.co.kr/images/avatar.png" />
            </div>
            <div class="infor">
              <div class="title3">김대교(001000)</div>
              <div class="center">
                <span class="text-body2 line">서울교육국</span>
                <span class="text-body2">눈높이신대방센터</span>
              </div>
            </div>
          </div>
          <!-- // 상담 선생님 정보 -->
          <div class="memo_contents">
            <div class="contents">
              국장이 작성한 상담요청 내용이 노출됩니다. 국장이 작성한 상담요청
              내용이 노출됩니다.
            </div>
          </div>
        </q-expansion-item>
        <!-- // group expansion -->
      </div>

      <div class="wrap_contents_box">
        <!-- group -->
        <div class="wrap_detail_counsel">
          <h3 class="title1">상담메모</h3>

          <!-- 상세 정보 -->
          <div class="detail_area">
            <!-- 메모 -->
            <div class="memo_contents">
              <div class="date text-body2">2023.03.16 (목)</div>
              <div class="contents">
                기존회원의 친구를 어머님에게 소개받아 상담을 시작함. 수학과 국어
                과목학습에 대해 관심이 많음
              </div>
            </div>
            <!-- // 메모 -->

            <!-- 메모 -->
            <div class="memo_contents">
              <div class="date text-body2">2023.03.17 (금)</div>
              <div class="contents">
                기존회원의 친구를 어머님에게 소개받아 상담을 시작함. 수학과 국어
                과목학습에 대해 관심이 많음. 기존회원의 친구를 어머님에게
                소개받아 상담을 시작함. 수학과 국어 과목학습에 대해 관심이 많음.
                기존회원의 친구를 어머님에게 소개받아 상담을 시작함. 수학과 국어
                과목학습에 대해 관심이 많음. 기존회원의 친구를 어머님에게
                소개받아 상담을 시작함. 수학과 국어 과목학습에 대해 관심이 많음.
              </div>
            </div>
            <!-- // 메모 -->

            <!-- 버튼 -->
            <div class="btn_area">
              <q-btn
                fill
                unelevated
                color="black"
                class="size_lg"
                label="확인"
              />
            </div>
            <!-- // 버튼 -->
          </div>
          <!-- // 상세 정보 -->
        </div>
        <!-- // group -->
      </div>
    </div>
  </div>
</template>

<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
