<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">입회상담</h2>
      <Breadcrumbs />
    </div>
    <div class="page_consulting">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-calendar">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <span class="text-body2">~</span>
                <!-- 달력 인풋 -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.to"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyTo.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-9">
              <div class="search_group">
                <!-- 검색팝업 완료시 class placeholder 삭제 -->
                <div class="placeholder">
                  <span>부문</span>
                  <span>본부</span>
                  <span>교육국</span>
                </div>
                <q-icon name="icon-search" class="icon_svg" />
              </div>
            </div>
          </div>
          <div class="mt10" v-if="stateHandle">
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-3">
                <q-select
                  class="hide_label"
                  label="상담채널 전체"
                  v-model="sysSelect"
                  :options="sysSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="hide_label"
                  label="상담구분 전체"
                  v-model="sysSelect2"
                  :options="sysSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
              <div class="col-12 col-md-3">
                <q-select
                  class="hide_label"
                  label="상담상태 전체"
                  v-model="sysSelect3"
                  :options="sysSelectOption"
                  option-value="id"
                  option-label="desc"
                  option-disable="inactive"
                  emit-value
                  map-options
                  dense
                  outlined
                  dropdown-icon="ion-ios-arrow-down"
                >
                </q-select>
              </div>
            </div>
            <div class="row q-col-gutter-sm">
              <div class="col-12 col-md-12">
                <div class="info">
                  <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                  <span class="body2 text-grey-3 ml8"
                    >최근 3개월간 데이터만 조회가 가능합니다</span
                  >
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>
      <!-- wrapper_tab -->
      <div class="wrapper_tab">
        <div class="btn_area center mt30">
          <q-btn
            outline
            color="grey-3"
            class="size_lg_rounded shadow btn_start"
            label="입회 / 체험상담 시작하기"
          >
            <div class="right">
              <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
            </div>
          </q-btn>
        </div>

        <div class="wrap_contents_box">
          <div class="wcb_tit_area">
            <div class="title">
              <span class="text-black">전체</span>
              <span class="text-positive num">5</span>
              <span class="text-positive">건</span>
            </div>
          </div>
          <div class="wcb_con_area justify-start">
            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <!-- <q-btn outline class="size_xxs btn_close" color="grey-3" icon="ion-ios-close" /> -->
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">
                  <span>솔루니 점프마스터</span>
                  <!-- <span>(체험중&nbsp;</span>
                    <span>2023.04.15</span>
                    <span>)</span> -->
                  <q-badge color="orange" class="small ml6 mr6">체험중</q-badge>
                  <span>외 4</span>
                </div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <!-- <q-btn outline class="size_xxs btn_close" color="grey-3" icon="ion-ios-close" /> -->
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>

            <div class="student_card">
              <div class="date">
                <p class="body1">2023.03.15 (수)</p>
                <q-btn
                  outline
                  class="size_xxs btn_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </div>
              <div class="profile_box">
                <div class="wrap_badge">
                  <q-badge color="brown-2" class="small">솔루니모바일</q-badge>
                  <q-badge color="orange" class="small">입회상담</q-badge>
                  <q-badge color="grey-4" class="small"
                    >이관(상담대기)
                  </q-badge>
                </div>
                <div class="wrap_personal">
                  <span class="name">김윤찬</span>
                  <span class="id">(P15907)</span>
                  <span class="grade">초등1</span>
                  <q-badge
                    rounded
                    color="orange"
                    text-color="white"
                    class="small circle"
                    label="N"
                  />
                  <q-space />
                  <button class="size_xxs btn_arrow_right"></button>
                </div>
                <div class="body2">등록된 관심 과목이 없습니다</div>
              </div>
            </div>
          </div>

          <div class="mt30 text-center">
            <q-btn flat class="size_md btn_arrow_down">
              <q-icon name="icon-arrow-down-grey" class="icon_svg"></q-icon>
            </q-btn>
          </div>
        </div>
      </div>
      <!-- // wrapper_tab -->
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchDate = ref({
  from: '2023.04.11',
  to: '2023.04.11',
});
const sysSelect = ref(['상담채널 전체']);
const sysSelect2 = ref(['상담구분 전체']);
const sysSelect3 = ref(['상담상태 전체']);
const sysSelectOption = ref([
  {
    id: 'N',
    desc: '눈높이(N)',
  },
  {
    id: 'G',
    desc: '학원(G)',
  },
  {
    id: 'C',
    desc: '공통코드(C) ',
  },
  {
    id: 'M',
    desc: 'MOS(M)',
  },
]);
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
