<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">회원선택</h2>
      <Breadcrumbs />
    </div>
    <!-- 회원 페이지 member_page 분기-->
    <div class="page_consulting">
      <div class="wrap_contents_box fit_height">
        <div class="cont_lg_center_400">
          <div class="block_certify">
            <p class="tit title1">회원을 선택해주세요</p>
            <div class="wrap_cerfiybtn">
              <q-btn class="btn_box_certify on" flat to="/">
                <div class="bg_img new_member">
                  <span class="title3">신규회원 등록</span>
                </div>
              </q-btn>
              <q-btn class="btn_box_certify" flat to="/">
                <div class="bg_img existing_member">
                  <span class="title3">기존회원 검색</span>
                </div>
              </q-btn>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>

<style lang="scss">
// 회원선택 이미지
.q-btn__content .bg_img {
  &.new_member:before {
    background-image: url(/icons/icon-user_add-grey.svg);
  }
  &.existing_member:before {
    background-image: url(/icons/icon-user_check-grey.svg);
  }

  .on & {
    &.new_member:before {
      background-image: url(/icons/icon-user_add-green.svg);
    }
    &.existing_member:before {
      background-image: url(/icons/icon-user_check-green.svg);
    }
  }
}
body {
  &.screen--lg {
    .cont_lg_center_400 {
      max-width: 400px;
      margin: 0 auto;
    }
  }
}
</style>
