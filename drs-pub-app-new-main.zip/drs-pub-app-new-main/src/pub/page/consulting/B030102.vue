<template>
  <div class="page_consulting">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_form">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">과목 검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="group_inp_select mb60">
            <q-select
              class=""
              v-model="brandSelect"
              :options="brandOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
            <q-select
              class=""
              v-model="subjectSelect"
              :options="subjectOption"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
            <q-select
              class=""
              v-model="subjectSelect2"
              :options="subjectOption2"
              option-value="id"
              option-label="desc"
              option-disable="inactive"
              emit-value
              map-options
              dense
              outlined
              dropdown-icon="ion-ios-arrow-down"
            >
            </q-select>
          </div>

          <div class="wrap_subject_select mb30">
            <div class="tit_area">
              <div class="title">
                <span class="text-orange num">2</span>
                <span class="text-orange">과목</span>
                <span class="text-grey-3"> 선택 가능합니다</span>
              </div>
            </div>
            <ul class="group_selected_subject">
              <li>
                <span>눈높이 수학</span>
                <q-badge color="black" class="small">패키지</q-badge>
                <q-space />
                <q-btn
                  outline
                  class="size_xxs btn_list_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </li>
              <li>
                <span>눈높이 국어똑똑</span>
                <!-- <q-badge color="black" class="small">패키지</q-badge> -->
                <q-space />
                <q-btn
                  outline
                  class="size_xxs btn_list_close"
                  color="grey-3"
                  icon="ion-ios-close"
                />
              </li>
            </ul>
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm btn_confirm"
            label="선택완료"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const brandSelect = ref(['브랜드를 선택하세요']);
const brandOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const subjectSelect = ref(['과목을 선택하세요']);
const subjectOption = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);

const subjectSelect2 = ref(['과목을 선택하세요']);
const subjectOption2 = ref([
  {
    id: 'type1',
    desc: '타입1',
  },
  {
    id: 'type2',
    desc: '타입2',
  },
]);
</script>

<style></style>
