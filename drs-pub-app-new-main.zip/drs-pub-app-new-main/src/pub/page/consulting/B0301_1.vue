<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">입회상담</h2>
      <Breadcrumbs />
    </div>
    <div class="page_consulting">
      <div class="wrap_contents_box">
        <div class="wrap_counsel_form">
          <!-- 프로필 -->
          <div class="user_profile">
            <div class="photo">
              <img src="https://cdn.quasar.dev/img/avatar5.jpg" />
            </div>
            <div class="infor">
              <div class="name">
                <b>김대교</b><span class="num">(P15907)</span>
                <q-badge class="badge20" rounded color="grey-4" label="임시" />
              </div>
              <div class="center">
                <span class="text-body2 line">초등1</span>
                <span class="text-body2">강남교육국 외2</span>
              </div>
            </div>
          </div>
          <!-- // 프로필 -->

          <!-- 입력영역 -->
          <fieldset class="counsel_membership">
            <!-- item -->
            <div class="group">
              <div class="title text-body1">
                <span class="essential">어떤 상담을 시작할까요?</span>
              </div>
              <div class="input_contents">
                <q-option-group
                  v-model="group"
                  :options="options"
                  color="black"
                  inline
                />
              </div>
            </div>
            <!-- // item -->
            <!-- item -->
            <div class="group">
              <div class="title text-body1">
                <span class="essential">관심학습을 선택하세요</span>
              </div>
              <div class="input_contents">
                <!-- search_item -->
                <div class="search_item">
                  <q-input
                    class="inp_search"
                    outlined
                    placeholder="과목을 검색하세요"
                  >
                    <template v-slot:append>
                      <q-icon name="icon-search" class="icon_svg" />
                    </template>
                  </q-input>
                </div>
                <!-- // search_item -->
                <p class="msg_info text-body2">
                  <q-icon name="icon-info-grey" class="icon_svg"></q-icon>
                  관심학습은 최대 5개까지 등록가능합니다
                </p>
              </div>
            </div>
            <!-- // item -->
          </fieldset>
          <!-- // 입력영역 -->

          <!-- 버튼 -->
          <div class="btn_area">
            <q-btn outline unelevated class="size_lg" label="취소" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_lg"
              label="상담하기"
            />
          </div>
          <!-- // 버튼 -->
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// radio group
const group = ref('op1');
const options = ref([
  {
    label: '입회상담',
    value: 'op1',
  },
  {
    label: '체험상담',
    value: 'op2',
  },
]);
</script>
