<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">일반상담</h2>
      <Breadcrumbs />
    </div>
    <div class="page_consulting">
      <div class="wrap_contents_box">
        <!-- group -->
        <div class="wrap_detail_counsel">
          <!-- 뱃지 -->
          <div class="badge_area">
            <q-badge
              class="badge20"
              rounded
              color="brown-2"
              label="마카다미아"
            />
            <q-badge class="badge20" rounded color="orange" label="고객불만" />
            <q-badge class="badge20" rounded color="grey-4" label="상담대기" />
          </div>
          <!-- // 뱃지 -->

          <!-- 상담요청일 -->
          <dl class="date_area">
            <dt class="text-body2">상담요청일</dt>
            <dd class="text-body2">2023.03.15(수)</dd>
          </dl>
          <!-- // 상담요청일 -->

          <h3 class="title1">회원정보</h3>
          <!-- 상세 정보 -->
          <div class="detail_area">
            <div class="text-h3">
              김윤찬 <span class="text-body1">(P15907)</span>
            </div>
            <dl class="detail_infor">
              <dt class="title4">학년</dt>
              <dd class="title4">초등 1학년</dd>
              <dt class="title4">성별</dt>
              <dd class="title4">남자</dd>
              <dt class="title4">생년월일</dt>
              <dd class="title4">2016.01.01</dd>
            </dl>
          </div>
          <!-- // 상세 정보 -->
        </div>
        <!-- // group -->
      </div>

      <div class="wrap_contents_box">
        <!-- group expansion -->
        <q-expansion-item class="expansion_custom type08" default-opened>
          <template v-slot:header>
            <h3 class="title1">상담정보</h3>
          </template>
          <dl class="detail_infor">
            <dt class="title4">상담원명</dt>
            <dd class="title4">홍길동</dd>
            <dt class="title4">접수일</dt>
            <dd class="title4">2023.03.10 (금)</dd>
            <dt class="title4">상담채널</dt>
            <dd class="title4">전화상담</dd>
            <dt class="title4">상담과목</dt>
            <dd class="title4">ITPA</dd>
          </dl>
        </q-expansion-item>
        <!-- // group expansion -->
      </div>

      <div class="wrap_contents_box">
        <!-- group expansion -->
        <q-expansion-item class="expansion_custom type08" default-opened>
          <template v-slot:header>
            <h3 class="title1">상담내용</h3>
          </template>
          <dl class="counsel_time">
            <dt class="text-body2">상담가능시간</dt>
            <dd class="text-body2">09:00 ~ 18:00</dd>
          </dl>
          <dl class="counsel_contents">
            <dt>
              상담실에서 직접 유선 통화를 한 건이 아닌, 인터넷 제품 상담 신청
              접수건입니다.
            </dt>
            <dd>
              상담 내용이 노출됩니다. 상담실에서 직접 유선 통화를 한 건이 아닌,
              인터넷 제품 상담 신청 접수 건입니다 고객 메모와 주소 및 학년/연령
              정보 재학인 부탁합니다. 상담 시 예전에 학습했던 회원인지 혹은 현재
              다른 과목을 학습하고 있는 회원인지 확인 부탁드립니다. 감사합니다.
            </dd>
          </dl>

          <div class="counsel_answer_contents">
            <h4 class="title1">답변내용</h4>
            <div class="counsel_answer">
              <!-- 답변 미작성 : 버튼 노출 -->
              <div class="btn_area">
                <q-btn class="size_lg shadow" label="답변작성하기" />
              </div>
              <!-- 답변 작성 후 -->
              <div class="text-body2">2023.03.16 (목)</div>
              <div class="answer">
                답변 미작성 시 답변작성하기 버튼이 나오고<br />
                답변을 작성한 후 날짜와 답변 내용이 나옵니다.<br />
                버튼과 이 영역 사이 여백이 없는 이유는 같이 나올 수가 없는
                별개의 영역이기 때문입니다.<br />
                안녕하세요. 회원님<br />
                상담 답변내용이 노출됩니다. 상담시 알려주신 내용에 대한 답변이
                노출됩니다.
              </div>
            </div>
          </div>

          <!-- 버튼 -->
          <div class="btn_area type_bottom">
            <q-btn outline unelevated class="size_lg" label="취소" />
            <q-btn
              fill
              unelevated
              color="black"
              class="size_lg"
              label="답변하기"
            />
          </div>
          <!-- // 버튼 -->
        </q-expansion-item>
        <!-- // group expansion -->
      </div>
    </div>
  </div>
</template>

<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
