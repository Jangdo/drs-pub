<template>
  <div class="page_consulting">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_form">
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">회원검색</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>
        <q-card-section class="dialog_content">
          <div class="mb30">
            <q-input
              class=""
              for=""
              outlined
              dense
              v-model="memberName"
              placeholder="회원 이름으로 검색"
            >
              <template v-slot:append>
                <q-icon name="icon-search" class="icon_svg" />
              </template>
            </q-input>
          </div>
          <div class="mb20">
            <div class="mb10 title3">
              <span class="text-black">[김윤찬]</span>
              <span class="text-grey-3"> 총</span>
              <span class="text-orange">2명</span>
              <span class="text-grey-3">의 회원이 검색 되었습니다.</span>
            </div>
            <!-- member_info_card -->
            <div class="member_info_card">
              <div class="infor_area">
                <div class="pic_area big">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/avatar.png"
                  />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <q-badge color="grey-3" class="small">임시</q-badge>
                    <p class="name mb6">김윤찬</p>
                    <div class="body2 mb6">
                      <span class="member_number">P159071234</span>
                      <span class="ml6 mr6 text-grey-6">|</span>
                      <span class="grade">초등1</span>
                    </div>
                    <div class="body2 text-grey-3 mb6">
                      <span>생년월일: </span>
                      <span>2000.01.01</span>
                    </div>
                    <div class="body2 text-grey-3">
                      <span>휴대폰: </span>
                      <span>010-****-1234</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- //member_info_card -->

            <!-- member_info_card -->
            <div class="member_info_card">
              <div class="infor_area">
                <div class="pic_area big">
                  <img
                    src="https://drs-imaged.daekyo.co.kr/images/avatar.png"
                  />
                </div>
                <div class="txt_area">
                  <div class="tit_area">
                    <q-badge color="grey-3" class="small">임시</q-badge>
                    <p class="name mb6">김윤찬</p>
                    <div class="body2 mb6">
                      <span class="member_number">P159071234</span>
                      <span class="ml6 mr6 text-grey-6">|</span>
                      <span class="grade">초등1</span>
                    </div>
                    <div class="body2 text-grey-3 mb6">
                      <span>생년월일: </span>
                      <span>2000.01.01</span>
                    </div>
                    <div class="body2 text-grey-3">
                      <span>휴대폰: </span>
                      <span>010-****-1234</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- //member_info_card -->
          </div>
        </q-card-section>

        <q-card-actions class="dialog_actions">
          <q-btn icon="" class="size_sm btn_reset" outline label="초기화" />
          <q-btn
            fill
            unelevated
            v-close-popup
            color="black"
            class="size_sm"
            label="검색"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

const memberName = ref(['']);
</script>
