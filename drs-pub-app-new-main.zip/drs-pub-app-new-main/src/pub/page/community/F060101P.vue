<template>
  <div class="page_community">
    <!-- dialog -->
    <q-dialog :modelValue="popForm" class="dialog_btm m_change">
      <q-card class="respons_card type_tree">
        <!-- 팝업 제목 영역 -->
        <q-card-section class="pop_title_wrap">
          <q-chip dense class="chip_line"></q-chip>
          <h3 class="tit">코드설정</h3>
          <q-btn
            icon="close"
            class="btn_close"
            v-close-popup
            flat
            @click="popForm = false"
            unelevated
            dense
            ><b class="a11y">닫기</b></q-btn
          >
        </q-card-section>

        <!-- 팝업 내용 영역 -->
        <q-card-section class="dialog_content">
          <div class="tree_container">
            <q-tree
              :nodes="treeData"
              node-key="id"
              selected-color="primary"
              class="popup_tree hastbltit"
              v-model:selected="treeSelected"
              default-expand-all
              @update:selected="temp1(treeSelected)"
              style="height: 418px"
            >
            </q-tree>
          </div>
        </q-card-section>

        <!-- 버튼 -->
        <q-card-actions class="dialog_actions">
          <q-btn
            unelevated
            outline
            v-close-popup
            class="size_lg"
            label="취소"
          />
          <q-btn
            unelevated
            v-close-popup
            color="black"
            class="size_lg"
            label="확인"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <!--// dialog -->
  </div>
</template>

<script setup>
import { ref } from 'vue';
// dialog
const popForm = ref(true);

// tree
const treeData = [
  {
    label: '대교드림스',
    id: 'a_1',
    icon: 'tree',
    children: [
      {
        id: 'a_2',
        label: '눈높이 서비스 부문',
        children: [
          {
            id: 'a_3',
            label: '뎁스3',
            children: [
              {
                id: 'a_4',
                class: 'color_grey',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
              {
                id: 'a_5',
                label: '뎁스4',
                img: '/icons/icon-tree-folder.svg',
              },
            ],
          },
          {
            id: 'a_6',
            label: '뎁스3',
            img: '/icons/icon-tree-folder.svg',
          },
        ],
      },
      {
        label: '결제 관련/뎁스2',
        id: 'a_7',
        children: [
          {
            label: '뎁스3',
            id: 'a_8',
            children: [
              { id: 'a_9', label: '뎁스4' },
              { id: 'a_10', label: '뎁스4' },
            ],
          },
          { id: 'a_11', label: '뎁스3' },
        ],
      },
      {
        label: '기타 관련',
        id: 'a_12',
        children: [
          { id: 'a_13', label: '뎁스4' },
          { id: 'a_14', label: '뎁스4' },
        ],
      },
    ],
  },
];
const treeSelected = ref('메시지 카테고리');
//  트리 셀렉트 이벤트
function temp1(target) {
  console.log('셀렉트 이벤트 발생', target);
}
</script>
