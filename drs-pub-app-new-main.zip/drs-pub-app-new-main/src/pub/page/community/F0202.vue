<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">소통게시판</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <table class="table_row_sales">
          <tbody>
            <tr>
              <th class="required">제목</th>
              <td>
                <div class="search_item type_full">
                  <q-input
                    class="box_xl inp_search"
                    outlined
                    placeholder="제목을 입력하세요"
                  ></q-input>
                </div>
              </td>
            </tr>
            <tr>
              <th class="required">내용</th>
              <td>
                <div class="search_item type_full">
                  <q-input
                    class="basic"
                    outlined
                    v-model="dataTextArea"
                    placeholder="내용을 입력하세요"
                    type="textarea"
                  >
                    <template v-slot:label>메시지 내용</template>
                  </q-input>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="btn_area btn_bottom_type01">
          <q-btn
            unelevated
            outline
            color="grey-4"
            class="size_lg"
            label="취소"
          />
          <q-btn unelevated color="black" class="size_lg" label="저장" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const dataTextArea = ref('');
</script>

<style lang="scss" scoped>
.q-textarea {
  height: 300px;
}

body {
  &.screen--lg {
    .q-textarea {
      height: 400px;
    }
  }
}
</style>
