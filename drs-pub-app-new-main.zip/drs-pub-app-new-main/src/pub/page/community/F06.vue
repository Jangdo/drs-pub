<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-4">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <div class="tilde">
                  <span>~</span>
                </div>
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyto"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          v-model="searchDate.to"
                          mask="YYYY.MM.DD"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyto.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                class=""
                for=""
                outlined
                dense
                v-model="keyword"
                placeholder="제목"
              >
              </q-input>
            </div>
            <div class="col-12 col-md-3">
              <q-input
                class=""
                for=""
                outlined
                dense
                v-model="keyword2"
                placeholder="등록자"
              >
              </q-input>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="hide_label"
                label="답변여부 전체"
                v-model="searchCategory"
                :options="searchCategoryOption"
                option-value="sysytemCategory"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-checkbox
                class="mr10"
                v-model="dataCheck"
                label="등록일자 조회 제외"
                color="black"
              />
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>

      <div class="wrap_table_box">
        <!-- general_table -->
        <div class="general_table">
          <!-- 게시판 리스트 -->
          <div class="board_list table_dk_div" v-if="$q.screen.name == 'lg'">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                총 <span>00</span>건의 검색결과가 있습니다
              </div>
              <div class="btn_wrap col-12 col-md-8 gap10">
                <q-btn class="size_sm" color="" outline label="선택삭제" />
                <q-btn class="size_sm" fill unelevated outline label="수정" />
                <q-btn
                  class="size_sm"
                  fill
                  unelevated
                  color="black"
                  label="신규등록"
                />
              </div>
            </div>
            <div class="board_header">
              <p class="board_col_check">
                <q-checkbox v-model="tblRowSelected" color="black" />
              </p>
              <p class="board_col board_col_tit">제목</p>
              <p class="board_col board_col_min">첨부</p>
              <p class="board_col board_col_min">조회</p>
              <p class="board_col board_col_author">등록자</p>
              <p class="board_col board_col_author">등록일</p>
            </div>
            <div class="board_body">
              <div
                class="board_row"
                v-for="(items, idx) in tableRows"
                :key="idx"
              >
                <div class="board_col_check">
                  <q-checkbox v-model="tblRowSelected" color="black" />
                </div>
                <div class="board_col board_col_tit text-left">
                  <div class="board_badge q-gutter-xs">
                    <q-badge color="orange" class="small" v-if="items.notice"
                      >공지</q-badge
                    >
                    <q-badge color="negative" class="small" v-if="items.urgent"
                      >긴급</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.news"
                      >알림</q-badge
                    >
                    <q-badge
                      color="brown-2"
                      class="small"
                      v-if="items.promotion"
                      >행사</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.event"
                      >이벤트</q-badge
                    >
                    <span class="ico_new" v-if="items.new">N</span>
                    <q-icon
                      name="icon-thumbup-grey"
                      class="icon_svg filter-black"
                      v-if="items.thumb"
                    ></q-icon>
                  </div>
                  <a href="" class="board_col_tit_link">
                    {{ items.name }}
                  </a>
                </div>
                <div class="board_col board_col_min">
                  <q-icon
                    v-if="items.file"
                    name="icon-file-2"
                    class="icon_svg title2"
                  ></q-icon>
                </div>
                <div class="board_col board_col_min">
                  {{ items.hit }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.author }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.date }}
                </div>
              </div>
            </div>
          </div>

          <div
            class="board_list"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          >
            <div class="board_header">
              <p class="board_col_check">
                <q-checkbox v-model="tblRowSelected" color="black" />
              </p>
              <p class="board_col board_col_tit">제목</p>
              <p class="board_col board_col_min">첨부</p>
              <p class="board_col board_col_min">조회</p>
              <p class="board_col board_col_author">등록자</p>
              <p class="board_col board_col_author">등록일</p>
            </div>
            <div class="board_body">
              <div
                class="board_row"
                v-for="(items, idx) in tableRows"
                :key="idx"
              >
                <div class="board_col board_col_tit text-left">
                  <div class="board_badge q-gutter-xs">
                    <q-badge color="orange" class="small" v-if="items.notice"
                      >공지</q-badge
                    >
                    <q-badge color="negative" class="small" v-if="items.urgent"
                      >긴급</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.news"
                      >알림</q-badge
                    >
                    <q-badge
                      color="brown-2"
                      class="small"
                      v-if="items.promotion"
                      >행사</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.event"
                      >이벤트</q-badge
                    >
                    <span class="ico_new" v-if="items.new">N</span>
                    <q-icon
                      name="icon-thumbup-grey"
                      class="icon_svg filter-black mt0"
                      v-if="items.thumb"
                    ></q-icon>
                  </div>
                  <div class="q-gutter-xs al_center">
                    <span
                      ><q-checkbox v-model="tblRowSelected" color="black" dense
                    /></span>
                    <a href="" class="board_col_tit ml8">
                      {{ items.name }}
                    </a>
                    <q-icon
                      v-if="items.file"
                      name="icon-file-2"
                      class="icon_svg title2"
                    ></q-icon>
                  </div>
                </div>
                <div class="board_col board_col_author">
                  {{ items.date }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.author }}
                </div>
                <div class="board_col board_col_min">
                  {{ items.hit }}
                </div>
              </div>
            </div>
          </div>

          <!-- pagination -->
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- // pagination -->
        </div>
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

// const searchExpand = ref(true);

const keyword = ref('');
const keyword2 = ref('');
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const searchCategory = ref(['']);
const searchCategoryOption = ref([
  {
    id: 'a',
    desc: '답변1',
  },
  {
    id: 'b',
    desc: '답변2',
  },
]);
const dataCheck = ref(true);

//table데이터
const tableRows = ref([
  {
    name: '게시대상 확인 테스트',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: true,
    urgent: true,
    news: false,
    promotion: false,
    event: false,
    file: true,
    new: false,
    thumb: false,
  },
  {
    name: '게시대상 확인 테스트 게시대상 확인',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: false,
    urgent: false,
    news: true,
    promotion: true,
    event: true,
    file: true,
    new: false,
    thumb: false,
  },
  {
    name: '게시대상 확인 테스트',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: false,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
    file: true,
    new: true,
    thumb: true,
  },
]);

//data테이블
const tblRowSelected = ref([]);
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>
