<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">공지/행사/이벤트</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <table class="table_row_sales table_community_details">
          <colgroup>
            <col />
            <col />
            <col />
            <col />
          </colgroup>
          <tbody>
            <tr>
              <th>유형</th>
              <td>공지</td>
              <th class="line_l">브랜드</th>
              <td>눈높이</td>
            </tr>
            <tr>
              <th>제목</th>
              <td colspan="3">드림스 사용 주의사항</td>
            </tr>
            <tr>
              <th>내용</th>
              <td colspan="3">
                <div class="td_innerBody">
                  신학기를 맞이하여 차이홍에서 프로모션을 진행합니다.<br />
                  아래 공지를 확인하세요
                </div>
              </td>
            </tr>
            <tr>
              <th>첨부파일</th>
              <td colspan="3">
                <ul class="attach_file_list">
                  <li v-for="(items, idx) in 3" :key="idx">
                    <button type="button" class="attach_file">
                      첨부파일 파일명.pdf
                    </button>
                  </li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="btn_area response justify-end">
          <q-btn unelevated color="grey-2" class="size_lg" label="목록" />
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.justify-end {
  justify-content: flex-end !important;
}
// 첨부파일
.attach_file_list {
  li + li {
    margin-top: 12px;
  }
}
.attach_file {
  font-size: 16px;
  text-align: left;
  text-decoration: underline;
  word-break: break-all;
}
</style>
