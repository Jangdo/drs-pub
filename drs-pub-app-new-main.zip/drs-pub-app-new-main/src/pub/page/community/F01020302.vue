<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">공공지원금 조회</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <table class="table_row_sales table_community_details">
          <colgroup>
            <col />
            <col />
            <col />
            <col />
          </colgroup>
          <tbody>
            <tr>
              <th>시스템</th>
              <td>드림스</td>
              <th class="line_l">지원금 코드</th>
              <td>00000001</td>
            </tr>
            <tr>
              <th>현재상태</th>
              <td colspan="3">
                <div class="q-gutter-xs">
                  <q-badge color="negative" class="square_sm" outline
                    >LIVE</q-badge
                  >
                </div>
              </td>
            </tr>
            <tr>
              <th>지원금명</th>
              <td colspan="3">공공지원금 할인1</td>
            </tr>
            <tr>
              <th>내용</th>
              <td colspan="3">
                <div class="td_innerBody">
                  신학기를 맞이하여 차이홍에서 프로모션을 진행합니다.<br />
                  아래 공지를 확인하세요
                </div>
              </td>
            </tr>
            <tr>
              <th>적용조직</th>
              <td colspan="3">눈높이 사업본부, 차이홍</td>
            </tr>
            <tr>
              <th>적용대상</th>
              <td colspan="3">
                <span class="q-gutter-xs">
                  <q-badge color="orange" class="small">고객</q-badge>
                </span>
                홍길동 외 33건
              </td>
            </tr>
            <tr>
              <th>신청기한</th>
              <td colspan="3">2023.03.01 14시 ~ 2023.03.31 14시</td>
            </tr>
            <tr>
              <th>적용기한</th>
              <td colspan="3">2023.03.01 ~ 2023.03.31</td>
            </tr>
            <tr>
              <th>적용상품</th>
              <td colspan="3">
                <div class="product_info_list">
                  <div class="product_info_card">
                    <div class="product_info_header">
                      <p class="lis_name">상품명</p>
                      <ul class="lis">
                        <li>눈높이 수학</li>
                        <li>선생님</li>
                        <li>주1회</li>
                      </ul>
                    </div>
                    <div class="product_info_body">
                      <p class="lis_name">공공지원금 정보</p>
                      <ul class="lis">
                        <li>본인부담금 (138,000원)</li>
                        <li>본사부담금 (7,000원)</li>
                        <li>공공지원금 (21,000원)</li>
                      </ul>
                    </div>
                  </div>
                  <div class="product_info_card">
                    <div class="product_info_header">
                      <p class="lis_name">상품명</p>
                      <ul class="lis">
                        <li>눈높이 수학</li>
                        <li>선생님</li>
                        <li>주1회</li>
                      </ul>
                    </div>
                    <div class="product_info_body">
                      <p class="lis_name">공공지원금 정보</p>
                      <ul class="lis">
                        <li>본인부담금 (38,000원)</li>
                        <li>본사부담금 (7,000원)</li>
                        <li>공공지원금 (21,000원)</li>
                      </ul>
                    </div>
                  </div>
                  <div class="product_info_card">
                    <div class="product_info_header">
                      <p class="lis_name">상품명</p>
                      <ul class="lis">
                        <li>눈높이 수학</li>
                        <li>선생님</li>
                        <li>주1회</li>
                      </ul>
                    </div>
                    <div class="product_info_body">
                      <p class="lis_name">공공지원금 정보</p>
                      <ul class="lis">
                        <li>본인부담금 (38,000원)</li>
                        <li>본사부담금 (7,000원)</li>
                        <li>공공지원금 (21,000원)</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div class="btn_area response justify-end">
          <q-btn unelevated color="grey-2" class="size_lg" label="목록" />
        </div>
      </div>
    </div>
  </div>
</template>
<script setup>
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';
</script>
<style lang="scss" scoped>
.justify-end {
  justify-content: flex-end !important;
}
// 상품정보 카드
.product_info {
  &_list {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: -20px;
  }
  &_card {
    width: 100%;
    margin-bottom: 20px;
    padding: 30px 20px;
    border: 2px solid #d7d7d7;
    border-radius: 8px;
    background: #fff;
    .lis_name {
      width: 70px;
    }
    .lis {
      color: #262626;
    }
  }
  &_header {
    display: flex;
    justify-content: space-between;
    .lis {
      display: flex;
      flex-wrap: wrap;
      li + li {
        margin-left: 6px;
        padding-left: 6px;
        line-height: 1;
        border-left: 1px solid #d7d7d7;
      }
    }
  }
  &_body {
    display: flex;
    justify-content: space-between;
    .lis {
      text-align: right;
      li + li {
        margin-top: 8px;
      }
    }
  }
  &_header + &_body {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #d7d7d7;
  }
}

body {
  &.screen--lg {
    .product_info {
      &_list {
        margin: {
          right: -20px;
          bottom: -20px;
        }
      }
      &_card {
        width: 355px;
        margin: {
          right: 20px;
          bottom: 20px;
        }
        .lis_name {
          width: 105px;
        }
      }
    }
  }
}
</style>
