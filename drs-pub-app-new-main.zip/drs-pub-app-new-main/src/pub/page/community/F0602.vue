<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">게시물 관리</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <div>
          <div class="row items-center mb20">
            <q-icon name="icon-star" class="icon_svg title4 mr10"></q-icon>
            <p class="title1 text-grey-1">[전자문의] 연차를 안냈는데...</p>
          </div>
          <div class="post_infor">
            <span class="name">이포탈</span>
            <span class="date">2023-02-02 15:59</span>
            <dl>
              <dt>추천수</dt>
              <dd>5</dd>
              <dt>조회수</dt>
              <dd>32</dd>
            </dl>
          </div>

          <table class="table_row_view">
            <tbody>
              <tr>
                <th><span class="">제목</span></th>
                <td colspan="3">
                  <div class="flex items-center wrap_title">
                    <div class="search_item type_unset">
                      <q-select
                        class="hide_label box_l"
                        label="안내문의"
                        v-model="selectType"
                        :options="selectTypeOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <p class="body2 al_center">{{ inpBoardTitle }}</p>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="">게시 카테고리</span></th>
                <td colspan="3">
                  {{ inpBoardCategory }}
                </td>
              </tr>
              <tr>
                <th><span class="required">게시대상</span></th>
                <td>
                  {{ inpBoardTarget }}
                </td>
                <th class="line_l"><span class="required">게시옵션</span></th>
                <td>
                  <q-option-group
                    v-model="inpBoardCheckGroup"
                    :options="inpBoardCheckGroupOption"
                    color="black"
                    type="checkbox"
                    inline
                  />
                </td>
              </tr>
              <tr>
                <th><span class="required">게시예약일</span></th>
                <td colspan="3">
                  <div class="row items-center wrap_time">
                    <p class="mr10">2023.02.02 00:00</p>
                    <div
                      class="line_break"
                      v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
                    ></div>
                    <div class="search_item type_half">
                      <q-select
                        class="hide_label box_s"
                        label=""
                        v-model="revHour"
                        :options="revHourOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                    <div class="search_item type_half">
                      <q-select
                        class="hide_label box_s"
                        label=""
                        v-model="revMinute"
                        :options="revMinuteOpt"
                        option-value="id"
                        option-label="desc"
                        option-disable="inactive"
                        emit-value
                        map-options
                        dense
                        outlined
                        dropdown-icon="ion-ios-arrow-down"
                      >
                      </q-select>
                    </div>
                  </div>
                </td>
              </tr>
              <tr>
                <th><span class="">텍스트 한줄</span></th>
                <td colspan="3">
                  {{ inpBoardText }}
                </td>
              </tr>
              <tr>
                <th><span class="">텍스트 여러줄</span></th>
                <td colspan="3">
                  {{ inpBoardTextMulti }}
                </td>
              </tr>
              <tr>
                <th><span class="">콤보 코드</span></th>
                <td colspan="3">
                  <q-btn
                    fill
                    unelevated
                    color="grey-3"
                    class="size_sm mr10"
                    label="코드선택"
                  />
                  {{ inpBoardCode }}
                </td>
              </tr>
              <tr>
                <th><span class="">멀티콤보 코드</span></th>
                <td colspan="3">
                  <q-btn
                    fill
                    unelevated
                    color="grey-3"
                    class="size_sm mr10"
                    label="코드선택"
                  />
                  {{ inpBoardMultiCode }}
                </td>
              </tr>
              <tr>
                <th><span class="">내용</span></th>
                <td colspan="3">
                  {{ inpBoardContents }}
                </td>
              </tr>
              <tr>
                <th><span class="">키워드</span></th>
                <td colspan="3">
                  {{ inpBoardKeyword }}
                </td>
              </tr>
              <tr>
                <th><span class="">첨부파일</span></th>
                <td colspan="3">
                  <div class="row items-center my10">
                    <q-icon
                      name="icon-file-2"
                      class="icon_svg title2 filter-grey-3 mr10"
                    ></q-icon>
                    <span>작업20230404_v12.5.txt</span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>

          <!-- 버튼 -->
          <div class="btn_area response type_half">
            <q-btn unelevated outline class="size_md" label="수정" />
            <q-btn unelevated outline class="size_md" label="삭제" />
            <q-btn unelevated color="black" class="size_md" label="답변" />
            <q-btn
              unelevated
              color="grey-2"
              class="size_md btn_position_end"
              label="목록"
            />
          </div>
          <!-- // 버튼 -->
        </div>

        <!-- 댓글영역 -->
        <div class="reply_list mt60">
          <!-- 댓글 정보 -->
          <div class="reply_list_header small">
            <p class="reply_total">신고 <strong>0</strong></p>
            <p class="reply_total">댓글 <strong>5</strong></p>
            <p class="reply_total">좋아요 <strong>1</strong></p>
            <p class="reply_total">싫어요 <strong>1</strong></p>
            <p class="reply_total">추천 <strong>0</strong></p>
          </div>

          <!-- 댓글 리스트 -->
          <div class="reply_list_body">
            <!-- 댓글 -->
            <div class="reply_item">
              <div class="reply_item_d01">
                <!-- 하위 댓글에서 재사용 -->
                <div class="reply_item_cont">
                  <div class="cont_header">
                    <span class="username">관리자 1</span>
                    <span class="date">2023.02.05 15:01:34</span>
                  </div>
                  <div class="cont_body">
                    <q-input
                      v-if="stateReply"
                      v-model="temp00"
                      class=""
                      outlined
                      dense
                    >
                    </q-input>
                    <p v-else>
                      {{ temp00 }}
                    </p>
                  </div>
                </div>
                <!-- //하위 댓글에서 재사용 -->

                <div class="reply_item_bottom">
                  <q-btn
                    outline
                    v-if="stateReply"
                    class="size_sm btn_detail_view"
                    label="등록"
                    @click="stateReply = !stateReply"
                  />
                  <q-btn
                    v-else
                    outline
                    class="size_sm btn_detail_view"
                    label="수정"
                    @click="stateReply = !stateReply"
                  />
                  <q-btn outline class="size_sm btn_detail_view" label="삭제" />
                </div>
              </div>

              <!-- 하위 댓글 등록 -->
              <div class="reply_item_d01 bg-grey-8">
                <!-- 댓글입력폼 - 공통사용 -->
                <div class="reply_write">
                  <div class="reply_write_form">
                    <q-input
                      borderless
                      v-model="replyInput"
                      placeholder="제목을 입력해주세요."
                      type="textarea"
                      class="reply_field"
                      height="25"
                    />
                  </div>
                  <div class="reply_write_bottom">
                    <span class="char"><strong>0</strong> / 1000</span>
                    <span class="btn_area">
                      <q-btn outline class="size_xs" label="취소" />
                      <q-btn outline class="size_xs" label="등록" />
                    </span>
                  </div>
                </div>
                <!-- //댓글입력폼 - 공통사용 -->
              </div>
              <!-- //하위 댓글 등록 -->
            </div>
            <!-- //댓글 -->
          </div>
          <!-- //댓글 리스트 -->
        </div>
        <!-- //댓글 리스트 그룹 -->

        <!-- general_table -->
        <div class="general_table mt60">
          <!-- <p class="body2 text-grey-1 mb24">10개의 관련글이 있습니다.</p> -->

          <div class="board_list table_dk_div" v-if="$q.screen.name == 'lg'">
            <div class="table_top">
              <div class="info_wrap col-12 col-md-4">
                총 <span>00</span>건의 관련글이 있습니다
              </div>
            </div>
            <div class="board_header">
              <p class="board_col board_col_tit">제목</p>
              <p class="board_col board_col_min">첨부</p>
              <p class="board_col board_col_min">조회</p>
              <p class="board_col board_col_author">등록자</p>
              <p class="board_col board_col_author">등록일</p>
            </div>
            <div class="board_body">
              <div
                class="board_row"
                v-for="(items, idx) in tableRows"
                :key="idx"
              >
                <div class="board_col board_col_tit text-left">
                  <div class="board_badge q-gutter-xs">
                    <q-icon
                      name="icon-reply-grey"
                      class="icon_svg"
                      v-if="items.reply"
                    ></q-icon>
                    <q-badge color="orange" class="small" v-if="items.notice"
                      >공지</q-badge
                    >
                    <q-badge color="negative" class="small" v-if="items.urgent"
                      >긴급</q-badge
                    >
                    <q-badge
                      color="brown-2"
                      class="small"
                      v-if="items.promotion"
                      >행사</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.event"
                      >이벤트</q-badge
                    >
                    <span class="ico_new" v-if="items.new">N</span>
                    <q-icon
                      name="icon-thumbup-grey"
                      class="icon_svg filter-black"
                      v-if="items.thumb"
                    ></q-icon>
                  </div>
                  <a href="" class="board_col_tit_link">
                    {{ items.name }}
                  </a>
                </div>
                <div class="board_col board_col_min">
                  <q-icon
                    v-if="items.file"
                    name="icon-file-2"
                    class="icon_svg title2"
                  ></q-icon>
                </div>
                <div class="board_col board_col_min">
                  {{ items.hit }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.author }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.date }}
                </div>
              </div>
            </div>
          </div>

          <div
            class="board_list"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
          >
            <div class="board_header">
              <p class="board_col board_col_tit">제목</p>
              <p class="board_col board_col_min">첨부</p>
              <p class="board_col board_col_min">조회</p>
              <p class="board_col board_col_author">등록자</p>
              <p class="board_col board_col_author">등록일</p>
            </div>
            <div class="board_body">
              <div
                class="board_row"
                v-for="(items, idx) in tableRows"
                :key="idx"
                v-bind:class="{ reply: items.reply }"
              >
                <div class="board_col board_col_tit text-left">
                  <div class="board_badge q-gutter-xs">
                    <q-icon
                      name="icon-reply-grey"
                      class="icon_svg icon_reply"
                      v-if="items.reply"
                    ></q-icon>
                    <q-badge color="orange" class="small" v-if="items.notice"
                      >공지</q-badge
                    >
                    <q-badge color="negative" class="small" v-if="items.urgent"
                      >긴급</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.news"
                      >알림</q-badge
                    >
                    <q-badge
                      color="brown-2"
                      class="small"
                      v-if="items.promotion"
                      >행사</q-badge
                    >
                    <q-badge color="brown-2" class="small" v-if="items.event"
                      >이벤트</q-badge
                    >
                    <span class="ico_new" v-if="items.new">N</span>
                    <q-icon
                      name="icon-thumbup-grey"
                      class="icon_svg filter-black mt0"
                      v-if="items.thumb"
                    ></q-icon>
                  </div>
                  <div class="q-gutter-x-xs al_center">
                    <a href="" class="board_col_tit ml8">
                      {{ items.name }}
                    </a>
                    <q-icon
                      v-if="items.file"
                      name="icon-file-2"
                      class="icon_svg title2"
                    ></q-icon>
                  </div>
                </div>
                <div class="board_col board_col_author">
                  {{ items.date }}
                </div>
                <div class="board_col board_col_author">
                  {{ items.author }}
                </div>
                <div class="board_col board_col_min">
                  {{ items.hit }}
                </div>
              </div>
            </div>
          </div>

          <!-- pagination -->
          <div class="pagination_container">
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
              input
              class="justify-center"
            />
            <q-pagination
              v-model="dataPagination.current"
              v-if="$q.screen.name == 'lg'"
              :max="10"
              :max-pages="8"
              direction-links
              boundary-links
              rounded
              icon-first="keyboard_double_arrow_left"
              icon-last="keyboard_double_arrow_right"
              class="justify-center type_01"
            />
          </div>
          <!-- // pagination -->
        </div>
        <!--// general_table -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const inpBoardTitle = ref('연차를 안냈는데...'); //제목
const inpBoardCategory = ref('MOS_테스트1'); //게시 카테고리
const inpBoardTarget = ref('눈높이 > 본부A'); //게시 대상
const inpBoardText = ref('MOS_테스트1'); //텍스트 한줄
const inpBoardTextMulti = ref('MOS_테스트1 MOS_테스트1 MOS_테스트1'); //텍스트 여러줄
const inpBoardCode = ref('프리랜서'); //콤보 코드
const inpBoardMultiCode = ref('노드 1-2-1'); //멀티콤보 코드
const inpBoardContents = ref('안녕하세요. 연차문의 드립니다.'); //내용
const inpBoardKeyword = ref('연차, 문의'); //키워드

// 제목타입
const selectType = ref('type1');
const selectTypeOpt = ref([
  {
    id: 'type1',
    desc: '안내문의',
  },
  {
    id: 'type2',
    desc: '안내문의2',
  },
]);

// 옵션그룹
const inpBoardCheckGroup = ref(['op1']);
const inpBoardCheckGroupOption = ref([
  {
    label: '긴급',
    value: 'op1',
  },
  {
    label: '공지',
    value: 'op2',
  },
]);

// 게시예약일 시간선택
const revHour = ref('h00');
const revHourOpt = ref([
  {
    id: 'h00',
    desc: 'AM 00',
  },
  {
    id: 'h01',
    desc: 'AM 01',
  },
]);

// 게시예약일 분선택
const revMinute = ref('m00');
const revMinuteOpt = ref([
  {
    id: 'm00',
    desc: '00',
  },
  {
    id: 'm01',
    desc: '01',
  },
]);

const replyInput = ref(''); //댓글 입력
const temp00 = ref('연차를 안냈는데..');
const stateReply = ref(true);
// pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
//table데이터
const tableRows = ref([
  {
    name: '게시대상 확인 테스트',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: true,
    urgent: true,
    news: true,
    new: true,
    promotion: false,
    event: false,
    file: true,
    thumb: false,
    reply: false,
  },
  {
    name: '게시대상 확인 테스트 게시대상 확인',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: false,
    urgent: false,
    news: true,
    new: true,
    promotion: false,
    event: false,
    file: true,
    thumb: false,
    reply: false,
  },
  {
    name: '게시대상 확인 테스트',
    author: '홍길동',
    date: '2023.06.29',
    hit: '9999',
    notice: false,
    urgent: false,
    news: false,
    new: false,
    promotion: false,
    event: false,
    file: true,
    thumb: true,
    reply: true,
  },
]);
</script>
