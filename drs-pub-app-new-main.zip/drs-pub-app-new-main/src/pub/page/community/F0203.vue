<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">소통게시판</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <table class="table_row_sales table_community_details">
          <colgroup>
            <col />
            <col />
            <col />
            <col />
          </colgroup>
          <tbody>
            <tr>
              <th>유형</th>
              <td>긴급</td>
              <th class="line_l">조회수</th>
              <td>9999</td>
            </tr>
            <tr>
              <th>제목</th>
              <td colspan="3">드림스 사용 주의사항</td>
            </tr>
            <tr>
              <th>내용</th>
              <td colspan="3">
                <div class="td_innerBody">
                  신학기를 맞이하여 차이홍에서 프로모션을 진행합니다.<br />
                  아래 공지를 확인하세요
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 버튼영역 -->
        <div class="btn_area response">
          <q-btn outline class="size_md btn_thumbUp" icon="" label="추천해요" />
          <q-btn
            outline
            class="size_md btn_thumbDown"
            icon=""
            label="아쉬워요"
          />
          <q-btn
            unelevated
            color="grey-2"
            class="size_md btn_position_end"
            label="목록"
          />
        </div>

        <div class="spacing_reply_write">
          <!-- 댓글입력폼 - 공통사용 -->
          <div class="reply_write">
            <div class="reply_write_form">
              <p class="username">홍*동</p>
              <q-input
                borderless
                v-model="replyInput"
                placeholder="댓글을 남겨보세요"
                type="textarea"
                class="reply_field"
                height="25"
              />
            </div>
            <div class="reply_write_bottom">
              <span class="char"><strong>5000</strong> / 5000</span>
              <span class="btn_area">
                <q-btn outline class="size_xs" label="취소" />
                <q-btn outline class="size_xs" label="등록" />
              </span>
            </div>
          </div>
          <!-- //댓글입력폼 - 공통사용 -->
        </div>

        <!-- 댓글 리스트 그룹 -->
        <div class="reply_list mt60">
          <!-- 댓글 정보 -->
          <div class="reply_list_header">
            <p class="reply_total">
              <q-icon name="icon-message" class="icon_svg"></q-icon>
              댓글 <strong>5</strong>
            </p>
            <div>
              <button type="button">등록순</button>
              <button type="button">최신순</button>
            </div>
          </div>

          <!-- 댓글 리스트 -->
          <div class="reply_list_body">
            <!-- 댓글 -->
            <div class="reply_item">
              <div class="reply_item_d01">
                <!-- 하위 댓글에서 재사용 -->
                <div class="reply_item_cont">
                  <div class="cont_header">
                    <span class="username">홍*동</span>
                    <span class="date">2023.02.05</span>
                  </div>
                  <div class="cont_body">
                    오늘 알려주신 내용 정말 감사합니다.<br />
                    앞으로 시스템 사용시 많은 참고가 될 것 같습니다.
                  </div>
                </div>
                <!-- //하위 댓글에서 재사용 -->

                <div class="reply_item_bottom">
                  <q-btn outline class="size_sm btn_reply" label="답글쓰기" />
                  <q-btn outline class="size_sm btn_detail_view" label="수정" />
                  <q-btn outline class="size_sm btn_detail_view" label="삭제" />
                </div>
              </div>

              <!-- 하위 댓글 -->
              <div class="reply_item_d02">
                <div class="reply_item_cont">
                  <div class="cont_header">
                    <span class="username">홍*동</span>
                    <span class="date">2023.02.05</span>
                  </div>
                  <div class="cont_body">
                    오늘 알려주신 내용 정말 감사합니다.<br />
                    앞으로 시스템 사용시 많은 참고가 될 것 같습니다.
                  </div>
                </div>
              </div>
              <!-- //하위 댓글 -->

              <!-- 하위 댓글 등록 -->
              <div class="reply_item_d02">
                <!-- 댓글입력폼 - 공통사용 -->
                <div class="reply_write">
                  <div class="reply_write_form">
                    <p class="username">홍*동</p>
                    <q-input
                      borderless
                      v-model="replyInput01"
                      placeholder="댓글을 남겨보세요"
                      type="textarea"
                      class="reply_field"
                      height="25"
                    />
                  </div>
                  <div class="reply_write_bottom">
                    <span class="char"><strong>0</strong> / 5000</span>
                    <span class="btn_area">
                      <q-btn outline class="size_xs" label="취소" />
                      <q-btn outline class="size_xs" label="등록" />
                    </span>
                  </div>
                </div>
                <!-- //댓글입력폼 - 공통사용 -->
              </div>
              <!-- //하위 댓글 등록 -->
            </div>
            <!-- //댓글 -->
            <!-- 댓글 -->
            <div class="reply_item">
              <div class="reply_item_d01">
                <!-- 하위 댓글에서 재사용 -->
                <div class="reply_item_cont">
                  <div class="cont_header">
                    <span class="username">홍*동</span>
                    <span class="date">2023.02.05</span>
                  </div>
                  <div class="cont_body">
                    오늘 알려주신 내용 정말 감사합니다.<br />
                    앞으로 시스템 사용시 많은 참고가 될 것 같습니다.
                  </div>
                </div>
                <!-- //하위 댓글에서 재사용 -->

                <div class="reply_item_bottom">
                  <q-btn outline class="size_sm btn_reply" label="답글쓰기" />
                </div>
              </div>
            </div>
            <!-- //댓글 -->
          </div>
          <!-- //댓글 리스트 -->
        </div>
        <!-- //댓글 리스트 그룹 -->

        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- //pagination -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const replyInput = ref(''); //댓글 입력
const replyInput01 = ref(''); //하위 댓글 입력

//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>

<style lang="scss" scope>
body {
  &.screen--sm {
    // 버튼 정렬 조정
    .btn_area.response {
      flex-wrap: wrap;
      .q-btn {
        width: calc((100% - 10px) / 2);
        margin-right: 0;
      }
      .btn_position_end {
        width: 112px;
        margin: {
          top: 10px;
          left: auto;
        }
      }
    }
    // 댓글입력폼 간격
    .spacing_reply_write {
      margin-top: 76px;
    }
  }
  &.screen--lg {
    // 댓글입력폼 간격
    .spacing_reply_write {
      margin-top: 100px;
    }
  }
}
</style>
