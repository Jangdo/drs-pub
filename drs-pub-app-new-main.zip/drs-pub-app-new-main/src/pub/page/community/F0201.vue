<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">소통게시판</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="wrap_table_box">
        <div class="row align_center">
          <span class="title1 mr10">본부</span>
          <span class="body2 text-primary">35개</span>
          <span class="body2 text-grey-3">등록된 게시판이 있습니다</span>
        </div>
        <!-- 게시판 리스트 -->
        <div class="board_list table_dk_div mt20">
          <div class="board_header">
            <p class="board_col board_col_tit">제목</p>
          </div>
          <div class="board_body">
            <div class="board_row" v-for="(items, idx) in tableRows" :key="idx">
              <div class="board_col board_col_tit">
                <a href="" class="board_col_tit_link eli">
                  {{ items.name }}
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
      </div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.board_list .board_body .board_col.board_col_tit {
  margin-bottom: 0;
}
</style>
<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const tableRows = ref([
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지) 대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
  {
    name: '대교_공공지원금_게시판(수정금지)',
  },
]);
//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>
