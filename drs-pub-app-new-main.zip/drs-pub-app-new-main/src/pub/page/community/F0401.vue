<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">FAQ</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="검색 전체"
                v-model="searchType"
                :options="searchTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input class="" outlined placeholder="자주 찾는 질문">
              </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- 게시판 리스트 -->
        <div class="board_list table_dk_div">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              총 <span>00</span>건의 검색결과가 있습니다
            </div>
          </div>
          <div class="board_header">
            <p class="board_col board_col_tit">제목</p>
            <p class="board_col">유형</p>
          </div>
          <div class="board_body">
            <div class="board_row" v-for="(items, idx) in tableRows" :key="idx">
              <div class="board_col board_col_tit">
                <a href="" class="board_col_tit_link eli">
                  {{ items.name }}
                </a>
              </div>
              <div class="board_col">
                {{ items.type }}
              </div>
            </div>
          </div>
        </div>

        <!-- pagination -->
        <div class="pagination_container mb0">
          <q-pagination
            @update:model-value="scrolTop"
            v-model="table_pagination.page"
            direction-links
            boundary-links
            :max-pages="10"
            :max="pagesNumber"
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
        </div>
        <!-- //pagination -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchType = ref(['검색 전체']);
const searchTypeOption = ref([
  {
    id: 'type1',
    desc: '선택1',
  },
  {
    id: 'type2',
    desc: '선택2',
  },
]);

//table데이터
const tableRows = ref([
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항 드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
  {
    name: '드림스 사용 주의사항',
    type: '시스템 사용',
  },
]);
const pagesNumber = computed(() =>
  Math.ceil(tableRows.value.length / table_pagination.value.rowsPerPage)
);

//pagination
const table_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
});

function scrolTop() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  });
}
</script>
