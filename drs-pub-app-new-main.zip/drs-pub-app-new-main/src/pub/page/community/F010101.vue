<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">공지/행사/이벤트</h2>
      <Breadcrumbs />
    </div>

    <div class="page_community">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-4">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!--// searchDate start.from -->
                <div class="tilde">
                  <span>~</span>
                </div>
                <!-- searchDate start.to -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyto"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          v-model="searchDate.to"
                          mask="YYYY.MM.DD"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyto.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="유형 전체"
                v-model="searcheventType"
                :options="searcheventTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="브랜드 전체"
                v-model="searchbrandType"
                :options="searchbrandTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="화면검색 전체"
                v-model="searchpageType"
                :options="searchpageTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
          </div>
          <div class="row q-col-gutter-sm" v-if="stateHandle">
            <div class="col-12 col-md-3">
              <q-input class="" outlined placeholder="제목"> </q-input>
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>
      <q-btn
        class="btn_search_handle"
        fill
        color="grey-5"
        unelevated
        @click="actionHandle"
      >
        <q-icon color="white" name="ion-ios-arrow-up" v-if="stateHandle" />
        <q-icon color="white" name="ion-ios-arrow-down" v-else />
      </q-btn>
      <!-- <q-space class="sp30" /> -->
      <div class="wrap_table_box">
        <!-- 게시판 리스트 -->
        <div class="board_list table_dk_div">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              총 <span>00</span>건의 검색결과가 있습니다
            </div>
          </div>
          <div class="board_header">
            <p class="board_col board_col_tit">제목</p>
            <p class="board_col">날짜</p>
            <p class="board_col">등록자</p>
            <p class="board_col">조회</p>
          </div>
          <div class="board_body">
            <div class="board_row" v-for="(items, idx) in tableRows" :key="idx">
              <div class="board_col board_col_tit">
                <div class="board_badge q-gutter-xs">
                  <q-badge color="orange" class="small" v-if="items.notice"
                    >공지</q-badge
                  >
                  <q-badge color="negative" class="small" v-if="items.urgent"
                    >긴급</q-badge
                  >
                  <q-badge color="brown-2" class="small" v-if="items.news"
                    >알림</q-badge
                  >
                  <q-badge color="brown-2" class="small" v-if="items.promotion"
                    >행사</q-badge
                  >
                  <q-badge color="brown-2" class="small" v-if="items.event"
                    >이벤트</q-badge
                  >
                </div>
                <a href="" class="board_col_tit_link eli">
                  {{ items.name }}
                </a>
              </div>
              <div class="board_col">
                {{ items.date }}
              </div>
              <div class="board_col">
                {{ items.author }}
              </div>
              <div class="board_col">
                {{ items.hit }}
              </div>
            </div>
          </div>
        </div>

        <!-- pagination -->
        <div class="pagination_container mb0">
          <q-pagination
            @update:model-value="scrolTop"
            v-model="table_pagination.page"
            direction-links
            boundary-links
            :max-pages="10"
            :max="pagesNumber"
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            icon-prev="keyboard_arrow_left"
            icon-next="keyboard_arrow_right"
            class="custom_pagination type_01"
          />
        </div>
        <!-- //pagination -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searcheventType = ref(['']);
const searcheventTypeOption = ref([
  {
    id: 'type1',
    desc: '유형1',
  },
  {
    id: 'type2',
    desc: '유형2',
  },
]);
const searchpageType = ref(['']);
const searchpageTypeOption = ref([
  {
    id: 'type1',
    desc: '화면1',
  },
  {
    id: 'type2',
    desc: '화면2',
  },
]);
const searchDate = ref({
  from: '2019.02.01',
  to: '2019.02.02',
});
const searchbrandType = ref(['']);
const searchbrandTypeOption = ref([
  {
    id: 'type1',
    desc: '브랜드1',
  },
  {
    id: 'type2',
    desc: '브랜드2',
  },
]);

//table데이터
const tableRows = ref([
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: true,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항 드림스 사용 주의사항드림스 사용 주의사항 드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: false,
    urgent: false,
    news: true,
    promotion: true,
    event: true,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: false,
    news: false,
    promotion: false,
    event: false,
  },
  {
    name: '드림스 사용 주의사항',
    author: '홍길동',
    date: '2022.11.01',
    hit: '9999',
    notice: true,
    urgent: true,
    news: false,
    promotion: false,
    event: false,
  },
]);
const pagesNumber = computed(() =>
  Math.ceil(tableRows.value.length / table_pagination.value.rowsPerPage)
);

//pagination
const table_pagination = ref({
  sortBy: 'code',
  descending: false,
  page: 1,
  rowsPerPage: 10,
});

function scrolTop() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth',
  });
}
const stateHandle = ref(false);
function actionHandle() {
  stateHandle.value = !stateHandle.value;
}
</script>

<style lang="scss" scoped></style>
