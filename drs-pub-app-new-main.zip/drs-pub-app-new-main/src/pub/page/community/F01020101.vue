<template>
  <div class="fregment">
    <div class="cnt_top">
      <h2 class="title">프로모션 조회</h2>
      <Breadcrumbs />
    </div>
    <div class="page_community">
      <div class="search_wrap">
        <div class="search_cnt">
          <div class="row q-col-gutter-sm">
            <div class="col-12 col-md-3">
              <div class="row-4">
                <q-input
                  outlined
                  v-model="searchDate.from"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyFrom"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          mask="YYYY.MM.DD"
                          v-model="searchDate.from"
                          @update:model-value="
                            searchDate.from, $refs.qDateProxyFrom.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
                <!--// searchDate start.from -->
                <div class="tilde">
                  <span>~</span>
                </div>
                <!-- searchDate start.to -->
                <q-input
                  outlined
                  v-model="searchDate.to"
                  class="inp_date normal"
                  readonly
                >
                  <template v-slot:append>
                    <q-icon
                      name="icon-calendar"
                      class="icon_svg cursor-pointer"
                    >
                      <q-popup-proxy
                        ref="qDateProxyto"
                        cover
                        transition-show="scale"
                        transition-hide="scale"
                      >
                        <q-date
                          minimal
                          v-model="searchDate.to"
                          mask="YYYY.MM.DD"
                          @update:model-value="
                            searchDate.to, $refs.qDateProxyto.hide()
                          "
                        >
                        </q-date>
                      </q-popup-proxy>
                    </q-icon>
                  </template>
                </q-input>
              </div>
            </div>
            <div class="col-12 col-md-3">
              <q-select
                class="box_l hide_label"
                label="시스템 전체"
                v-model="searchType"
                :options="searchTypeOption"
                option-value="id"
                option-label="desc"
                option-disable="inactive"
                emit-value
                map-options
                dense
                outlined
                dropdown-icon="ion-ios-arrow-down"
              >
              </q-select>
            </div>
            <div class="col-12 col-md-3">
              <q-input class="box_l" outlined placeholder="프로모션명">
              </q-input>
            </div>
            <div class="col-12 col-md-3">
              <q-checkbox
                v-model="dataCheck.live"
                label="LIVE"
                color="black"
                class="check_in_multiple"
              />
              <q-checkbox
                v-model="dataCheck.off"
                label="OFF"
                color="black"
                class="check_in_multiple"
              />
            </div>
          </div>
        </div>
        <div class="btn_area">
          <q-btn outline class="size_sm btn_reset" icon="" label="">
            <span class="a11y">초기화</span>
          </q-btn>
          <q-btn class="size_sm btn_search" fill unelevated label="조회" />
        </div>
      </div>

      <div class="wrap_table_box">
        <!-- 게시판 리스트 -->
        <div class="board_list table_dk_div">
          <div class="table_top">
            <div class="info_wrap col-12 col-md-4">
              총 <span>00</span>건의 검색결과가 있습니다
            </div>
          </div>
          <div class="board_header">
            <p class="board_col board_col_tit">제목</p>
            <p class="board_col col_270">날짜</p>
            <p class="board_col">시스템</p>
          </div>
          <div class="board_body">
            <div class="board_row" v-for="(items, idx) in tableRows" :key="idx">
              <div class="board_col board_col_tit">
                <div class="board_badge q-gutter-xs">
                  <q-badge
                    color="negative"
                    class="square_sm"
                    outline
                    v-if="items.live"
                    >LIVE</q-badge
                  >
                  <q-badge
                    color="orange"
                    class="square_sm"
                    outline
                    v-if="items.on"
                    >진행중</q-badge
                  >
                  <q-badge
                    color="grey-3"
                    class="square_sm"
                    outline
                    v-if="items.off"
                    >OFF</q-badge
                  >
                  <q-badge
                    color="black"
                    class="square_sm"
                    outline
                    v-if="items.close"
                    >종료</q-badge
                  >
                </div>
                <a href="" class="board_col_tit_link eli">
                  {{ items.name }}
                </a>
              </div>
              <div class="board_col col_270">
                {{ items.startdate }} ~ {{ items.enddate }}
              </div>
              <div class="board_col">
                {{ items.system }}
              </div>
            </div>
          </div>
        </div>

        <!-- pagination -->
        <div class="pagination_container">
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'sm' || $q.screen.name == 'md'"
            input
            class="justify-center"
          />
          <q-pagination
            v-model="dataPagination.current"
            v-if="$q.screen.name == 'lg'"
            :max="10"
            :max-pages="8"
            direction-links
            boundary-links
            rounded
            icon-first="keyboard_double_arrow_left"
            icon-last="keyboard_double_arrow_right"
            class="justify-center type_01"
          />
        </div>
        <!-- //pagination -->
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import Breadcrumbs from 'src/pub/component/common/breadcrumbs.vue';

const searchType = ref(['시스템 전체']);
const searchTypeOption = ref([
  {
    id: 'type1',
    desc: '시스템1',
  },
  {
    id: 'type2',
    desc: '시스템2',
  },
]);
const dataCheck = ref({
  live: true,
  off: false,
});
const searchDate = ref({
  from: '2022.02.12',
  to: '2022.02.12',
});

//table데이터
const tableRows = ref([
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: true,
    on: true,
    off: false,
    close: false,
  },
  {
    name: '드림스 사용 주의사항 드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
  {
    name: '드림스 사용 주의사항',
    system: '드림스',
    startdate: '2022.11.01',
    enddate: '2022.11.01',
    live: false,
    on: false,
    off: true,
    close: true,
  },
]);

//pagination
const dataPagination = ref({
  current: 1,
  sortBy: 'idx',
  descending: true,
  page: 1,
  rowsPerPage: 17,
});
</script>

<style lang="scss" scoped>
// 모바일에서 기간 선택 정렬 수정
body {
  &.screen--sm {
    .table_search_area.type_flexable .search_item.wrap_date .inner_wrap {
      display: block;
    }
    .table_search_area.type_flexable .tilde {
      height: 14px;
      font-size: 0;
    }
  }
}
</style>
