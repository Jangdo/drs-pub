<template>
  <div class="fullscreen bg-blue text-white text-center q-pa-md flex flex-center">
    <div>
      <div style="font-size: 10vh">
        404
      </div>

      <div class="text-h2 mb-15">
        잘못된 접근입니다.
      </div>
      <p>
        찾으려는 페이지의 주소가 잘못되었거나, 해당 페이지에 접근할 수 있는 권한이 없습니다.
      </p>

      <q-btn
        class="q-mt-xl"
        color="white"
        text-color="blue"
        unelevated
        to="/"
        label="홈으로"
        no-caps
      />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'ErrorNotFound'
});
</script>
<style scoped>
.mb-15{
  margin-bottom: 15px;
}
</style>