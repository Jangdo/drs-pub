## 진행 내용 확인

https://drs-pub-app.herokuapp.com/pub
<br><br>

## css 파일 위치
<br> drs-pub-app\src\css
<br> drs-pub-app\src\assets\sass
<br><br>

```bash
각메뉴에 맞춰 css 분리 scoped 사용
ex) C01040102.vue 하단에 삽입
    <style lang="scss" scoped>
      @import '../../../css/list_c.scss';
    </style>
```
## router

1.  router 파일 / pub.router.ts
2.  Ia List 네이게이션 파일 / IaListHeader.vue
    <br>
    <br>

## 관련파일

최신파일<br>
  \\172.17.17.99\차세대드림스\20. 프로젝트*개발\02.설계\07. 화면설계서<br>
  \\172.17.17.99\차세대드림스\20. 프로젝트*개발\03.구현 (wbs)<br>
  \\172.17.17.99\차세대드림스\70. 프로젝트\_업무\frontend
<br><br>

## masonry(핀터레스트) 관련

<br>
-@yeger/vue-masonry-wall
<br>
https://github.com/DerYeger/yeger/blob/main/packages/vue-masonry-wall/README.md
<br><br>
License
<br>
MIT - Copyright © Fuxing Loh, Jan Müller
<br>
<br>

## 스케쥴러 관련
<br>fullcalendar https://github.com/fullcalendar/fullcalendar-vue/blob/main/LICENSE.txt
  <br><br>

## 어드민(공통)

공통어드민 PL
  <br> 육성근 부장 피노텍 zipuragi@finotek.co.kr

화면설계
  <br> 서거성 수석 DX META 기획자 geoseong@dxmeta.co.kr

디자인
  <br> 윤민정 수석 DX Meta기획자 lucy@dxmeta.co.kr
<br><br>

## 이미지 서버

### 사용법

- images 폴더에 s3에 올릴 이미지파일을 저장<br>
- 퍼지(캐시삭제) 깃 커밋시 퍼지됨<br>

- https://drs-imaged.daekyo.co.kr/images/admin/logo-admin.png?w=50&h=150&f=webp&q=10&o=cover&p=left|top
  <br><br>

- 파라미터 값
  <br> o : cover(디폴트), contain, fill, inside, outside
  <br> p : center(디폴트), top, right|top, right, right|bottom, bottom, left|bottom, left, left|top
  <br>drs-imaged.daekyo.co.kr 도메인이 현재 대교 내부망에서 안열립니다.
  <br>추후 등록예정입니다.
  <br>hosts 파일에 아래 등록 후 사용 해 주세요.
  <br>18.64.8.111 drs-imaged.daekyo.co.kr

### 확인 url:

- https://d2wwpgb2oxedpp.cloudfront.net/images/이미지파일?w=500&h=300&f=webp&q=50 (resize)
- https://d2wwpgb2oxedpp.cloudfront.net/images/이미지파일 (original)
  <br>
  <br>
### 문의:
신창호 수석님 / 아시아나IDT
<br>
최광민 책임님 / 아시아나 IDT
<br>
<br>

## 환경설정

### 파워쉘 관리자 권한 설정

관리자 권한으로 파워쉘 실행후 프롬프트에 아래와 같이 적어준다.<br>
Set-ExecutionPolicy Unrestricted

### node 설치
```bash
https://nodejs.org/en/
```

### git 설치
```bash
http://git-scm.com/download/win
```

### 퀘이사 설치

퀘이사 url https://quasar.dev/

```bash
npm i -g @quasar/cli
```
### 샘플 깃

git clone http://gitlab.daekyo.co.kr/drs/heroku/drs-pub-app.git

cd drs-pub-app

### Install the dependencies

```bash
yarn
# or
npm install
```

### Start the app in development mode (hot-code reloading, error reporting, etc.)

```bash
quasar dev
```

### Lint the files

```bash
yarn lint
# or
npm run lint
```

### Format the files

```bash
yarn format
# or
npm run format
```

### Build the app for production

```bash
quasar build
```

## Customize the configuration

See [Configuring quasar.config.js](https://v2.quasar.dev/quasar-cli-webpack/quasar-config-js).
<br>
<br>
## 최종 브랜치
 -  main
<br>
